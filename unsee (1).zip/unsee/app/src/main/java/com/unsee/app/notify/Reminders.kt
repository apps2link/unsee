package com.unsee.app.notify

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.unsee.app.MainActivity
import com.unsee.app.R
import com.unsee.app.core.Reminder
import com.unsee.app.core.ReminderKind
import com.unsee.app.core.TimeLogic
import com.unsee.app.data.Category
import com.unsee.app.data.Store
import com.unsee.app.widget.WidgetRenderer
import java.time.LocalDate
import java.time.ZonedDateTime
import java.util.concurrent.TimeUnit

/**
 * تذكيرات هادئة عبر WorkManager (دون إذن «المنبّه الدقيق»). لكل تذكير اسم عمل فريد، وبعد كل إشعار
 * نجدول الموعد التالي ضمن الأيام المختارة. قد يتأخر التنفيذ دقائق بسبب توفير الطاقة، وهذا مقصود.
 * القناة صامتة بلا اهتزاز ويمكن للمستخدم تعديلها من إعدادات النظام.
 */
object Reminders {
    const val CHANNEL_ID = "adhkar_reminders"

    fun createChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val ch = NotificationChannel(CHANNEL_ID, "تذكيرات الأذكار", NotificationManager.IMPORTANCE_LOW).apply {
            description = "تذكير هادئ بأذكار الصباح والمساء وتذكيراتك المخصصة"
            setSound(null, null)
            enableVibration(false)
            setShowBadge(false)
        }
        ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun workName(id: String, slot: Int) = "unsee_rem_${id}_$slot"

    fun schedule(ctx: Context, r: Reminder, slot: Int = 0) {
        val delay = TimeLogic.delayUntilNextOnDays(ZonedDateTime.now(), r.minute, r.days) ?: return
        val req = OneTimeWorkRequestBuilder<ReminderWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setInputData(workDataOf("id" to r.id, "slot" to slot))
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork(workName(r.id, slot), ExistingWorkPolicy.REPLACE, req)
    }

    fun cancel(ctx: Context, id: String) {
        val wm = WorkManager.getInstance(ctx)
        wm.cancelUniqueWork(workName(id, 0))
        wm.cancelUniqueWork(workName(id, 1))
    }

    /** يُستدعى عند فتح التطبيق، وعند الإقلاع، وعند تغيّر الوقت/المنطقة الزمنية، وبعد تحديث التطبيق. */
    fun rescheduleAll(ctx: Context) {
        for (r in Store.get(ctx).reminders()) {
            cancel(ctx, r.id)
            if (r.enabled) schedule(ctx, r)
        }
    }

    fun canNotify(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return false
        return NotificationManagerCompat.from(ctx).areNotificationsEnabled()
    }

    private fun categoryOf(r: Reminder): Category? = runCatching { Category.valueOf(r.category) }.getOrNull()

    fun show(ctx: Context, r: Reminder) {
        if (!canNotify(ctx)) return
        val cat = categoryOf(r)
        val route = if (cat != null) "list/${cat.name}" else "adhkar"
        val open = Intent(ctx, MainActivity::class.java)
            .putExtra("route", route)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(ctx, r.id.hashCode(), open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val (title, text) = when (r.kind) {
            ReminderKind.MORNING -> "أذكار الصباح" to "حان وقت أذكار الصباح — دقائق تهدّئ القلب"
            ReminderKind.EVENING -> "أذكار المساء" to "حان وقت أذكار المساء — ختامٌ هادئ ليومك"
            ReminderKind.CUSTOM -> r.label.ifBlank { "تذكير" } to (cat?.let { "افتح ${it.title}" } ?: "حان موعد تذكيرك")
        }
        val n = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setSubText("أُنسي — أذكارك أقرب، وقلبك أهدأ")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .build()
        runCatching { NotificationManagerCompat.from(ctx).notify(r.id.hashCode(), n) }
    }
}

class ReminderWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val id = inputData.getString("id") ?: return Result.success()
        val slot = inputData.getInt("slot", 0)
        val r = Store.get(applicationContext).reminders().firstOrNull { it.id == id } ?: return Result.success()
        if (!r.enabled) return Result.success()
        if (r.runsOn(LocalDate.now().dayOfWeek.value)) Reminders.show(applicationContext, r)
        // نجدول الموعد التالي تحت اسم بديل (0/1) كي لا نُلغي هذا العمل أثناء تنفيذه.
        Reminders.schedule(applicationContext, r, 1 - slot)
        return Result.success()
    }
}

class SystemEventsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED, Intent.ACTION_MY_PACKAGE_REPLACED -> {
                Reminders.createChannel(context)
                Reminders.rescheduleAll(context)
                WidgetRenderer.updateAll(context)
            }
        }
    }
}
