package com.unsee.app.ui

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.SharedPreferences
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.unsee.app.core.Arabic
import com.unsee.app.core.WidgetSource
import com.unsee.app.data.AdhkarData
import com.unsee.app.data.Settings
import com.unsee.app.data.Store
import com.unsee.app.widget.WidgetRenderer
import com.unsee.app.widget.WidgetStyle

fun requestPinWidget(ctx: Context, style: WidgetStyle) {
    val mgr = AppWidgetManager.getInstance(ctx)
    if (mgr.isRequestPinAppWidgetSupported) {
        val ok = mgr.requestPinAppWidget(ComponentName(ctx, WidgetRenderer.providerClass(style)), null, null)
        if (!ok) Toast.makeText(ctx, "تعذّر الطلب. أضِفها يدويًا: اضغط مطولًا على الشاشة الرئيسية ← الودجت ← أُنسي", Toast.LENGTH_LONG).show()
    } else {
        Toast.makeText(ctx, "الشاشة الرئيسية لا تدعم الإضافة المباشرة. اضغط مطولًا على الشاشة ← الودجت ← أُنسي", Toast.LENGTH_LONG).show()
    }
}

@Composable
fun WidgetHowToDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = UColors.CardSolid,
        title = { Text("كيف أضيف الودجت؟", color = UColors.Cream) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                val steps = listOf(
                    "من شاشة «الويدجت» في التطبيق اضغط «أضِف» بجانب الشكل الذي يعجبك ثم أكّد من نافذة النظام.",
                    "أو اضغط مطولًا على مساحة فارغة في الشاشة الرئيسية ← «الودجت» ← ابحث عن «أُنسي» ← اسحب الشكل إلى مكانه.",
                    "يمكنك تغيير الحجم بالضغط مطولًا على الودجت ثم سحب الحواف.",
                    "إن لم يظهر طلب الإضافة (شائع في Xiaomi): فعّل إذن «اختصارات الشاشة الرئيسية» من إعدادات التطبيق ▸ الأذونات.",
                    "تتحدّث الودجت كل نحو 30 دقيقة وعند كل تفاعل (تالي/سابق/تسبيح) وعند فتح التطبيق؛ هذا قيد من نظام Android لتوفير البطارية، وليست تحديثات لحظية.",
                )
                steps.forEachIndexed { i, t ->
                    Row(Modifier.padding(vertical = 5.dp)) {
                        Text("${Arabic.digits(i + 1)}.", color = UColors.Gold, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(8.dp))
                        Text(t, color = UColors.CreamDim, fontSize = 14.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("فهمت", color = UColors.Gold) } },
    )
}

private fun previewSize(style: WidgetStyle): Pair<Dp, Dp> = when (style) {
    WidgetStyle.MINI -> 150.dp to 46.dp
    WidgetStyle.TASBIH -> 100.dp to 100.dp
    WidgetStyle.LARGE -> 150.dp to 150.dp
    WidgetStyle.PERIOD -> 150.dp to 110.dp
    else -> 150.dp to 84.dp
}

/** معاينة توضيحية لشكل الودجت (ليست ودجت حقيقية — الودجت الحقيقية تُضاف من الشاشة الرئيسية للهاتف). */
@Composable
fun WidgetPreview(style: WidgetStyle, modifier: Modifier = Modifier) {
    val (w, h) = previewSize(style)
    val sample = remember { AdhkarData.byId("x_subhan")?.text ?: "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ" }
    val gold = Color(0xFFE2B857)
    val cream = Color(0xFFFFF4D6)
    val bg: Brush = when (style) {
        WidgetStyle.CINEMATIC -> Brush.verticalGradient(listOf(Color(0xFF050E24), Color(0xFF173A73)))
        WidgetStyle.TRANSPARENT -> Brush.verticalGradient(listOf(Color(0x33000000), Color(0x22000000)))
        WidgetStyle.GLASS -> Brush.verticalGradient(listOf(Color(0x55FFFFFF), Color(0x22FFFFFF)))
        WidgetStyle.MINI -> Brush.verticalGradient(listOf(Color(0xFF0A4D3C), Color(0xFF0F7B5F)))
        WidgetStyle.LARGE -> Brush.verticalGradient(listOf(Color(0xFF241848), Color(0xFF6F2E57)))
        WidgetStyle.TASBIH -> Brush.verticalGradient(listOf(Color(0x00000000), Color(0x00000000)))
        WidgetStyle.PERIOD -> Brush.verticalGradient(listOf(Color(0xFF1B2A6B), Color(0xFF8A4B66)))
        WidgetStyle.LUXE -> Brush.verticalGradient(listOf(Color(0xFF04251E), Color(0xFF0B5E49)))
        WidgetStyle.CUSTOM -> Brush.verticalGradient(listOf(Color(0xFF1B1033), Color(0xFF3B2470)))
    }
    val shape = RoundedCornerShape(if (style == WidgetStyle.TASBIH) 50.dp else 18.dp)
    Box(
        modifier.size(w, h).clip(shape).background(bg).border(1.dp, gold.copy(alpha = if (style == WidgetStyle.LUXE) 0.8f else 0.3f), shape),
        contentAlignment = Alignment.Center,
    ) {
        when (style) {
            WidgetStyle.TASBIH -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("١٢", color = cream, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Text("الهدف ٣٣", color = gold, fontSize = 10.sp)
            }
            WidgetStyle.MINI -> Text(sample, color = cream, fontSize = 12.sp, maxLines = 2, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 8.dp))
            else -> Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(8.dp)) {
                Text("أذكار الصباح", color = gold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text(sample, color = cream, fontSize = 13.sp, maxLines = 2, textAlign = TextAlign.Center, fontFamily = LocalAppFont.current)
                if (style == WidgetStyle.LARGE || style == WidgetStyle.PERIOD) {
                    Spacer(Modifier.height(4.dp))
                    Box(Modifier.clip(RoundedCornerShape(50)).background(Color(0x33FFFFFF)).padding(horizontal = 14.dp, vertical = 3.dp)) {
                        Text("سَبِّح", color = cream, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun WidgetsScreen(store: Store, s: Settings) {
    val ctx = LocalContext.current
    var howTo by remember { mutableStateOf(false) }
    fun save(block: SharedPreferences.Editor.() -> Unit) { store.edit(block); WidgetRenderer.updateAll(ctx) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader("الويدجت")
        GlassCard(Modifier.fillMaxWidth(), glow = true) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconBadge(Ico.Widgets)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("ودجت على شاشتك الرئيسية", color = UColors.Cream, fontWeight = FontWeight.Bold)
                    Text("${Arabic.digits(WidgetStyle.values().size)} أشكال حقيقية تعمل بعد إغلاق التطبيق وبعد إعادة التشغيل.", color = UColors.CreamDim, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(10.dp))
            PillButton("تعليمات الإضافة", { howTo = true }, icon = Ico.Help, filled = false)
        }

        WidgetStyle.values().forEach { st ->
            GlassCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    WidgetPreview(st)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(st.label, color = UColors.Cream, fontWeight = FontWeight.Bold)
                        Text(st.description, color = UColors.CreamDim, fontSize = 12.sp)
                        Spacer(Modifier.height(6.dp))
                        PillButton("أضِف", { requestPinWidget(ctx, st) }, icon = Ico.Add)
                    }
                }
            }
        }

        SectionLabel("إعدادات الودجت العامة")
        GlassCard(Modifier.fillMaxWidth()) {
            Text("مصدر الأذكار", color = UColors.CreamDim, fontSize = 12.sp)
            ChipRow(WidgetSource.values().toList(), { it == s.widgetSource }, { it.label }) { src -> save { putString("w_source", src.name) } }
            SwitchRow("تدوير تلقائي كل نصف ساعة", "للودجت السينمائية والشفافة والزجاجية والمصغرة والفاخرة", s.widgetAutoRotate) { save { putBoolean("w_auto_rotate", it) } }
            Text("لون النص (الشفافة والزجاجية)", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            Row(Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf(0xFFFFF4D6, 0xFFE2B857, 0xFFFFFFFF, 0xFFB8F0D2, 0xFFBFD8FF).forEach { c ->
                    ColorDot(Color(c), s.widgetTextColor == c.toInt()) { save { putInt("w_text_color", c.toInt()) } }
                }
            }
            LabeledSlider("درجة خلفية الودجت الشفافة: ${Arabic.digits(s.widgetBgAlpha)}٪", s.widgetBgAlpha.toFloat(), 0f..100f) { v -> save { putInt("w_bg_alpha", v.toInt()) } }
        }
        Text("ملاحظة: الودجت لا تدعم أنيميشن مستمرًّا ولا ضبابية حقيقية؛ المؤثرات الغنية داخل التطبيق نفسه. الودجت «المخصّصة» تفتح شاشة اختيار الألوان عند إضافتها.", color = UColors.CreamDim, fontSize = 12.sp)
    }
    if (howTo) WidgetHowToDialog { howTo = false }
}

@Composable
fun ColorDot(color: Color, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(34.dp).clip(CircleShape).background(color)
            .border(if (selected) 3.dp else 1.dp, if (selected) UColors.Gold else Color.Gray.copy(alpha = 0.6f), CircleShape)
            .clickable(onClick = onClick),
    )
}
