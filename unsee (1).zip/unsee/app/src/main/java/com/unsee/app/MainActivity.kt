package com.unsee.app

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.unsee.app.data.Store
import com.unsee.app.notify.Reminders
import com.unsee.app.ui.UnseeApp
import com.unsee.app.widget.WidgetRenderer

class MainActivity : ComponentActivity() {
    private var route by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        super.onCreate(savedInstanceState)
        route = intent?.getStringExtra("route")
        val store = Store.get(this)
        store.pruneOld()
        Reminders.createChannel(this)
        Reminders.rescheduleAll(this)
        setContent { UnseeApp(store = store, startRoute = route, onRouteConsumed = { route = null }) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        route = intent.getStringExtra("route")
    }

    override fun onStop() {
        super.onStop()
        // نُحدّث كل الودجت بما سجّله المستخدم داخل التطبيق.
        WidgetRenderer.updateAll(this)
    }
}
