package com.unsee.app.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.unsee.app.core.Arabic
import com.unsee.app.core.DateText
import com.unsee.app.core.TimeLogic
import com.unsee.app.data.AdhkarData
import com.unsee.app.data.Category
import com.unsee.app.data.Settings
import com.unsee.app.data.Store
import com.unsee.app.widget.WidgetStyle
import java.time.LocalDate
import java.time.LocalTime

@Composable
fun HomeScreen(store: Store, s: Settings, nav: NavController) {
    val ctx = LocalContext.current
    val progress by store.observeAsState { store.todayProgress() }
    val tas by store.observeAsState { store.tasbih() }
    val reminders by store.observeAsState { store.reminders() }
    val today = remember { LocalDate.now() }
    val hour = remember { LocalTime.now().hour }
    val suggested = TimeLogic.suggestedCategory(hour)
    var heroOffset by rememberSaveable { mutableIntStateOf(0) }
    var howTo by remember { mutableStateOf(false) }
    val pool = remember(suggested) {
        AdhkarData.forCategory(suggested).filter { it.isShort }.ifEmpty { AdhkarData.all.filter { it.isShort } }
    }
    val hero = pool[Math.floorMod(today.dayOfYear + heroOffset, pool.size)]

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        // ---------------------------------------------------- 1) الرأس
        item {
            Appear {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        val name = if (s.userName.isNotBlank()) "، ${s.userName}" else ""
                        Text("${TimeLogic.greeting(hour)}$name", color = UColors.Gold, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        val hijri = DateText.hijri(today)
                        Text(
                            (if (hijri != null) "$hijri  ·  " else "") + "${DateText.weekDay(today.dayOfWeek)} ${DateText.gregorian(today)}",
                            color = UColors.CreamDim, fontSize = 12.sp,
                        )
                        Text("أذكارك أقرب، وقلبك أهدأ", color = UColors.Cream, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
                    }
                    IconBtn(Ico.Bell, "التذكيرات", { nav.navigate("reminders") })
                    IconBtn(Ico.Settings, "الإعدادات", { nav.navigate("appsettings") })
                    IconBtn(Ico.Person, "ملفي الشخصي", { nav.navigate("appsettings") })
                }
            }
        }

        // ---------------------------------------------------- 2) البطاقة الرئيسية (ذكر اليوم)
        item {
            Appear(80) {
                val shape = RoundedCornerShape(UColors.radiusDp.dp + 4.dp)
                Column(
                    Modifier.fillMaxWidth().clip(shape)
                        .background(Brush.linearGradient(listOf(UColors.Gold.copy(alpha = 0.30f).compositeOver(UColors.CardSolid), UColors.CardSolid)))
                        .border(1.5.dp, UColors.Gold.copy(alpha = 0.7f), shape)
                        .padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconBadge(hero.category.icon(), 34.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("ذكر مقترح الآن  ·  ${hero.title}", color = UColors.Gold, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Spacer(Modifier.height(10.dp))
                    AnimatedContent(
                        targetState = hero,
                        transitionSpec = { fadeIn(tween(300)) togetherWith fadeOut(tween(180)) },
                        label = "hero",
                    ) { z ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            ZikrText(z.text, s, Modifier.fillMaxWidth(), scaleOverride = 0.9f)
                            Text("المصدر: ${z.source}", color = UColors.CreamDim, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp))
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PillButton("افتح", { nav.navigate("list/${hero.category.name}?start=${hero.id}") }, icon = Ico.Book)
                        PillButton("التالي", { heroOffset++ }, icon = Ico.Forward, filled = false)
                        IconBtn(Ico.Share, "مشاركة", { shareZikr(ctx, hero) })
                    }
                }
            }
        }

        // ---------------------------------------------------- 3) أذكار اليوم
        item { SectionLabel("أذكار اليوم") }
        items(Category.values().toList().chunked(2).size) { row ->
            val pair = Category.values().toList().chunked(2)[row]
            Appear(row * 60) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    pair.forEach { c ->
                        val (done, total) = categoryProgress(c, progress)
                        GlassCard(Modifier.weight(1f), onClick = { nav.navigate("list/${c.name}") }) {
                            IconBadge(c.icon(), 38.dp)
                            Spacer(Modifier.height(8.dp))
                            Text(c.title, color = UColors.Cream, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
                            if (total > 0) {
                                Text("${Arabic.digits(done)} / ${Arabic.digits(total)} مكتمل", color = UColors.CreamDim, fontSize = 11.sp)
                                Spacer(Modifier.height(6.dp))
                                LinearProgressIndicator(
                                    progress = { done.toFloat() / total },
                                    modifier = Modifier.fillMaxWidth().height(5.dp).clip(CircleShape),
                                    color = UColors.Gold, trackColor = UColors.Gold.copy(alpha = 0.2f),
                                )
                            } else {
                                Text("${Arabic.digits(AdhkarData.forCategory(c).size)} ذكرًا", color = UColors.CreamDim, fontSize = 11.sp)
                            }
                        }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }

        // ---------------------------------------------------- 4) التسبيح
        item {
            Appear(100) {
                val goal = s.dailyGoal
                val frac = (tas.todayTotal.toFloat() / goal).coerceIn(0f, 1f)
                GlassCard(Modifier.fillMaxWidth(), onClick = { nav.navigate("tasbih") }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(72.dp)) {
                            CircularProgressIndicator(progress = { frac }, modifier = Modifier.fillMaxSize(), color = UColors.Gold, trackColor = UColors.Gold.copy(alpha = 0.2f), strokeWidth = 7.dp)
                            Text("${Arabic.digits((frac * 100).toInt())}٪", color = UColors.Cream, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text("تسبيح اليوم", color = UColors.CreamDim, fontSize = 12.sp)
                            Text("${Arabic.digits(tas.todayTotal)} من ${Arabic.digits(goal)}", color = UColors.Cream, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Text(if (tas.todayTotal >= goal) "أتممت هدفك اليوم، بارك الله فيك" else "هدفك اليومي قابل للتعديل من المسبحة", color = UColors.CreamDim, fontSize = 12.sp)
                        }
                        IconBadge(Ico.Beads)
                    }
                }
            }
        }

        // ---------------------------------------------------- 5) متابعة الورد
        item { SectionLabel("متابعة الورد") }
        val resume = Category.values().mapNotNull { c ->
            val (done, total) = categoryProgress(c, progress)
            val started = AdhkarData.forCategory(c).any { (progress[it.id] ?: 0) > 0 }
            val next = firstIncomplete(c, progress)
            if (started && next != null && done < total) Triple(c, done to total, next) else null
        }.take(3)
        if (resume.isEmpty()) {
            item {
                EmptyState(
                    Ico.Book, "لم تبدأ وردًا اليوم بعد",
                    "ابدأ بـ${suggested.title}، وسيظهر هنا ما لم تُكمله لتستأنفه من موضعك.",
                    "ابدأ ${suggested.title}",
                ) { nav.navigate("list/${suggested.name}") }
            }
        } else {
            items(resume.size) { i ->
                val (c, dt, next) = resume[i]
                GlassCard(Modifier.fillMaxWidth(), onClick = { nav.navigate("list/${c.name}?start=${next.id}") }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconBadge(c.icon())
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(c.title, color = UColors.Cream, fontWeight = FontWeight.Bold)
                            Text("التالي: ${next.title}", color = UColors.CreamDim, fontSize = 12.sp, maxLines = 1)
                            Spacer(Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress = { dt.first.toFloat() / dt.second },
                                modifier = Modifier.fillMaxWidth().height(5.dp).clip(CircleShape),
                                color = UColors.Gold, trackColor = UColors.Gold.copy(alpha = 0.2f),
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        Text("استكمل", color = UColors.Gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }

        // ---------------------------------------------------- 6) الويدجت
        item { SectionLabel("ودجت الشاشة الرئيسية") }
        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    listOf(WidgetStyle.CINEMATIC, WidgetStyle.LUXE, WidgetStyle.TASBIH, WidgetStyle.GLASS, WidgetStyle.PERIOD).forEach {
                        WidgetPreview(it, Modifier.clickable { nav.navigate("widgets") })
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text("أضف الودجت من شاشة الهاتف الرئيسية لتقرأ ذكرك دون فتح التطبيق.", color = UColors.CreamDim, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillButton("كل الودجت", { nav.navigate("widgets") }, icon = Ico.Widgets)
                    PillButton("التعليمات", { howTo = true }, icon = Ico.Help, filled = false)
                }
            }
        }

        // ---------------------------------------------------- 7) اختصارات سريعة
        item { SectionLabel("اختصارات سريعة") }
        item {
            val items = listOf(
                Triple(Ico.Beads, "المسبحة") { nav.navigate("tasbih") },
                Triple(Ico.Heart, "المفضلة") { nav.navigate("favorites") },
                Triple(Ico.Chart, "السجل") { nav.navigate("stats") },
                Triple(Ico.Palette, "المظهر") { nav.navigate("themes") },
                Triple(Ico.Alarm, "التذكيرات") { nav.navigate("reminders") },
                Triple(Ico.Share, "مشاركة ذكر") { shareZikr(ctx, hero) },
            )
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items.chunked(3).forEach { rowItems ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        rowItems.forEach { (icon, label, action) ->
                            GlassCard(Modifier.weight(1f), onClick = action) {
                                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                                    IconBadge(icon, 40.dp)
                                    Text(label, color = UColors.Cream, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp), maxLines = 1)
                                }
                            }
                        }
                    }
                }
            }
        }

        // ---------------------------------------------------- 8) مقترح حسب الفترة
        item { SectionLabel("مقترح لهذه الفترة من اليوم") }
        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Text(
                    "بحسب ساعة جهازك فقط (${suggested.title})، دون تحديد وقت صلاة.",
                    color = UColors.CreamDim, fontSize = 12.sp,
                )
                AdhkarData.forCategory(suggested).take(3).forEach { z ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                            .clickable { nav.navigate("list/${z.category.name}?start=${z.id}") }.padding(vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(z.title, color = UColors.Cream, modifier = Modifier.weight(1f))
                        Text(if (z.count > 0) "×${Arabic.digits(z.count)}" else "∞", color = UColors.Gold, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
    if (howTo) WidgetHowToDialog { howTo = false }
}
