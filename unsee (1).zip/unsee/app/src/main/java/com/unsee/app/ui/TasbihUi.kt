package com.unsee.app.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.unsee.app.core.Arabic
import com.unsee.app.data.AdhkarData
import com.unsee.app.data.Settings
import com.unsee.app.data.Store
import com.unsee.app.data.TasbihPhrases
import com.unsee.app.widget.WidgetRenderer
import com.unsee.app.widget.WidgetStyle
import kotlinx.coroutines.delay

@Composable
internal fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = UColors.Cream, unfocusedTextColor = UColors.Cream,
    focusedBorderColor = UColors.Gold, unfocusedBorderColor = UColors.Gold.copy(alpha = 0.4f),
    cursorColor = UColors.Gold, focusedLabelColor = UColors.Gold, unfocusedLabelColor = UColors.CreamDim,
)

@Composable
fun TasbihScreen(store: Store, s: Settings) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val t by store.observeAsState { store.tasbih() }
    val sessions by store.observeAsState { store.sessions() }
    val log by store.observeAsState { store.achievements() }
    var picker by remember { mutableIntStateOf(0) }          // 0 مغلق، 1 اختيار ذكر، 2 جلسة جديدة
    var customTarget by remember { mutableStateOf(false) }
    var goalDialog by remember { mutableStateOf(false) }
    var confirmReset by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var done by remember { mutableStateOf(false) }
    fun refresh() = WidgetRenderer.updateStyle(ctx, WidgetStyle.TASBIH)

    LaunchedEffect(done) { if (done) { delay(2600); done = false } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        ScreenHeader("المسبحة")
        ChipRow(sessions, { it.id == t.sessionId }, { "${it.text.take(16)} · ${Arabic.digits(it.count)}" }) { sn -> store.selectSession(sn.id); refresh() }
        Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PillButton("اختيار ذكر", { picker = 1 }, icon = Ico.Stories, filled = false)
            PillButton("جلسة جديدة", { picker = 2 }, icon = Ico.Add, filled = false)
        }
        Spacer(Modifier.height(12.dp))
        AnimatedContent(targetState = t.text, transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(150)) }, label = "phrase") { txt ->
            Text(txt, color = UColors.Cream, fontSize = 24.sp, textAlign = TextAlign.Center, fontFamily = LocalAppFont.current, modifier = Modifier.padding(horizontal = 8.dp))
        }
        Spacer(Modifier.height(12.dp))
        CounterButton(
            count = t.count, target = t.target, size = 270.dp,
            caption = "الهدف ${Arabic.digits(t.target)}",
            reduceMotion = s.reduceMotion,
            onTap = {
                val r = store.tasbihTap()
                feedback(view, s, r.completedRound)
                if (r.completedRound) done = true
                refresh()
            },
        )
        AnimatedVisibility(done) {
            GlassCard(Modifier.fillMaxWidth().padding(top = 10.dp), glow = true) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(Ico.CheckCircle, 36.dp)
                    Spacer(Modifier.width(10.dp))
                    Text("ما شاء الله! أتممت هدف ${Arabic.digits(t.target)}. اضغط للبدء من جديد.", color = UColors.Cream, fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        ChipRow(listOf(33, 99, 100, 500, 1000), { it == t.target }, { Arabic.digits(it) }) { n -> store.setTasbihTarget(n); refresh() }
        Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PillButton("هدف مخصص", { customTarget = true }, icon = Ico.Edit, filled = false)
            PillButton("هدف اليوم", { goalDialog = true }, icon = Ico.Star, filled = false)
        }

        Spacer(Modifier.height(12.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Stat("اليوم", Arabic.digits(t.todayTotal))
                Stat("جولات الجلسة", Arabic.digits(t.rounds))
                Stat("إجمالي كل الجلسات", Arabic.digits(t.lifetime))
            }
            Spacer(Modifier.height(10.dp))
            Text("الهدف اليومي: ${Arabic.digits(t.todayTotal)} من ${Arabic.digits(s.dailyGoal)}", color = UColors.CreamDim, fontSize = 12.sp)
            LinearProgressIndicator(
                progress = { (t.todayTotal.toFloat() / s.dailyGoal).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp).height(6.dp).clip(CircleShape),
                color = UColors.Gold, trackColor = UColors.Gold.copy(alpha = 0.2f),
            )
        }
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PillButton("تصفير العدّاد", { confirmReset = true }, icon = Ico.Refresh, filled = false)
            if (sessions.size > 1) PillButton("حذف الجلسة", { confirmDelete = true }, icon = Ico.Delete, filled = false)
        }

        if (log.isEmpty()) {
            Spacer(Modifier.height(12.dp))
            EmptyState(Ico.Beads, "لا إنجازات بعد", "كل مرة تُتمّ فيها هدفًا يُسجَّل هنا مع تاريخه.")
        } else {
            SectionLabel("سجل الإنجازات", Modifier.align(Alignment.Start))
            log.take(8).forEach { a ->
                GlassCard(Modifier.fillMaxWidth().padding(top = 6.dp)) {
                    Text("${a.text} × ${Arabic.digits(a.target)}", color = UColors.Cream)
                    Text(Arabic.digits(a.date), color = UColors.CreamDim, fontSize = 12.sp)
                }
            }
        }
    }

    // ---------------- نوافذ
    if (picker != 0) {
        var custom by remember { mutableStateOf("") }
        val options = remember {
            TasbihPhrases.all.map { it to 33 } +
                AdhkarData.all.filter { it.isShort && it.text !in TasbihPhrases.all }.map { it.text to (if (it.count > 0) it.count else 33) }
        }
        AlertDialog(
            onDismissRequest = { picker = 0 },
            containerColor = UColors.CardSolid,
            title = { Text(if (picker == 2) "جلسة تسبيح جديدة" else "اختيار الذكر", color = UColors.Cream) },
            text = {
                Column {
                    OutlinedTextField(
                        value = custom, onValueChange = { custom = it.take(80) }, singleLine = true,
                        label = { Text("ذكر شخصي (اختياري)") }, colors = fieldColors(), modifier = Modifier.fillMaxWidth(),
                    )
                    if (custom.isNotBlank()) {
                        PillButton("استخدم هذا الذكر", {
                            if (picker == 2) store.newSession(custom, 33) else store.useText(custom, 33)
                            picker = 0; refresh()
                        }, Modifier.padding(top = 6.dp))
                    }
                    Spacer(Modifier.height(8.dp))
                    Column(Modifier.height(260.dp).verticalScroll(rememberScrollState())) {
                        options.forEach { (txt, tgt) ->
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable {
                                    if (picker == 2) store.newSession(txt, tgt) else store.useText(txt, tgt)
                                    picker = 0; refresh()
                                }.padding(vertical = 9.dp, horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(txt, color = UColors.Cream, fontSize = 14.sp, maxLines = 2, modifier = Modifier.weight(1f))
                                Text("×${Arabic.digits(tgt)}", color = UColors.Gold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { picker = 0 }) { Text("إغلاق", color = UColors.CreamDim) } },
        )
    }
    if (customTarget) NumberDialog("الهدف المخصص", "العدد", t.target, { customTarget = false }) { store.setTasbihTarget(it); refresh() }
    if (goalDialog) NumberDialog("الهدف اليومي للتسبيح", "العدد", s.dailyGoal, { goalDialog = false }) { n -> store.edit { putInt("daily_goal", n.coerceIn(1, 100_000)) } }
    if (confirmReset) ConfirmDialog("تصفير العدّاد؟", "سيعود عدّاد هذه الجلسة إلى الصفر. لا يتأثر سجل اليوم.", "تصفير", { store.tasbihReset(); refresh() }) { confirmReset = false }
    if (confirmDelete) ConfirmDialog("حذف الجلسة؟", "تُحذف هذه الجلسة فقط. لا تتأثر باقي الجلسات ولا الإحصائيات.", "حذف", { store.deleteSession(t.sessionId); refresh() }) { confirmDelete = false }
}

@Composable
fun Stat(label: String, value: String) =
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = UColors.Cream, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text(label, color = UColors.CreamDim, fontSize = 11.sp, textAlign = TextAlign.Center)
    }

@Composable
fun NumberDialog(title: String, label: String, initial: Int, onDismiss: () -> Unit, onSave: (Int) -> Unit) {
    var text by remember { mutableStateOf(initial.toString()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = UColors.CardSolid,
        title = { Text(title, color = UColors.Cream) },
        text = {
            OutlinedTextField(
                value = text, onValueChange = { text = it.filter(Char::isDigit).take(6) }, singleLine = true,
                label = { Text(label) }, colors = fieldColors(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            )
        },
        confirmButton = {
            TextButton(onClick = { text.toIntOrNull()?.takeIf { it > 0 }?.let(onSave); onDismiss() }) { Text("حفظ", color = UColors.Gold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء", color = UColors.CreamDim) } },
    )
}
