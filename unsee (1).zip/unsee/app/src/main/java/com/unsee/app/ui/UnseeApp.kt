package com.unsee.app.ui

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.unsee.app.core.ThemeId
import com.unsee.app.data.Category
import com.unsee.app.data.Store
import java.time.LocalTime

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val TABS = listOf(
    Tab("home", "الرئيسية", Ico.Home),
    Tab("adhkar", "الأذكار", Ico.Book),
    Tab("tasbih", "المسبحة", Ico.Beads),
    Tab("widgets", "الويدجت", Ico.Widgets),
    Tab("more", "المزيد", Ico.More),
)
private val MORE_ROUTES = setOf("favorites", "stats", "reminders", "themes", "reading", "appsettings", "help", "about")

@Composable
fun UnseeApp(store: Store, startRoute: String?, onRouteConsumed: () -> Unit) {
    val ctx = LocalContext.current
    val flow = remember { store.observe { store.settings() } }
    val raw by flow.collectAsStateWithLifecycle(initialValue = remember { store.settings() })
    // نحترم إعداد النظام «إزالة الرسوم المتحركة»
    val systemReduce = remember {
        runCatching { android.provider.Settings.Global.getFloat(ctx.contentResolver, android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f }.getOrDefault(false)
    }
    val settings = if (systemReduce && raw.motion != 0) raw.copy(motion = 0) else raw
    val hour = remember { LocalTime.now().hour }

    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val forceDark = settings.readerNight && route?.startsWith("list/") == true

    UnseeTheme(settings, forceDark) {
        Box(Modifier.fillMaxSize()) {
            if (settings.themeId == ThemeId.NATURE) {
                NatureBackdrop(Scenes.forHour(hour), settings.reduceMotion, settings.particles)
            } else {
                StaticBackdrop()
            }

            LaunchedEffect(startRoute) {
                if (startRoute != null) {
                    runCatching { nav.navigate(startRoute) }
                    onRouteConsumed()
                }
            }

            Scaffold(
                containerColor = Color.Transparent,
                contentWindowInsets = WindowInsets.safeDrawing,
                bottomBar = {
                    if (route?.startsWith("list/") != true) {
                        NavigationBar(containerColor = UColors.CardSolid.copy(alpha = 0.94f).compositeOver(UColors.BgBottom)) {
                            TABS.forEach { tab ->
                                val selected = route == tab.route || (tab.route == "more" && route in MORE_ROUTES)
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = {
                                        nav.navigate(tab.route) {
                                            popUpTo("home") { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                    icon = { Icon(tab.icon, tab.label) },
                                    label = { Text(tab.label, fontSize = 11.sp) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = UColors.OnAccent,
                                        selectedTextColor = UColors.Gold,
                                        unselectedIconColor = UColors.CreamDim,
                                        unselectedTextColor = UColors.CreamDim,
                                        indicatorColor = UColors.Gold,
                                    ),
                                )
                            }
                        }
                    }
                },
            ) { pad ->
                NavHost(
                    navController = nav,
                    startDestination = "home",
                    modifier = Modifier.padding(pad),
                    enterTransition = { if (settings.reduceMotion) fadeIn(tween(0)) else fadeIn(tween(320)) + slideInVertically(tween(320)) { it / 24 } },
                    exitTransition = { fadeOut(tween(if (settings.reduceMotion) 0 else 180)) },
                    popEnterTransition = { fadeIn(tween(if (settings.reduceMotion) 0 else 260)) },
                    popExitTransition = { fadeOut(tween(if (settings.reduceMotion) 0 else 180)) },
                ) {
                    composable("home") { HomeScreen(store, settings, nav) }
                    composable("adhkar") { AdhkarScreen(store, nav) }
                    composable(
                        "list/{cat}?start={start}",
                        arguments = listOf(
                            navArgument("cat") { type = NavType.StringType },
                            navArgument("start") { type = NavType.StringType; defaultValue = "" },
                        ),
                    ) { e ->
                        val cat = runCatching { Category.valueOf(e.arguments?.getString("cat") ?: "") }.getOrDefault(Category.MORNING)
                        AdhkarPagerScreen(cat, e.arguments?.getString("start") ?: "", store, settings, nav)
                    }
                    composable("tasbih") { TasbihScreen(store, settings) }
                    composable("widgets") { WidgetsScreen(store, settings) }
                    composable("more") { MoreScreen(nav) }
                    composable("favorites") { FavoritesScreen(store, nav) }
                    composable("stats") { StatsScreen(store, nav) }
                    composable("reminders") { RemindersScreen(store, nav) }
                    composable("themes") { ThemesScreen(store, settings, nav) }
                    composable("reading") { ReadingSettingsScreen(store, settings, nav) }
                    composable("appsettings") { AppSettingsScreen(store, settings, nav) }
                    composable("help") { HelpScreen(nav) }
                    composable("about") { AboutScreen(nav) }
                }
            }
        }
    }
}
