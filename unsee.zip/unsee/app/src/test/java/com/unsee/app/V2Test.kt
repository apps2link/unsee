package com.unsee.app

import com.unsee.app.core.ArabicText
import com.unsee.app.core.Codec
import com.unsee.app.core.DateText
import com.unsee.app.core.Palettes
import com.unsee.app.core.Reminder
import com.unsee.app.core.ReminderKind
import com.unsee.app.core.TasbihSession
import com.unsee.app.core.ThemeId
import com.unsee.app.core.TimeLogic
import com.unsee.app.data.AdhkarData
import com.unsee.app.data.Category
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

class ThemeContrastTest {
    @Test fun thirtyOneThemesSilkFirstAndMain() {
        assertEquals(31, ThemeId.values().size)
        assertEquals(ThemeId.SILK, ThemeId.values().first())
        assertTrue(ThemeId.values().contains(ThemeId.NATURE))
        assertEquals(ThemeId.values().size, ThemeId.values().map { it.label }.toSet().size)
    }

    @Test fun everyThemeIsReadable() {
        for (id in ThemeId.values()) {
            val p = Palettes.spec(id)
            val tag = "$id dark=${p.dark}"
            assertTrue("text/card $tag", Palettes.contrast(p.text, p.card) >= 4.5)
            assertTrue("dim/card $tag", Palettes.contrast(p.textDim, p.card) >= 4.5)
            assertTrue("text/bgTop $tag", Palettes.contrast(p.text, p.bgTop) >= 4.5)
            assertTrue("text/bgBottom $tag", Palettes.contrast(p.text, p.bgBottom) >= 4.5)
            assertTrue("dim/bgBottom $tag", Palettes.contrast(p.textDim, p.bgBottom) >= 4.5)
            assertTrue("accent/card $tag", Palettes.contrast(p.accent, p.card) >= 4.5)
            assertTrue("onAccent/accent $tag", Palettes.contrast(p.onAccent, p.accent) >= 4.5)
        }
    }

    @Test fun accentSwatchesReadableOnEveryThemeCard() {
        for (id in ThemeId.values()) {
            val p = Palettes.spec(id)
            for ((name, pair) in Palettes.ACCENTS) {
                val a = if (p.dark) pair.first else pair.second
                assertTrue("$name on $id", Palettes.contrast(a, p.card) >= 4.5)
            }
        }
    }
}

class CounterCatalogTest {
    @Test fun fiftyNineDistinctStylesAcrossTwentyThreeEngines() {
        val all = com.unsee.app.core.CounterCatalog.all
        assertEquals(59, all.size)
        assertEquals(59, all.map { it.id }.toSet().size)
        assertEquals(59, all.map { it.name }.toSet().size)
        assertEquals(com.unsee.app.core.CounterEngine.values().size, all.map { it.engine }.toSet().size)
    }

    @Test fun cfgRoundTripKeepsEverything() {
        val c = com.unsee.app.core.CounterCfg(
            styleId = "k07", size = 300, numScale = 1.2f, font = 2, numColor = 0xFFFFFFFFL, ringColor = 0xFF3FE0A0L, bgColor = 0xFF112233L,
            bgAlpha = 0.5f, anim = false, speed = 1.5f, glow = 0.8f, showName = false, showGoal = false, tone = 2,
        )
        val back = com.unsee.app.core.CounterCodec.decode(com.unsee.app.core.CounterCodec.encode(c))
        assertEquals(c, back)
    }

    @Test fun badOrUnknownInputFallsBackToClassic() {
        assertEquals(com.unsee.app.core.CounterCatalog.CLASSIC, com.unsee.app.core.CounterCodec.decode("s=nope;z=99999").styleId)
        assertEquals(com.unsee.app.core.CounterCfg.SIZE_MAX, com.unsee.app.core.CounterCodec.decode("s=k01;z=99999").size)
        assertEquals(com.unsee.app.core.CounterCfg(), com.unsee.app.core.CounterCodec.decode(null))
    }

    @Test fun changingSizeOrColorsKeepsTheStyle() {
        val c = com.unsee.app.core.CounterCfg(styleId = "k19").copy(size = 220, ringColor = 0xFFFF0000L)
        assertEquals("k19", c.styleId)
        val r = c.resetKeepingStyle()
        assertEquals("k19", r.styleId)
        assertEquals(0L, r.ringColor)
    }

    @Test fun savedDesignsRoundTrip() {
        val list = listOf(
            com.unsee.app.core.NamedCounter("ذهبي كبير", com.unsee.app.core.CounterCfg(styleId = "k01", size = 320)),
            com.unsee.app.core.NamedCounter("ليلي", com.unsee.app.core.CounterCfg(styleId = "k37")),
        )
        val back = com.unsee.app.core.CounterCodec.decodeSaved(com.unsee.app.core.CounterCodec.encodeSaved(list))
        assertEquals(list, back)
    }
}

class CodecTest {
    @Test fun remindersRoundTrip() {
        val l = listOf(
            Reminder("morning", ReminderKind.MORNING, "أذكار الصباح", 330, 127, true, "MORNING"),
            Reminder("c1", ReminderKind.CUSTOM, "ورد | خاص\nسطر", 800, 5, false, ""),
        )
        val back = Codec.decodeReminders(Codec.encodeReminders(l))
        assertEquals(2, back.size)
        assertEquals(l[0], back[0])
        assertEquals(800, back[1].minute)
        assertEquals(5, back[1].days)
        assertTrue(!back[1].label.contains('|') && !back[1].label.contains('\n'))
    }

    @Test fun sessionsRoundTripAndBadLinesIgnored() {
        val l = listOf(TasbihSession("a", "سُبْحَانَ اللَّهِ", 33, 5, 105, 123456789L, 3))
        val enc = Codec.encodeSessions(l) + "\nbroken-line"
        val back = Codec.decodeSessions(enc)
        assertEquals(l, back)
        assertTrue(Codec.decodeSessions("").isEmpty())
    }

    @Test fun reminderDays() {
        val r = Reminder("x", ReminderKind.CUSTOM, "x", 0, days = 0b0000101) // الإثنين والأربعاء
        assertTrue(r.runsOn(1)); assertTrue(!r.runsOn(2)); assertTrue(r.runsOn(3))
    }
}

class ScheduleAndTextTest {
    private val utc = ZoneId.of("UTC")

    @Test fun nextOnSelectedDaysOnly() {
        // 2026-10-26 الإثنين 10:00
        val now = ZonedDateTime.of(2026, 10, 26, 10, 0, 0, 0, utc)
        val wedOnly = 0b0000100
        val d = TimeLogic.delayUntilNextOnDays(now, 9 * 60, wedOnly)!!
        assertEquals((2 * 24 * 60 - 60) * 60_000L, d) // الأربعاء 9:00
        assertNull(TimeLogic.delayUntilNextOnDays(now, 9 * 60, 0))
        val monOnly = 0b0000001
        assertEquals(60 * 60_000L, TimeLogic.delayUntilNextOnDays(now, 11 * 60, monOnly))
        assertEquals((7 * 24 * 60 - 60) * 60_000L, TimeLogic.delayUntilNextOnDays(now, 9 * 60, monOnly))
    }

    @Test fun searchNormalizationIgnoresDiacritics() {
        assertEquals(ArabicText.normalize("سُبْحَانَ اللَّهِ"), ArabicText.normalize("سبحان الله"))
        val hits = AdhkarData.all.filter { ArabicText.normalize(it.text).contains(ArabicText.normalize("القيوم")) || ArabicText.normalize(it.title).contains("القيوم") }
        assertTrue(hits.isNotEmpty())
    }

    @Test fun hijriDateIsProduced() {
        val h = DateText.hijri(LocalDate.of(2026, 10, 27))
        assertNotNull(h)
        assertTrue(h!!.endsWith("هـ"))
        assertEquals("٢٧ أكتوبر ٢٠٢٦", DateText.gregorian(LocalDate.of(2026, 10, 27)))
    }

    @Test fun newCategoriesHaveContentWithSources() {
        for (c in listOf(Category.ENTER_EXIT, Category.FOOD, Category.TRAVEL, Category.DUAS)) {
            val l = AdhkarData.forCategory(c)
            assertTrue(c.name, l.size >= 3)
            assertTrue(l.all { it.source.isNotBlank() })
        }
    }
}
