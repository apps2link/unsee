package com.unsee.app

import com.unsee.app.core.CompanionSchedule
import com.unsee.app.core.CompanionSettings
import com.unsee.app.core.Dialect
import com.unsee.app.core.DialectPref
import com.unsee.app.core.DialectResolve
import com.unsee.app.core.Essential
import com.unsee.app.core.LedgerCodec
import com.unsee.app.core.LedgerEntry
import com.unsee.app.core.LedgerLogic
import com.unsee.app.core.LedgerType
import com.unsee.app.core.LogKind
import com.unsee.app.core.PendingCodec
import com.unsee.app.core.PendingItem
import com.unsee.app.core.PlanCodec
import com.unsee.app.core.PlanLogic
import com.unsee.app.core.QuitPlan
import com.unsee.app.core.Voice
import com.unsee.app.data.CompanionMessages
import com.unsee.app.data.CompanionMessagesGulf
import com.unsee.app.data.MsgKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

class ArenaTest {
    private val zone = ZoneId.of("Africa/Cairo")
    private val today = LocalDate.of(2026, 10, 31)

    private fun e(date: LocalDate, title: String, type: LedgerType = LedgerType.GOOD, key: String = "") =
        LedgerEntry("id${title.hashCode()}${date}", 1L, date.toString(), type, title, key)

    // ---------------------------------------------------------------- اللهجة
    @Test fun dialectFromCountry() {
        assertEquals(Dialect.EGYPT, DialectResolve.fromCountry("EG"))
        assertEquals(Dialect.EGYPT, DialectResolve.fromCountry(null))
        assertEquals(Dialect.GULF, DialectResolve.fromCountry("sa"))
        assertEquals(Dialect.GULF, DialectResolve.fromCountry("AE"))
        assertEquals(Dialect.GULF, DialectResolve.resolve(DialectPref.GULF, "EG"))
        assertEquals(Dialect.EGYPT, DialectResolve.resolve(DialectPref.EGYPT, "KW"))
        assertEquals(Dialect.GULF, DialectResolve.resolve(DialectPref.AUTO, "KW"))
    }

    @Test fun voiceListsAndSafeIndex() {
        val eg = Voice(Dialect.EGYPT)
        val gu = Voice(Dialect.GULF)
        assertEquals(eg.cheersEg.size, eg.cheersGulf.size)
        assertEquals(eg.comfortEg.size, eg.comfortGulf.size)
        for (seed in listOf(-7, -1, 0, 1, 99, Int.MIN_VALUE, Int.MAX_VALUE)) {
            assertTrue(eg.cheer(seed).isNotBlank()); assertTrue(gu.cheer(seed).isNotBlank())
            assertTrue(eg.comfort(seed).isNotBlank()); assertTrue(gu.comfort(seed).isNotBlank())
        }
        assertNotEquals(eg.greeting(9), gu.greeting(9))
        assertTrue(Essential.values().all { eg.essentialQuestion(it).isNotBlank() && gu.essentialTitle(it).isNotBlank() })
    }

    @Test fun everyAdviceHasGulfVersionAndScriptureNeverChanges() {
        for (m in CompanionMessages.all) {
            if (m.kind == MsgKind.ADVICE) {
                // بعض الجمل محايدة فتتطابق في اللهجتين، لكن لكل تذكير وعظي مدخلة خليجية صريحة
                assertTrue("ينقص نص خليجي: ${m.id}", CompanionMessagesGulf.advice.containsKey(m.id))
            } else {
                assertEquals(m.text, m.textFor(Dialect.GULF))
            }
            assertEquals(m.text, m.textFor(Dialect.EGYPT))
        }
    }

    // ---------------------------------------------------------------- الدفتر
    @Test fun ledgerCodecRoundTripWithSpecialChars() {
        val list = listOf(e(today, "ساعدت | حد\nجاري"), e(today, "غيبة", LedgerType.SIN, "k:1"))
        val back = LedgerCodec.decode(LedgerCodec.encode(list))
        assertEquals(list, back)
        assertTrue(LedgerCodec.decode("garbage|line").isEmpty())
    }

    @Test fun scoreAndShare() {
        val s = LedgerLogic.score(listOf(e(today, "a"), e(today, "b"), e(today, "c", LedgerType.SIN)))
        assertEquals(2, s.good); assertEquals(1, s.sin)
        assertEquals(2f / 3f, s.goodShare, 0.001f)
        assertEquals(0.5f, LedgerLogic.score(emptyList()).goodShare, 0.0001f)
    }

    @Test fun habitReminderOnlyWhenDoneYesterdayAndNotToday() {
        val y = today.minusDays(1)
        val by = mapOf(y.toString() to listOf(e(y, "ساعدت حد"), e(y, "غيبة", LedgerType.SIN), e(y, "صليت الفجر", key = "ess:fajr")))
        assertEquals(listOf("ساعدت حد"), LedgerLogic.habitsToRemind(by, today))
        val done = by + (today.toString() to listOf(e(today, "  ساعدت   حد ")))
        assertTrue(LedgerLogic.habitsToRemind(done, today).isEmpty())
    }

    @Test fun streakCountsConsecutiveDays() {
        val by = (1..3).associate { i -> today.minusDays(i.toLong()).toString() to listOf(e(today.minusDays(i.toLong()), "تصدقت")) }
        assertEquals(3, LedgerLogic.streak("تصدقت", by, today))
        val withToday = by + (today.toString() to listOf(e(today, "تصدقت")))
        assertEquals(4, LedgerLogic.streak("تصدقت", withToday, today))
        val gap = mapOf(today.minusDays(3).toString() to listOf(e(today.minusDays(3), "تصدقت")))
        assertEquals(0, LedgerLogic.streak("تصدقت", gap, today))
    }

    // ---------------------------------------------------------------- الخطط
    private fun plan(lastKept: String = "", lastSlip: String = "") =
        QuitPlan("p1", "غيبة | كلام", "أستغفر", listOf(14 * 60, 21 * 60), "2026-10-01", lastSlip, lastKept, 3, true)

    @Test fun planCodecRoundTrip() {
        val l = listOf(plan(), plan().copy(id = "p2", active = false, times = listOf(60)))
        assertEquals(l, PlanCodec.decode(PlanCodec.encode(l)))
    }

    @Test fun cleanDaysAndSlip() {
        assertEquals(30, PlanLogic.cleanDays(plan(), today))
        val slipped = PlanLogic.afterSlip(plan(), today)
        assertEquals(0, PlanLogic.cleanDays(slipped, today))
        assertEquals(30, slipped.bestStreak)
        assertEquals(2, PlanLogic.cleanDays(slipped, today.plusDays(2)))
    }

    @Test fun nextPlanReminderSkipsTodayOnceKept() {
        val now = ZonedDateTime.of(2026, 10, 31, 15, 0, 0, 0, zone)
        assertEquals(now.withHour(21), PlanLogic.nextReminder(listOf(plan()), now)!!.second)
        val kept = PlanLogic.nextReminder(listOf(plan(lastKept = "2026-10-31")), now)!!.second
        assertEquals(ZonedDateTime.of(2026, 11, 1, 14, 0, 0, 0, zone), kept)
        assertNull(PlanLogic.nextReminder(listOf(plan().copy(active = false)), now))
    }

    // ---------------------------------------------------------------- المعلّق والعادات
    @Test fun pendingCodecAndOrdering() {
        val a = PendingItem(LogKind.DHIKR, "ist_01", "رفيق|أُنسي", "سطر1\nسطر2", null, "تم", "لاحقًا", "فتح", "adhkar", 3001, false, 5L)
        val b = PendingItem(LogKind.PLAN, "plan:p1", "خطة", "نص", "— مصدر", "التزمت", "وقعت", "افتح", "muhasaba", 5100, true, 1L)
        val back = PendingCodec.decode(PendingCodec.encode(listOf(a, b)))
        assertEquals(listOf(a, b), back)
        assertEquals("plan:p1", PendingCodec.ordered(back).first().ref) // الأولوية قبل الأحدث
    }

    @Test fun habitSlotScheduling() {
        val s = CompanionSettings(habitEnabled = true, habitMin = 17 * 60)
        val before = ZonedDateTime.of(2026, 10, 31, 10, 0, 0, 0, zone)
        val after = ZonedDateTime.of(2026, 10, 31, 18, 0, 0, 0, zone)
        assertEquals(before.withHour(17), CompanionSchedule.nextHabit(before, s))
        assertEquals(after.plusDays(1).withHour(17), CompanionSchedule.nextHabit(after, s))
        assertNull(CompanionSchedule.nextHabit(before, s.copy(habitEnabled = false)))
    }
}
