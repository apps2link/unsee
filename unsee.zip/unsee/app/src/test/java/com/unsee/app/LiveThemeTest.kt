package com.unsee.app

import com.unsee.app.core.Appearance
import com.unsee.app.core.LiveClock
import com.unsee.app.core.Palettes
import com.unsee.app.core.SkyPhase
import com.unsee.app.core.SunWindow
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId

class LiveThemeTest {
    private val w = SunWindow(6 * 60, 18 * 60)

    @Test fun dayAndNightExtremes() {
        assertEquals(1f, LiveClock.dayBlend(12 * 60f, w), 1e-4f)
        assertEquals(0f, LiveClock.dayBlend(0f, w), 1e-4f)
        assertEquals(0f, LiveClock.dayBlend(23 * 60f, w), 1e-4f)
        // عند الشروق والغروب تمامًا نصف المزج
        assertEquals(0.5f, LiveClock.dayBlend(6 * 60f, w), 1e-3f)
        assertEquals(0.5f, LiveClock.dayBlend(18 * 60f, w), 1e-3f)
    }

    @Test fun blendIsMonotonicAcrossSunrise() {
        var prev = -1f
        for (m in 5 * 60..7 * 60 step 5) {
            val b = LiveClock.dayBlend(m.toFloat(), w)
            assertTrue("m=$m", b >= prev - 1e-6f)
            prev = b
        }
    }

    @Test fun targetBlendByAppearance() {
        assertEquals(1f, LiveClock.targetBlend(Appearance.LIGHT, 2 * 60f, w, systemDark = true), 0f)
        assertEquals(0f, LiveClock.targetBlend(Appearance.DARK, 12 * 60f, w, systemDark = false), 0f)
        assertEquals(0f, LiveClock.targetBlend(Appearance.SYSTEM, 12 * 60f, w, systemDark = true), 0f)
        assertEquals(1f, LiveClock.targetBlend(Appearance.SYSTEM, 2 * 60f, w, systemDark = false), 0f)
        assertEquals(1f, LiveClock.targetBlend(Appearance.AUTO_TIME, 12 * 60f, w, systemDark = true), 1e-4f)
        assertTrue(Appearance.AUTO_TIME.isAuto && Appearance.SYSTEM.isAuto && !Appearance.LIGHT.isAuto && !Appearance.DARK.isAuto)
    }

    @Test fun celestialArcs() {
        assertEquals(0f, LiveClock.sunProgress(5 * 60f, w), 0f)
        assertEquals(0.5f, LiveClock.sunProgress(12 * 60f, w), 1e-4f)
        assertEquals(1f, LiveClock.sunProgress(20 * 60f, w), 0f)
        assertEquals(0f, LiveClock.moonProgress(18 * 60f, w), 1e-4f)
        // منتصف الليل (بعد 6 ساعات من الغروب من أصل 12) = نصف القوس
        assertEquals(0.5f, LiveClock.moonProgress(0f, w), 1e-3f)
        assertEquals(1f, LiveClock.moonProgress(6 * 60f - 0.01f, w), 1e-2f)
    }

    @Test fun phases() {
        assertEquals(SkyPhase.DAY, LiveClock.phase(12 * 60f, w))
        assertEquals(SkyPhase.NIGHT, LiveClock.phase(1 * 60f, w))
        assertEquals(SkyPhase.DAWN, LiveClock.phase(6 * 60f, w))
        assertEquals(SkyPhase.DUSK, LiveClock.phase(18 * 60f, w))
    }

    @Test fun sunWindowFromRealCoordinates() {
        // القاهرة صيفًا: شروق قبل 6:00 تقريبًا وغروب بعد 18:30 (بتوقيت القاهرة) — نتحقق من معقولية النافذة فقط
        val win = LiveClock.sunWindow(30.0444, 31.2357, LocalDate.of(2026, 6, 21), ZoneId.of("Africa/Cairo"))
        assertTrue("sunrise ${win.sunriseMin}", win.sunriseMin in 4 * 60..7 * 60)
        assertTrue("sunset ${win.sunsetMin}", win.sunsetMin in 17 * 60..21 * 60)
        // إحداثيات غير صالحة لا تكسر شيئًا
        val bad = LiveClock.sunWindow(99.0, 999.0, LocalDate.of(2026, 1, 1), ZoneId.of("UTC"))
        assertTrue(bad.sunsetMin > bad.sunriseMin)
    }

    @Test fun silkEndpointsAreReadable() {
        for (spec in listOf(Palettes.silk(0f), Palettes.silk(1f), Palettes.SILK_DAY, Palettes.SILK_NIGHT)) {
            assertTrue(Palettes.contrast(spec.text, spec.card) >= 4.5)
            assertTrue(Palettes.contrast(spec.textDim, spec.card) >= 4.5)
            assertTrue(Palettes.contrast(spec.text, spec.bgTop) >= 4.5)
            assertTrue(Palettes.contrast(spec.textDim, spec.bgBottom) >= 4.5)
            assertTrue(Palettes.contrast(spec.accent, spec.card) >= 4.5)
            assertTrue(Palettes.contrast(spec.onAccent, spec.accent) >= 4.5)
        }
        assertTrue(Palettes.silk(0f).dark && !Palettes.silk(1f).dark)
    }

    @Test fun silkMidTransitionStaysMostlyReadable() {
        // أثناء انتقال الـ1.6 ثانية تمرّ الأسطح بلون وسطي؛ نتأكد أن اللحظات الضعيفة (<3:1) قليلة جدًا
        var weak = 0
        val n = 200
        for (i in 0..n) {
            val p = Palettes.silk(i / n.toFloat())
            val worst = minOf(Palettes.contrast(p.text, p.card), Palettes.contrast(p.text, p.bgTop), Palettes.contrast(p.text, p.bgBottom))
            if (worst < 3.0) weak++
        }
        assertTrue("weak frames=$weak", weak <= n * 0.08)
        // وفي المنتصف تمامًا لا تنكسر الألوان (قيم ARGB صالحة)
        val mid = Palettes.silk(0.5f)
        assertEquals(0xFF, ((mid.card shr 24) and 0xFF).toInt())
    }
}
