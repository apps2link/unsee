package com.unsee.app

import com.unsee.app.core.*
import org.junit.Assert.*
import org.junit.Test

class VoicePolicyTest {
    @Test fun quietHoursCrossMidnight() {
        assertTrue(QuietHours.isQuiet(23 * 60 + 30, 23 * 60, 6 * 60))
        assertTrue(QuietHours.isQuiet(2 * 60, 23 * 60, 6 * 60))
        assertFalse(QuietHours.isQuiet(6 * 60, 23 * 60, 6 * 60))
        assertFalse(QuietHours.isQuiet(12 * 60, 23 * 60, 6 * 60))
        assertTrue(QuietHours.isQuiet(13 * 60, 12 * 60, 14 * 60))
        assertFalse(QuietHours.isQuiet(2 * 60, 23 * 60, 6 * 60, enabled = false))
        assertFalse(QuietHours.isQuiet(1, 600, 600))
    }

    @Test fun dedupeWindow() {
        val d = SpeechDeduper(10 * 60_000L)
        assertTrue(d.shouldSpeak("a", 0L))
        assertFalse(d.shouldSpeak("a", 5 * 60_000L))
        assertTrue(d.shouldSpeak("b", 5 * 60_000L))
        assertTrue(d.shouldSpeak("a", 11 * 60_000L))
        d.forget("a"); assertTrue(d.shouldSpeak("a", 11 * 60_000L + 1))
    }

    @Test fun queuePolicyPreventsOverlap() {
        assertEquals(QueueDecision.FLUSH, SpeechQueuePolicy.decide(SpeechPriority.HIGH, true))
        assertEquals(QueueDecision.ADD, SpeechQueuePolicy.decide(SpeechPriority.NORMAL, true))
        assertEquals(QueueDecision.DROP, SpeechQueuePolicy.decide(SpeechPriority.LOW, true))
        assertEquals(QueueDecision.ADD, SpeechQueuePolicy.decide(SpeechPriority.LOW, false))
    }

    @Test fun gateRules() {
        val s = VoiceSettings()
        fun gate(st: VoiceSettings = s, sec: VoiceSection = VoiceSection.NOTIFY, notif: Boolean = true, min: Int = 12 * 60, silent: Boolean = false, dnd: Boolean = false, text: String = "نص") =
            VoiceGate.check(st, sec, notif, min, silent, dnd, text)
        assertNull(gate())
        assertEquals(SkipReason.EMPTY, gate(text = "  "))
        assertEquals(SkipReason.MASTER_OFF, gate(s.copy(master = false)))
        assertEquals(SkipReason.SECTION_OFF, gate(s.copy(sections = mapOf(VoiceSection.NOTIFY to SectionVoice(enabled = false)))))
        assertEquals(SkipReason.NOTIFICATIONS_OFF, gate(s.copy(speakNotifications = false)))
        assertEquals(SkipReason.QUIET_HOURS, gate(min = 1 * 60))
        assertEquals(SkipReason.SILENT_MODE, gate(silent = true))
        assertEquals(SkipReason.DND, gate(dnd = true))
        // القراءة اليدوية داخل التطبيق لا تتأثر بساعات الهدوء ولا بعدم الإزعاج
        assertNull(gate(notif = false, min = 1 * 60, dnd = true))
        assertEquals(SkipReason.SILENT_MODE, gate(notif = false, silent = true))
    }

    @Test fun sectionCodecRoundTrip() {
        val m = mapOf(VoiceSection.TASBIH to SectionVoice(false, true, "ar-xa-x-abc#male_1-local"), VoiceSection.COMPANION to SectionVoice(true, false, ""))
        assertEquals(m, VoiceCodec.decodeSections(VoiceCodec.encodeSections(m)))
        assertTrue(VoiceCodec.decodeSections("garbage|x~1").isEmpty())
        assertEquals(emptyMap<VoiceSection, SectionVoice>(), VoiceCodec.decodeSections(null))
    }

    @Test fun voiceForFallsBackToGlobal() {
        val s = VoiceSettings(voice = "G", sections = mapOf(VoiceSection.COMPANION to SectionVoice(voice = "C")))
        assertEquals("C", s.voiceFor(VoiceSection.COMPANION))
        assertEquals("G", s.voiceFor(VoiceSection.NOTIFY))
        val c = VoiceSettings(rate = 9f, pitch = 0f, volume = -1f, quietStartMin = -60).clamped()
        assertEquals(VoiceSettings.RATE_MAX, c.rate, 0f); assertEquals(VoiceSettings.PITCH_MIN, c.pitch, 0f)
        assertEquals(VoiceSettings.VOL_MIN, c.volume, 0f); assertEquals(23 * 60, c.quietStartMin)
    }

    @Test fun spokenScriptsMatchTheExamples() {
        assertEquals("يلا بينا، جه وقت أذكار المساء", SpeechScript.compose(SpokenKind.REMINDER_EVENING, "أذكار المساء", "حان وقت أذكار المساء — ختامٌ هادئ ليومك", false, false))
        assertEquals("أحسنت، ربنا يتقبل منك، استمر على طاعتك", SpeechScript.compose(SpokenKind.GENERIC, "أحسنت!", "أحسنت! لقد أتممت وردك اليومي", false, false))
        assertEquals("خد دقيقة من وقتك، وصلّي على النبي", SpeechScript.compose(SpokenKind.GENERIC, "تذكير", "لا تنسَ الصلاة على النبي", false, false))
        assertEquals("يلا، حان وقت أذكار الصباح", SpeechScript.compose(SpokenKind.REMINDER_MORNING, "x", "y", true, false))
        assertEquals("عنوان. نص عادي", SpeechScript.compose(SpokenKind.GENERIC, "عنوان", "نص عادي", false, true))
        assertEquals("نص عادي", SpeechScript.compose(SpokenKind.GENERIC, "عنوان", "نص عادي", false, false))
    }

    @Test fun quranGuard() {
        assertTrue(QuranGuard.isQuranic("آية الكرسي", "اللَّهُ لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ"))
        assertTrue(QuranGuard.isQuranic("", "قُلْ هُوَ اللَّهُ أَحَدٌ"))
        assertTrue(QuranGuard.isQuranic("المعوذات", "x"))
        assertTrue(QuranGuard.isQuranic("", "بِسْمِ اللَّهِ {آية}"))
        assertFalse(QuranGuard.isQuranic("", "أَصْبَحْنَا عَلَى فِطْرَةِ الْإِسْلاَمِ وَعَلَى كَلِمَةِ الإِخْلاَصِ"))
        assertFalse(QuranGuard.isQuranic("سبحان الله", "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ"))
    }

    @Test fun cleanRemovesNoise() {
        assertEquals("سبحان الله", SpeechScript.clean("«سبحان الله» ***"))
    }
}
