package com.unsee.app

import com.unsee.app.data.AdhkarData
import com.unsee.app.data.Category
import com.unsee.app.data.EveningForms
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** صيغة المساء: «أمسينا وأمسى الملك لله» بدل نص الصباح، وترتيب الأقسام بعد «فضل الذكر». */
class EveningFormsTest {
    private val ebd = Regex("[\\u064B-\\u0652\\u0670\\u0640]")
    private fun bare(s: String) = ebd.replace(s, "")

    @Test fun everyReplacementAppliesToTheMorningText() {
        for (row in AdhkarData.rows().filter { it.id in EveningForms.replacements.keys }) {
            assertTrue(row.id, EveningForms.unmatched(row.id, row.text).isEmpty())
        }
        assertEquals(EveningForms.replacements.keys, AdhkarData.rows().map { it.id }.filter { it in EveningForms.replacements.keys }.toSet())
    }

    @Test fun eveningHasNoMorningWording() {
        val evening = AdhkarData.readerList(Category.EVENING).filter { it.chapterNo == 27 }
        for (z in evening) {
            val t = bare(z.text)
            assertFalse(z.id, t.contains("أصبحنا وأصبح الملك"))
            assertFalse(z.id, t.contains("أصبحت أشهدك"))
            assertFalse(z.id, t.contains("هذا اليوم"))
            assertFalse(z.id, t.contains("أصبحنا على فطرة"))
            assertFalse(z.id, t.contains("ما أصبح بي"))
        }
        val first = bare(AdhkarData.byId("e_h77")!!.text)
        assertTrue(first.startsWith("أمسينا وأمسى الملك لله"))
        assertTrue(first.contains("هذه الليلة"))
    }

    @Test fun morningTextIsUntouched() {
        val m = bare(AdhkarData.byId("m_h77")!!.text)
        assertTrue(m.startsWith("أصبحنا وأصبح الملك لله"))
        assertTrue(m.contains("هذا اليوم"))
    }

    @Test fun eveningFormFootnotesNotDuplicated() {
        val e = AdhkarData.byId("e_h77")!!
        assertTrue(e.footnotes.none { it.text.startsWith("وإذا أمسى") })
        assertTrue(AdhkarData.byId("m_h77")!!.footnotes.any { it.text.startsWith("وإذا أمسى") })
    }

    @Test fun morningAndEveningFollowFadlFirst() {
        val keys = AdhkarData.sections.map { it.key }
        assertEquals(listOf("ch0", "ch27m", "ch27e"), keys.take(3))
        assertEquals(listOf(Category.FADL, Category.MORNING, Category.EVENING), Category.values().take(3))
        // بقية الأبواب بترتيب الكتاب
        val rest = keys.drop(3).map { it.removePrefix("ch").filter(Char::isDigit).toInt() }
        assertEquals(rest.sorted(), rest)
    }
}
