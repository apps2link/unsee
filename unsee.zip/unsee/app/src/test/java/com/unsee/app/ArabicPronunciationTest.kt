package com.unsee.app

import com.unsee.app.core.ArabicPronunciation as AP
import com.unsee.app.core.Dialect
import org.junit.Assert.*
import org.junit.Test

class ArabicPronunciationTest {
    private fun eg(t: String, tag: String? = "ar-XA") = AP.prepare(t, Dialect.EGYPT, tag).text

    @Test fun cardinalNumbers() {
        assertEquals("ثلاث وثلاثين", AP.cardinal(33, true))
        assertEquals("ثلاثة وثلاثين", AP.cardinal(33, false))
        assertEquals("مئة", AP.cardinal(100, false))
        assertEquals("ألف", AP.cardinal(1000, false))
        assertEquals("ألفين وخمسة وعشرين", AP.cardinal(2025, false))
        assertEquals("إحدى عشرة", AP.cardinal(11, true))
        assertEquals("ثلاثمئة وثلاث وستين", AP.cardinal(363, true))
        assertEquals("ثلاثة آلاف", AP.cardinal(3000, false))
        assertEquals("صفر", AP.cardinal(0, false))
    }

    @Test fun numbersInContext() {
        assertEquals("ثلاث مرات", eg("٣ مرات"))
        assertEquals("ثلاثة أيام", eg("3 أيام"))
        assertEquals("مئة مرة", eg("١٠٠ مرة"))
        assertEquals("الهدف ثلاثة وثلاثين", eg("الهدف ٣٣"))
        assertEquals("ثلاثة فاصلة خمسة", eg("٣٫٥"))
        assertEquals("ستة ونصف", eg("٦:٣٠"))
        assertEquals("تسعة وخمس دقائق", eg("٩:٠٥"))
        assertEquals("سبعة", eg("٧:٠٠"))
        // رقم طويل يُقرأ رقمًا رقمًا
        assertEquals("واحد اثنان ثلاثة أربعة خمسة ستة سبعة", eg("1234567"))
        assertFalse(eg("لديك ٥٠ حسنة").any { it.isDigit() || it in '٠'..'٩' })
    }

    @Test fun religiousSymbolsAndEmojiAndNoise() {
        assertTrue(eg("محمد ﷺ").contains("صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ"))
        assertEquals("خد دقيقة", eg("خد دقيقة 🤲"))
        assertEquals("نص، آخر", eg("نص — آخر"))
        assertEquals("كلمة. جديدة", eg("كلمة... جديدة"))
        assertEquals("سلام، عليكم", eg("سلام  ،،،   عليكم"))
        assertEquals("نص نص", eg("«نص»   (نص)"))
    }

    @Test fun phraseLexiconOnlyOnUndiacritizedText() {
        assertEquals("سُبْحَانَ اللَّهِ", eg("سبحان الله"))
        assertEquals("الْحَمْدُ لِلَّهِ", eg("الحمد لله"))
        assertEquals("أَسْتَغْفِرُ اللَّهَ", eg("استغفر الله"))
        assertEquals("لَا إِلَهَ إِلَّا اللَّهُ", eg("لا اله الا الله"))
        // نص مشكّل أصلًا لا يُمسّ
        val already = "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ"
        assertEquals(already, eg(already))
        // كلمة ضمن جملة أخرى لا تُستبدل جزئيًا
        assertEquals("سبحانك يا رب", eg("سبحانك يا رب"))
        assertTrue(eg("لقد أتممت وردك اليومي").contains("وِرْدَك الْيَوْمِي"))
        assertTrue(eg("لا تنس الصلاة على النبي").contains("الصَّلَاة عَلَى النَّبِيِّ"))
    }

    @Test fun egyptianRespellingIsContextualOnly() {
        val s = eg("إزيك؟ عامل إيه؟")
        assertTrue(s, s.contains("إِزَّيَّكْ") && s.contains("إِيهْ"))
        assertTrue(eg("يلا بينا، متنساش أذكارك").contains("يَلَّا بِينَا"))
        // «تعمل» وحدها في جملة فصيحة لا تُغيَّر
        assertEquals("ماذا تعمل اليوم؟", eg("ماذا تعمل اليوم؟"))
        // لكن في جملة عامّية تتغير
        assertTrue(eg("لسه عندك فرصة تعمل خير").contains("لِسَّهْ"))
        // صوت مصري أصلي: لا تهجئة
        assertEquals("إزيك؟ عامل إيه؟", AP.prepare("إزيك؟ عامل إيه؟", Dialect.EGYPT, "ar-EG").text)
    }

    @Test fun dialectSupportIsHonest() {
        assertEquals(AP.DialectSupport.NATIVE, AP.dialectSupport(Dialect.EGYPT, "ar-EG"))
        assertEquals(AP.DialectSupport.APPROXIMATE, AP.dialectSupport(Dialect.EGYPT, "ar-XA"))
        assertEquals(AP.DialectSupport.APPROXIMATE, AP.dialectSupport(Dialect.EGYPT, null))
        assertEquals(AP.DialectSupport.NATIVE, AP.dialectSupport(Dialect.GULF, "ar_SA"))
    }

    @Test fun duplicatesAndSafeFallback() {
        assertEquals("أحسنت.", eg("أحسنت. أحسنت."))
        // تكرار الذكر المقصود داخل جملة واحدة لا يُحذف
        assertEquals(2, Regex("سُبْحَانَ").findAll(eg("سبحان الله سبحان الله")).count())
        // نص فارغ/رموز فقط يرجع الأصلي
        assertEquals("🤲", AP.prepare("🤲", Dialect.EGYPT).text)
        assertEquals("  ", AP.prepare("  ", Dialect.EGYPT).text)
        // التعطيل = النص الأصلي حرفيًا
        assertEquals("٣ مرات ﷺ", AP.prepare("٣ مرات ﷺ", Dialect.EGYPT, enabled = false).text)
    }

    @Test fun originalIsNeverMutated() {
        val src = "لسه عندك فرصة تعمل خير ٣ مرات"
        val copy = String(src.toCharArray())
        AP.prepare(src, Dialect.EGYPT)
        assertEquals(copy, src)
    }
}
