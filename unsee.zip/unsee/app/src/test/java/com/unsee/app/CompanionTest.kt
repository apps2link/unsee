package com.unsee.app

import com.unsee.app.core.AsrMethod
import com.unsee.app.core.CalcMethod
import com.unsee.app.core.Cities
import com.unsee.app.core.CompanionPersona
import com.unsee.app.core.CompanionPicker
import com.unsee.app.core.CompanionSchedule
import com.unsee.app.core.CompanionSettings
import com.unsee.app.core.GeoPoint
import com.unsee.app.core.LogAction
import com.unsee.app.core.LogCodec
import com.unsee.app.core.LogEntry
import com.unsee.app.core.LogKind
import com.unsee.app.core.LogStats
import com.unsee.app.core.Muhasaba
import com.unsee.app.core.MuhasabaCodec
import com.unsee.app.core.MuhasabaLogic
import com.unsee.app.core.Prayer
import com.unsee.app.core.PrayerEventKind
import com.unsee.app.core.PrayerLog
import com.unsee.app.core.PrayerStats
import com.unsee.app.core.PrayerTimes
import com.unsee.app.data.CompanionMessages
import com.unsee.app.data.MsgCategory
import com.unsee.app.data.MsgKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import kotlin.random.Random

private val CAIRO = ZoneId.of("Africa/Cairo")
private fun minutes(z: ZonedDateTime?): Int = z!!.hour * 60 + z.minute
private fun hm(h: Int, m: Int) = h * 60 + m

/**
 * القيم المرجعية لمواقيت الصلاة محسوبة بنسخة Python مستقلة من الخوارزمية نفسها (tools/verify)، وليست من جهة رسمية،
 * فهي تتحقق من صحة التحويل البرمجي وثبات الحساب. المطابقة مع الإمساكية الرسمية تتم يدويًا (انظر README).
 */
class PrayerTimesTest {
    private fun assertNear(expected: Int, actual: Int, tol: Int = 1) =
        assertTrue("expected $expected got $actual", Math.abs(expected - actual) <= tol)

    @Test fun julianDayOfJ2000() {
        assertEquals(2451544.5, PrayerTimes.julian(2000, 1, 1), 1e-9)
    }

    @Test fun cairoWinter() {
        val d = PrayerTimes.forDate(LocalDate.of(2026, 12, 21), Cities.DEFAULT, CalcMethod.EGYPT, AsrMethod.STANDARD, CAIRO)
        assertNear(hm(5, 14), minutes(d.fajr))
        assertNear(hm(6, 47), minutes(d.sunrise))
        assertNear(hm(11, 53), minutes(d.dhuhr))
        assertNear(hm(14, 41), minutes(d.asr))
        assertNear(hm(16, 59), minutes(d.maghrib))
        assertNear(hm(18, 23), minutes(d.isha))
    }

    @Test fun cairoSummerFollowsDaylightSaving() {
        val d = PrayerTimes.forDate(LocalDate.of(2026, 6, 21), Cities.DEFAULT, CalcMethod.EGYPT, AsrMethod.STANDARD, CAIRO)
        assertNear(hm(12, 57), minutes(d.dhuhr)) // ساعة أبعد من الشتاء بسبب التوقيت الصيفي
        assertNear(hm(19, 59), minutes(d.maghrib))
        assertNear(hm(21, 33), minutes(d.isha))
    }

    @Test fun hanafiAsrIsLaterAndOthersUnchanged() {
        val std = PrayerTimes.forDate(LocalDate.of(2026, 12, 21), Cities.DEFAULT, CalcMethod.EGYPT, AsrMethod.STANDARD, CAIRO)
        val han = PrayerTimes.forDate(LocalDate.of(2026, 12, 21), Cities.DEFAULT, CalcMethod.EGYPT, AsrMethod.HANAFI, CAIRO)
        assertNear(hm(15, 23), minutes(han.asr))
        assertTrue(minutes(han.asr) > minutes(std.asr))
        assertEquals(minutes(std.dhuhr), minutes(han.dhuhr))
    }

    @Test fun ummAlQuraIshaIsNinetyMinutesAfterMaghrib() {
        val mecca = GeoPoint("مكة", 21.3891, 39.8579)
        val d = PrayerTimes.forDate(LocalDate.of(2026, 6, 21), mecca, CalcMethod.UMM_AL_QURA, AsrMethod.STANDARD, ZoneId.of("Asia/Riyadh"))
        assertNear(hm(19, 5), minutes(d.maghrib))
        assertEquals(90, minutes(d.isha) - minutes(d.maghrib))
    }

    @Test fun orderIsMonotonicForEveryCityAndSeason() {
        for (city in Cities.ALL) for (date in listOf(LocalDate.of(2026, 3, 20), LocalDate.of(2026, 6, 21), LocalDate.of(2026, 12, 21))) {
            val d = PrayerTimes.forDate(date, city, CalcMethod.EGYPT, AsrMethod.STANDARD, ZoneId.of("UTC"))
            val list = listOf(d.fajr, d.sunrise, d.dhuhr, d.asr, d.maghrib, d.isha)
            assertTrue("${city.name} $date has null", list.all { it != null })
            val inst = list.map { it!!.toInstant() }
            assertEquals("${city.name} $date order", inst.sorted(), inst)
        }
    }

    @Test fun highLatitudeReturnsNullInsteadOfInventingTimes() {
        val london = GeoPoint("لندن", 51.5072, -0.1276)
        val d = PrayerTimes.forDate(LocalDate.of(2026, 6, 21), london, CalcMethod.MWL, AsrMethod.STANDARD, ZoneId.of("Europe/London"))
        assertNull(d.fajr)
        assertNull(d.isha)
        assertNotNull(d.dhuhr)
        assertNear(hm(13, 2), minutes(d.dhuhr))
    }

    @Test fun manualAdjustmentShiftsOnlyThatPrayer() {
        val base = PrayerTimes.forDate(LocalDate.of(2026, 12, 21), Cities.DEFAULT, CalcMethod.EGYPT, AsrMethod.STANDARD, CAIRO)
        val adj = PrayerTimes.forDate(LocalDate.of(2026, 12, 21), Cities.DEFAULT, CalcMethod.EGYPT, AsrMethod.STANDARD, CAIRO, listOf(0, 3, 0, -2, 0))
        assertEquals(minutes(base.dhuhr) + 3, minutes(adj.dhuhr))
        assertEquals(minutes(base.maghrib) - 2, minutes(adj.maghrib))
        assertEquals(minutes(base.fajr), minutes(adj.fajr))
    }
}

class CompanionScheduleTest {
    private fun at(h: Int, m: Int = 0, day: Int = 21) = ZonedDateTime.of(2026, 12, day, h, m, 0, 0, CAIRO)
    private val base = CompanionSettings(enabled = true)

    @Test fun dailySlotsAreAFixedGridCappedAtMax() {
        assertEquals(listOf(hm(9, 0), hm(11, 0), hm(13, 0), hm(15, 0), hm(17, 0)), CompanionSchedule.dailySlots(base))
        assertEquals(2, CompanionSchedule.dailySlots(base.copy(maxPerDay = 2)).size)
    }

    @Test fun quietHoursWrapAroundMidnight() {
        assertTrue(CompanionSchedule.isQuiet(hm(23, 30), base))
        assertTrue(CompanionSchedule.isQuiet(hm(3, 0), base))
        assertFalse(CompanionSchedule.isQuiet(hm(12, 0), base))
        assertFalse(CompanionSchedule.isQuiet(hm(23, 30), base.copy(quietEnabled = false)))
    }

    @Test fun quietHoursRemoveSlots() {
        val s = base.copy(startMin = hm(20, 0), endMin = hm(23, 59), intervalMin = 60, maxPerDay = 10)
        assertEquals(listOf(hm(20, 0), hm(21, 0), hm(22, 0)), CompanionSchedule.dailySlots(s))
    }

    @Test fun invalidWindowGivesNoSlots() {
        assertTrue(CompanionSchedule.dailySlots(base.copy(startMin = hm(18, 0), endMin = hm(9, 0))).isEmpty())
        assertNull(CompanionSchedule.nextDhikr(at(10), base.copy(startMin = hm(18, 0), endMin = hm(9, 0)), 0))
    }

    @Test fun nextDhikrPicksNextSlotAndIsDeterministic() {
        val a = CompanionSchedule.nextDhikr(at(10), base, 0)
        val b = CompanionSchedule.nextDhikr(at(10), base, 0)
        assertEquals(at(11), a)
        assertEquals(a, b) // إعادة الجدولة لا تغيّر الموعد فلا تتكرر التذكيرات
    }

    @Test fun nextDhikrRollsToTomorrowAfterLastSlotOrWhenCapReached() {
        assertEquals(at(9, 0, 22), CompanionSchedule.nextDhikr(at(17, 30), base, 0))
        assertEquals(at(9, 0, 22), CompanionSchedule.nextDhikr(at(8, 0), base, 5))
    }

    @Test fun nextDhikrIsStrictlyAfterNow() {
        val t = CompanionSchedule.nextDhikr(at(11, 0), base, 0)
        assertEquals(at(13), t)
    }

    @Test fun muhasabaScheduleOnlyWhenEnabled() {
        assertNull(CompanionSchedule.nextMuhasaba(at(10), base))
        val s = base.copy(muhasabaEnabled = true, muhasabaMin = hm(22, 30))
        assertEquals(at(22, 30), CompanionSchedule.nextMuhasaba(at(10), s))
        assertEquals(at(22, 30, 22), CompanionSchedule.nextMuhasaba(at(23, 0), s))
    }

    private val prayerSettings = base.copy(prayerEnabled = true)

    @Test fun nextPrayerEventIsDhuhrAtMidday() {
        val ev = CompanionSchedule.nextPrayerEvent(at(10), prayerSettings)!!
        assertEquals(Prayer.DHUHR, ev.prayer)
        assertEquals(PrayerEventKind.ADHAN, ev.kind)
        assertTrue(Math.abs(minutes(ev.at) - hm(11, 53)) <= 1)
    }

    @Test fun beforeAndAfterEventsAreOrderedAroundTheAdhan() {
        val s = prayerSettings.copy(beforeMin = 10, afterMin = 20)
        val first = CompanionSchedule.nextPrayerEvent(at(10), s)!!
        assertEquals(PrayerEventKind.BEFORE, first.kind)
        val adhan = CompanionSchedule.nextPrayerEvent(first.at, s)!!
        assertEquals(PrayerEventKind.ADHAN, adhan.kind)
        assertEquals(10L, java.time.Duration.between(first.at, adhan.at).toMinutes())
        val after = CompanionSchedule.nextPrayerEvent(adhan.at, s)!!
        assertEquals(PrayerEventKind.AFTER, after.kind)
        assertEquals(20L, java.time.Duration.between(adhan.at, after.at).toMinutes())
    }

    @Test fun afterEventSkippedWhenUserAlreadyLoggedThePrayer() {
        val s = prayerSettings.copy(afterMin = 20)
        val adhan = CompanionSchedule.nextPrayerEvent(at(10), s)!!
        val next = CompanionSchedule.nextPrayerEvent(adhan.at, s) { _, p -> p == Prayer.DHUHR }!!
        assertEquals(Prayer.ASR, next.prayer)
    }

    @Test fun disabledPrayersAreNeverScheduled() {
        val onlyIsha = prayerSettings.copy(prayerMask = Prayer.ISHA.bit)
        assertEquals(Prayer.ISHA, CompanionSchedule.nextPrayerEvent(at(10), onlyIsha)!!.prayer)
        assertNull(CompanionSchedule.nextPrayerEvent(at(10), prayerSettings.copy(prayerMask = 0)))
        assertNull(CompanionSchedule.nextPrayerEvent(at(10), base))
    }

    @Test fun afterIshaNextEventIsTomorrowsFajr() {
        val ev = CompanionSchedule.nextPrayerEvent(at(21), prayerSettings)!!
        assertEquals(Prayer.FAJR, ev.prayer)
        assertEquals(LocalDate.of(2026, 12, 22), ev.at.toLocalDate())
    }

    @Test fun eventKeyIsUniquePerDayPrayerAndKind() {
        val s = prayerSettings.copy(beforeMin = 5, afterMin = 5)
        val keys = CompanionSchedule.prayerEvents(LocalDate.of(2026, 12, 21), s, CAIRO).map { it.key }
        assertEquals(keys.size, keys.toSet().size)
        assertEquals(15, keys.size)
    }
}

class CompanionPickerTest {
    private val s = CompanionSettings(enabled = true)

    @Test fun sameSeedGivesSameMessage() {
        val a = CompanionPicker.pick(CompanionMessages.all, s, 12, emptyList(), Random(7))
        val b = CompanionPicker.pick(CompanionMessages.all, s, 12, emptyList(), Random(7))
        assertEquals(a, b)
    }

    @Test fun recentMessagesAreAvoidedWhenAlternativesExist() {
        val recent = CompanionMessages.all.drop(1).map { it.id }
        repeat(50) { seed ->
            val m = CompanionPicker.pick(CompanionMessages.all.filter { it.slot.name == "ANY" }, s, 12, recent, Random(seed))!!
            assertFalse(m.id in recent)
        }
    }

    @Test fun categoryFilterIsRespected() {
        val only = s.copy(categories = setOf(MsgCategory.PARENTS.name))
        repeat(50) { seed ->
            assertEquals(MsgCategory.PARENTS, CompanionPicker.pick(CompanionMessages.all, only, 12, emptyList(), Random(seed))!!.category)
        }
    }

    @Test fun timeSlotMessagesOnlyAtTheirTime() {
        val morningOnly = CompanionMessages.all.filter { it.id.startsWith("day_m") }
        repeat(30) { seed ->
            val m = CompanionPicker.pick(CompanionMessages.all, s.copy(categories = setOf(MsgCategory.DAY_ADHKAR.name)), 8, emptyList(), Random(seed))!!
            assertTrue(m in morningOnly || m.slot.name == "ANY")
        }
        val night = CompanionPicker.eligible(CompanionMessages.all, s, 13)
        assertTrue(night.none { it.slot.name == "NIGHT" })
    }

    @Test fun prayerPersonaFavoursPrayerMessages() {
        fun share(p: CompanionPersona): Double {
            val st = s.copy(persona = p)
            val n = 600
            val hits = (0 until n).count { CompanionPicker.pick(CompanionMessages.all, st, 13, emptyList(), Random(it))!!.category == MsgCategory.SALAH }
            return hits.toDouble() / n
        }
        assertTrue(share(CompanionPersona.PRAYER) > share(CompanionPersona.BALANCED) * 2)
    }
}

class CompanionMessagesTest {
    @Test fun idsAreUniqueAndTextsNotBlank() {
        val ids = CompanionMessages.all.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
        assertTrue(CompanionMessages.all.all { it.text.isNotBlank() })
    }

    @Test fun everyCategoryHasMessages() {
        for (c in MsgCategory.values()) assertTrue(c.title, CompanionMessages.forCategory(c).isNotEmpty())
    }

    @Test fun scriptureAlwaysHasSourceAndAdviceNeverPretendsToBeScripture() {
        for (m in CompanionMessages.all) {
            if (m.kind == MsgKind.ADVICE) {
                assertNull(m.id, m.source)
                assertNull(m.id, m.grade)
            } else {
                assertTrue("${m.id} source", !m.source.isNullOrBlank())
            }
            if (m.kind == MsgKind.QURAN) assertEquals(m.id, "قرآن", m.grade)
            // لا درجة إلا للقرآن أو المتفق عليه
            if (m.grade != null) assertTrue(m.id, m.grade == "قرآن" || m.grade == "متفق عليه")
        }
    }

    @Test fun noThreateningOrSurveillanceWording() {
        val banned = listOf("مراقب", "هتتحاسب", "عقاب", "جهنم", "أنت مذنب")
        for (m in CompanionMessages.all) for (w in banned) assertFalse("${m.id} contains $w", m.text.contains(w))
    }
}

class CompanionCodecTest {
    @Test fun muhasabaRoundTripKeepsSpecialCharacters() {
        val m = Muhasaba(
            "2026-12-21", 2, 1, 3, 5, "ساعدت جاري | وبرّيت أمي\nوكتبت \"ملاحظة\" 100%", "أصحى للفجر, وأقلل الموبايل",
            listOf("صفحة قرآن", "استغفار, خمس دقايق", "هدف | ثالث"), 12345L,
        )
        assertEquals(m, MuhasabaCodec.decode(MuhasabaCodec.encode(m)))
    }

    @Test fun muhasabaDecodeRejectsGarbage() {
        assertNull(MuhasabaCodec.decode("abc"))
        assertNull(MuhasabaCodec.decode("a|b|c|d|e|f|g|h|i"))
    }

    @Test fun muhasabaEmptyGoalsRoundTrip() {
        val m = Muhasaba("2026-12-21", prayers = 1)
        assertEquals(m, MuhasabaCodec.decode(MuhasabaCodec.encode(m)))
    }

    @Test fun logRoundTripAndGarbageSkipped() {
        val list = listOf(
            LogEntry(1L, LogKind.DHIKR, "ist_01", LogAction.SHOWN_BUBBLE),
            LogEntry(2L, LogKind.PRAYER, "2026-12-21|dhuhr", LogAction.PRAYED),
        )
        assertEquals(list, LogCodec.decode(LogCodec.encode(list) + "\nغير صالح\n9|X|y|Z"))
    }

    @Test fun logStatsCountOnlyRealInteractions() {
        val list = listOf(
            LogEntry(100, LogKind.DHIKR, "a", LogAction.SHOWN_BUBBLE),
            LogEntry(101, LogKind.DHIKR, "a", LogAction.DONE),
            LogEntry(102, LogKind.DHIKR, "b", LogAction.SHOWN_NOTIF),
            LogEntry(103, LogKind.DHIKR, "b", LogAction.SNOOZE),
            LogEntry(104, LogKind.PRAYER, "x|fajr", LogAction.UNDELIVERED),
            LogEntry(5, LogKind.DHIKR, "old", LogAction.DONE),
        )
        val c = LogStats.count(list, 100)
        assertEquals(2, c.shown); assertEquals(1, c.done); assertEquals(1, c.snoozed); assertEquals(1, c.undelivered); assertEquals(0, c.prayed)
    }
}

class MuhasabaLogicTest {
    @Test fun planUsesOnlyWhatTheUserAnsweredAndIsCapped() {
        val m = Muhasaba("d", prayers = 3, tongue = 2, quran = 3, good = 8, improve = "أقلل الموبايل", goals = listOf("هدف ١", "هدف ٢", "هدف ٣"))
        val plan = MuhasabaLogic.plan(m)
        assertEquals(4, plan.size)
        assertEquals("هدف ١", plan.first())
    }

    @Test fun emptyAnswersStillGiveOneGentleStep() {
        assertEquals(1, MuhasabaLogic.plan(Muhasaba("d")).size)
    }

    @Test fun userWhoPrayedAndReadGetsNoRemedialItems() {
        val plan = MuhasabaLogic.plan(Muhasaba("d", prayers = 1, tongue = 1, quran = 1))
        assertTrue(plan.none { it.contains("اختار صلاة") || it.contains("لسانك") || it.contains("ابدأ بصفحة") })
    }

    @Test fun summaryShowsRecordedPrayersOnlyWhenProvided() {
        val m = Muhasaba("d", prayers = 1)
        assertTrue(MuhasabaLogic.summary(m, null, null).none { it.contains("المسجّل") })
        assertTrue(MuhasabaLogic.summary(m, 4, 5).any { it.contains("المسجّل") })
    }
}

class PrayerStatsTest {
    @Test fun unrecordedIsNotCountedAsMissed() {
        val d = LocalDate.of(2026, 12, 21)
        val s = PrayerStats.day(d) { _, p ->
            when (p) { Prayer.FAJR -> PrayerLog.PRAYED; Prayer.DHUHR -> PrayerLog.MISSED; else -> PrayerLog.NONE }
        }
        assertEquals(1, s.prayed); assertEquals(1, s.missed); assertEquals(3, s.unrecorded)
    }
}
