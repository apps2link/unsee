package com.unsee.app

import com.unsee.app.core.BubbleLook
import com.unsee.app.core.BubbleMood
import com.unsee.app.core.CardKind
import com.unsee.app.core.LogKind
import org.junit.Assert.assertEquals
import org.junit.Test

class BubbleLookTest {
    @Test fun moodPriorityOrder() {
        assertEquals(BubbleMood.NORMAL, BubbleLook.mood(0, false, null, null))
        assertEquals(BubbleMood.NORMAL, BubbleLook.mood(0, true, LogKind.PRAYER, null))
        assertEquals(BubbleMood.URGENT, BubbleLook.mood(2, true, LogKind.DHIKR, null))
        assertEquals(BubbleMood.PRAYER, BubbleLook.mood(1, false, LogKind.PRAYER, null))
        assertEquals(BubbleMood.DHIKR, BubbleLook.mood(1, false, LogKind.DHIKR, null))
        assertEquals(BubbleMood.DHIKR, BubbleLook.mood(1, false, LogKind.HABIT, null))
        assertEquals(BubbleMood.REFLECT, BubbleLook.mood(1, false, LogKind.PLAN, null))
        assertEquals(BubbleMood.REFLECT, BubbleLook.mood(1, false, LogKind.MUHASABA, null))
        assertEquals(BubbleMood.REMINDER, BubbleLook.mood(1, false, null, null))
        // الاحتفال/المواساة المؤقتان يغلبان كل شيء
        assertEquals(BubbleMood.CELEBRATE, BubbleLook.mood(3, true, LogKind.PRAYER, BubbleMood.CELEBRATE))
        assertEquals(BubbleMood.COMFORT, BubbleLook.mood(0, false, null, BubbleMood.COMFORT))
    }

    @Test fun cardKinds() {
        assertEquals(CardKind.URGENT, BubbleLook.cardKind(LogKind.DHIKR, true))
        assertEquals(CardKind.PRAYER, BubbleLook.cardKind(LogKind.PRAYER, false))
        assertEquals(CardKind.REFLECT, BubbleLook.cardKind(LogKind.PLAN, false))
        assertEquals(CardKind.REFLECT, BubbleLook.cardKind(LogKind.MUHASABA, false))
        assertEquals(CardKind.DHIKR, BubbleLook.cardKind(LogKind.DHIKR, false))
        assertEquals(CardKind.DHIKR, BubbleLook.cardKind(LogKind.HABIT, false))
    }
}
