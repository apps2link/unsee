package com.unsee.app

import com.unsee.app.data.AdhkarData
import com.unsee.app.data.Category
import com.unsee.app.data.HisnMeta
import com.unsee.app.data.LegacyIdMap
import com.unsee.app.data.ZikrKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** سلامة قاعدة «حصن المسلم»: أرقام وبنية الكتاب كما في الأصل (تتحقق من تولّد البيانات كاملة). */
class HisnBookTest {
    private val rows = AdhkarData.rows()

    @Test fun bookStructureMatchesTheOriginal() {
        assertEquals(132, HisnMeta.CHAPTERS)
        assertEquals(132, AdhkarData.chapters.count { it.no > 0 })
        assertEquals(281, rows.size)
        // الأذكار المرقَّمة 1..267 كلها موجودة بلا فجوة ولا تكرار في الرقم الرئيسي
        val numbers = rows.filter { it.kind == ZikrKind.DHIKR }.map { it.bookNo }.toSortedSet()
        assertEquals((1..267).toList(), numbers.toList())
    }

    @Test fun allFootnotesPresentExactlyOnce() {
        val ns = rows.flatMap { r -> r.footnotes.map { it.n } } + AdhkarData.prefaceFootnotes.map { it.n }
        assertEquals((2..315).toList(), ns.sorted())
    }

    @Test fun rowIdsAreUnique() {
        assertEquals(rows.size, rows.map { it.id }.toSet().size)
    }

    @Test fun noRawFontGlyphsOrFootnoteMarkersLeak() {
        val bad = Regex("[\\uFB50-\\uFBFF%^\\u00D7\\u2018\\u2019]|\\{\\{|\\(\\)")
        for (r in rows) {
            assertTrue("رمز خام في ${r.id}", !bad.containsMatchIn(r.text))
            for (f in r.footnotes) assertTrue("رمز خام في حاشية ${f.n}", !bad.containsMatchIn(f.text))
        }
    }

    @Test fun everyCategoryHasEntriesAndIdsAreGloballyUnique() {
        for (c in Category.values()) assertTrue(c.name, AdhkarData.readerList(c).isNotEmpty())
        val ids = Category.values().flatMap { AdhkarData.readerList(it) }.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
    }

    @Test fun legacyMapTargetsExist() {
        for ((old, new) in LegacyIdMap.map) assertTrue("$old -> $new", AdhkarData.byId(new) != null)
    }

    @Test fun counterOnlyForCountableKinds() {
        for (z in AdhkarData.all) assertTrue(z.id, z.countable || z.kind == ZikrKind.FADL)
    }
}
