package com.unsee.app

import com.unsee.app.core.Palettes
import com.unsee.app.core.RingCodec
import com.unsee.app.core.RingConfig
import com.unsee.app.core.RingDesign
import com.unsee.app.core.ThemeId
import com.unsee.app.core.ringFraction
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RingModelTest {
    @Test fun fifteenDistinctDesigns() {
        assertEquals(15, RingDesign.values().size)
        assertEquals(15, RingDesign.values().map { it.label }.toSet().size)
    }

    @Test fun configRoundTrip() {
        val c = RingConfig(
            design = RingDesign.WATER_RIPPLE, ringSize = 0.8f, digitScale = 1.3f, font = 2, thickness = 1.2f,
            digitColor = 0xFFFFF4D6L, ringColor = 0xFF5BD6A8L, bgColor = 0xFF102030L, bgAlpha = 40,
            animate = false, speed = 1.5f, glow = 0.5f, showName = true, showGoal = false, haptic = false, sound = 2, variant = 1,
        )
        assertEquals(c, RingCodec.decode(RingCodec.encode(c)))
    }

    @Test fun badInputFallsBackToDefaultsAndClamps() {
        assertEquals(RingConfig(), RingCodec.decode(null))
        assertEquals(RingConfig(), RingCodec.decode("garbage;;==;x"))
        val c = RingCodec.decode("d=NOPE;rs=9;ds=-3;th=abc;ba=500;so=99;va=-4;sp=100;gl=-1")
        assertEquals(RingDesign.GOLD_HALO, c.design)
        assertEquals(1.1f, c.ringSize, 0.0001f)
        assertEquals(0.6f, c.digitScale, 0.0001f)
        assertEquals(1f, c.thickness, 0.0001f)
        assertEquals(100, c.bgAlpha)
        assertEquals(3, c.sound)
        assertEquals(0, c.variant)
        assertEquals(2.5f, c.speed, 0.0001f)
        assertEquals(0f, c.glow, 0.0001f)
    }

    @Test fun switchingDesignKeepsCustomisation() {
        val c = RingConfig(ringSize = 0.7f, ringColor = 0xFFE2B857L, speed = 0.5f)
        val d = c.copy(design = RingDesign.GALAXY)
        assertEquals(0.7f, d.ringSize, 0f)
        assertEquals(0xFFE2B857L, d.ringColor)
        assertEquals(0.5f, d.speed, 0f)
    }

    @Test fun presetsKeepNamesSanitiseAndReplace() {
        var list = emptyList<Pair<String, RingConfig>>()
        list = RingCodec.upsert(list, "ذهبي | هادئ\nجدًا", RingConfig(design = RingDesign.GOLD_HALO))
        list = RingCodec.upsert(list, "مجرتي", RingConfig(design = RingDesign.GALAXY))
        list = RingCodec.upsert(list, "مجرتي", RingConfig(design = RingDesign.PULSE))
        assertEquals(2, list.size)
        val back = RingCodec.decodePresets(RingCodec.encodePresets(list))
        assertEquals(2, back.size)
        assertFalse(back[0].first.contains('|') || back[0].first.contains('\n'))
        assertEquals(RingDesign.PULSE, back.first { it.first == "مجرتي" }.second.design)
        assertEquals("تصميمي", RingCodec.cleanName("   "))
    }

    @Test fun presetsCapped() {
        var list = emptyList<Pair<String, RingConfig>>()
        for (i in 0 until 50) list = RingCodec.upsert(list, "p$i", RingConfig())
        assertEquals(RingCodec.MAX_PRESETS, list.size)
        assertEquals("p49", list.last().first)
    }

    @Test fun fraction() {
        assertEquals(0.5f, ringFraction(5, 10), 0.0001f)
        assertEquals(1f, ringFraction(50, 10), 0f)
        assertEquals(1f, ringFraction(0, 0), 0f)
    }
}

class AnimatedThemesTest {
    @Test fun thirtyAnimatedThemesWithNatureFirst() {
        val a = ThemeId.animatedSet
        assertEquals(30, a.size)
        assertEquals(ThemeId.NATURE, a.first())
        assertEquals(30, a.map { it.label }.toSet().size)
    }

    @Test fun classicThemesPreserved() {
        val names = ThemeId.classicSet.map { it.name }
        for (n in listOf("SOFT", "EMERALD", "BLACK", "WHITE", "NIGHT", "PURPLE", "PATTERN")) assertTrue(n, n in names)
        assertTrue(ThemeId.classicSet.none { it.animated })
    }

    @Test fun fixedModeThemesIgnoreRequestedMode() {
        for (id in ThemeId.animatedSet) {
            val want = id.fixedDark!!
            assertEquals(id.name, want, Palettes.spec(id, true).dark)
            assertEquals(id.name, Palettes.spec(id, true), Palettes.spec(id, false))
        }
    }

    @Test fun animatedPalettesReadableForEveryAccent() {
        for (id in ThemeId.animatedSet) {
            val p = Palettes.spec(id, true)
            for ((name, pair) in Palettes.ACCENTS) {
                val c = if (p.dark) pair.first else pair.second
                assertTrue("$id $name", Palettes.contrast(c, p.card) >= 4.5)
            }
        }
    }
}
