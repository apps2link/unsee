package com.unsee.app

import com.unsee.app.core.Arabic
import com.unsee.app.core.DayPart
import com.unsee.app.core.TimeLogic
import com.unsee.app.core.WidgetLogic
import com.unsee.app.core.WidgetSource
import com.unsee.app.data.AdhkarData
import com.unsee.app.data.Category
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import java.time.ZoneId
import java.time.ZonedDateTime
import org.junit.Test

class AdhkarDataTest {
    @Test fun idsAreUnique() {
        val ids = AdhkarData.all.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
    }

    @Test fun everyEntryHasTextSourceAndValidCount() {
        for (z in AdhkarData.all) {
            assertTrue("نص فارغ: ${z.id}", z.text.isNotBlank())
            assertTrue("مصدر فارغ: ${z.id}", z.source.isNotBlank())
            assertTrue("عدد غير صالح: ${z.id}", z.count >= 0)
        }
    }

    @Test fun everyCategoryHasEntries() {
        for (c in Category.values()) assertTrue(c.name, AdhkarData.forCategory(c).isNotEmpty())
    }

    @Test fun textsAreDiacritized() {
        // نصوص الكتاب الطويلة مشكولة (الفتحة U+064E أو الضمة U+064F أو الكسرة U+0650)
        for (z in AdhkarData.all.filter { it.text.length > 20 }) {
            assertTrue("بلا تشكيل: ${z.id}", z.text.any { it in '\u064E'..'\u0650' })
        }
    }

    @Test fun knownCountsAreAsPrintedInTheBook() {
        assertEquals(3, AdhkarData.byId("m_h76")?.count)    // الإخلاص والمعوذتان: ثلاث مرات
        assertEquals(100, AdhkarData.byId("m_h91")?.count)  // سبحان الله وبحمده: مائة مرة
        assertEquals(100, AdhkarData.byId("m_h93")?.count)  // التهليل مائة مرة إذا أصبح
        assertEquals(10, AdhkarData.byId("m_h98")?.count)   // الصلاة على النبي عشر مرات
        assertEquals(7, AdhkarData.byId("m_h83")?.count)    // حسبي الله: سبع مرات
        assertEquals(1, AdhkarData.byId("m_h75")?.count)    // آية الكرسي: لا عدد في الكتاب فيُعدّ مرة واحدة
    }

    @Test fun legacyIdsResolveToBookEntries() {
        assertEquals("m_h75", AdhkarData.byId("m_kursi")?.id)
        assertEquals(false, AdhkarData.byId("m_kursi")?.text.isNullOrBlank())
    }

    @Test fun timeBoundItemsAppearOnlyInTheirPeriod() {
        // الكتاب قيّد هذه الأذكار بـ «إذا أصبح» أو «إذا أمسى»
        assertTrue(AdhkarData.byId("m_h93") != null && AdhkarData.byId("e_h93") == null)
        assertTrue(AdhkarData.byId("m_h94") != null && AdhkarData.byId("e_h94") == null)
        assertTrue(AdhkarData.byId("e_h97") != null && AdhkarData.byId("m_h97") == null)
    }

    @Test fun searchFindsBookTextIgnoringDiacritics() {
        assertTrue(AdhkarData.search("القيوم").isNotEmpty())
        assertTrue(AdhkarData.search("75").any { it.bookNo == 75 })
        assertTrue(AdhkarData.search("القيوم", Category.TRAVEL).isEmpty())
    }
}

class LogicTest {
    @Test fun arabicDigits() {
        assertEquals("١٢٣٤٥٦٧٨٩٠", Arabic.digits(1234567890))
        assertEquals("٣/٣٣", Arabic.digits("3/33"))
    }

    @Test fun dayParts() {
        assertEquals(DayPart.DAWN, TimeLogic.dayPart(5))
        assertEquals(DayPart.DAY, TimeLogic.dayPart(12))
        assertEquals(DayPart.SUNSET, TimeLogic.dayPart(17))
        assertEquals(DayPart.NIGHT, TimeLogic.dayPart(23))
        assertEquals(DayPart.NIGHT, TimeLogic.dayPart(2))
    }

    @Test fun suggestedCategory() {
        assertEquals(Category.MORNING, TimeLogic.suggestedCategory(8))
        assertEquals(Category.EVENING, TimeLogic.suggestedCategory(20))
    }

    @Test fun delayUntilNext() {
        val utc = ZoneId.of("UTC")
        val now = ZonedDateTime.of(2026, 10, 26, 10, 0, 0, 0, utc)
        assertEquals(60 * 60_000L, TimeLogic.delayUntilNext(now, 11 * 60))          // بعد ساعة
        assertEquals(23 * 60 * 60_000L, TimeLogic.delayUntilNext(now, 9 * 60))      // غدًا
        assertEquals(24 * 60 * 60_000L, TimeLogic.delayUntilNext(now, 10 * 60))     // نفس الوقت = غدًا
    }

    @Test fun rotatingIndexWrapsAndShifts() {
        val slot = WidgetLogic.ROTATE_SLOT_MS
        assertEquals(0, WidgetLogic.rotatingIndex(0, 5, 123))
        val a = WidgetLogic.rotatingIndex(5, 0, 10 * slot)
        val b = WidgetLogic.rotatingIndex(5, 1, 10 * slot)
        assertEquals((a + 1) % 5, b)
        assertEquals(4, WidgetLogic.manualIndex(5, -1))
    }

    @Test fun widgetPools() {
        val morning = WidgetLogic.pool(WidgetSource.AUTO, 8, emptySet(), false)
        assertTrue(morning.all { it.category == Category.MORNING })
        val evening = WidgetLogic.pool(WidgetSource.AUTO, 20, emptySet(), false)
        assertTrue(evening.all { it.category == Category.EVENING })
        // مفضلة فارغة تعود إلى كل الأذكار بدل ودجت فارغة
        assertEquals(AdhkarData.all.size, WidgetLogic.pool(WidgetSource.FAVORITES, 8, emptySet(), false).size)
        assertEquals(1, WidgetLogic.pool(WidgetSource.FAVORITES, 8, setOf("m_h75"), false).size)
        assertTrue(WidgetLogic.pool(WidgetSource.ALL, 8, emptySet(), true).all { it.isShort })
    }
}
