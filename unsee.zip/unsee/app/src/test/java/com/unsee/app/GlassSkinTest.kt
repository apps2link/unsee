package com.unsee.app

import com.unsee.app.core.LogKind
import com.unsee.app.overlay.BubbleMood
import com.unsee.app.overlay.GlassMood
import com.unsee.app.overlay.GlassSkin
import com.unsee.app.overlay.SpringInterpolator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** منطق حالات الفقاعة/البطاقة الزجاجية (بلا أي View): الاختيار، التباين، والنابض. */
class GlassSkinTest {
    @Test fun emptyPendingIsNormal() {
        assertEquals(BubbleMood.NORMAL, GlassMood.forPending(emptyList(), false))
    }

    @Test fun priorityBeatsEverything() {
        assertEquals(BubbleMood.URGENT, GlassMood.forPending(listOf(LogKind.DHIKR, LogKind.PRAYER), true))
        assertEquals(BubbleMood.URGENT, GlassMood.forItem(LogKind.PLAN, true))
    }

    @Test fun prayerBeatsDhikrThenGenericNew() {
        assertEquals(BubbleMood.PRAYER, GlassMood.forPending(listOf(LogKind.DHIKR, LogKind.PRAYER), false))
        assertEquals(BubbleMood.DHIKR, GlassMood.forPending(listOf(LogKind.DHIKR, LogKind.HABIT), false))
        assertEquals(BubbleMood.NEW, GlassMood.forPending(listOf(LogKind.HABIT), false))
        assertEquals(BubbleMood.NEW, GlassMood.forItem(LogKind.MUHASABA, false))
    }

    @Test fun everyMoodHasDistinctAccent() {
        val accents = BubbleMood.values().map { GlassSkin.of(it, true).accentA }
        assertEquals(accents.size, accents.toSet().size)
    }

    @Test fun lightSkinTextIsDarkAndDarkSkinTextIsLight() {
        fun lum(c: Int): Double = 0.299 * ((c shr 16) and 0xFF) + 0.587 * ((c shr 8) and 0xFF) + 0.114 * (c and 0xFF)
        BubbleMood.values().forEach { m ->
            assertTrue(lum(GlassSkin.of(m, false).textPrimary) < 90)
            assertTrue(lum(GlassSkin.of(m, true).textPrimary) > 190)
            // عنوان الوضع الفاتح مُغمَّق ليبقى مقروءًا فوق السطح الأبيض
            assertTrue(lum(GlassSkin.of(m, false).titleColor) < 170)
        }
    }

    @Test fun surfacesStayTranslucentButReadable() {
        BubbleMood.values().forEach { m ->
            listOf(true, false).forEach { dark ->
                val s = GlassSkin.of(m, dark)
                val a = (s.surfaceTop ushr 24) and 0xFF
                assertTrue("شفافية السطح يجب ألا تقل عن 200 كي يبقى النص واضحًا بدون Blur", a >= 200)
                assertNotEquals(0xFF, a)   // وليس معتمًا تمامًا: يبقى زجاجًا
            }
        }
    }

    @Test fun springStartsAtZeroEndsAtOneAndOvershoots() {
        val sp = SpringInterpolator()
        assertEquals(0f, sp.getInterpolation(0f), 0f)
        assertEquals(1f, sp.getInterpolation(1f), 0f)
        val peak = (1..99).maxOf { sp.getInterpolation(it / 100f) }
        assertTrue("النابض يرتد قليلًا فوق ١ قبل الاستقرار", peak > 1.0f)
        assertTrue("والارتداد خفيف", peak < 1.2f)
    }

    @Test fun withAlphaKeepsRgb() {
        assertEquals(0x80E2B857.toInt(), GlassSkin.withAlpha(0xFFE2B857.toInt(), 0x80))
        assertEquals(0x00E2B857, GlassSkin.withAlpha(0xFFE2B857.toInt(), -5))
    }
}
