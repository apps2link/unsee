package com.unsee.app

import com.unsee.app.core.ArabicText
import com.unsee.app.data.AdhkarData
import com.unsee.app.data.Category
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** الإخلاص والفلق والناس: بطاقة مستقلة لكل سورة في الصباح والمساء (الكتاب يجمعها في ذكر واحد رقم 76). */
class MuawwidhatSplitTest {
    private fun n(s: String) = ArabicText.normalize(s)

    @Test fun threeSeparateCardsInMorningAndEvening() {
        for (p in listOf("m_", "e_")) {
            val z = listOf("h76", "h76b", "h76c").map { AdhkarData.byId(p + it) }
            z.forEach { assertNotNull(p, it) }
            assertEquals(listOf("سورة الإخلاص", "سورة الفلق", "سورة الناس"), z.map { it!!.title })
            z.forEach { assertEquals(3, it!!.count); assertTrue(it.footnotes.isNotEmpty()) }
            assertTrue(n(z[0]!!.text).contains("الصمد")); assertFalse(n(z[0]!!.text).contains("الفلق")); assertFalse(n(z[0]!!.text).contains("الوسواس"))
            assertTrue(n(z[1]!!.text).contains("الفلق")); assertFalse(n(z[1]!!.text).contains("الصمد")); assertFalse(n(z[1]!!.text).contains("الوسواس"))
            assertTrue(n(z[2]!!.text).contains("الوسواس")); assertFalse(n(z[2]!!.text).contains("الصمد")); assertFalse(n(z[2]!!.text).contains("الفلق"))
            z.forEach { assertTrue(n(it!!.text).startsWith(n("بسم الله الرحمن الرحيم"))) }
        }
    }

    @Test fun cardsAreConsecutiveInReaderOrder() {
        val ids = AdhkarData.readerList(Category.MORNING).map { it.id }
        val i = ids.indexOf("m_h76")
        assertTrue(i >= 0)
        assertEquals(listOf("m_h76", "m_h76b", "m_h76c"), ids.subList(i, i + 3))
    }

    @Test fun legacyIdsMapToTheirOwnSurah() {
        assertEquals("m_h76", AdhkarData.byId("m_ikhlas")?.id)
        assertEquals("m_h76b", AdhkarData.byId("m_falaq")?.id)
        assertEquals("e_h76c", AdhkarData.byId("e_nas")?.id)
    }
}
