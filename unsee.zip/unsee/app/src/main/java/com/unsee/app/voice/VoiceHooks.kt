package com.unsee.app.voice

import android.content.Context
import com.unsee.app.core.Dialect
import com.unsee.app.core.LogKind
import com.unsee.app.core.Reminder
import com.unsee.app.core.ReminderKind
import com.unsee.app.core.SpeechPriority
import com.unsee.app.core.SpeechScript
import com.unsee.app.core.SpokenKind
import com.unsee.app.core.VoiceSection
import com.unsee.app.data.CompanionStore
import com.unsee.app.notify.Presentation
import java.time.LocalDate
import java.time.LocalTime
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * الجسر بين الإشعارات/الرفيق وبين محرك الصوت. إدارة الإشعارات (النص) منفصلة تمامًا عن إدارة الكلام:
 * الإشعار النصي يُنشر دائمًا كما كان، وهذه الدوال تطلب النطق فقط إن سمحت الإعدادات.
 * الـ Workers تنتظر انتهاء الكلام ([awaitAll]) فلا تُنهى العملية في منتصفه، دون خدمة أمامية ودون صلاحيات إضافية.
 */
object VoiceHooks {
    private val ids = ConcurrentLinkedQueue<String>()

    private fun gulf(ctx: Context) = runCatching { CompanionStore.get(ctx).dialect() == Dialect.GULF }.getOrDefault(false)
    private fun track(id: String?) { if (id != null) ids.add(id) }

    suspend fun awaitAll(timeoutMs: Long = 60_000L) {
        while (true) {
            val id = ids.poll() ?: break
            VoiceEngine.await(id, timeoutMs)
        }
    }

    /** تذكير الأذكار المجدول (WorkManager). */
    fun onReminder(ctx: Context, r: Reminder, title: String, text: String) {
        val s = VoiceStore.get(ctx).current()
        if (!s.section(VoiceSection.NOTIFY).auto) return
        val kind = when (r.kind) {
            ReminderKind.MORNING -> SpokenKind.REMINDER_MORNING
            ReminderKind.EVENING -> SpokenKind.REMINDER_EVENING
            ReminderKind.CUSTOM -> SpokenKind.REMINDER_CUSTOM
        }
        val spoken = SpeechScript.compose(kind, title, text, gulf(ctx), s.speakTitle, r.label)
        val key = "rem|${r.id}|${LocalDate.now()}|${LocalTime.now().hour}"
        track(VoiceEngine.speak(ctx, spoken, VoiceSection.NOTIFY, SpeechPriority.NORMAL, key, notification = true, title = title))
    }

    /** رسالة الرفيق (فقاعة أو إشعار). */
    fun onPresentation(ctx: Context, p: Presentation) {
        val s = VoiceStore.get(ctx).current()
        val (section, kind) = when (p.kind) {
            LogKind.DHIKR -> VoiceSection.COMPANION to SpokenKind.DHIKR_MESSAGE
            LogKind.HABIT -> VoiceSection.COMPANION to SpokenKind.HABIT
            LogKind.PRAYER -> VoiceSection.NOTIFY to SpokenKind.PRAYER
            LogKind.PLAN -> VoiceSection.NOTIFY to SpokenKind.PLAN
            LogKind.MUHASABA -> VoiceSection.MUHASABA to SpokenKind.MUHASABA
        }
        if (!s.section(section).auto) return
        val spoken = SpeechScript.compose(kind, p.title, p.text, gulf(ctx), s.speakTitle)
        val key = "cmp|${p.kind}|${p.ref}|${LocalDate.now()}|${LocalTime.now().hour}"
        val prio = if (p.priority) SpeechPriority.HIGH else SpeechPriority.NORMAL
        track(VoiceEngine.speak(ctx, spoken, section, prio, key, notification = true, title = p.title))
    }

    /** عند إتمام هدف المسبحة: ينطق الذكر نفسه إن فُعّل التشغيل التلقائي لقسم العدّاد. */
    fun onTasbihComplete(ctx: Context, phrase: String) {
        val s = VoiceStore.get(ctx).current()
        if (!s.section(VoiceSection.TASBIH).auto) return
        VoiceEngine.speak(ctx, SpeechScript.clean(phrase), VoiceSection.TASBIH, SpeechPriority.LOW)
    }

    // ------------------------------------------------------------ رسائل التشجيع
    private val goodEg = listOf("أحسنت، ربنا يتقبل منك", "ما شاء الله، كمّل على كده", "جزاك الله خيرًا، حسنة جديدة في ميزانك")
    private val goodGulf = listOf("أحسنت، الله يتقبل منك", "ما شاء الله، واصل", "جزاك الله خيرًا، حسنة جديدة في ميزانك")
    private val badEg = listOf("استغفر الله، وابدأ من جديد", "ما تيأسش من رحمة ربنا، وارجع له")
    private val badGulf = listOf("استغفر الله، وابدأ من جديد", "لا تيأس من رحمة الله، وارجع له")

    fun encourage(ctx: Context, good: Boolean) {
        val s = VoiceStore.get(ctx).current()
        if (!s.section(VoiceSection.ENCOURAGE).auto) return
        val g = gulf(ctx)
        val list = if (good) (if (g) goodGulf else goodEg) else (if (g) badGulf else badEg)
        val text = list[Math.floorMod((System.currentTimeMillis() / 1000).toInt(), list.size)]
        VoiceEngine.speak(ctx, text, VoiceSection.ENCOURAGE, SpeechPriority.LOW)
    }

    /** نطق بطلب المستخدم (زر استماع): لا يخضع لساعات الهدوء، ويقطع ما يُقال حاليًا. */
    fun speakNow(ctx: Context, text: String, section: VoiceSection, title: String = ""): Boolean {
        val spoken = SpeechScript.clean(text)
        return VoiceEngine.speak(ctx, spoken, section, SpeechPriority.HIGH, notification = false, title = title, ignoreGate = false) != null
    }
}
