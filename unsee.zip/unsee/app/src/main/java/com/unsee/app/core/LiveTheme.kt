package com.unsee.app.core

import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.max
import kotlin.math.min

/**
 * وضع المظهر الحي. AUTO_TIME يتبع الوقت الحقيقي وشروق/غروب موقعك، SYSTEM يتبع وضع الهاتف،
 * وLIGHT/DARK ثابتان. التغيير التلقائي يُعطَّل نهائيًا باختيار LIGHT أو DARK (أو مفتاح «التغيير التلقائي» في الإعدادات).
 */
enum class Appearance(val label: String, val blurb: String) {
    AUTO_TIME("حسب الوقت", "نهار وليل بحسب شروق وغروب منطقتك"),
    SYSTEM("حسب النظام", "يتبع وضع الهاتف الليلي أو النهاري"),
    LIGHT("نهاري", "مشهد النهار ثابتًا"),
    DARK("ليلي", "مشهد الليل ثابتًا");

    val isAuto: Boolean get() = this == AUTO_TIME || this == SYSTEM
}

data class SunWindow(val sunriseMin: Int, val sunsetMin: Int) {
    companion object {
        val DEFAULT = SunWindow(6 * 60, 18 * 60)
    }
}

enum class SkyPhase(val label: String) { NIGHT("ليل"), DAWN("فجر وشروق"), DAY("نهار"), DUSK("غروب") }

/** منطق الوقت الحي: دوال نقية بلا Android كي تُختبر على JVM. كل الأوقات بالدقائق منذ منتصف الليل. */
object LiveClock {
    /** مدة الانتقال بين الليل والنهار حول الشروق والغروب (بالدقائق). */
    const val RAMP_MIN = 60

    private fun smooth(x: Float): Float {
        val c = x.coerceIn(0f, 1f)
        return c * c * (3f - 2f * c)
    }

    /** 0 = ليل كامل، 1 = نهار كامل، وبينهما تدرّج ناعم حول الشروق والغروب. */
    fun dayBlend(minutes: Float, w: SunWindow, ramp: Int = RAMP_MIN): Float {
        val half = ramp / 2f
        val rise = smooth((minutes - (w.sunriseMin - half)) / ramp)
        val fall = smooth(((w.sunsetMin + half) - minutes) / ramp)
        return min(rise, fall)
    }

    /** الهدف النهائي للمزج حسب وضع المظهر. */
    fun targetBlend(appearance: Appearance, minutes: Float, w: SunWindow, systemDark: Boolean): Float = when (appearance) {
        Appearance.AUTO_TIME -> dayBlend(minutes, w)
        Appearance.SYSTEM -> if (systemDark) 0f else 1f
        Appearance.LIGHT -> 1f
        Appearance.DARK -> 0f
    }

    /** موضع الشمس على قوس النهار 0..1 (يُثبَّت عند الطرفين). */
    fun sunProgress(minutes: Float, w: SunWindow): Float =
        ((minutes - w.sunriseMin) / max(1, w.sunsetMin - w.sunriseMin).toFloat()).coerceIn(0f, 1f)

    /** موضع القمر على قوس الليل 0..1 من الغروب حتى الشروق التالي (يعالج عبور منتصف الليل). */
    fun moonProgress(minutes: Float, w: SunWindow): Float {
        val nightLen = (1440 - w.sunsetMin + w.sunriseMin).toFloat()
        val pos = if (minutes >= w.sunsetMin) minutes - w.sunsetMin else minutes + 1440 - w.sunsetMin
        return (pos / max(1f, nightLen)).coerceIn(0f, 1f)
    }

    fun phase(minutes: Float, w: SunWindow): SkyPhase {
        val b = dayBlend(minutes, w)
        return when {
            b >= 0.98f -> SkyPhase.DAY
            b <= 0.02f -> SkyPhase.NIGHT
            minutes < 12 * 60 -> SkyPhase.DAWN
            else -> SkyPhase.DUSK
        }
    }

    /** مشهد القرار الثنائي لألوان الواجهة (البطاقات والنصوص): نهاري إن كان المزج ≥ 0.5. */
    fun uiDay(skyBlend: Float): Float = if (skyBlend >= 0.5f) 1f else 0f

    /** شروق وغروب اليوم لموقع المستخدم؛ وإن تعذّر الحساب (قطبي/إحداثيات سيئة) تُستخدم 6:00 و18:00. */
    fun sunWindow(lat: Double, lng: Double, date: LocalDate, zone: ZoneId): SunWindow {
        val t = runCatching {
            PrayerTimes.forDate(date, GeoPoint("", lat, lng), CalcMethod.values().first(), AsrMethod.values().first(), zone)
        }.getOrNull() ?: return SunWindow.DEFAULT
        val sr = t.sunrise?.let { it.hour * 60 + it.minute }
        val ss = t.maghrib?.let { it.hour * 60 + it.minute }
        return if (sr != null && ss != null && ss - sr in 240..1200) SunWindow(sr, ss) else SunWindow.DEFAULT
    }
}
