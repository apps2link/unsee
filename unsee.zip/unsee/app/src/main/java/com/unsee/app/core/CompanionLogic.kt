package com.unsee.app.core

import com.unsee.app.data.CompanionMsg
import com.unsee.app.data.MsgCategory
import com.unsee.app.data.MsgKind
import com.unsee.app.data.MsgSlot
import java.net.URLDecoder
import java.net.URLEncoder
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import kotlin.random.Random

// ============================================================================ الشخصيات (اختلاف في اختيار الرسائل فقط)
/**
 * ليست ذكاءً اصطناعيًا: كل شخصية مجرد أوزان مختلفة لاختيار الرسائل من المكتبة المحلية.
 */
enum class CompanionPersona(val label: String, val blurb: String) {
    CALM("رفيق هادئ", "آيات وأذكار قصيرة وكلمات رحمة"),
    EGYPTIAN("رفيق مصري بسيط", "تذكيرات مباشرة بلهجة قريبة"),
    PRAYER("رفيق الصلاة", "تركيز على المحافظة على الصلاة"),
    DHIKR_QURAN("رفيق الذكر والقرآن", "استغفار وتسبيح وصلاة على النبي وقرآن"),
    MUHASABA("رفيق محاسبة النفس", "مراجعة وأمل وحسن خلق"),
    BALANCED("رفيق متوازن", "من كل الفئات بالتساوي"),
}

// ============================================================================ الإعدادات
data class CompanionSettings(
    // تذكيرات الذكر العامة
    val enabled: Boolean = false,
    val persona: CompanionPersona = CompanionPersona.BALANCED,
    /** أسماء [MsgCategory] المختارة؛ فارغة = كل الفئات. */
    val categories: Set<String> = emptySet(),
    val startMin: Int = 9 * 60,
    val endMin: Int = 22 * 60,
    val intervalMin: Int = 120,
    val maxPerDay: Int = 5,
    val quietEnabled: Boolean = true,
    val quietStartMin: Int = 23 * 60,
    val quietEndMin: Int = 6 * 60,
    // الفقاعة العائمة
    val bubble: Boolean = false,
    val bubbleSeconds: Int = 10,
    val bubbleStyle: Int = 0, // موروث (لم يعد يؤثر: الفقاعة الآن بأيقونة التطبيق)
    val bubbleAlways: Boolean = true, // الفقاعة ظاهرة دائمًا كأيقونة، والنقطة الحمراء تعني رسالة جديدة
    val dialectPref: DialectPref = DialectPref.AUTO,
    val sfx: Boolean = true,          // مؤثرات صوتية (تصفيق/تنبيه...) بلا موسيقى ولا تلاوة
    val habitEnabled: Boolean = true, // تذكير بالأعمال الصالحة التي سُجّلت أمس ولم تُسجَّل اليوم
    val habitMin: Int = 17 * 60,
    // الصلاة
    val prayerEnabled: Boolean = false,
    val prayerMask: Int = Prayer.ALL_MASK,
    val method: CalcMethod = CalcMethod.EGYPT,
    val asr: AsrMethod = AsrMethod.STANDARD,
    val placeName: String = Cities.DEFAULT.name,
    val lat: Double = Cities.DEFAULT.lat,
    val lng: Double = Cities.DEFAULT.lng,
    val beforeMin: Int = 0,      // 0 = بلا تذكير قبل الصلاة
    val afterMin: Int = 0,       // 0 = بلا تذكير بعد دخول الوقت (إن لم تُسجَّل الصلاة)
    val snoozeMin: Int = 10,     // مدة «فكّرني لاحقًا» للصلاة
    val adjust: List<Int> = listOf(0, 0, 0, 0, 0),
    // محاسبة النفس
    val muhasabaEnabled: Boolean = false,
    val muhasabaMin: Int = 22 * 60 + 30,
) {
    val point: GeoPoint get() = GeoPoint(placeName, lat, lng)
    fun prayerOn(p: Prayer): Boolean = (prayerMask and p.bit) != 0
}

// ============================================================================ جدولة الذكر وأحداث الصلاة
enum class PrayerEventKind { BEFORE, ADHAN, AFTER }

data class PrayerEvent(val prayer: Prayer, val kind: PrayerEventKind, val at: ZonedDateTime) {
    /** مفتاح فريد لمنع تكرار نفس التذكير. */
    val key: String get() = "${at.toLocalDate()}|${prayer.key}|${kind.name}"
}

object CompanionSchedule {
    const val SNOOZE_DHIKR_MIN = 20
    /** أقصى تأخير مقبول لعرض تذكير بعد موعده (دقائق)؛ بعده نتجاهله لأنه فات أوانه. */
    const val STALE_DHIKR_MIN = 25
    const val STALE_PRAYER_MIN = 30

    fun inRange(min: Int, start: Int, end: Int): Boolean =
        if (start <= end) min in start..end else (min >= start || min <= end)

    fun isQuiet(min: Int, s: CompanionSettings): Boolean = s.quietEnabled && inRange(min, s.quietStartMin, s.quietEndMin)

    /**
     * مواعيد الذكر في اليوم (دقائق من منتصف الليل): شبكة ثابتة تبدأ من [CompanionSettings.startMin] بخطوة الفاصل،
     * تُستبعد منها فترة الهدوء، وتُقصّ عند الحد الأقصى اليومي. الشبكة حتمية، فإعادة الجدولة لا تغيّر المواعيد ولا تكرّرها.
     * إن كانت نهاية الفترة قبل بدايتها تُعتبر الفترة فارغة.
     */
    fun dailySlots(s: CompanionSettings): List<Int> {
        if (s.endMin < s.startMin) return emptyList()
        val step = s.intervalMin.coerceAtLeast(15)
        val out = ArrayList<Int>()
        var m = s.startMin.coerceIn(0, 1439)
        while (m <= s.endMin && m < 1440) {
            if (!isQuiet(m, s)) out.add(m)
            m += step
        }
        return out.take(s.maxPerDay.coerceAtLeast(1))
    }

    /** أقرب موعد ذكر قادم بعد [now]. إن بلغ عدد ما عُرض اليوم الحد الأقصى ننتقل إلى الغد. */
    fun nextDhikr(now: ZonedDateTime, s: CompanionSettings, shownToday: Int): ZonedDateTime? {
        val slots = dailySlots(s)
        if (slots.isEmpty()) return null
        for (dayOffset in 0..2) {
            if (dayOffset == 0 && shownToday >= s.maxPerDay) continue
            val date = now.toLocalDate().plusDays(dayOffset.toLong())
            for (m in slots) {
                val t = date.atTime(m / 60, m % 60).atZone(now.zone)
                if (t.isAfter(now)) return t
            }
        }
        return null
    }

    /** أقرب موعد قادم لمحاسبة النفس. */
    fun nextMuhasaba(now: ZonedDateTime, s: CompanionSettings): ZonedDateTime? {
        if (!s.muhasabaEnabled) return null
        for (dayOffset in 0..1) {
            val date = now.toLocalDate().plusDays(dayOffset.toLong())
            val t = date.atTime(s.muhasabaMin / 60, s.muhasabaMin % 60).atZone(now.zone)
            if (t.isAfter(now)) return t
        }
        return null
    }

    /** موعد تذكير «العادات الحلوة» القادم (مرة يوميًا في الوقت المختار). */
    fun nextHabit(now: ZonedDateTime, s: CompanionSettings): ZonedDateTime? {
        if (!s.habitEnabled) return null
        for (dayOffset in 0..1) {
            val t = now.toLocalDate().plusDays(dayOffset.toLong()).atTime(s.habitMin / 60, s.habitMin % 60).atZone(now.zone)
            if (t.isAfter(now)) return t
        }
        return null
    }

    fun prayerDay(date: LocalDate, s: CompanionSettings, zone: ZoneId): DayTimes =
        PrayerTimes.forDate(date, s.point, s.method, s.asr, zone, s.adjust)

    /** كل أحداث الصلاة المفعّلة ليوم واحد (قبل/دخول الوقت/بعده). */
    fun prayerEvents(date: LocalDate, s: CompanionSettings, zone: ZoneId): List<PrayerEvent> {
        val day = prayerDay(date, s, zone)
        val out = ArrayList<PrayerEvent>()
        for (p in Prayer.values()) {
            if (!s.prayerOn(p)) continue
            val t = day.of(p) ?: continue
            if (s.beforeMin > 0) out.add(PrayerEvent(p, PrayerEventKind.BEFORE, t.minusMinutes(s.beforeMin.toLong())))
            out.add(PrayerEvent(p, PrayerEventKind.ADHAN, t))
            if (s.afterMin > 0) out.add(PrayerEvent(p, PrayerEventKind.AFTER, t.plusMinutes(s.afterMin.toLong())))
        }
        return out
    }

    /**
     * أقرب حدث صلاة بعد [now]. [isLogged] يُستعمل لاستبعاد أحداث «بعد الوقت» لصلوات سجّلها المستخدم بالفعل.
     */
    fun nextPrayerEvent(
        now: ZonedDateTime,
        s: CompanionSettings,
        isLogged: (LocalDate, Prayer) -> Boolean = { _, _ -> false },
    ): PrayerEvent? {
        if (!s.prayerEnabled || (s.prayerMask and Prayer.ALL_MASK) == 0) return null
        for (dayOffset in 0..2) {
            val date = now.toLocalDate().plusDays(dayOffset.toLong())
            val events = prayerEvents(date, s, now.zone)
                .filter { it.at.isAfter(now) }
                .filter { !(it.kind == PrayerEventKind.AFTER && isLogged(it.at.toLocalDate(), it.prayer)) }
                .sortedBy { it.at.toInstant() }
            if (events.isNotEmpty()) return events.first()
        }
        return null
    }

    /** الصلاة القادمة (وقت دخولها) للعرض في الواجهة، بصرف النظر عن التنبيهات. */
    fun nextPrayerTime(now: ZonedDateTime, s: CompanionSettings): Pair<Prayer, ZonedDateTime>? {
        for (dayOffset in 0..1) {
            val day = prayerDay(now.toLocalDate().plusDays(dayOffset.toLong()), s, now.zone)
            val next = Prayer.values().mapNotNull { p -> day.of(p)?.let { p to it } }
                .filter { it.second.isAfter(now) }
                .minByOrNull { it.second.toInstant() }
            if (next != null) return next
        }
        return null
    }
}

// ============================================================================ اختيار الرسائل
object CompanionPicker {
    private fun slotFits(slot: MsgSlot, hour: Int): Boolean = when (slot) {
        MsgSlot.ANY -> true
        MsgSlot.MORNING -> hour in 4..11
        MsgSlot.EVENING -> hour in 15..21
        MsgSlot.NIGHT -> hour >= 20 || hour <= 3
    }

    private fun categoryWeight(p: CompanionPersona, c: MsgCategory): Double = when (p) {
        CompanionPersona.BALANCED, CompanionPersona.EGYPTIAN -> 1.0
        CompanionPersona.CALM -> when (c) {
            MsgCategory.QURAN, MsgCategory.TASBIH, MsgCategory.HOPE -> 2.0
            MsgCategory.SABR_SHUKR -> 1.5
            else -> 0.7
        }
        CompanionPersona.PRAYER -> if (c == MsgCategory.SALAH) 4.0 else 0.6
        CompanionPersona.DHIKR_QURAN -> when (c) {
            MsgCategory.TASBIH, MsgCategory.QURAN -> 3.0
            MsgCategory.ISTIGHFAR, MsgCategory.SALAWAT -> 2.5
            MsgCategory.DAY_ADHKAR -> 2.0
            else -> 0.5
        }
        CompanionPersona.MUHASABA -> when (c) {
            MsgCategory.MUHASABA -> 4.0
            MsgCategory.HOPE, MsgCategory.TONGUE -> 2.0
            MsgCategory.AKHIRA -> 1.5
            else -> 0.5
        }
    }

    fun weight(m: CompanionMsg, persona: CompanionPersona, hour: Int): Double {
        var w = categoryWeight(persona, m.category)
        if (persona == CompanionPersona.CALM && m.isShort) w *= 1.5
        if (persona == CompanionPersona.EGYPTIAN && m.kind == MsgKind.ADVICE) w *= 2.0
        if (m.slot != MsgSlot.ANY && slotFits(m.slot, hour)) w *= 3.0
        return w
    }

    /** يعيد الرسائل المؤهلة (حسب الفئات المختارة ووقت اليوم) مع الرجوع لأوسع مجموعة إن لم يبقَ شيء. */
    fun eligible(all: List<CompanionMsg>, s: CompanionSettings, hour: Int): List<CompanionMsg> {
        val byTime = all.filter { slotFits(it.slot, hour) }
        val chosen = if (s.categories.isEmpty()) byTime else byTime.filter { it.category.name in s.categories }
        return chosen.ifEmpty { byTime }.ifEmpty { all }
    }

    /**
     * يختار رسالة بوزن عشوائي حتمي (يعتمد على [random]) مع تجنب آخر الرسائل المعروضة [recentIds] قدر الإمكان
     * حتى لا تتكرر الرسالة نفسها بصورة مزعجة.
     */
    fun pick(all: List<CompanionMsg>, s: CompanionSettings, hour: Int, recentIds: List<String>, random: Random): CompanionMsg? {
        val pool = eligible(all, s, hour)
        if (pool.isEmpty()) return null
        val fresh = pool.filter { it.id !in recentIds }.ifEmpty { pool }
        val weights = fresh.map { weight(it, s.persona, hour) }
        val total = weights.sum()
        if (total <= 0.0) return fresh[random.nextInt(fresh.size)]
        var r = random.nextDouble() * total
        for (i in fresh.indices) {
            r -= weights[i]
            if (r <= 0.0) return fresh[i]
        }
        return fresh.last()
    }
}

// ============================================================================ نصوص الصلاة
object CompanionTexts {
    /** (العنوان، النص) لتذكير الصلاة، باللهجة [v] (المصرية افتراضيًا). */
    fun prayer(p: Prayer, kind: PrayerEventKind, beforeMin: Int, afterMin: Int, v: Voice = Voice(Dialect.EGYPT)): Pair<String, String> = when (kind) {
        PrayerEventKind.BEFORE -> "قرّب وقت ${p.label}" to v.prayerBefore(p.label, beforeMin)
        PrayerEventKind.ADHAN -> when (p) {
            Prayer.FAJR -> "أذان الفجر" to v.prayerFajr()
            else -> "أذان ${p.label}" to v.prayerAdhan(p.label)
        }
        PrayerEventKind.AFTER -> "صلاة ${p.label}" to v.prayerAfter(p.label, afterMin)
    }

    fun prayerSnoozed(p: Prayer, v: Voice = Voice(Dialect.EGYPT)): Pair<String, String> =
        "صلاة ${p.label}" to v.prayerSnoozed(p.label)

    const val MUHASABA_TITLE = "خلينا نحاسب نفسنا يا صاحبي"
    const val MUHASABA_BODY = "قبل ما تنام، تعالى نقعد دقيقتين مع نفسنا. مش علشان نجلد نفسنا، علشان بكرة نبقى أحسن."
}

// ============================================================================ سجل التذكيرات
enum class LogKind(val label: String) { DHIKR("ذكر"), PRAYER("صلاة"), MUHASABA("محاسبة"), HABIT("عادة حلوة"), PLAN("خطة إقلاع") }

enum class LogAction(val label: String) {
    SHOWN_BUBBLE("ظهر كفقاعة"),
    SHOWN_NOTIF("وصل كإشعار"),
    UNDELIVERED("لم يُعرض: الفقاعة والإشعارات غير متاحة"),
    DONE("تم الذكر"),
    SNOOZE("ذكّرني لاحقًا"),
    PRAYED("سجّلت: صليت"),
    DISMISSED("أُخفي"),
    OPENED("فتحت أُنسي"),
    SLIPPED("سجّلت: وقعت"),
}

data class LogEntry(val ts: Long, val kind: LogKind, val ref: String, val action: LogAction)

object LogCodec {
    fun encode(list: List<LogEntry>): String =
        list.joinToString("\n") { "${it.ts}|${it.kind.name}|${it.ref.replace('|', ' ').replace('\n', ' ')}|${it.action.name}" }

    fun decode(raw: String): List<LogEntry> = raw.split('\n').mapNotNull { line ->
        val p = line.split('|')
        if (p.size != 4) return@mapNotNull null
        val ts = p[0].toLongOrNull() ?: return@mapNotNull null
        val kind = runCatching { LogKind.valueOf(p[1]) }.getOrNull() ?: return@mapNotNull null
        val action = runCatching { LogAction.valueOf(p[3]) }.getOrNull() ?: return@mapNotNull null
        LogEntry(ts, kind, p[2], action)
    }
}

data class LogCounts(val shown: Int, val done: Int, val snoozed: Int, val prayed: Int, val undelivered: Int)

object LogStats {
    /** إحصاءات مبنية على السجل الفعلي فقط، من [fromMillis] (شاملًا) فصاعدًا. */
    fun count(entries: List<LogEntry>, fromMillis: Long): LogCounts {
        val e = entries.filter { it.ts >= fromMillis }
        return LogCounts(
            shown = e.count { it.action == LogAction.SHOWN_BUBBLE || it.action == LogAction.SHOWN_NOTIF },
            done = e.count { it.action == LogAction.DONE },
            snoozed = e.count { it.action == LogAction.SNOOZE },
            prayed = e.count { it.action == LogAction.PRAYED },
            undelivered = e.count { it.action == LogAction.UNDELIVERED },
        )
    }
}

// ============================================================================ سجل الصلاة (يعتمد على تسجيل المستخدم فقط)
object PrayerLog {
    const val NONE = 0
    const val PRAYED = 1
    const val MISSED = 2
}

data class PrayerDaySummary(val date: LocalDate, val prayed: Int, val missed: Int, val unrecorded: Int)

object PrayerStats {
    fun day(date: LocalDate, status: (LocalDate, Prayer) -> Int): PrayerDaySummary {
        var prayed = 0
        var missed = 0
        for (p in Prayer.values()) when (status(date, p)) {
            PrayerLog.PRAYED -> prayed++
            PrayerLog.MISSED -> missed++
        }
        return PrayerDaySummary(date, prayed, missed, Prayer.values().size - prayed - missed)
    }

    fun range(days: List<LocalDate>, status: (LocalDate, Prayer) -> Int): List<PrayerDaySummary> = days.map { day(it, status) }
}

// ============================================================================ محاسبة النفس
data class Muhasaba(
    val date: String,
    val prayers: Int = 0,   // 0 لم يُجب، 1 حافظت، 2 قصّرت، 3 أحتاج أظبط نفسي
    val tongue: Int = 0,    // 0 لم يُجب، 1 حاولت، 2 وقعت وأريد أن أصلح
    val quran: Int = 0,     // 0 لم يُجب، 1 قرأت وردي، 2 ذكرت ربنا ولو قليلًا، 3 لسه محتاج أبدأ
    val good: Int = 0,      // قناع بتات: 1 ساعدت حدًا، 2 برّيت أهلي، 4 تصدقت/خير، 8 لسه عندي فرصة
    val win: String = "",
    val improve: String = "",
    val goals: List<String> = emptyList(),
    val updated: Long = 0L,
) {
    val answered: Boolean get() = prayers != 0 || tongue != 0 || quran != 0 || good != 0 || win.isNotBlank() || improve.isNotBlank() || goals.isNotEmpty()
}

object MuhasabaText {
    val PRAYERS = listOf("الحمد لله، حافظت عليها", "قصّرت في بعض الصلوات", "محتاج أظبط نفسي أكتر بكرة")
    val TONGUE = listOf("حاولت أبعد عن الغيبة والكلام اللي ملوش لازمة", "وقعت في الغلط وعايز أصلح نفسي")
    val QURAN = listOf("قرأت وردي", "ذكرت ربنا، حتى لو قليل", "لسه محتاج أبدأ وأنتظم")
    val GOOD = listOf(1 to "ساعدت حد", 2 to "برّيت أهلي", 4 to "تصدقت أو عملت خير ولو بسيط", 8 to "لسه عندي فرصة أعمل خير بكرة")
    const val CLOSING = "متنساش يا صاحبي، مش مطلوب منك تبقى كامل. المهم كل يوم تحاول تصلح حاجة، وتفضل راجع لربنا. تصبح على خير."
}

object MuhasabaCodec {
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun dec(s: String) = runCatching { URLDecoder.decode(s, "UTF-8") }.getOrDefault("")

    fun encode(m: Muhasaba): String = listOf(
        m.date, m.prayers, m.tongue, m.quran, m.good, enc(m.win), enc(m.improve),
        m.goals.joinToString(",") { enc(it) }, m.updated,
    ).joinToString("|")

    fun decode(raw: String): Muhasaba? {
        val p = raw.split('|')
        if (p.size != 9) return null
        return Muhasaba(
            date = p[0],
            prayers = (p[1].toIntOrNull() ?: return null).coerceIn(0, 3),
            tongue = (p[2].toIntOrNull() ?: return null).coerceIn(0, 2),
            quran = (p[3].toIntOrNull() ?: return null).coerceIn(0, 3),
            good = (p[4].toIntOrNull() ?: return null).coerceIn(0, 15),
            win = dec(p[5]),
            improve = dec(p[6]),
            goals = if (p[7].isEmpty()) emptyList() else p[7].split(',').map { dec(it) }.filter { it.isNotBlank() },
            updated = p[8].toLongOrNull() ?: 0L,
        )
    }
}

object MuhasabaLogic {
    const val MAX_GOALS = 3

    /**
     * خطة بسيطة لليوم التالي مبنية على إجابات المستخدم نفسه، بحد أقصى 4 بنود. لا نصدر أحكامًا،
     * ولا نخترع حالة لم يذكرها المستخدم؛ وما كتبه بيده يدخل الخطة كما هو.
     */
    fun plan(m: Muhasaba): List<String> {
        val out = ArrayList<String>()
        out.addAll(m.goals.map { it.trim() }.filter { it.isNotEmpty() }.take(MAX_GOALS))
        if (m.improve.isNotBlank()) out.add("أصلح بكرة: ${m.improve.trim()}")
        if (m.prayers == 2 || m.prayers == 3) out.add("اختار صلاة واحدة تركّز عليها بكرة وتصليها في وقتها")
        if (m.tongue == 2) out.add("اختار موقف واحد بكرة تمسك فيه لسانك")
        if (m.quran == 3) out.add("ابدأ بصفحة واحدة بس من القرآن بعد صلاة الصبح")
        if (m.quran == 2) out.add("حدّد وقت ثابت قصير لوردك بكرة")
        if ((m.good and 8) != 0) out.add("اختار عمل خير بسيط تعمله بكرة")
        if (out.isEmpty()) out.add("ابدأ يومك بأذكار الصباح")
        return out.distinct().take(4)
    }

    /** ملخص نصي من إجابات المستخدم فقط. [recordedPrayers] = عدد الصلوات التي سجّلها فعلًا اليوم (أو null إن لم يُسجّل شيئًا). */
    fun summary(m: Muhasaba, recordedPrayed: Int?, recordedTotal: Int?): List<String> {
        val out = ArrayList<String>()
        if (m.prayers != 0) out.add("الصلاة: ${MuhasabaText.PRAYERS[m.prayers - 1]}")
        if (recordedPrayed != null && recordedTotal != null && recordedTotal > 0) {
            out.add("المسجّل في أُنسي: ${Arabic.digits(recordedPrayed)} من ${Arabic.digits(recordedTotal)} صلوات")
        }
        if (m.quran != 0) out.add("القرآن والذكر: ${MuhasabaText.QURAN[m.quran - 1]}")
        if (m.tongue != 0) out.add("اللسان: ${MuhasabaText.TONGUE[m.tongue - 1]}")
        val goods = MuhasabaText.GOOD.filter { (m.good and it.first) != 0 }.map { it.second }
        if (goods.isNotEmpty()) out.add("خير: ${goods.joinToString("، ")}")
        if (m.win.isNotBlank()) out.add("إنجاز اليوم: ${m.win.trim()}")
        return out
    }
}
