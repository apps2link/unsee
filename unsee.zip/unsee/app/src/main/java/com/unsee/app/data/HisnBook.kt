package com.unsee.app.data

/** باب من أبواب الكتاب. no = 0 لباب «فضل الذكر» الذي يسبق الباب 1. category: اسم قسم أو MORNING_EVENING. */
internal data class HisnChapter(val no: Int, val title: String, val titleRaw: String, val category: String)

/** صف خام كما استُخرج من الكتاب (ملف HisnBookData.kt مولَّد آليًا). 0 في bookNo/seq تعني «لا يوجد». */
internal data class HisnRow(
    val id: String,
    val kind: ZikrKind,
    val bookNo: Int,
    val chapterNo: Int,
    val seq: Int,
    val text: String,
    val count: Int,
    val countText: String?,
    val countWhen: String?,   // MORNING أو EVENING إن قيّد الكتاب الذكر بوقت
    val afterNote: String?,
    val footnotes: List<Footnote>,
)

internal val KD = ZikrKind.DHIKR
internal val KA = ZikrKind.ADDITION
internal val KF = ZikrKind.FADL
internal val KN = ZikrKind.NOTE

@Suppress("LongParameterList")
internal fun r(
    id: String, kind: ZikrKind, bookNo: Int, chapterNo: Int, seq: Int, text: String,
    count: Int, countText: String?, countWhen: String?, afterNote: String?, footnotes: List<Footnote>,
) = HisnRow(id, kind, bookNo, chapterNo, seq, text, count, countText, countWhen, afterNote, footnotes)
