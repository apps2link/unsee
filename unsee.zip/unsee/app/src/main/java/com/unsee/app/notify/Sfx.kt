package com.unsee.app.notify

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.SoundPool
import com.unsee.app.R
import com.unsee.app.data.CompanionStore
import com.unsee.app.data.Store

/**
 * صوت أُنسي الوحيد: زقزقة عصفور لإشعار الفقاعة (حُذف صوتا التصفيق والبكاء).
 * الملفات في res/raw (مولَّدة بالتركيب بواسطة tools/gen_sounds.py ويمكن استبدالها بتسجيلات بنفس الأسماء).
 * تُكتم تلقائيًا إن أوقف المستخدم المؤثرات أو كان الهاتف على الصامت/الاهتزاز.
 */
object Sfx {
    enum class Sound(val res: Int) {
        CHIRP(R.raw.sfx_chirp),   // زقزقة عصفور: إشعار الفقاعة العائمة
    }

    private val attrs: AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
        .build()

    private var pool: SoundPool? = null
    private val ids = HashMap<Sound, Int>()
    private val loaded = HashSet<Int>()

    @Synchronized
    private fun ensure(ctx: Context) {
        if (pool != null) return
        val p = SoundPool.Builder().setMaxStreams(5).setAudioAttributes(attrs).build()
        p.setOnLoadCompleteListener { _, sampleId, status -> if (status == 0) synchronized(this) { loaded.add(sampleId) } }
        for (s in Sound.values()) ids[s] = p.load(ctx.applicationContext, s.res, 1)
        pool = p
    }

    /** تحميل مسبق كي لا يتأخر أول صوت. */
    fun warm(ctx: Context) {
        runCatching { ensure(ctx) }
    }

    private fun audible(ctx: Context, companionOnly: Boolean): Boolean {
        // مفتاح الصوت العام هو المفتاح الرئيسي لكل أصوات التطبيق.
        if (!Store.get(ctx).settings().sound) return false
        if (companionOnly && !CompanionStore.get(ctx).sfxEnabled()) return false
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return false
        return am.ringerMode == AudioManager.RINGER_MODE_NORMAL
    }

    fun play(ctx: Context, sound: Sound, volume: Float = 1f, companionOnly: Boolean = false) {
        val app = ctx.applicationContext
        if (!audible(app, companionOnly)) return
        runCatching {
            ensure(app)
            val id = ids[sound]
            val ready = id != null && synchronized(this) { id in loaded }
            if (ready) {
                pool?.play(id!!, volume, volume, 1, 0, 1f)
            } else {
                // لم يكتمل تحميل المجموعة بعد: نشغّل الملف مباشرة مرة واحدة
                MediaPlayer.create(app, sound.res, attrs, AudioManager.AUDIO_SESSION_ID_GENERATE)?.apply {
                    setVolume(volume, volume)
                    setOnCompletionListener { it.release() }
                    start()
                }
            }
        }
    }

    /** صوت إشعار الفقاعة (زقزقة العصفور) كـ URI للاستعمال في قنوات الإشعار إن لزم. */
    fun chirpUri(ctx: Context): android.net.Uri =
        android.net.Uri.parse("android.resource://${ctx.packageName}/${Sound.CHIRP.res}")
}
