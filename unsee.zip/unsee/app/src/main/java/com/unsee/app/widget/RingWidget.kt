package com.unsee.app.widget

import android.app.Activity
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.widget.RemoteViews
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.unsee.app.R
import com.unsee.app.core.RingConfig
import com.unsee.app.data.Store
import com.unsee.app.ui.RingPainter
import com.unsee.app.ui.RingState
import com.unsee.app.ui.RingStudioContent
import com.unsee.app.ui.UColors
import com.unsee.app.ui.UnseeTheme
import kotlin.math.min

/**
 * ودجت العدّاد الدائري: يرسم نفس تصميمات التطبيق الـ15 في صورة (Bitmap) بالإعدادات المحفوظة لكل ودجت.
 * قيد Android: الودجت لا تعرض حركة مستمرة؛ نعرض لقطة من التصميم، ونُظهر نبضة الضغط في بضعة إطارات متتابعة.
 */
object RingWidgetRenderer {
    const val ACTION_TAP = "com.unsee.app.widget.RING_TAP"

    fun ids(ctx: Context): IntArray =
        AppWidgetManager.getInstance(ctx).getAppWidgetIds(ComponentName(ctx, RingWidget::class.java))

    fun updateAll(ctx: Context, kick: Float = 0f) {
        val mgr = AppWidgetManager.getInstance(ctx)
        for (id in ids(ctx)) update(ctx, mgr, id, kick)
    }

    private fun isNight(ctx: Context): Boolean =
        (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    fun update(ctx: Context, mgr: AppWidgetManager, id: Int, kick: Float = 0f) {
        runCatching {
            val store = Store.get(ctx)
            val cfg = store.ringWidgetCfg(id)
            val t = store.tasbih()
            val opts = mgr.getAppWidgetOptions(id)
            val density = ctx.resources.displayMetrics.density
            val wDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 120)
            val hDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 120)
            val side = (min(wDp, hDp).coerceIn(80, 260) * density).toInt().coerceIn(160, 520)
            val bmp = Bitmap.createBitmap(side, side, Bitmap.Config.ARGB_8888)
            val dark = when (cfg.variant) { 1 -> true; 2 -> false; else -> isNight(ctx) }
            val tm = (System.currentTimeMillis() % 3_600_000L) / 1000f
            RingPainter().draw(Canvas(bmp), side.toFloat(), side.toFloat(), cfg, RingState(t.count.coerceAtMost(t.target), t.target, t.text), dark, tm, kick, density)
            val rv = RemoteViews(ctx.packageName, R.layout.widget_ring)
            rv.setImageViewBitmap(R.id.r_img, bmp)
            rv.setOnClickPendingIntent(R.id.r_root, tapIntent(ctx, id))
            mgr.updateAppWidget(id, rv)
        }
    }

    private fun tapIntent(ctx: Context, id: Int): PendingIntent {
        val i = Intent(ctx, RingWidget::class.java).setAction(ACTION_TAP).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
        return PendingIntent.getBroadcast(ctx, id * 31 + 7, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
}

class RingWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) RingWidgetRenderer.update(context, appWidgetManager, id)
    }

    override fun onAppWidgetOptionsChanged(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle?) {
        RingWidgetRenderer.update(context, appWidgetManager, appWidgetId)
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        val store = Store.get(context)
        for (id in appWidgetIds) store.removeWidget(id)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action != RingWidgetRenderer.ACTION_TAP) return
        val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        if (id == AppWidgetManager.INVALID_APPWIDGET_ID) return
        val store = Store.get(context)
        val cfg = store.ringWidgetCfg(id)
        val r = store.tasbihTap()
        if (cfg.haptic) vibrate(context, if (r.completedRound) 60 else 15)
        // نبضة الضغط: إطار قوي ثم يخفت على إطارين، ثم يعود الودجت لحالته الهادئة
        WidgetRenderer.updateStyle(context, WidgetStyle.TASBIH)
        RingWidgetRenderer.updateAll(context, 1f)
        val pending = goAsync()
        val h = Handler(Looper.getMainLooper())
        h.postDelayed({ runCatching { RingWidgetRenderer.updateAll(context, 0.5f) } }, 200L)
        h.postDelayed({
            try { RingWidgetRenderer.updateAll(context, 0f) } finally { pending.finish() }
        }, 450L)
    }

    private fun vibrate(context: Context, ms: Int) {
        runCatching {
            val v = context.getSystemService(Vibrator::class.java) ?: return
            if (v.hasVibrator()) v.vibrate(VibrationEffect.createOneShot(ms.toLong(), VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }
}

/** شاشة تخصيص ودجت العدّاد: تُفتح عند الإضافة وعند «إعادة الإعداد»، وتحفظ تصميمًا مستقلًا لكل ودجت. */
class RingWidgetConfigActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(Activity.RESULT_CANCELED)
        val id = intent?.extras?.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (id == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return }
        val store = Store.get(this)
        setContent {
            val settings = remember { store.settings() }
            val initial: RingConfig = remember { store.ringWidgetCfg(id) }
            UnseeTheme(settings) {
                Column(
                    Modifier.fillMaxSize().background(UColors.BgTop).safeDrawingPadding().verticalScroll(rememberScrollState()).padding(16.dp),
                ) {
                    Text("تخصيص العدّاد الدائري", color = UColors.Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    RingStudioContent(
                        store = store, s = settings, initial = initial, applyLabel = "حفظ وإضافة", showTarget = false,
                        onApply = { cfg ->
                            store.setRingWidgetCfg(id, cfg)
                            RingWidgetRenderer.update(this@RingWidgetConfigActivity, AppWidgetManager.getInstance(this@RingWidgetConfigActivity), id)
                            setResult(Activity.RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id))
                            finish()
                        },
                    )
                }
            }
        }
    }
}
