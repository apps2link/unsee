package com.unsee.app.core

/**
 * منطق «محرك أُنسي الصوتي» النقي (بلا Android) كي يُختبر على JVM: الأقسام، الإعدادات، ساعات الهدوء،
 * منع التكرار، قرار الطابور حسب الأولوية، وصياغة النص المنطوق للإشعارات، وحارس القرآن.
 */
enum class VoiceSection(val key: String, val label: String, val blurb: String) {
    ADHKAR_DAY("adhkar_day", "أذكار الصباح والمساء", "قراءة نص الذكر عند الضغط على زر الاستماع"),
    ADHKAR_SLEEP("adhkar_sleep", "أذكار النوم والاستيقاظ", "قراءة أذكار النوم والاستيقاظ وغيرها من الأبواب"),
    TASBIH("tasbih", "عدّاد التسبيح", "نطق الذكر عند إتمام الهدف"),
    COMPANION("companion", "رفيق أُنسي", "رسائل الرفيق بصوتك المختار"),
    ENCOURAGE("encourage", "رسائل التشجيع", "كلمة تشجيع عند عمل الحسنات"),
    NOTIFY("notify", "الإشعارات والتذكيرات", "نطق الإشعار المنشور إلى جانب نصه"),
    MUHASABA("muhasaba", "المحاسبة اليومية", "تذكير آخر اليوم بالمحاسبة");

    companion object {
        fun byKey(k: String): VoiceSection? = values().firstOrNull { it.key == k }
    }
}

enum class SpeechPriority { LOW, NORMAL, HIGH }

/** إعداد صوتي لقسم واحد. [voice] فارغ = الصوت الافتراضي العام. */
data class SectionVoice(val enabled: Boolean = true, val auto: Boolean = true, val voice: String = "")

data class VoiceSettings(
    val master: Boolean = true,
    val voice: String = "",              // اسم صوت Android المعتمد؛ فارغ = الافتراضي للغة العربية
    val rate: Float = 0.95f,             // 0.5 .. 1.6
    val pitch: Float = 1.0f,             // 0.7 .. 1.4
    val volume: Float = 1.0f,            // 0.2 .. 1.0 (نسبي لصوت النظام)
    val speakNotifications: Boolean = true,
    val speakTitle: Boolean = false,     // نطق عنوان الإشعار قبل المحتوى
    val respectSilent: Boolean = true,   // لا نطق في وضع الصامت/الاهتزاز
    val respectDnd: Boolean = true,      // لا نطق في «عدم الإزعاج»
    val quietEnabled: Boolean = true,
    val quietStartMin: Int = 23 * 60,    // ساعات الهدوء/النوم
    val quietEndMin: Int = 6 * 60,
    val sections: Map<VoiceSection, SectionVoice> = emptyMap(),
) {
    fun section(s: VoiceSection): SectionVoice = sections[s] ?: SectionVoice(enabled = true, auto = s != VoiceSection.ADHKAR_DAY && s != VoiceSection.ADHKAR_SLEEP && s != VoiceSection.TASBIH)

    /** الصوت الفعّال للقسم: صوت القسم إن حُدّد وإلا الصوت العام. */
    fun voiceFor(s: VoiceSection): String = section(s).voice.ifBlank { voice }

    fun clamped(): VoiceSettings = copy(
        rate = rate.coerceIn(RATE_MIN, RATE_MAX), pitch = pitch.coerceIn(PITCH_MIN, PITCH_MAX), volume = volume.coerceIn(VOL_MIN, 1f),
        quietStartMin = Math.floorMod(quietStartMin, 1440), quietEndMin = Math.floorMod(quietEndMin, 1440),
    )

    companion object {
        const val RATE_MIN = 0.5f; const val RATE_MAX = 1.6f
        const val PITCH_MIN = 0.7f; const val PITCH_MAX = 1.4f
        const val VOL_MIN = 0.2f
    }
}

object VoiceCodec {
    fun encodeSections(m: Map<VoiceSection, SectionVoice>): String =
        m.entries.joinToString("|") { (k, v) -> "${k.key}~${if (v.enabled) 1 else 0}~${if (v.auto) 1 else 0}~${v.voice.replace("|", "").replace("~", "")}" }

    fun decodeSections(raw: String?): Map<VoiceSection, SectionVoice> {
        if (raw.isNullOrBlank()) return emptyMap()
        val out = LinkedHashMap<VoiceSection, SectionVoice>()
        for (part in raw.split('|')) {
            val f = part.split('~')
            if (f.size < 3) continue
            val sec = VoiceSection.byKey(f[0]) ?: continue
            out[sec] = SectionVoice(f[1] == "1", f[2] == "1", f.getOrElse(3) { "" })
        }
        return out
    }
}

/** ساعات الهدوء: النطاق قد يعبر منتصف الليل (23:00 → 06:00). */
object QuietHours {
    fun isQuiet(nowMin: Int, startMin: Int, endMin: Int, enabled: Boolean = true): Boolean {
        if (!enabled || startMin == endMin) return false
        return if (startMin < endMin) nowMin in startMin until endMin else nowMin >= startMin || nowMin < endMin
    }
}

/** منع نطق الشيء نفسه مرتين خلال نافذة زمنية. الساعة قابلة للحقن للاختبار. */
class SpeechDeduper(private val windowMs: Long = 10 * 60_000L) {
    private val last = LinkedHashMap<String, Long>()

    @Synchronized
    fun shouldSpeak(key: String, nowMs: Long): Boolean {
        val it = last.entries.iterator()
        while (it.hasNext()) if (nowMs - it.next().value > windowMs) it.remove()
        val prev = last[key]
        if (prev != null && nowMs - prev <= windowMs) return false
        last[key] = nowMs
        return true
    }

    @Synchronized fun forget(key: String) { last.remove(key) }
}

enum class QueueDecision { DROP, ADD, FLUSH }

/** HIGH يقطع ما يُقال فورًا، NORMAL يُضاف بعده فلا تتداخل الأصوات، LOW يُهمل إن كان المحرك مشغولًا. */
object SpeechQueuePolicy {
    fun decide(priority: SpeechPriority, busy: Boolean): QueueDecision = when {
        priority == SpeechPriority.HIGH -> QueueDecision.FLUSH
        !busy -> QueueDecision.ADD
        priority == SpeechPriority.NORMAL -> QueueDecision.ADD
        else -> QueueDecision.DROP
    }
}

/** لماذا لم يُنطق النص (للعرض والتشخيص). */
enum class SkipReason { MASTER_OFF, SECTION_OFF, NOTIFICATIONS_OFF, QUIET_HOURS, SILENT_MODE, DND, DUPLICATE, EMPTY, QURAN }

object VoiceGate {
    fun check(
        s: VoiceSettings, section: VoiceSection, isNotification: Boolean, nowMin: Int,
        silentMode: Boolean, dndOn: Boolean, text: String,
    ): SkipReason? {
        if (text.isBlank()) return SkipReason.EMPTY
        if (!s.master) return SkipReason.MASTER_OFF
        if (!s.section(section).enabled) return SkipReason.SECTION_OFF
        if (isNotification && !s.speakNotifications) return SkipReason.NOTIFICATIONS_OFF
        if (isNotification && QuietHours.isQuiet(nowMin, s.quietStartMin, s.quietEndMin, s.quietEnabled)) return SkipReason.QUIET_HOURS
        if (s.respectSilent && silentMode) return SkipReason.SILENT_MODE
        if (isNotification && s.respectDnd && dndOn) return SkipReason.DND
        return null
    }
}

/** حارس القرآن: لا يُحوَّل نص الآيات إلى كلام آلي بديلًا عن التلاوة؛ التلاوة بصوت قارئ فقط. */
object QuranGuard {
    private val marks = Regex("[\\u064B-\\u0652\\u0670\\u0640\\u0653-\\u065F]")
    private val markers = listOf(
        "الله لا اله الا هو الحي القيوم", "قل هو الله احد", "قل اعوذ برب الفلق", "قل اعوذ برب الناس",
        "امن الرسول بما انزل", "آية الكرسي", "اية الكرسي", "المعوذات",
    )

    fun norm(s: String): String = marks.replace(s, "").replace('آ', 'ا').replace('أ', 'ا').replace('إ', 'ا').replace('ى', 'ي').replace('ة', 'ه')

    fun isQuranic(title: String, text: String): Boolean {
        // «حصن المسلم» يضع الآيات بين أقواس معقوفة { … }
        if (text.contains('{') && text.contains('}')) return true
        val n = norm("$title ${text.take(400)}")
        return markers.any { n.contains(norm(it)) }
    }
}

enum class SpokenKind { REMINDER_MORNING, REMINDER_EVENING, REMINDER_CUSTOM, DHIKR_MESSAGE, PRAYER, HABIT, PLAN, MUHASABA, WIRD_DONE, SALAH_NABI, GENERIC }

/**
 * صياغة الكلام: الإشعار النصي يبقى كما هو، والصوت أقرب للحديث الطبيعي (مثل «يلا بينا، جه وقت أذكار المساء»).
 * اللهجة مصرية أو خليجية حسب إعداد الرفيق.
 */
object SpeechScript {
    private val nabiMark = QuranGuard.norm("الصلاة على النبي")
    private val wirdMark = QuranGuard.norm("أتممت وردك")

    /** يستنتج النوع من نص الإشعار حين لا يُعرف نوعه صراحة. */
    fun refine(kind: SpokenKind, title: String, text: String): SpokenKind {
        val n = QuranGuard.norm("$title $text")
        return when {
            n.contains(wirdMark) -> SpokenKind.WIRD_DONE
            n.contains(nabiMark) && (n.contains("لا تنس") || n.contains("صل")) -> SpokenKind.SALAH_NABI
            else -> kind
        }
    }

    fun compose(kind: SpokenKind, title: String, text: String, gulf: Boolean, speakTitle: Boolean, label: String = ""): String {
        val k = refine(kind, title, text)
        val body = when (k) {
            SpokenKind.REMINDER_MORNING -> if (gulf) "يلا، حان وقت أذكار الصباح" else "يلا بينا، جه وقت أذكار الصباح"
            SpokenKind.REMINDER_EVENING -> if (gulf) "يلا، حان وقت أذكار المساء" else "يلا بينا، جه وقت أذكار المساء"
            SpokenKind.REMINDER_CUSTOM -> (label.ifBlank { title }).let { if (gulf) "تذكير: $it" else "افتكر، $it" }
            SpokenKind.WIRD_DONE -> if (gulf) "أحسنت، الله يتقبل منك، واصل على طاعتك" else "أحسنت، ربنا يتقبل منك، استمر على طاعتك"
            SpokenKind.SALAH_NABI -> if (gulf) "خذ دقيقة من وقتك، وصلّ على النبي" else "خد دقيقة من وقتك، وصلّي على النبي"
            else -> text
        }
        val clean = clean(body)
        val t = clean(title)
        val useTitle = speakTitle && t.isNotBlank() && k in setOf(SpokenKind.GENERIC, SpokenKind.DHIKR_MESSAGE, SpokenKind.PRAYER, SpokenKind.HABIT, SpokenKind.PLAN, SpokenKind.MUHASABA)
        return if (useTitle && !clean.startsWith(t)) "$t. $clean" else clean
    }

    /** يزيل الرموز والأرقام المرجعية والزخارف التي لا تُنطق جيدًا. */
    fun clean(s: String): String = s
        .replace(Regex("[\\u200E\\u200F\\u202A-\\u202E\\u2066-\\u2069]"), "")
        .replace(Regex("[\\u06DD\\u06DE\\u06E9]"), " ")
        .replace(Regex("[«»\\[\\]{}()*_#~•●▪◆★☆✓✔➜←→↑↓—–-]+"), " ")
        .replace(Regex("[\\u00A0\\s]+"), " ")
        .trim()
}
