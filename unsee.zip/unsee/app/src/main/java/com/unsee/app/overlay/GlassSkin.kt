package com.unsee.app.overlay

import android.animation.TimeInterpolator
import com.unsee.app.core.LogKind
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp

/**
 * لغة التصميم المشتركة بين الفقاعة العائمة والبطاقات («Premium Islamic Ambient Glassmorphism»).
 * الفقاعة والبطاقة يقرآن اللون نفسه من [BubbleMood] فيشعر المستخدم أنهما قطعة واحدة.
 * الملف لا يلمس أي View (باستثناء المُسرِّع [SpringInterpolator]) فيسهل اختباره.
 */
enum class BubbleMood {
    /** لا شيء معلّق: ذهبي هادئ. */
    NORMAL,
    /** تذكير جديد عادي (عادة حلوة/محاسبة). */
    NEW,
    /** عنصر أولوية لا يُؤجَّل (خطة إقلاع أو تذكير عاجل). */
    URGENT,
    /** تذكير صلاة. */
    PRAYER,
    /** تذكير ذكر. */
    DHIKR,
    /** لحظة احتفال بعد تسجيل حسنة. */
    CELEBRATE,
    /** لحظة مواساة بعد تسجيل زلّة. */
    COMFORT,
}

/** أيقونة البطاقة الصغيرة المتحركة. */
enum class GlyphKind { CRESCENT, STAR, CHECK, SHIELD, HEART, SPARKLE }

/** ألوان كل حالة. القيم ARGB كاملة الشفافية (alpha تُضاف عند الرسم). */
data class GlassSkin(
    val accentA: Int,
    val accentB: Int,
    val glyph: GlyphKind,
    val dark: Boolean,
) {
    /** سطح البطاقة الزجاجي: يعلوه توهج خفيف ويتدرّج للأسفل. الشفافية تُبقي النص مقروءًا بدون Blur. */
    val surfaceTop: Int get() = if (dark) argb(0xE6, 0x16, 0x2C, 0x55) else argb(0xEB, 0xFF, 0xFF, 0xFF)
    val surfaceBottom: Int get() = if (dark) argb(0xF0, 0x08, 0x14, 0x2E) else argb(0xE6, 0xF3, 0xF1, 0xFA)
    val textPrimary: Int get() = if (dark) 0xFFFFF4D6.toInt() else 0xFF1B2540.toInt()
    val textSecondary: Int get() = if (dark) 0xFFC9C1A5.toInt() else 0xFF55607A.toInt()

    /** لون النص فوق [accentA] (أزرار ممتلئة وشارة النوع). */
    val onAccent: Int get() = 0xFF0B1B3A.toInt()

    /** لون الأيقونة والعنوان: في الوضع الفاتح نُغمّق اللون للحفاظ على التباين. */
    val titleColor: Int get() = if (dark) accentA else darken(accentA, 0.55f)

    companion object {
        fun argb(a: Int, r: Int, g: Int, b: Int): Int = (a shl 24) or (r shl 16) or (g shl 8) or b
        fun withAlpha(color: Int, a: Int): Int = (a.coerceIn(0, 255) shl 24) or (color and 0x00FFFFFF)
        fun darken(color: Int, k: Float): Int {
            val r = (((color shr 16) and 0xFF) * k).toInt()
            val g = (((color shr 8) and 0xFF) * k).toInt()
            val b = ((color and 0xFF) * k).toInt()
            return argb(0xFF, r, g, b)
        }

        private fun c(v: Long) = v.toInt()

        fun of(mood: BubbleMood, dark: Boolean): GlassSkin = when (mood) {
            BubbleMood.NORMAL -> GlassSkin(c(0xFFE2B857), c(0xFFFFE9A8), GlyphKind.CRESCENT, dark)
            BubbleMood.NEW -> GlassSkin(c(0xFFFFD36B), c(0xFF5EEAD4), GlyphKind.SPARKLE, dark)
            BubbleMood.URGENT -> GlassSkin(c(0xFFFF5A6E), c(0xFFFFB4A2), GlyphKind.SHIELD, dark)
            BubbleMood.PRAYER -> GlassSkin(c(0xFF34D399), c(0xFFA7F3D0), GlyphKind.STAR, dark)
            BubbleMood.DHIKR -> GlassSkin(c(0xFFC4B5FD), c(0xFFFDE68A), GlyphKind.CRESCENT, dark)
            BubbleMood.CELEBRATE -> GlassSkin(c(0xFF4ADE80), c(0xFFFDE047), GlyphKind.CHECK, dark)
            BubbleMood.COMFORT -> GlassSkin(c(0xFFA5B4FC), c(0xFFCBD5E1), GlyphKind.HEART, dark)
        }
    }
}

object GlassMood {
    /** حالة الفقاعة نفسها من قائمة المعلّق: الأولوية أولًا ثم الصلاة ثم الذكر. */
    fun forPending(kinds: List<LogKind>, anyPriority: Boolean): BubbleMood = when {
        anyPriority -> BubbleMood.URGENT
        kinds.isEmpty() -> BubbleMood.NORMAL
        LogKind.PRAYER in kinds -> BubbleMood.PRAYER
        LogKind.DHIKR in kinds -> BubbleMood.DHIKR
        else -> BubbleMood.NEW
    }

    /** مظهر بطاقة عنصر واحد. */
    fun forItem(kind: LogKind, priority: Boolean): BubbleMood = when {
        priority -> BubbleMood.URGENT
        kind == LogKind.PRAYER -> BubbleMood.PRAYER
        kind == LogKind.DHIKR -> BubbleMood.DHIKR
        else -> BubbleMood.NEW
    }
}

/**
 * نابض مخمَّد (ارتداد خفيف ثم استقرار) بديل عن مكتبة DynamicAnimation حتى لا نضيف اعتمادات جديدة.
 * f(t) = 1 - e^(-k·t)·cos(2π·n·t) ، ويساوي 1 تمامًا عند t=1.
 */
class SpringInterpolator(private val damping: Float = 6f, private val cycles: Float = 1.1f) : TimeInterpolator {
    override fun getInterpolation(input: Float): Float {
        if (input <= 0f) return 0f
        if (input >= 1f) return 1f
        return (1f - exp(-damping * input) * cos(2f * PI.toFloat() * cycles * input))
    }
}
