package com.unsee.app.ui

import android.widget.Toast
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.unsee.app.core.Arabic
import com.unsee.app.core.CounterCatalog
import com.unsee.app.core.CounterCfg
import com.unsee.app.core.CounterStyle
import com.unsee.app.data.Settings
import com.unsee.app.data.Store
import com.unsee.app.data.TasbihState
import com.unsee.app.widget.WidgetRenderer
import kotlinx.coroutines.launch

// ================================================================ العدّاد المرسوم (حركة حقيقية)
/**
 * عدّاد بتصميم من الكتالوج. الحركة المستمرة تتوقف عند: «بلا حركة» في التطبيق، أو إيقاف الأنيميشن في إعدادات العدّاد،
 * أو [staticFrame] (المعاينات المصغّرة). الرسم كله في مرحلة الرسم دون إعادة تركيب.
 */
@Composable
fun StyledCounter(
    cfg: CounterCfg,
    count: Int,
    target: Int,
    name: String,
    reduceMotion: Boolean,
    onTap: (() -> Unit)?,
    modifier: Modifier = Modifier,
    sizeDp: Dp? = null,
    staticFrame: Boolean = false,
) {
    val st: CounterStyle = CounterCatalog.byId(cfg.styleId) ?: return
    val animate = cfg.anim && !reduceMotion && !staticFrame
    val frac = if (target > 0) (count.toFloat() / target).coerceIn(0f, 1f) else 1f
    val progress by animateFloatAsState(frac, tween(if (animate) 300 else 0), label = "cnt_progress")
    val tapA = remember { Animatable(0f) }
    val burstA = remember { Animatable(0f) }
    val scale = remember { Animatable(1f) }
    val scope = rememberCoroutineScope()
    val initial = remember { count }

    LaunchedEffect(count) {
        if (animate && target > 0 && count == target && count > initial) {
            burstA.snapTo(0f)
            burstA.animateTo(1f, tween(900))
        }
    }

    val clock: State<Float> = if (animate) {
        val ms = (14_000f / cfg.speed).toInt().coerceAtLeast(2_000)
        rememberInfiniteTransition(label = "cnt_clock").animateFloat(
            initialValue = 0f, targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(ms, easing = LinearEasing)),
            label = "cnt_t",
        )
    } else {
        remember { mutableStateOf(0.35f) }
    }

    var box = modifier.size(sizeDp ?: cfg.size.dp).graphicsLayer { scaleX = scale.value; scaleY = scale.value }
    if (onTap != null) {
        box = box.clip(CircleShape).clickable {
            if (animate) {
                scope.launch { tapA.snapTo(1f); tapA.animateTo(0f, tween(650)) }
                scope.launch { scale.animateTo(0.95f, tween(60)); scale.animateTo(1f, spring(Spring.DampingRatioMediumBouncy)) }
            }
            onTap()
        }
    }
    Canvas(box.semantics { contentDescription = "عدّاد التسبيح ${Arabic.digits(count)}" }) {
        val frame = resolveFrame(st, cfg, count, target, name, clock.value, if (animate) tapA.value else 0f, burstA.value, progress)
        drawCounter(frame)
    }
}

/** العدّاد الفعلي في شاشة المسبحة: الأصلي (الرئيسي) أو التصميم المختار. */
@Composable
fun ActiveCounter(cfg: CounterCfg, t: TasbihState, s: Settings, onTap: () -> Unit) {
    if (CounterCatalog.isClassic(cfg.styleId)) {
        CounterButton(
            count = t.count, target = t.target, size = cfg.size.dp,
            caption = if (cfg.showGoal) "الهدف ${Arabic.digits(t.target)}" else "",
            reduceMotion = s.reduceMotion || !cfg.anim, onTap = onTap,
        )
    } else {
        // اسم الذكر ظاهر أصلًا فوق العدّاد في الشاشة، فلا نكرّره داخل الدائرة
        StyledCounter(cfg, t.count, t.target, "", s.reduceMotion, onTap)
    }
}

// ================================================================ استوديو العدّادات
private val SWATCHES = listOf(
    0xFFFFF4D6L, 0xFFE9C46AL, 0xFFFFFFFFL, 0xFF3FE0A0L, 0xFF4DA8FFL,
    0xFFB27CFFL, 0xFFFF8FB5L, 0xFFFF5A5FL, 0xFFFF8A3DL, 0xFF16161CL,
)

@Composable
private fun LiveSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Text(label, color = UColors.CreamDim, fontSize = 12.sp)
    Slider(
        value = value, onValueChange = onChange, valueRange = range,
        colors = SliderDefaults.colors(thumbColor = UColors.Gold, activeTrackColor = UColors.Gold, inactiveTrackColor = UColors.Gold.copy(alpha = 0.25f)),
    )
}

@Composable
private fun ColorPickRow(title: String, current: Long, defaultColor: Color, onPick: (Long) -> Unit) {
    Text(title, color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        ColorDot(defaultColor, current == 0L) { onPick(0L) }
        Text("افتراضي", color = UColors.CreamDim, fontSize = 11.sp)
        SWATCHES.forEach { c -> ColorDot(Color(c), current == c) { onPick(c) } }
    }
}

@Composable
private fun StyleCell(st: CounterStyle?, selected: Boolean, modifier: Modifier, onPick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier.clip(shape).background(if (selected) UColors.Gold.copy(alpha = 0.14f) else UColors.Card)
            .border(if (selected) 2.dp else 1.dp, if (selected) UColors.Gold else UColors.Cream.copy(alpha = 0.10f), shape)
            .padding(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(92.dp), contentAlignment = Alignment.Center) {
            if (st == null) {
                CounterButton(count = 21, target = 33, size = 92.dp, caption = "", reduceMotion = true, onTap = {})
            } else {
                StyledCounter(CounterCfg(styleId = st.id, showName = false, showGoal = false), 21, 33, "", true, null, sizeDp = 92.dp, staticFrame = true)
            }
            // طبقة شفافة تلتقط الضغط فوق المعاينة
            Box(Modifier.fillMaxSize().clickable(onClick = onPick))
        }
        Text(st?.name ?: CounterCatalog.CLASSIC_NAME, color = if (selected) UColors.Gold else UColors.Cream, fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 1)
        Text(st?.engine?.label ?: "الأصلي", color = UColors.CreamDim, fontSize = 9.sp, textAlign = TextAlign.Center, maxLines = 1)
    }
}

@Composable
fun CounterStudioScreen(store: Store, s: Settings, nav: NavController) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val saved by store.observeAsState { store.savedCounters() }
    var draft by remember { mutableStateOf(store.counterCfg()) }
    var demoCount by remember { mutableIntStateOf(0) }
    var demoTarget by remember { mutableIntStateOf(33) }
    var customTarget by remember { mutableStateOf(false) }
    var saveDialog by remember { mutableStateOf(false) }
    var saveName by remember { mutableStateOf("") }
    var confirmReset by remember { mutableStateOf(false) }
    var confirmTarget by remember { mutableStateOf(false) }
    val style = CounterCatalog.byId(draft.styleId)
    val classic = style == null
    val defaultRing = Color(style?.c1 ?: 0xFFE2B857)
    val defaultFace = Color(style?.face ?: 0xFF0A1530)

    fun update(block: CounterCfg.() -> CounterCfg) { draft = draft.block().clamped() }
    fun tapDemo() {
        demoCount = if (demoCount >= demoTarget) 1 else demoCount + 1
        feedback(view, s, demoCount == demoTarget)
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        ScreenHeader("استوديو العدّادات", { nav.popBackStack() })

        // ---- المعاينة الحية (ثابتة أعلى الشاشة أثناء التخصيص)
        Box(Modifier.fillMaxWidth().height(250.dp), contentAlignment = Alignment.Center) {
            val shown = draft.size.coerceAtMost(240).dp
            if (classic) {
                CounterButton(
                    count = demoCount, target = demoTarget, size = shown,
                    caption = if (draft.showGoal) "الهدف ${Arabic.digits(demoTarget)}" else "",
                    reduceMotion = s.reduceMotion || !draft.anim, onTap = { tapDemo() },
                )
            } else {
                StyledCounter(draft, demoCount, demoTarget, "سُبْحَانَ اللَّهِ", s.reduceMotion, { tapDemo() }, sizeDp = shown)
            }
        }
        Text(
            "اضغط على العدّاد للتجربة · الحجم الفعلي ${Arabic.digits(draft.size)} dp",
            color = UColors.CreamDim, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(),
        )
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PillButton("تطبيق", {
                store.setCounterCfg(draft)
                WidgetRenderer.updateTasbihFamily(ctx)
                Toast.makeText(ctx, "تم تطبيق التصميم على المسبحة والودجت", Toast.LENGTH_SHORT).show()
            }, Modifier.weight(1f), icon = Ico.Check)
            PillButton("حفظ باسم", { saveName = ""; saveDialog = true }, Modifier.weight(1f), icon = Ico.Add, filled = false)
        }

        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { SectionLabel("اختر التصميم (${Arabic.digits(CounterCatalog.all.size + 1)})") }
            item {
                Text("العدّاد الرئيسي الأصلي يبقى الافتراضي، وبقية التصاميم إضافات تغيّر الشكل والحركة دون أن تفقد تخصيصك.", color = UColors.CreamDim, fontSize = 12.sp)
            }
            val entries: List<CounterStyle?> = listOf<CounterStyle?>(null) + CounterCatalog.all
            items(entries.chunked(3)) { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { st ->
                        StyleCell(st, (st?.id ?: CounterCatalog.CLASSIC) == draft.styleId, Modifier.weight(1f)) {
                            update { copy(styleId = st?.id ?: CounterCatalog.CLASSIC) } // يبقى الحجم والألوان كما هي
                        }
                    }
                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }

            item { SectionLabel("الحجم والشكل") }
            item {
                GlassCard(Modifier.fillMaxWidth()) {
                    LiveSlider("حجم العدّاد: ${Arabic.digits(draft.size)}", draft.size.toFloat(), CounterCfg.SIZE_MIN.toFloat()..CounterCfg.SIZE_MAX.toFloat()) { v -> update { copy(size = v.toInt()) } }
                    if (classic) {
                        Text("العدّاد الرئيسي الأصلي يدعم الحجم والهدف والأنيميشن. باقي التخصيصات (الألوان والخط والإضاءة) للتصاميم الجديدة.", color = UColors.CreamDim, fontSize = 11.sp)
                    } else {
                        LiveSlider("حجم الرقم: ${Arabic.digits((draft.numScale * 100).toInt())}٪", draft.numScale, 0.6f..1.5f) { v -> update { copy(numScale = v) } }
                        Text("الخط", color = UColors.CreamDim, fontSize = 12.sp)
                        ChipRow(listOf(0, 1, 2, 3), { it == draft.font }, { CounterCfg.FONT_NAMES[it] }) { v -> update { copy(font = v) } }
                        Text("الوضع", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                        ChipRow(listOf(0, 1, 2), { it == draft.tone }, { listOf("حسب التصميم", "داكن", "فاتح")[it] }) { v -> update { copy(tone = v) } }
                    }
                }
            }

            if (!classic) {
                item { SectionLabel("الألوان والشفافية") }
                item {
                    GlassCard(Modifier.fillMaxWidth()) {
                        ColorPickRow("لون الأرقام", draft.numColor, Color(0xFFFFF8E6)) { c -> update { copy(numColor = c) } }
                        ColorPickRow("لون الحلقة", draft.ringColor, defaultRing) { c -> update { copy(ringColor = c) } }
                        ColorPickRow("لون الخلفية", draft.bgColor, defaultFace) { c -> update { copy(bgColor = c) } }
                        LiveSlider("شفافية الخلفية: ${Arabic.digits((draft.bgAlpha * 100).toInt())}٪", draft.bgAlpha, 0f..1f) { v -> update { copy(bgAlpha = v) } }
                    }
                }
            }

            item { SectionLabel("الحركة والإضاءة") }
            item {
                GlassCard(Modifier.fillMaxWidth()) {
                    SwitchRow("التأثيرات المتحركة", if (s.reduceMotion) "متوقفة حاليًا من إعدادات «الحركة» في التطبيق" else "إيقافها يوفّر البطارية", draft.anim) { v -> update { copy(anim = v) } }
                    if (!classic) {
                        LiveSlider("سرعة الأنيميشن: ${Arabic.digits((draft.speed * 100).toInt())}٪", draft.speed, 0.4f..2.5f) { v -> update { copy(speed = v) } }
                        LiveSlider("شدة الإضاءة: ${Arabic.digits((draft.glow * 100).toInt())}٪", draft.glow, 0f..1.6f) { v -> update { copy(glow = v) } }
                    }
                }
            }

            item { SectionLabel("المحتوى والهدف") }
            item {
                GlassCard(Modifier.fillMaxWidth()) {
                    SwitchRow("إظهار اسم الذكر داخل العدّاد", "يظهر خصوصًا في ودجت الشاشة الرئيسية", draft.showName) { v -> update { copy(showName = v) } }
                    SwitchRow("إظهار الهدف", null, draft.showGoal) { v -> update { copy(showGoal = v) } }
                    Text("عدد التسبيحات المستهدف", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                    ChipRow(listOf(33, 99, 100), { it == demoTarget }, { Arabic.digits(it) }) { v -> demoTarget = v; demoCount = 0 }
                    Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PillButton("رقم مخصص", { customTarget = true }, icon = Ico.Edit, filled = false)
                        PillButton("اجعله هدف الجلسة", { confirmTarget = true }, icon = Ico.Star, filled = false)
                    }
                    Text("الهدف هنا للمعاينة؛ «اجعله هدف الجلسة» يطبّقه على جلستك الحالية.", color = UColors.CreamDim, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                }
            }

            item { SectionLabel("الاهتزاز والصوت") }
            item {
                GlassCard(Modifier.fillMaxWidth()) {
                    SwitchRow("اهتزاز خفيف عند الضغط", "إعداد عام للتطبيق", s.haptics) { v -> store.edit { putBoolean("haptics", v) } }
                    SwitchRow("صوت النقرة", "افتراضيًا متوقف", s.sound) { v -> store.edit { putBoolean("sound", v) } }
                }
            }

            item { SectionLabel("تصاميمي المحفوظة") }
            if (saved.isEmpty()) {
                item { Text("لا توجد تصاميم محفوظة بعد. خصّص العدّاد ثم اضغط «حفظ باسم».", color = UColors.CreamDim, fontSize = 12.sp) }
            }
            items(saved) { nc ->
                GlassCard(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(64.dp), contentAlignment = Alignment.Center) {
                            if (CounterCatalog.isClassic(nc.cfg.styleId)) CounterButton(21, 33, 64.dp, "", true, {})
                            else StyledCounter(nc.cfg.copy(showName = false, showGoal = false), 21, 33, "", true, null, sizeDp = 64.dp, staticFrame = true)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(nc.name, color = UColors.Cream, fontWeight = FontWeight.Bold)
                            Text(CounterCatalog.byId(nc.cfg.styleId)?.name ?: CounterCatalog.CLASSIC_NAME, color = UColors.CreamDim, fontSize = 11.sp)
                        }
                        IconBtn(Ico.Check, "استخدام", { draft = nc.cfg })
                        IconBtn(Ico.Delete, "حذف", { store.deleteCounterDesign(nc.name) })
                    }
                }
            }

            item { SectionLabel("إعادة الضبط") }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillButton("استعادة الإعدادات الافتراضية للتصميم", { draft = draft.resetKeepingStyle() }, Modifier.fillMaxWidth(), icon = Ico.Refresh, filled = false)
                    PillButton("العودة للعدّاد الرئيسي الأصلي", { draft = CounterCfg() }, Modifier.fillMaxWidth(), icon = Ico.Beads, filled = false)
                    PillButton("تصفير عدّاد المسبحة الحالي", { confirmReset = true }, Modifier.fillMaxWidth(), icon = Ico.Delete, filled = false)
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }

    if (customTarget) NumberDialog("الهدف المخصص", "العدد", demoTarget, { customTarget = false }) { n -> demoTarget = n.coerceIn(1, 100_000); demoCount = 0 }
    if (confirmTarget) ConfirmDialog(
        "تطبيق الهدف على الجلسة؟",
        "سيصبح هدف الجلسة الحالية ${Arabic.digits(demoTarget)} ويبدأ عدّها من الصفر. لا يتأثر سجل اليوم.",
        "تطبيق",
        { store.setTasbihTarget(demoTarget); WidgetRenderer.updateTasbihFamily(ctx) },
    ) { confirmTarget = false }
    if (confirmReset) ConfirmDialog(
        "تصفير العدّاد؟", "سيعود عدّاد الجلسة الحالية إلى الصفر. لا يتأثر سجل اليوم.", "تصفير",
        { store.tasbihReset(); WidgetRenderer.updateTasbihFamily(ctx) },
    ) { confirmReset = false }
    if (saveDialog) {
        AlertDialog(
            onDismissRequest = { saveDialog = false },
            containerColor = UColors.CardSolid,
            title = { Text("حفظ التصميم", color = UColors.Cream) },
            text = {
                OutlinedTextField(
                    value = saveName, onValueChange = { saveName = it.take(24) }, singleLine = true,
                    label = { Text("اسم التصميم") }, colors = fieldColors(),
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (saveName.isNotBlank()) {
                        store.saveCounterDesign(saveName, draft)
                        Toast.makeText(ctx, "تم حفظ التصميم", Toast.LENGTH_SHORT).show()
                    }
                    saveDialog = false
                }) { Text("حفظ", color = UColors.Gold) }
            },
            dismissButton = { TextButton(onClick = { saveDialog = false }) { Text("إلغاء", color = UColors.CreamDim) } },
        )
    }
}
