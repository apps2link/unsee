package com.unsee.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews
import com.unsee.app.MainActivity
import com.unsee.app.R
import com.unsee.app.core.Arabic
import com.unsee.app.core.DayPart
import com.unsee.app.core.TimeLogic
import com.unsee.app.core.WidgetLogic
import com.unsee.app.core.WidgetSource
import com.unsee.app.data.Settings
import com.unsee.app.data.Store
import com.unsee.app.data.Zikr
import java.time.LocalTime
import kotlin.math.min

enum class WidgetStyle(val label: String, val description: String, val autoRotate: Boolean) {
    CINEMATIC("السينمائية", "ذكر واحد بخلفية الفجر أو الليل وتوهج ذهبي", true),
    TRANSPARENT("الشفافة", "نص أنيق على خلفية شفافة تتحكم بدرجتها ولون النص", true),
    GLASS("الزجاجية", "تصميم زجاجي بحدود مضيئة يندمج مع خلفية الشاشة", true),
    MINI("المصغرة", "ذكر قصير مع عدد التكرار — مساحة صغيرة", true),
    LARGE("الكبيرة", "الذكر كاملًا مع زر التسبيح والتنقل وعدّاد اليوم", false),
    TASBIH("سبحة", "عدّاد دائري بتوهج عند الضغط وهدف قابل للتحديد", false),
    PERIOD("الصباح والمساء", "تتبدّل حسب الفترة، وتتيح التنقل بين الأذكار والعدّ", false),
    LUXE("الفاخرة", "زمردي وذهبي بزخارف هندسية إسلامية", true),
    CUSTOM("المخصّصة", "تختار لون الخلفية والنص ونوع الأذكار", true),
    COUNTER_ART("العدّاد الفني", "عدّاد التسبيح بالتصميم الذي تختاره من استوديو العدّادات (50+ تصميمًا)", false),
}

object WidgetRenderer {
    const val ACTION_NEXT = "com.unsee.app.widget.NEXT"
    const val ACTION_PREV = "com.unsee.app.widget.PREV"
    const val ACTION_TAP = "com.unsee.app.widget.TAP"

    fun providerClass(style: WidgetStyle): Class<out AppWidgetProvider> = when (style) {
        WidgetStyle.CINEMATIC -> CinematicWidget::class.java
        WidgetStyle.TRANSPARENT -> TransparentWidget::class.java
        WidgetStyle.GLASS -> GlassWidget::class.java
        WidgetStyle.MINI -> MiniWidget::class.java
        WidgetStyle.LARGE -> LargeWidget::class.java
        WidgetStyle.TASBIH -> TasbihWidget::class.java
        WidgetStyle.PERIOD -> PeriodWidget::class.java
        WidgetStyle.LUXE -> LuxeWidget::class.java
        WidgetStyle.CUSTOM -> CustomWidget::class.java
        WidgetStyle.COUNTER_ART -> CounterArtWidget::class.java
    }

    fun ids(ctx: Context, style: WidgetStyle): IntArray =
        AppWidgetManager.getInstance(ctx).getAppWidgetIds(ComponentName(ctx, providerClass(style)))

    /** يحدّث ودجت المسبحة الأصلية وودجت العدّاد الفني معًا (يشتركان في نفس عدّاد الجلسة). */
    fun updateTasbihFamily(ctx: Context, flash: Boolean = false) {
        updateStyle(ctx, WidgetStyle.TASBIH, flash)
        updateStyle(ctx, WidgetStyle.COUNTER_ART, flash)
    }

    fun updateAll(ctx: Context) = WidgetStyle.values().forEach { updateStyle(ctx, it) }

    fun updateStyle(ctx: Context, style: WidgetStyle, flash: Boolean = false) {
        val mgr = AppWidgetManager.getInstance(ctx)
        for (id in ids(ctx, style)) update(ctx, mgr, id, style, flash)
    }

    fun update(ctx: Context, mgr: AppWidgetManager, id: Int, style: WidgetStyle, flash: Boolean = false) {
        val views = runCatching { build(ctx, id, style, flash) }
            .getOrElse { RemoteViews(ctx.packageName, if (style == WidgetStyle.TASBIH) R.layout.widget_tasbih else if (style == WidgetStyle.COUNTER_ART) R.layout.widget_counter_art else if (style == WidgetStyle.MINI) R.layout.widget_mini else R.layout.widget_card) }
        mgr.updateAppWidget(id, views)
    }

    // ---------------------------------------------------------------- المحتوى

    data class Resolved(val pool: List<Zikr>, val index: Int) {
        val zikr: Zikr? get() = pool.getOrNull(index)
    }

    fun resolve(id: Int, style: WidgetStyle, store: Store, s: Settings): Resolved {
        val hour = LocalTime.now().hour
        val source = when (style) {
            WidgetStyle.PERIOD -> WidgetSource.AUTO
            WidgetStyle.CUSTOM -> store.widgetCfg(id).source ?: s.widgetSource
            else -> s.widgetSource
        }
        val pool = WidgetLogic.pool(source, hour, store.favorites(), shortOnly = style == WidgetStyle.MINI)
        val off = store.widgetOffset(id)
        val idx = if (style.autoRotate && s.widgetAutoRotate)
            WidgetLogic.rotatingIndex(pool.size, off, System.currentTimeMillis())
        else WidgetLogic.manualIndex(pool.size, off)
        return Resolved(pool, idx)
    }

    private fun backgroundFor(part: DayPart): Int = when (part) {
        DayPart.DAWN -> R.drawable.bg_dawn
        DayPart.DAY -> R.drawable.bg_day
        DayPart.SUNSET -> R.drawable.bg_sunset
        DayPart.NIGHT -> R.drawable.bg_night
    }

    private fun build(ctx: Context, id: Int, style: WidgetStyle, flash: Boolean): RemoteViews {
        val store = Store.get(ctx)
        val s = store.settings()
        return when (style) {
            WidgetStyle.TASBIH -> buildTasbih(ctx, id, store, s, flash)
            WidgetStyle.COUNTER_ART -> buildCounterArt(ctx, id, store, flash)
            WidgetStyle.MINI -> buildMini(ctx, id, store, s)
            else -> buildCard(ctx, id, style, store, s)
        }
    }

    private fun progressText(z: Zikr, p: Int): String =
        if (z.count > 0) "${Arabic.digits(p.coerceAtMost(z.count))}/${Arabic.digits(z.count)}" else "${Arabic.digits(p)}"

    private fun buildCard(ctx: Context, id: Int, style: WidgetStyle, store: Store, s: Settings): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_card)
        val hour = LocalTime.now().hour
        val part = TimeLogic.dayPart(hour)
        val r = resolve(id, style, store, s)
        val z = r.zikr

        // الخلفية
        val cfg = if (style == WidgetStyle.CUSTOM) store.widgetCfg(id) else null
        val (bgRes, alpha) = when (style) {
            WidgetStyle.TRANSPARENT -> R.drawable.bg_transparent_fill to (s.widgetBgAlpha * 255 / 100)
            WidgetStyle.GLASS -> R.drawable.bg_glass to 255
            WidgetStyle.LUXE -> R.drawable.bg_luxe to 255
            WidgetStyle.CUSTOM -> {
                val res = when (cfg?.bg ?: 0) {
                    1 -> R.drawable.bg_night
                    2 -> R.drawable.bg_dawn
                    3 -> R.drawable.bg_black
                    4 -> R.drawable.bg_purple
                    else -> R.drawable.bg_luxe
                }
                res to ((cfg?.alpha ?: 100) * 255 / 100)
            }
            else -> backgroundFor(part) to 255
        }
        rv.setImageViewResource(R.id.bg, bgRes)
        rv.setInt(R.id.bg, "setImageAlpha", alpha.coerceIn(0, 255))

        // الزخارف
        val decorated = style == WidgetStyle.CINEMATIC || style == WidgetStyle.LARGE || style == WidgetStyle.PERIOD
        rv.setViewVisibility(R.id.deco_sky, if (decorated) View.VISIBLE else View.GONE)
        rv.setViewVisibility(R.id.deco_skyline, if (decorated) View.VISIBLE else View.GONE)
        rv.setImageViewResource(R.id.deco_sky, if (part == DayPart.NIGHT) R.drawable.deco_moon else R.drawable.deco_sun)
        rv.setViewVisibility(R.id.deco_geo, if (style == WidgetStyle.LUXE) View.VISIBLE else View.GONE)

        if (z == null) {
            rv.setTextViewText(R.id.zikr, "افتح التطبيق لاختيار الأذكار")
            return rv
        }
        val p = store.progress(z.id)

        // النصوص
        val title = when (style) {
            WidgetStyle.PERIOD -> "${z.category.title}  ·  ${Arabic.digits(r.index + 1)}/${Arabic.digits(r.pool.size)}"
            WidgetStyle.LARGE -> "${z.category.title}  ·  ${z.title}"
            else -> z.title
        }
        rv.setTextViewText(R.id.title, title)
        rv.setTextViewText(R.id.zikr, z.text)
        val textColor = when (style) {
            WidgetStyle.TRANSPARENT, WidgetStyle.GLASS -> s.widgetTextColor
            WidgetStyle.CUSTOM -> (cfg?.color ?: 0xFFFFF4D6).toInt()
            else -> 0xFFFFF4D6.toInt()
        }
        rv.setTextColor(R.id.zikr, textColor)

        val meta = when (style) {
            WidgetStyle.LARGE -> buildString {
                append(if (z.count > 0) "التكرار ${progressText(z, p)}" else "عدد: ${Arabic.digits(p)}")
                if (s.statsEnabled) append("  ·  تسبيحات اليوم ${Arabic.digits(store.todayTaps())}")
            }
            WidgetStyle.PERIOD -> if (z.count > 0) "التكرار ${progressText(z, p)}" else "عدد: ${Arabic.digits(p)}"
            else -> if (z.count > 0) "×${Arabic.digits(z.count)}  ·  ${z.source}" else z.source
        }
        rv.setTextViewText(R.id.meta, meta)

        // الأزرار
        val manual = style == WidgetStyle.LARGE || style == WidgetStyle.PERIOD
        rv.setViewVisibility(R.id.btn_prev, if (manual) View.VISIBLE else View.GONE)
        rv.setViewVisibility(R.id.btn_tap, if (manual) View.VISIBLE else View.GONE)
        val done = z.count > 0 && p >= z.count
        rv.setTextViewText(R.id.btn_tap, if (done) "✓ تم — التالي" else "سَبِّح")
        rv.setOnClickPendingIntent(R.id.btn_next, actionIntent(ctx, id, style, ACTION_NEXT))
        rv.setOnClickPendingIntent(R.id.btn_prev, actionIntent(ctx, id, style, ACTION_PREV))
        rv.setOnClickPendingIntent(R.id.btn_tap, actionIntent(ctx, id, style, ACTION_TAP))
        rv.setOnClickPendingIntent(R.id.root, openAppIntent(ctx, id, "list/${z.category.name}?start=${z.id}"))
        return rv
    }

    private fun buildMini(ctx: Context, id: Int, store: Store, s: Settings): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_mini)
        val part = TimeLogic.dayPart(LocalTime.now().hour)
        rv.setImageViewResource(R.id.m_bg, backgroundFor(part))
        val r = resolve(id, WidgetStyle.MINI, store, s)
        val z = r.zikr ?: return rv
        rv.setTextViewText(R.id.m_zikr, z.text)
        rv.setTextViewText(R.id.m_meta, if (z.count > 0) "×${Arabic.digits(z.count)}" else "∞")
        rv.setOnClickPendingIntent(R.id.m_next, actionIntent(ctx, id, WidgetStyle.MINI, ACTION_NEXT))
        rv.setOnClickPendingIntent(R.id.m_root, openAppIntent(ctx, id, "list/${z.category.name}?start=${z.id}"))
        return rv
    }

    private fun buildTasbih(ctx: Context, id: Int, store: Store, s: Settings, flash: Boolean): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_tasbih)
        val t = store.tasbih()
        val shown = t.count.coerceAtMost(t.target)
        val (w, h) = WidgetBitmaps.sizePx(ctx, AppWidgetManager.getInstance(ctx), id)
        rv.setImageViewBitmap(R.id.t_img, WidgetBitmaps.tasbih(w, h, shown, t.target, t.text, flash, WidgetBitmaps.isNight(ctx, s)))
        rv.setOnClickPendingIntent(R.id.t_root, actionIntent(ctx, id, WidgetStyle.TASBIH, ACTION_TAP))
        return rv
    }

    /** ودجت العدّاد الفني: لقطة (Bitmap) من نفس رسم العدّاد بحجم الودجت الفعلي (وليس 360 بكسل ثابتة) فتبقى حادة عند التكبير. */
    private fun buildCounterArt(ctx: Context, id: Int, store: Store, flash: Boolean): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_counter_art)
        val t = store.tasbih()
        val cfg = store.counterCfg()
        val shown = t.count.coerceAtMost(t.target)
        val drawCfg = if (com.unsee.app.core.CounterCatalog.isClassic(cfg.styleId)) {
            // العدّاد الرئيسي الأصلي: نعرضه بأول تصميم ذهبي مضيء كي تظهر لقطة جميلة في الودجت
            cfg.copy(styleId = com.unsee.app.core.CounterCatalog.all.first().id)
        } else cfg
        val (w, h) = WidgetBitmaps.sizePx(ctx, AppWidgetManager.getInstance(ctx), id)
        val side = min(w, h).coerceIn(128, 1100)
        val bmp = com.unsee.app.ui.renderCounterBitmap(side, drawCfg, shown, t.target, t.text, if (flash) 1f else 0f)
        rv.setImageViewBitmap(R.id.c_img, bmp)
        rv.setOnClickPendingIntent(R.id.c_root, actionIntent(ctx, id, WidgetStyle.COUNTER_ART, ACTION_TAP))
        return rv
    }

    // ---------------------------------------------------------------- PendingIntents

    private fun actionIntent(ctx: Context, id: Int, style: WidgetStyle, action: String): PendingIntent {
        val i = Intent(ctx, providerClass(style)).setAction(action).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
        return PendingIntent.getBroadcast(ctx, id * 31 + action.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun openAppIntent(ctx: Context, id: Int, route: String): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
            .putExtra("route", route)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        return PendingIntent.getActivity(ctx, id * 31 + route.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
}
