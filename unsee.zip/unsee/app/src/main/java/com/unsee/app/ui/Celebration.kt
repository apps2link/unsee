package com.unsee.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.withFrameNanos
import com.unsee.app.core.Arabic
import com.unsee.app.core.Dialect
import com.unsee.app.core.Voice
import com.unsee.app.data.CompanionStore
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

// ============================================================ اللهجة داخل الواجهة
val LocalVoice = staticCompositionLocalOf { Voice(Dialect.EGYPT) }

/** يوفّر لهجة المستخدم (مصرية/خليجية) لكل الشاشات، ويتحدّث فور تغيير الاختيار. */
@Composable
fun ProvideVoice(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val cs = remember { CompanionStore.get(ctx) }
    val d by cs.observeAsState { cs.dialect() }
    CompositionLocalProvider(LocalVoice provides remember(d) { Voice(d) }, content = content)
}

// ============================================================ الأحداث
data class ArenaEvent(val id: Int, val good: Boolean, val milestone: Boolean, val message: String)

private class Piece(val x0: Float, val y0: Float, val vx: Float, val vy: Float, val size: Float, val color: Color, val rot: Float, val spin: Float, val round: Boolean)

private val CONFETTI = listOf(Color(0xFF4ADE80), Color(0xFFFFD54F), Color(0xFFFFFFFF), Color(0xFF60A5FA), Color(0xFFF472B6))
private val RAIN = listOf(Color(0xFF94A3B8), Color(0xFF64748B), Color(0xFFCBD5E1))

private fun makePieces(e: ArenaEvent): List<Piece> {
    val r = Random(e.id * 7919)
    return if (e.good) {
        val n = if (e.milestone) 150 else 80
        List(n) {
            // تنطلق من منطقة اللوحة (أعلى الشاشة) وتتناثر لأسفل
            val fromBurst = it % 3 == 0
            Piece(
                x0 = if (fromBurst) 0.5f + (r.nextFloat() - 0.5f) * 0.2f else r.nextFloat(),
                y0 = if (fromBurst) 0.18f else -0.05f - r.nextFloat() * 0.2f,
                vx = (r.nextFloat() - 0.5f) * (if (fromBurst) 1.4f else 0.25f),
                vy = if (fromBurst) -0.5f - r.nextFloat() * 0.5f else 0.15f + r.nextFloat() * 0.25f,
                size = 5f + r.nextFloat() * 6f, color = CONFETTI[r.nextInt(CONFETTI.size)],
                rot = r.nextFloat() * 360f, spin = (r.nextFloat() - 0.5f) * 900f, round = r.nextInt(3) == 0,
            )
        }
    } else {
        List(46) {
            Piece(
                x0 = r.nextFloat(), y0 = -0.1f - r.nextFloat() * 0.4f, vx = 0f, vy = 0.35f + r.nextFloat() * 0.35f,
                size = 3f + r.nextFloat() * 3f, color = RAIN[r.nextInt(RAIN.size)], rot = 0f, spin = 0f, round = true,
            )
        }
    }
}

/**
 * طبقة الاحتفال فوق الشاشة كلها (لا تلتقط اللمس): قصاصات ملوّنة تتناثر وتدور عند الحسنة (وأكثر عند كل ٥ حسنات)،
 * ومطر هادئ مع وجه حزين تنزل دمعته عند تسجيل ذنب. مدتها نحو ٢٫٦ ثانية ثم تختفي.
 */
@Composable
fun CelebrationLayer(event: ArenaEvent?, modifier: Modifier = Modifier) {
    if (event == null) return
    var t by remember(event.id) { mutableLongStateOf(0L) }
    val pieces = remember(event.id) { makePieces(event) }
    LaunchedEffect(event.id) {
        val start = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            t = now - start
            if (t > 2_600_000_000L) break
        }
    }
    val secs = t / 1_000_000_000f
    if (secs >= 2.6f) return
    Canvas(modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val fade = (1f - ((secs - 1.9f) / 0.7f)).coerceIn(0f, 1f)
        if (!event.good) {
            // تعتيم خفيف يتنفس
            drawRect(Color(0xFF0F172A).copy(alpha = 0.28f * fade))
        }
        for (p in pieces) {
            val g = if (event.good) 0.55f else 0f
            val x = (p.x0 + p.vx * secs) * w
            val y = (p.y0 + p.vy * secs + 0.5f * g * secs * secs) * h
            if (y < -20f || y > h + 20f) continue
            val a = fade * (if (event.good) 1f else 0.7f)
            if (p.round) {
                drawCircle(p.color.copy(alpha = a), p.size, Offset(x, y))
            } else {
                rotate(p.rot + p.spin * secs, Offset(x, y)) {
                    drawRect(p.color.copy(alpha = a), Offset(x - p.size, y - p.size * 0.6f), Size(p.size * 2f, p.size * 1.2f))
                }
            }
        }
        if (!event.good) drawSadFace(Offset(w / 2f, h * 0.34f), w * 0.16f, secs, fade)
        else if (event.milestone) drawStarburst(Offset(w * 0.5f, h * 0.2f), w * 0.3f * (0.4f + secs / 2.6f), fade)
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawSadFace(c: Offset, r: Float, secs: Float, fade: Float) {
    val pop = (secs / 0.35f).coerceIn(0f, 1f)
    val rr = r * (0.6f + 0.4f * pop)
    val a = fade
    drawCircle(Color(0xFF475569).copy(alpha = 0.92f * a), rr, c)
    drawCircle(Color(0xFF94A3B8).copy(alpha = a), rr, c, style = Stroke(rr * 0.07f))
    val eyeY = c.y - rr * 0.18f
    drawCircle(Color.White.copy(alpha = a), rr * 0.09f, Offset(c.x - rr * 0.33f, eyeY))
    drawCircle(Color.White.copy(alpha = a), rr * 0.09f, Offset(c.x + rr * 0.33f, eyeY))
    // حاجبان مائلان للحزن
    drawLine(Color.White.copy(alpha = a), Offset(c.x - rr * 0.5f, eyeY - rr * 0.2f), Offset(c.x - rr * 0.2f, eyeY - rr * 0.32f), rr * 0.06f, StrokeCap.Round)
    drawLine(Color.White.copy(alpha = a), Offset(c.x + rr * 0.5f, eyeY - rr * 0.2f), Offset(c.x + rr * 0.2f, eyeY - rr * 0.32f), rr * 0.06f, StrokeCap.Round)
    // فم مقلوب
    drawArc(
        Color.White.copy(alpha = a), startAngle = 205f, sweepAngle = 130f, useCenter = false,
        topLeft = Offset(c.x - rr * 0.38f, c.y + rr * 0.22f), size = Size(rr * 0.76f, rr * 0.5f),
        style = Stroke(rr * 0.07f, cap = StrokeCap.Round),
    )
    // دمعة تنزل
    val k = ((secs - 0.4f) / 1.4f).coerceIn(0f, 1f)
    drawCircle(Color(0xFF7DD3FC).copy(alpha = a * (1f - k * 0.6f)), rr * 0.07f, Offset(c.x - rr * 0.33f, eyeY + rr * 0.1f + k * rr * 0.9f))
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawStarburst(c: Offset, r: Float, fade: Float) {
    for (i in 0 until 12) {
        val a = (i * PI / 6).toFloat()
        drawLine(
            Color(0xFFFFD54F).copy(alpha = 0.55f * fade), Offset(c.x + cos(a) * r * 0.35f, c.y + sin(a) * r * 0.35f),
            Offset(c.x + cos(a) * r, c.y + sin(a) * r), 5f, StrokeCap.Round,
        )
    }
}

/** لافتة التشجيع/المواساة تنزلق من أعلى الشاشة وتختفي وحدها. */
@Composable
fun CheerBanner(event: ArenaEvent?, modifier: Modifier = Modifier) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(event?.id) {
        if (event != null) { visible = true; delay(2600); visible = false }
    }
    Box(modifier.fillMaxWidth().padding(top = 70.dp, start = 24.dp, end = 24.dp), contentAlignment = Alignment.TopCenter) {
        AnimatedVisibility(
            visible && event != null,
            enter = slideInVertically(spring(dampingRatio = Spring.DampingRatioMediumBouncy)) { -it } + fadeIn() + scaleIn(),
            exit = fadeOut(tween(300)) + scaleOut(),
        ) {
            val good = event?.good != false
            val shape = RoundedCornerShape(22.dp)
            Text(
                event?.message.orEmpty(),
                color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp, textAlign = TextAlign.Center,
                modifier = Modifier.clip(shape)
                    .background(Brush.horizontalGradient(if (good) listOf(Color(0xFF16A34A), Color(0xFF0D9488)) else listOf(Color(0xFF475569), Color(0xFF334155))))
                    .border(1.5.dp, Color.White.copy(alpha = 0.35f), shape)
                    .padding(horizontal = 18.dp, vertical = 12.dp),
            )
        }
    }
}

// ============================================================ الشاشة العملاقة
/**
 * شاشة العرض: يسار = السيئات (أحمر) ويمين = الحسنات (أخضر) دائمًا، بصرف النظر عن اتجاه الواجهة (نفرض LTR هنا عمدًا).
 * الأرقام تعدّ تصاعديًا بحركة وتنبض عند التغيّر، وشريط الميزان في الأسفل يميل لجهة الأغلب، والشريط النصي يعرض آخر كلمة تشجيع.
 */
@Composable
fun ScoreBoard(good: Int, sin: Int, ticker: String, modifier: Modifier = Modifier) {
    val v = LocalVoice.current
    val g by animateIntAsState(good, tween(700), label = "good")
    val s by animateIntAsState(sin, tween(700), label = "sin")
    val share by animateFloatAsState(if (good + sin == 0) 0.5f else good.toFloat() / (good + sin), spring(dampingRatio = 0.55f), label = "share")
    val bumpG = remember { Animatable(1f) }
    val bumpS = remember { Animatable(1f) }
    LaunchedEffect(good) { if (good > 0) { bumpG.snapTo(1.35f); bumpG.animateTo(1f, spring(dampingRatio = 0.35f, stiffness = 300f)) } }
    LaunchedEffect(sin) { if (sin > 0) { bumpS.snapTo(1.35f); bumpS.animateTo(1f, spring(dampingRatio = 0.35f, stiffness = 300f)) } }
    val glow by rememberInfiniteTransition(label = "glow").animateFloat(
        0.55f, 1f, infiniteRepeatable(tween(1700), RepeatMode.Reverse), label = "glowv",
    )
    val green = Color(0xFF4ADE80)
    val red = Color(0xFFF87171)
    val shape = RoundedCornerShape(28.dp)

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(
            modifier.fillMaxWidth().height(206.dp).clip(shape)
                .background(Brush.verticalGradient(listOf(Color(0xFF04060B), Color(0xFF0B1324))))
                .border(2.dp, Color(0xFF26324F), shape),
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                // وهج كل جهة
                drawCircle(Brush.radialGradient(listOf(red.copy(alpha = 0.30f * glow), Color.Transparent), Offset(w * 0.25f, h * 0.42f), w * 0.36f), w * 0.36f, Offset(w * 0.25f, h * 0.42f))
                drawCircle(Brush.radialGradient(listOf(green.copy(alpha = 0.30f * glow), Color.Transparent), Offset(w * 0.75f, h * 0.42f), w * 0.36f), w * 0.36f, Offset(w * 0.75f, h * 0.42f))
                // خطوط مسح تعطي إحساس شاشة LED
                var y = 0f
                while (y < h) { drawLine(Color.White.copy(alpha = 0.035f), Offset(0f, y), Offset(w, y), 1f); y += 7f }
                // فاصل المنتصف
                drawLine(Color.White.copy(alpha = 0.14f), Offset(w / 2f, 18f), Offset(w / 2f, h - 62f), 2f, StrokeCap.Round)
                // شريط الميزان: أحمر من اليسار وأخضر من اليمين، الحد بينهما يتحرك
                val barH = 12.dp.toPx()
                val left = 20.dp.toPx()
                val trackW = w - left * 2
                val top = h - 50.dp.toPx()
                drawRoundRect(Color.White.copy(alpha = 0.08f), Offset(left, top), Size(trackW, barH), androidx.compose.ui.geometry.CornerRadius(barH / 2f))
                val greenW = trackW * share
                if (share < 0.999f) drawRoundRect(red.copy(alpha = 0.95f), Offset(left, top), Size(trackW - greenW + barH / 2f, barH), androidx.compose.ui.geometry.CornerRadius(barH / 2f))
                if (share > 0.001f) drawRoundRect(green.copy(alpha = 0.95f), Offset(left + trackW - greenW, top), Size(greenW, barH), androidx.compose.ui.geometry.CornerRadius(barH / 2f))
                drawCircle(Color.White, barH * 0.62f, Offset(left + trackW - greenW, top + barH / 2f))
            }
            Row(Modifier.fillMaxSize().padding(top = 14.dp, bottom = 62.dp)) {
                Column(Modifier.weight(1f).fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center) {
                    Text(v.t("سيئات", "سيئات"), color = red, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text(
                        Arabic.digits(s), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black, fontSize = 66.sp,
                        style = TextStyle(color = red, shadow = Shadow(red, blurRadius = 26f)),
                        modifier = Modifier.graphicsScale(bumpS.value),
                    )
                }
                Column(Modifier.weight(1f).fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center) {
                    Text(v.t("حسنات", "حسنات"), color = green, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text(
                        Arabic.digits(g), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black, fontSize = 66.sp,
                        style = TextStyle(color = green, shadow = Shadow(green, blurRadius = 26f)),
                        modifier = Modifier.graphicsScale(bumpG.value),
                    )
                }
            }
            Text(
                ticker, color = Color(0xFFE2E8F0), fontSize = 13.sp, maxLines = 1, textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(bottom = 12.dp, start = 12.dp, end = 12.dp),
            )
        }
    }
}

private fun Modifier.graphicsScale(s: Float): Modifier = this.scale(s)
