package com.unsee.app.core

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField

/** التاريخ الهجري (تقويم أم القرى المدمج في Java/Android) والميلادي. قد يختلف عن رؤية بلدك بيوم. */
object DateText {
    private val HIJRI_MONTHS = listOf(
        "محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة",
        "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة",
    )
    private val GREG_MONTHS = listOf(
        "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
        "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر",
    )
    val WEEK_DAYS = listOf("الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد")

    fun weekDay(d: DayOfWeek): String = WEEK_DAYS[d.value - 1]

    fun hijri(date: LocalDate): String? = runCatching {
        val h = HijrahDate.from(date)
        val d = h.get(ChronoField.DAY_OF_MONTH)
        val m = h.get(ChronoField.MONTH_OF_YEAR)
        val y = h.get(ChronoField.YEAR)
        "${Arabic.digits(d)} ${HIJRI_MONTHS[m - 1]} ${Arabic.digits(y)} هـ"
    }.getOrNull()

    fun gregorian(date: LocalDate): String =
        "${Arabic.digits(date.dayOfMonth)} ${GREG_MONTHS[date.monthValue - 1]} ${Arabic.digits(date.year)}"
}
