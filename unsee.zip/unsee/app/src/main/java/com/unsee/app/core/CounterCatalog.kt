package com.unsee.app.core

/**
 * كتالوج عدّادات التسبيح الدائرية.
 *
 * العدّاد الأصلي الموجود في التطبيق («classic») يبقى هو العدّاد الرئيسي والافتراضي، وتُضاف إليه 50 تصميمًا جديدًا.
 * كل «محرّك» ([CounterEngine]) له رسم وحركة مستقلان تمامًا (حلقة مضيئة، زجاج، هلال ونجوم، ماء، مجرة، زخارف، 3D، ورق شجر، قمر، خط عربي، لهب…)،
 * والتصاميم داخل المحرّك الواحد تختلف في الألوان وفي شكل الهندسة نفسها عبر [CounterStyle.variant] (مثلًا حلقة ناعمة / حلقة مزدوجة / حلقة نقطية).
 *
 * الألوان بصيغة ARGB (Long) ليبقى الملف نقيًّا وقابلًا للاختبار على JVM دون Compose.
 */
enum class CounterEngine(val label: String) {
    HALO("حلقة مضيئة"), GLASS_GEM("زجاج الأحجار"), CRESCENT("هلال ونجوم"), ORBIT("جزيئات مدارية"),
    HUE_RING("حلقة متغيّرة اللون"), WATER("ماء وتموّجات"), GALAXY("مجرة"), GEO("زخارف هندسية"),
    PULSE("نبض ضوئي"), DEPTH("ثلاثي الأبعاد"), LEAF("طبيعة وأوراق"), FROST("زجاج متحرك"),
    MOON("قمر وسماء"), CALLI("خط عربي"), EMBER("لهب هادئ"), BEADS("حبات مسبحة"),
    STAR8("نجمة ثمانية"), SUNRISE("شروق"), LANTERN("فانوس"), PETALS("بتلات"),
}

/**
 * @param variant يغيّر هندسة الرسم داخل المحرّك (0 أو 1 أو 2).
 * @param c1 اللون الأساسي للحلقة، [c2] ثانوي/توهج، [c3] ثالث (نجوم/جزيئات/نهاية التدرج).
 * @param face لون وجه العدّاد الافتراضي، [dark] هل التصميم داكن افتراضيًا.
 */
data class CounterStyle(
    val id: String,
    val name: String,
    val engine: CounterEngine,
    val variant: Int,
    val c1: Long, val c2: Long, val c3: Long,
    val face: Long,
    val dark: Boolean = true,
)

object CounterCatalog {
    const val CLASSIC = "classic"
    const val CLASSIC_NAME = "العدّاد الرئيسي"

    private fun s(n: Int, name: String, e: CounterEngine, v: Int, c1: Long, c2: Long, c3: Long, face: Long, dark: Boolean = true) =
        CounterStyle("k" + n.toString().padStart(2, '0'), name, e, v, c1, c2, c3, face, dark)

    val all: List<CounterStyle> = listOf(
        // حلقة مضيئة
        s(1, "الهالة الذهبية", CounterEngine.HALO, 0, 0xFFE9C46A, 0xFFFFE9A8, 0xFFFFF6D6, 0xFF14110A),
        s(2, "الهالة الفضية", CounterEngine.HALO, 1, 0xFFDDE3EE, 0xFFFFFFFF, 0xFFB9C4D6, 0xFF10151C),
        s(3, "الذهب الوردي", CounterEngine.HALO, 2, 0xFFF2B8A0, 0xFFFFD9C7, 0xFFFFF0E8, 0xFF1F1214),
        // زجاج الأحجار
        s(4, "الزمرد الزجاجي", CounterEngine.GLASS_GEM, 0, 0xFF3FE0A0, 0xFFB8FFE3, 0xFFFFFFFF, 0xFF06251C),
        s(5, "الياقوت الأزرق", CounterEngine.GLASS_GEM, 1, 0xFF4DA8FF, 0xFFBFE0FF, 0xFFFFFFFF, 0xFF07203A),
        s(6, "الجمشت", CounterEngine.GLASS_GEM, 2, 0xFFB27CFF, 0xFFE3CCFF, 0xFFFFFFFF, 0xFF1C0F36),
        // هلال ونجوم
        s(7, "هلال ذهبي", CounterEngine.CRESCENT, 0, 0xFFE9C46A, 0xFFFFF1B8, 0xFFFFFFFF, 0xFF0A1230),
        s(8, "هلال فضي ليلي", CounterEngine.CRESCENT, 1, 0xFFC9D6F2, 0xFFFFFFFF, 0xFF8FB0FF, 0xFF0B1026),
        s(9, "هلال زمردي", CounterEngine.CRESCENT, 2, 0xFF58E6B0, 0xFFC6FFE8, 0xFFFFE9A8, 0xFF05231B),
        // جزيئات مدارية
        s(10, "شرارات ذهبية", CounterEngine.ORBIT, 0, 0xFFFFD36E, 0xFFFFF1C2, 0xFFFFAA33, 0xFF120D05),
        s(11, "لآلئ فيروزية", CounterEngine.ORBIT, 1, 0xFF5EEAE0, 0xFFC9FFFB, 0xFF8FE9FF, 0xFF042A2E),
        s(12, "شهب وردية", CounterEngine.ORBIT, 2, 0xFFFF8FC0, 0xFFFFD0E5, 0xFFFFFFFF, 0xFF24101C),
        // حلقة تتغير ألوانها حسب الإنجاز
        s(13, "قوس الإنجاز", CounterEngine.HUE_RING, 0, 0xFFFF5A5F, 0xFFFFC857, 0xFF3DDC84, 0xFF0E1412),
        s(14, "تدرّج الغسق", CounterEngine.HUE_RING, 1, 0xFF4DA8FF, 0xFFB27CFF, 0xFFFF7AB6, 0xFF0F1030),
        s(15, "تدرّج الشروق", CounterEngine.HUE_RING, 2, 0xFF3CD6C7, 0xFFFFD36E, 0xFFFF8A4C, 0xFF0B1A1E),
        // ماء وتموجات
        s(16, "ماء أزرق", CounterEngine.WATER, 0, 0xFF3DA5FF, 0xFF9FD6FF, 0xFFE6F5FF, 0xFF061B33),
        s(17, "بحيرة فيروزية", CounterEngine.WATER, 1, 0xFF2FD6C3, 0xFF9FF3E8, 0xFFE6FFFB, 0xFF04262B),
        s(18, "ينبوع زمردي", CounterEngine.WATER, 2, 0xFF3DDC84, 0xFFA8F5C8, 0xFFE8FFF2, 0xFF062115),
        // مجرة
        s(19, "مجرة بنفسجية", CounterEngine.GALAXY, 0, 0xFFB58CFF, 0xFF6A3DF0, 0xFFFF8AD8, 0xFF0A0620),
        s(20, "سديم أزرق", CounterEngine.GALAXY, 1, 0xFF5AA9FF, 0xFF2F5BFF, 0xFF8FF0FF, 0xFF050B25),
        s(21, "سديم وردي", CounterEngine.GALAXY, 2, 0xFFFF7AC6, 0xFF7B2FF7, 0xFFFFD1EE, 0xFF12061F),
        // زخارف هندسية إسلامية
        s(22, "النجمة الذهبية", CounterEngine.GEO, 0, 0xFFE9C46A, 0xFFFFE9A8, 0xFFB8862B, 0xFF08201A),
        s(23, "نقش زمردي", CounterEngine.GEO, 1, 0xFF4FE3A8, 0xFFC6FFE8, 0xFFE9C46A, 0xFF03241C),
        s(24, "نقش فيروزي فاتح", CounterEngine.GEO, 2, 0xFF1F9FB0, 0xFF7ADFE8, 0xFFB8862B, 0xFFF4FBFC, false),
        // نبض ضوئي
        s(25, "نبض ذهبي", CounterEngine.PULSE, 0, 0xFFFFD36E, 0xFFFFB347, 0xFFFFF1C2, 0xFF0F0C06),
        s(26, "نبض نيون أخضر", CounterEngine.PULSE, 1, 0xFF3DFFA0, 0xFF00C97A, 0xFFB8FFE0, 0xFF031A10),
        s(27, "نبض قرمزي", CounterEngine.PULSE, 2, 0xFFFF5A6B, 0xFFFF9A5A, 0xFFFFD0C8, 0xFF1A0609),
        // ثلاثي الأبعاد
        s(28, "الذهب البارز", CounterEngine.DEPTH, 0, 0xFFE9C46A, 0xFFFFF1B8, 0xFF8A5A0F, 0xFF4A3810),
        s(29, "التيتانيوم", CounterEngine.DEPTH, 1, 0xFFC5CCD6, 0xFFFFFFFF, 0xFF6B7684, 0xFF3A4250),
        s(30, "الزمرد البارز", CounterEngine.DEPTH, 2, 0xFF3FD99A, 0xFFC8FFE6, 0xFF0E6B4A, 0xFF0E4F38),
        // طبيعة وأوراق
        s(31, "ورقة الشجر", CounterEngine.LEAF, 0, 0xFF6FE39A, 0xFFCFFFE0, 0xFF2E9E5F, 0xFF06251A),
        s(32, "إكليل الزيتون", CounterEngine.LEAF, 1, 0xFFA8C95A, 0xFFE3F2B0, 0xFF6E8F2A, 0xFF14200A),
        s(33, "أوراق الخريف", CounterEngine.LEAF, 2, 0xFFFFAA4D, 0xFFFFD9A0, 0xFFC4612A, 0xFF1F1208),
        // زجاج بخلفية متحركة
        s(34, "زجاج متحرك", CounterEngine.FROST, 0, 0xFF9BE3FF, 0xFFFFFFFF, 0xFFB58CFF, 0xFF0A1A2E),
        s(35, "جليد", CounterEngine.FROST, 1, 0xFFCFF0FF, 0xFFFFFFFF, 0xFF7FC8FF, 0xFF0B2236),
        s(36, "زجاج الغروب", CounterEngine.FROST, 2, 0xFFFFB27A, 0xFFFFE0C2, 0xFFFF7AA8, 0xFF2A1226),
        // قمر وسماء ليلية
        s(37, "قمر ونجوم", CounterEngine.MOON, 0, 0xFFF3EFD8, 0xFFFFFFFF, 0xFFAFC4FF, 0xFF0A1330),
        s(38, "قمر الفجر", CounterEngine.MOON, 1, 0xFFFFE3B8, 0xFFFFF6E6, 0xFFFF9ABA, 0xFF241638),
        s(39, "قمر دافئ", CounterEngine.MOON, 2, 0xFFFFC857, 0xFFFFE9A8, 0xFFFF8A4C, 0xFF1C1022),
        // خط عربي
        s(40, "خط ذهبي", CounterEngine.CALLI, 0, 0xFFE9C46A, 0xFFFFF1B8, 0xFFB8862B, 0xFF0D0D12),
        s(41, "حبر على ورق", CounterEngine.CALLI, 1, 0xFF7A4F12, 0xFFB98A2E, 0xFF2B1D0C, 0xFFFFF8E5, false),
        s(42, "ثلث أزرق", CounterEngine.CALLI, 2, 0xFF4D8BFF, 0xFFBFD6FF, 0xFFE9C46A, 0xFF08122B),
        // لهب ناري خفيف
        s(43, "لهب هادئ", CounterEngine.EMBER, 0, 0xFFFF8A3D, 0xFFFFD27A, 0xFFFF4D2E, 0xFF1A0B06),
        s(44, "جمر ذهبي", CounterEngine.EMBER, 1, 0xFFFFC24D, 0xFFFFF0B8, 0xFFFF7A2E, 0xFF160E05),
        s(45, "ضوء شمعة", CounterEngine.EMBER, 2, 0xFFFFD98A, 0xFFFFF5D6, 0xFFFFB347, 0xFF140F08),
        // إضافات
        s(46, "المسبحة الذهبية", CounterEngine.BEADS, 0, 0xFFE9C46A, 0xFFFFF1B8, 0xFF8A5A0F, 0xFF0E1511),
        s(47, "النجمة الثمانية", CounterEngine.STAR8, 0, 0xFFE9C46A, 0xFFFFF1B8, 0xFF3DDC84, 0xFF06201A),
        s(48, "الشروق", CounterEngine.SUNRISE, 0, 0xFFFFB347, 0xFFFFE0A0, 0xFFFF6F59, 0xFF1B1030),
        s(49, "فانوس رمضان", CounterEngine.LANTERN, 0, 0xFFFFB84D, 0xFFFFE2A8, 0xFFE9C46A, 0xFF1C0A12),
        s(50, "بتلات الورد", CounterEngine.PETALS, 0, 0xFFFF8FB5, 0xFFFFD0E0, 0xFFFFF0F5, 0xFF2A1020),
    )

    fun byId(id: String): CounterStyle? = all.firstOrNull { it.id == id }
    fun isClassic(id: String): Boolean = id == CLASSIC || byId(id) == null
}

/**
 * إعدادات عدّاد المستخدم. القيمة 0 في الألوان تعني «لون التصميم الافتراضي».
 * تغيير الحجم أو الألوان لا يغيّر [styleId]، فيبقى التصميم نفسه دون البدء من الصفر.
 */
data class CounterCfg(
    val styleId: String = CounterCatalog.CLASSIC,
    val size: Int = 270,           // dp
    val numScale: Float = 1f,
    val font: Int = 0,             // 0 نسخ عريض، 1 عصري عريض، 2 نسخ خفيف، 3 عصري خفيف
    val numColor: Long = 0L,
    val ringColor: Long = 0L,
    val bgColor: Long = 0L,
    val bgAlpha: Float = 1f,
    val anim: Boolean = true,
    val speed: Float = 1f,
    val glow: Float = 1f,
    val showName: Boolean = true,
    val showGoal: Boolean = true,
    val tone: Int = 0,             // 0 حسب التصميم، 1 داكن، 2 فاتح
) {
    /** يعيد ضبط كل التخصيصات مع الإبقاء على التصميم المختار. */
    fun resetKeepingStyle(): CounterCfg = CounterCfg(styleId = styleId)

    fun clamped(): CounterCfg = copy(
        size = size.coerceIn(SIZE_MIN, SIZE_MAX),
        numScale = numScale.coerceIn(0.6f, 1.5f),
        font = font.coerceIn(0, 3),
        bgAlpha = bgAlpha.coerceIn(0f, 1f),
        speed = speed.coerceIn(0.4f, 2.5f),
        glow = glow.coerceIn(0f, 1.6f),
        tone = tone.coerceIn(0, 2),
    )

    companion object {
        const val SIZE_MIN = 180
        const val SIZE_MAX = 340
        val FONT_NAMES = listOf("نسخ عريض", "عصري عريض", "نسخ خفيف", "عصري خفيف")
    }
}

data class NamedCounter(val name: String, val cfg: CounterCfg)

object CounterCodec {
    private fun clean(s: String) = s.replace('|', ' ').replace(';', ' ').replace('=', ' ').replace('\n', ' ').trim()

    fun encode(c: CounterCfg): String = listOf(
        "s=${clean(c.styleId)}", "z=${c.size}", "n=${c.numScale}", "f=${c.font}",
        "nc=${c.numColor}", "rc=${c.ringColor}", "bc=${c.bgColor}", "ba=${c.bgAlpha}",
        "an=${if (c.anim) 1 else 0}", "sp=${c.speed}", "gl=${c.glow}",
        "sn=${if (c.showName) 1 else 0}", "sg=${if (c.showGoal) 1 else 0}", "tn=${c.tone}",
    ).joinToString(";")

    fun decode(raw: String?): CounterCfg {
        if (raw.isNullOrBlank()) return CounterCfg()
        val m = HashMap<String, String>()
        for (part in raw.split(';')) {
            val i = part.indexOf('=')
            if (i > 0) m[part.substring(0, i)] = part.substring(i + 1)
        }
        val d = CounterCfg()
        fun i(k: String, def: Int) = m[k]?.toIntOrNull() ?: def
        fun f(k: String, def: Float) = m[k]?.toFloatOrNull() ?: def
        fun l(k: String, def: Long) = m[k]?.toLongOrNull() ?: def
        val id = m["s"]?.takeIf { it == CounterCatalog.CLASSIC || CounterCatalog.byId(it) != null } ?: CounterCatalog.CLASSIC
        return CounterCfg(
            styleId = id, size = i("z", d.size), numScale = f("n", d.numScale), font = i("f", d.font),
            numColor = l("nc", 0L), ringColor = l("rc", 0L), bgColor = l("bc", 0L), bgAlpha = f("ba", d.bgAlpha),
            anim = i("an", 1) == 1, speed = f("sp", d.speed), glow = f("gl", d.glow),
            showName = i("sn", 1) == 1, showGoal = i("sg", 1) == 1, tone = i("tn", 0),
        ).clamped()
    }

    fun encodeSaved(list: List<NamedCounter>): String = list.joinToString("\n") { clean(it.name) + "|" + encode(it.cfg) }

    fun decodeSaved(raw: String?): List<NamedCounter> {
        if (raw.isNullOrBlank()) return emptyList()
        return raw.split('\n').mapNotNull { line ->
            val i = line.indexOf('|')
            if (i <= 0) return@mapNotNull null
            val name = line.substring(0, i).trim()
            if (name.isEmpty()) null else NamedCounter(name, decode(line.substring(i + 1)))
        }
    }
}
