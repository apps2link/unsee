package com.unsee.app.ui

import android.Manifest
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import com.unsee.app.core.Arabic
import com.unsee.app.core.DateText
import com.unsee.app.core.Palettes
import com.unsee.app.core.Reminder
import com.unsee.app.core.ReminderKind
import com.unsee.app.core.ThemeId
import com.unsee.app.core.ThemeMode
import com.unsee.app.core.TimeLogic
import com.unsee.app.data.AdhkarData
import com.unsee.app.data.Category
import com.unsee.app.data.Settings
import com.unsee.app.data.Store
import com.unsee.app.notify.Reminders
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

// ============================================================ المزيد
@Composable
fun MoreScreen(nav: NavController) {
    data class Item(val icon: ImageVector, val title: String, val sub: String, val route: String)
    val items = listOf(
        Item(Ico.Book, "مكتبة الأذكار", "كل الأقسام والبحث في الأذكار", "adhkar"),
        Item(Ico.Mosque, "رفيق أُنسي", "صاحبك اللي يفكّرك بربنا: صلاة وذكر ومحاسبة", "companion"),
        Item(Ico.Beads, "استوديو العدّاد", "15 تصميمًا للعدّاد الدائري وتخصيص كامل", "ringstudio"),
        Item(Ico.Heart, "المفضلة", "أذكارك المحفوظة", "favorites"),
        Item(Ico.Chart, "الإحصائيات", "تسبيحك وتقدّمك اليومي", "stats"),
        Item(Ico.Alarm, "التذكيرات", "الصباح والمساء وتذكيرات مخصصة", "reminders"),
        Item(Ico.Palette, "الثيمات والمظهر", "الألوان والخط والبطاقات", "themes"),
        Item(Ico.FontSize, "إعدادات القراءة", "حجم الخط والتباعد والوضع الليلي", "reading"),
        Item(Ico.Settings, "إعدادات التطبيق", "الحركة والاهتزاز والبيانات", "appsettings"),
        Item(Ico.Help, "المساعدة", "أسئلة شائعة وطريقة الاستخدام", "help"),
        Item(Ico.Info, "معلومات التطبيق", "الإصدار والخصوصية والمصادر", "about"),
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ScreenHeader("المزيد")
        items.forEachIndexed { i, it ->
            Appear(i * 40) {
                GlassCard(Modifier.fillMaxWidth(), onClick = { nav.navigate(it.route) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconBadge(it.icon)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(it.title, color = UColors.Cream, fontWeight = FontWeight.Bold)
                            Text(it.sub, color = UColors.CreamDim, fontSize = 12.sp)
                        }
                        Icon(Ico.Forward, null, tint = UColors.Gold)
                    }
                }
            }
        }
    }
}

// ============================================================ المفضلة
@Composable
fun FavoritesScreen(store: Store, nav: NavController) {
    val ctx = LocalContext.current
    val favs by store.observeAsState { store.favorites() }
    val list = AdhkarData.all.filter { it.id in favs }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ScreenHeader("المفضلة", { nav.popBackStack() })
        if (list.isEmpty()) {
            EmptyState(Ico.HeartOutline, "لا توجد أذكار مفضلة", "افتح أي ذكر واضغط أيقونة القلب ليُحفظ هنا، ويمكنك جعل «المفضلة» مصدرًا للودجت.", "تصفّح الأذكار") { nav.navigate("adhkar") }
        }
        list.forEach { z ->
            GlassCard(Modifier.fillMaxWidth(), glow = true, onClick = { nav.navigate("list/${z.category.name}?start=${z.id}") }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(z.category.icon(), 38.dp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(z.title, color = UColors.Gold, fontWeight = FontWeight.Bold)
                        Text(z.text, color = UColors.Cream, fontSize = 14.sp, maxLines = 3)
                        Text(if (z.count > 0) "التكرار: ${Arabic.digits(z.count)}" else "بلا عدد محدد", color = UColors.CreamDim, fontSize = 11.sp)
                    }
                    Column {
                        IconBtn(Ico.Heart, "إزالة من المفضلة", { store.toggleFavorite(z.id) })
                        IconBtn(Ico.Share, "مشاركة", { shareZikr(ctx, z) })
                    }
                }
            }
        }
    }
}

// ============================================================ الإحصائيات
@Composable
fun StatsScreen(store: Store, nav: NavController) {
    val tasDays by store.observeAsState { store.tasbihDays(30) }
    val days by store.observeAsState { store.dayStats(30) }
    val sessions by store.observeAsState { store.sessions() }
    val log by store.observeAsState { store.achievements() }
    val favs by store.observeAsState { store.favorites() }
    var month by remember { mutableStateOf(false) }
    var delSession by remember { mutableStateOf<String?>(null) }
    var delDay by remember { mutableStateOf<LocalDate?>(null) }
    var clearAll by remember { mutableStateOf(false) }

    val range = if (month) 30 else 7
    val shown = tasDays.takeLast(range)
    val maxV = shown.maxOfOrNull { it.second }?.coerceAtLeast(1) ?: 1
    val today = tasDays.lastOrNull()?.second ?: 0
    val week = tasDays.takeLast(7).sumOf { it.second }
    val monthSum = tasDays.sumOf { it.second }
    val cutoff = LocalDate.now().minusDays((range - 1).toLong())
    val goals = log.count { runCatching { !LocalDate.parse(it.date).isBefore(cutoff) }.getOrDefault(false) }
    val completed = days.takeLast(range).sumOf { it.completed }
    val hasData = monthSum > 0 || days.any { it.taps > 0 } || sessions.any { it.total > 0 }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader("الإحصائيات", { nav.popBackStack() })
        ChipRow(listOf(false, true), { it == month }, { if (it) "آخر ٣٠ يومًا" else "آخر ٧ أيام" }) { month = it }
        GlassCard(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Stat("اليوم", Arabic.digits(today)); Stat("الأسبوع", Arabic.digits(week)); Stat("الشهر", Arabic.digits(monthSum))
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Stat("أهداف مكتملة", Arabic.digits(goals)); Stat("أذكار مكتملة", Arabic.digits(completed)); Stat("المفضلة", Arabic.digits(favs.size))
            }
        }
        if (!hasData) {
            EmptyState(Ico.Chart, "لا بيانات بعد", "ابدأ التسبيح أو اقرأ أذكارك وستظهر هنا أرقامك الحقيقية (محفوظة على جهازك فقط).", "افتح المسبحة") { nav.navigate("tasbih") }
        } else {
            GlassCard(Modifier.fillMaxWidth()) {
                Text("تسبيحات المسبحة يوميًا", color = UColors.CreamDim, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth().height(150.dp), horizontalArrangement = Arrangement.spacedBy(if (month) 2.dp else 8.dp), verticalAlignment = Alignment.Bottom) {
                    shown.forEach { (d, v) ->
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                            if (!month) Text(Arabic.digits(v), color = UColors.Cream, fontSize = 10.sp)
                            Box(
                                Modifier.fillMaxWidth().height((100f * v / maxV).coerceAtLeast(2f).dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Brush.verticalGradient(listOf(UColors.Gold, UColors.Gold.copy(alpha = 0.35f)))),
                            )
                            if (!month) Text(DateText.weekDay(d.dayOfWeek).take(3), color = UColors.CreamDim, fontSize = 9.sp, maxLines = 1)
                        }
                    }
                }
            }
        }

        SectionLabel("جلسات التسبيح")
        sessions.sortedByDescending { it.updated }.forEach { sn ->
            GlassCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(sn.text, color = UColors.Cream, fontWeight = FontWeight.Bold, maxLines = 2)
                        Text("الإجمالي ${Arabic.digits(sn.total)} · جولات ${Arabic.digits(sn.rounds)} · الحالي ${Arabic.digits(sn.count)}/${Arabic.digits(sn.target)}", color = UColors.CreamDim, fontSize = 12.sp)
                        if (sn.updated > 0) Text("آخر استخدام ${Arabic.digits(Instant.ofEpochMilli(sn.updated).atZone(ZoneId.systemDefault()).toLocalDate().toString())}", color = UColors.CreamDim, fontSize = 11.sp)
                    }
                    IconBtn(Ico.Delete, "حذف الجلسة", { delSession = sn.id }, UColors.CreamDim)
                }
            }
        }

        val dayRows = days.filter { it.taps > 0 || it.completed > 0 }.reversed().take(14)
        if (dayRows.isNotEmpty()) {
            SectionLabel("سجل الأيام")
            dayRows.forEach { d ->
                GlassCard(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${DateText.weekDay(d.date.dayOfWeek)} ${DateText.gregorian(d.date)}", color = UColors.Cream)
                            Text("ضغطات ${Arabic.digits(d.taps)} · أذكار مكتملة ${Arabic.digits(d.completed)}", color = UColors.CreamDim, fontSize = 12.sp)
                        }
                        IconBtn(Ico.Delete, "حذف سجل اليوم", { delDay = d.date }, UColors.CreamDim)
                    }
                }
            }
        }
        if (hasData) PillButton("مسح كل السجل", { clearAll = true }, icon = Ico.Delete, filled = false)
    }

    delSession?.let { id -> ConfirmDialog("حذف الجلسة؟", "تُحذف هذه الجلسة فقط ولا تتأثر السجلات اليومية.", "حذف", { store.deleteSession(id) }) { delSession = null } }
    delDay?.let { d -> ConfirmDialog("حذف سجل هذا اليوم؟", "يُحذف سجل ${DateText.gregorian(d)} فقط ولا تتأثر باقي الأيام أو الجلسات.", "حذف", { store.deleteDay(d) }) { delDay = null } }
    if (clearAll) ConfirmDialog("مسح كل السجل؟", "تُمسح السجلات اليومية وإنجازات التسبيح. تبقى الجلسات والمفضلة والإعدادات.", "مسح", { store.clearStats() }) { clearAll = false }
}

// ============================================================ التذكيرات
@Composable
fun RemindersScreen(store: Store, nav: NavController) {
    val ctx = LocalContext.current
    val list by store.observeAsState { store.reminders() }
    var pendingEnable by remember { mutableStateOf<String?>(null) }
    var rationale by remember { mutableStateOf(false) }
    var addDialog by remember { mutableStateOf(false) }
    var delId by remember { mutableStateOf<String?>(null) }

    fun commit(newList: List<Reminder>) { store.saveReminders(newList); Reminders.rescheduleAll(ctx) }
    fun setEnabled(id: String, on: Boolean) = commit(list.map { if (it.id == id) it.copy(enabled = on) else it })

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val id = pendingEnable
        pendingEnable = null
        if (granted && id != null) setEnabled(id, true)
        else Toast.makeText(ctx, "لم يُمنح إذن الإشعارات، فلن تصل التذكيرات", Toast.LENGTH_LONG).show()
    }
    fun toggle(id: String, on: Boolean) {
        val needs = Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        if (on && needs) { pendingEnable = id; rationale = true } else setEnabled(id, on)
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader("التذكيرات", { nav.popBackStack() }) { IconBtn(Ico.AddAlarm, "تذكير جديد", { addDialog = true }) }
        list.forEach { r ->
            GlassCard(Modifier.fillMaxWidth(), glow = r.enabled) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(if (r.kind == ReminderKind.MORNING) Ico.Sun else if (r.kind == ReminderKind.EVENING) Ico.Night else Ico.Alarm)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(r.label, color = UColors.Cream, fontWeight = FontWeight.Bold)
                        Text(runCatching { Category.valueOf(r.category).title }.getOrDefault("فتح مكتبة الأذكار"), color = UColors.CreamDim, fontSize = 12.sp)
                    }
                    androidx.compose.material3.Switch(
                        checked = r.enabled, onCheckedChange = { toggle(r.id, it) },
                        colors = androidx.compose.material3.SwitchDefaults.colors(checkedThumbColor = UColors.OnAccent, checkedTrackColor = UColors.Gold),
                    )
                }
                Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillButton(TimeLogic.formatMinute(r.minute), {
                        TimePickerDialog(ctx, { _, h, m -> commit(list.map { if (it.id == r.id) it.copy(minute = h * 60 + m) else it }) }, r.minute / 60, r.minute % 60, false).show()
                    }, icon = Ico.Alarm, filled = false)
                    if (r.kind == ReminderKind.CUSTOM) IconBtn(Ico.Delete, "حذف التذكير", { delId = r.id }, UColors.CreamDim)
                }
                Text("أيام التكرار", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                ChipRow(listOf(6, 7, 1, 2, 3, 4, 5), { r.runsOn(it) }, { DateText.weekDay(DayOfWeek.of(it)).removePrefix("ال").take(4) }) { v ->
                    val bit = 1 shl (v - 1)
                    commit(list.map { if (it.id == r.id) it.copy(days = it.days xor bit) else it })
                }
                if (r.enabled && r.days == 0) Text("لم تختر أي يوم، لن يصلك إشعار.", color = UColors.Gold, fontSize = 12.sp)
            }
        }
        Text("إشعار هادئ بلا صوت. يعمل عبر WorkManager فقد يتأخر دقائق بسبب توفير الطاقة، ويُعاد جدولته بعد إعادة التشغيل وتغيّر الوقت. لا يعتمد على مواقيت الصلاة؛ اختر الوقت الذي يناسبك.", color = UColors.CreamDim, fontSize = 12.sp)
    }

    if (rationale) AlertDialog(
        onDismissRequest = { rationale = false; pendingEnable = null },
        containerColor = UColors.CardSolid,
        title = { Text("السماح بالإشعارات", color = UColors.Cream) },
        text = { Text("نحتاج إذن الإشعارات لنُذكّرك بأذكارك في الوقت الذي تختاره فقط. لن نُرسل إعلانات ولا إشعارات أخرى، ويمكنك إيقافها في أي وقت.", color = UColors.CreamDim) },
        confirmButton = { TextButton(onClick = { rationale = false; permission.launch(Manifest.permission.POST_NOTIFICATIONS) }) { Text("متابعة", color = UColors.Gold) } },
        dismissButton = { TextButton(onClick = { rationale = false; pendingEnable = null }) { Text("ليس الآن", color = UColors.CreamDim) } },
    )
    if (addDialog) {
        var label by remember { mutableStateOf("") }
        var cat by remember { mutableStateOf<Category?>(null) }
        AlertDialog(
            onDismissRequest = { addDialog = false },
            containerColor = UColors.CardSolid,
            title = { Text("تذكير مخصص", color = UColors.Cream) },
            text = {
                Column {
                    OutlinedTextField(label, { label = it.take(30) }, singleLine = true, label = { Text("اسم التذكير") }, colors = fieldColors())
                    Text("القسم الذي يفتحه الإشعار", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp, bottom = 4.dp))
                    ChipRow(listOf<Category?>(null) + Category.values().toList(), { it == cat }, { it?.title ?: "المكتبة" }) { cat = it }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val r = Reminder("c${System.currentTimeMillis()}", ReminderKind.CUSTOM, label.ifBlank { "تذكير" }, 12 * 60, Reminder.ALL_DAYS, false, cat?.name ?: "")
                    commit(list + r); addDialog = false
                }) { Text("إضافة", color = UColors.Gold) }
            },
            dismissButton = { TextButton(onClick = { addDialog = false }) { Text("إلغاء", color = UColors.CreamDim) } },
        )
    }
    delId?.let { id -> ConfirmDialog("حذف التذكير؟", "سيُلغى هذا التذكير فقط.", "حذف", { Reminders.cancel(ctx, id); commit(list.filterNot { it.id == id }) }) { delId = null } }
}

// ============================================================ الثيمات
// ============================================================ إعدادات القراءة
@Composable
fun ReadingSettingsScreen(store: Store, s: Settings, nav: NavController) {
    val sample = remember { AdhkarData.byId("m_kursi")!! }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ScreenHeader("إعدادات القراءة", { nav.popBackStack() })
        LabeledSlider("حجم خط الأذكار: ${Arabic.digits((s.readerScale * 100).toInt())}٪", s.readerScale, 0.7f..1.8f) { v -> store.edit { putFloat("reader_scale", v) } }
        LabeledSlider("تباعد الأسطر", s.lineSpacing, 1.4f..2.6f) { v -> store.edit { putFloat("line_spacing", v) } }
        SwitchRow("وضع القراءة الليلي", "يجعل شاشة القراءة داكنة حتى لو كان الثيم فاتحًا", s.readerNight) { v -> store.edit { putBoolean("reader_night", v) } }
        SectionLabel("نوع الخط")
        ChipRow(listOf(0, 1, 2), { it == s.font }, { listOf("نسخ كلاسيكي", "نظيف عصري", "أميري (إن أُضيف)")[it] }) { v -> store.edit { putInt("font", v) } }
        GlassCard(Modifier.fillMaxWidth(), glow = true) {
            Text(sample.title, color = UColors.Gold, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            ZikrText(sample.text, s, Modifier.fillMaxWidth())
        }
    }
}

// ============================================================ إعدادات التطبيق
@Composable
fun AppSettingsScreen(store: Store, s: Settings, nav: NavController) {
    var name by remember(s.userName) { mutableStateOf(s.userName) }
    var clear by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ScreenHeader("إعدادات التطبيق", { nav.popBackStack() })
        SectionLabel("ملفي الشخصي (محلي)")
        GlassCard(Modifier.fillMaxWidth()) {
            OutlinedTextField(name, { name = it.take(20) }, singleLine = true, label = { Text("الاسم الظاهر في التحية") }, colors = fieldColors(), modifier = Modifier.fillMaxWidth())
            Text("يُحفظ على جهازك فقط ولا يُرسل لأي جهة. لا حاجة لتسجيل حساب.", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
            PillButton("حفظ الاسم", { store.edit { putString("user_name", name.trim()) }; Toast.makeText(ctx, "تم الحفظ", Toast.LENGTH_SHORT).show() })
        }
        SectionLabel("الحركة والأداء")
        GlassCard(Modifier.fillMaxWidth()) {
            ChipRow(listOf(0, 1, 2), { it == s.motion }, { listOf("بلا حركة", "حركة خفيفة", "حركة كاملة")[it] }) { v -> store.edit { putInt("motion", v) } }
            Text("«بلا حركة» توقف الخلفيات المتحركة والشرارات. ويحترم التطبيق أيضًا إعداد النظام «إزالة الرسوم المتحركة».", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            SwitchRow("إيقاف الحركة عند توفير الطاقة", "يوقف الخلفيات والعدّادات المتحركة تلقائيًا حين يفعّل النظام «توفير الطاقة»", s.autoSaver) { v -> store.edit { putBoolean("auto_saver", v) } }
        }
        SectionLabel("الاهتزاز والصوت")
        GlassCard(Modifier.fillMaxWidth()) {
            SwitchRow("اهتزاز خفيف", "عند التسبيح وإكمال الذكر (يحترم إعدادات النظام)", s.haptics) { v -> store.edit { putBoolean("haptics", v) } }
            SwitchRow("صوت النقر", "افتراضيًا متوقف", s.sound) { v -> store.edit { putBoolean("sound", v) } }
        }
        SectionLabel("البيانات والخصوصية")
        GlassCard(Modifier.fillMaxWidth()) {
            SwitchRow("تسجيل الإحصائيات محليًا", "لا يُرسل شيء خارج جهازك", s.statsEnabled) { v -> store.edit { putBoolean("stats_enabled", v) } }
            PillButton("مسح سجل الإحصائيات", { clear = true }, icon = Ico.Delete, filled = false)
        }
    }
    if (clear) ConfirmDialog("مسح السجل؟", "تُمسح السجلات اليومية وإنجازات التسبيح فقط. تبقى الجلسات والمفضلة والإعدادات.", "مسح", { store.clearStats() }) { clear = false }
}

// ============================================================ المساعدة
@Composable
fun HelpScreen(nav: NavController) {
    val faq = listOf(
        "كيف أضيف الودجت؟" to "من شاشة «الويدجت» اضغط «أضِف» بجانب الشكل، أو اضغط مطولًا على الشاشة الرئيسية للهاتف ثم «الودجت» ثم «أُنسي». في أجهزة Xiaomi فعّل إذن «اختصارات الشاشة الرئيسية» إن لم يظهر الطلب.",
        "لماذا لا تتحدث الودجت لحظيًا؟" to "يحدّ نظام Android تحديثات الودجت لتوفير البطارية؛ تتحدّث نحو كل 30 دقيقة وفورًا عند الضغط على أزرارها أو عند فتح التطبيق.",
        "كيف تعمل جلسات المسبحة؟" to "لكل جلسة ذكرها وهدفها وعدّادها المحفوظ؛ بدّل بينها لتستكمل من حيث توقفت. الحذف يطال الجلسة المحددة فقط.",
        "التذكيرات لا تصل في الوقت تمامًا" to "التذكيرات تعمل عبر WorkManager لتوفير الطاقة فقد تتأخر دقائق. على Xiaomi: فعّل «بدء التشغيل التلقائي» وعطّل قيود البطارية للتطبيق، وتأكد من السماح بالإشعارات.",
        "ما دقة التاريخ الهجري؟" to "يُحسب بتقويم أم القرى المدمج في نظام Android، وقد يختلف يومًا عن رؤية الهلال المعتمدة في بلدك.",
        "هل يحتاج التطبيق إنترنت؟" to "لا. كل الأذكار والبيانات محفوظة على جهازك، ولا يجمع التطبيق أي بيانات شخصية.",
        "هل مواقيت الصلاة مدعومة؟" to "نعم، ضمن «رفيق أُنسي»: حساب فلكي محلي بلا إنترنت وبلا إذن الموقع، تختار مدينتك وطريقة الحساب وتعدّل الدقائق يدويًا. قد تختلف بدقائق عن مسجدك. أما «الأذكار المقترحة» في الرئيسية فتعتمد على ساعة الجهاز فقط.",
        "ما هي الفقاعة العائمة؟" to "رسالة ذكر تظهر ثوانيَ فوق التطبيقات الأخرى بأزرار «تم الذكر» و«ذكّرني لاحقًا». تحتاج إذن «العرض فوق التطبيقات» الذي تمنحه بنفسك، وبدونه تصلك التذكيرات كإشعارات. لا تعمل أثناء «عدم الإزعاج».",
        "من أين النصوص؟" to "من القرآن الكريم وكتاب «حصن المسلم» وكتب السنة المذكورة في حقل «المصدر» لكل ذكر. نرجو مراجعتها على نسخة موثوقة، وإبلاغنا بأي خطأ.",
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ScreenHeader("المساعدة", { nav.popBackStack() })
        faq.forEach { (q, a) ->
            GlassCard(Modifier.fillMaxWidth()) {
                Text(q, color = UColors.Gold, fontWeight = FontWeight.Bold)
                Text(a, color = UColors.CreamDim, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}

// ============================================================ معلومات التطبيق
@Composable
fun AboutScreen(nav: NavController) {
    val ctx = LocalContext.current
    val version = remember { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "1.0" }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ScreenHeader("معلومات التطبيق", { nav.popBackStack() })
        GlassCard(Modifier.fillMaxWidth(), glow = true) {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("أُنسي", color = UColors.Gold, fontSize = 40.sp, fontWeight = FontWeight.Bold)
                Text("UNSEE", color = UColors.CreamDim, fontSize = 12.sp, letterSpacing = 6.sp)
                Text("أذكارك أقرب، وقلبك أهدأ", color = UColors.Cream, modifier = Modifier.padding(top = 6.dp))
                Text("الإصدار ${Arabic.digits(version)}", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Text("الخصوصية", color = UColors.Gold, fontWeight = FontWeight.Bold)
            Text("بلا إنترنت، بلا حسابات، بلا إعلانات، بلا تتبّع. كل بياناتك (العدّادات، المفضلة، السجل) على جهازك فقط. الأذونات: الإشعارات (اختياري)، الاهتزاز، إعادة جدولة التذكيرات بعد إعادة التشغيل، و«العرض فوق التطبيقات» للفقاعة العائمة (اختياري ويمنحه المستخدم بنفسه). مواقيت الصلاة تُحسب محليًا ولا يُطلب إذن الموقع.", color = UColors.CreamDim, fontSize = 13.sp)
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Text("المصادر والمراجعة", color = UColors.Gold, fontWeight = FontWeight.Bold)
            Text("النصوص من القرآن الكريم و«حصن المسلم» وكتب السنة المذكورة لكل ذكر. لا نذكر درجة حديث إلا حيث تم التثبت منها. ننصح بمراجعة النصوص على نسخة موثوقة أو عند أهل العلم.", color = UColors.CreamDim, fontSize = 13.sp)
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Text("حدود معروفة", color = UColors.Gold, fontWeight = FontWeight.Bold)
            Text("الودجت لا تدعم حركة مستمرة ولا ضبابية حقيقية. مواقيت الصلاة غير مدعومة. التاريخ الهجري تقريبي (أم القرى).", color = UColors.CreamDim, fontSize = 13.sp)
        }
    }
}
