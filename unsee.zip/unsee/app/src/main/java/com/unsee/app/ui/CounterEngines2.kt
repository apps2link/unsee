package com.unsee.app.ui

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.nativeCanvas

/* المحركات 11–20 (انظر ملاحظة CounterEngines.kt). */

// ------------------------------------------------------------------ 11) طبيعة وأوراق
internal fun DrawScope.engLeaf(f: CFrame) {
    val u = uu; val r = rad * 0.84f
    faceDisc(f, rad * 0.66f)
    glowDisc(center, rad * 0.7f, f.ring, 0.06f * f.glow + 0.2f * f.tap)
    if (f.st.variant == 0) { // ورقة كبيرة باهتة خلف الرقم
        drawPath(leafPath(center, rad * 0.75f, rad * 0.26f, 35f), f.ring.al(0.08f))
    }
    val lit = Color(f.st.c1); val dim = Color(f.st.c3)
    if (f.st.variant == 1) {
        // إكليل زيتون مفتوح من الأعلى: غصنان يرتفعان من الأسفل، وكل ورقة تضيء حين يبلغها التقدّم
        val per = 11
        for (side in 0 until 2) for (i in 0 until per) {
            val q = (i + 1f) / per
            val ang = if (side == 0) 180f - q * 150f else 180f + q * 150f
            val sway = 4f * cWave(f.t, 2f, i * 0.07f + side * 0.3f)
            val on = q <= f.p + 0.001f
            for (pair in 0 until 2) {
                val tilt = if (pair == 0) 38f else -38f
                val base = cPt(ang, r + pair * 4f * u * (if (pair == 0) 1 else -1))
                val col = if (on) (if (pair == 0) lit else f.hi) else dim.al(0.30f)
                drawPath(leafPath(base, 24f * u, 7f * u, ang + 90f * (if (side == 0) -1f else 1f) + tilt + sway), col.al(if (on) 0.95f else 0.40f))
            }
        }
    } else {
        val n = if (f.st.variant == 2) 24 else 28
        for (i in 0 until n) {
            val q = (i + 1f) / n
            val on = q <= f.p + 0.001f
            val ang = i * 360f / n
            val sway = 6f * cWave(f.t, 2f, i * 0.05f)
            val col = when {
                !on -> dim.al(0.35f)
                f.st.variant == 2 -> listOf(lit, f.hi, dim)[i % 3]
                i % 2 == 0 -> lit
                else -> f.hi
            }
            drawPath(leafPath(cPt(ang, r), 26f * u, 8.5f * u, ang + 90f + sway), col.al(if (on) 0.95f else 0.5f))
        }
        if (f.st.variant == 2) { // أوراق تتساقط داخل الوجه
            for (i in 0 until 6) {
                val y = cFrac(cRnd(i) + f.t * (1 + i % 2))
                val x = center.x + (cRnd(i, 2) - 0.5f) * rad * 0.8f + 10f * u * cWave(f.t, 2f, i * 0.2f)
                drawPath(leafPath(Offset(x, center.y - rad * 0.6f + y * rad * 1.2f), 11f * u, 4f * u, 360f * (f.t + i * 0.15f)), lit.al(0.45f))
            }
        }
    }
    if (f.p > 0.01f) glowDisc(cPt(360f * f.p, r), 16f * u, f.hi, 0.35f * f.glow)
}

// ------------------------------------------------------------------ 12) زجاج شفاف بخلفية متحركة
internal fun DrawScope.engFrost(f: CFrame) {
    val u = uu; val fr = rad * 0.80f
    clipPath(circlePath(center, fr)) {
        drawCircle(f.face.al(f.bgA), fr, center)
        val cols = listOf(f.ring, f.acc, f.hi)
        for (i in 0 until 3) {
            val c = cPt((if (i % 2 == 0) 1f else -1f) * 360f * f.t + i * 120f, fr * 0.45f)
            glowDisc(c, fr * 0.80f, cols[i], 0.55f * f.glow)
        }
        if (f.st.variant == 1) { // قشور جليد: خطوط قطرية
            for (i in 0 until 6) {
                val a = i * 60f + 15f
                drawLine(Color.White.al(0.22f), cPt(a, fr * 0.2f), cPt(a, fr), strokeWidth = 1.3f * u)
            }
        }
        if (f.st.variant == 2) { // أفق غروب في أسفل الزجاج
            drawRect(Brush.verticalGradient(listOf(Color.Transparent, f.ring.al(0.45f)), startY = center.y, endY = center.y + fr), Offset(center.x - fr, center.y), Size(fr * 2f, fr))
        }
        drawCircle(Color.White.al(if (f.light) 0.18f else 0.12f), fr, center)
        drawOval(Brush.verticalGradient(listOf(Color.White.al(0.38f), Color.Transparent), startY = center.y - fr, endY = center.y - fr * 0.1f), Offset(center.x - fr * 0.85f, center.y - fr * 0.98f), Size(fr * 1.7f, fr * 0.9f))
    }
    drawCircle(Color.White.al(0.55f), fr, center, style = Stroke(1.8f * u))
    drawCircle(f.ring.al(0.25f), rad * 0.89f, center, style = Stroke(5f * u))
    glowArc(f, f.ring, 360f * f.p, rad * 0.89f, 5f * u)
}

// ------------------------------------------------------------------ 13) قمر وسماء ليلية
internal fun DrawScope.engMoon(f: CFrame) {
    val u = uu; val fr = rad * 0.80f
    clipPath(circlePath(center, fr)) {
        drawCircle(Brush.verticalGradient(listOf(f.face.al(f.bgA), lerp(f.face, f.acc, 0.35f).al(f.bgA)), startY = center.y - fr, endY = center.y + fr), fr, center)
        for (i in 0 until 22) {
            val tw = 0.5f + 0.5f * cWave(f.t, 6f, cRnd(i, 4))
            drawCircle(Color.White.al(0.2f + 0.7f * tw), (0.6f + cRnd(i, 3)) * u, Offset(center.x + (cRnd(i, 1) - 0.5f) * fr * 2f, center.y - fr + cRnd(i, 2) * fr * 1.4f))
        }
        val mx = center.x + fr * 0.40f + 6f * u * cWave(f.t, 1f)
        val my = center.y - fr * 0.42f
        when (f.st.variant) {
            0 -> { glowDisc(Offset(mx, my), fr * 0.5f, f.ring, 0.4f * f.glow); drawPath(crescentPath(Offset(mx, my), fr * 0.2f), f.ring) }
            1 -> { // بدر مع غيوم عابرة
                glowDisc(Offset(mx, my), fr * 0.6f, f.ring, 0.45f * f.glow)
                drawCircle(Brush.radialGradient(listOf(f.hi, f.ring), center = Offset(mx - 4f * u, my - 4f * u), radius = fr * 0.3f), fr * 0.2f, Offset(mx, my))
                for (i in 0 until 2) {
                    val x = center.x - fr + cFrac(f.t * (1 + i) + i * 0.4f) * fr * 3f - fr * 0.4f
                    drawOval(Color.White.al(0.16f), Offset(x, center.y - fr * (0.55f - 0.2f * i)), Size(fr * 0.9f, fr * 0.16f))
                }
            }
            else -> { // قمر كبير دافئ قرب الأفق مع تلال
                glowDisc(Offset(mx, my + fr * 0.25f), fr * 0.7f, f.ring, 0.45f * f.glow)
                drawCircle(f.ring.al(0.92f), fr * 0.27f, Offset(mx, my + fr * 0.25f))
                drawPath(waveFill(center.y + fr * 0.62f, 7f * u, 1f, 0.1f, center.y + fr, center.x - fr, center.x + fr), f.face.al(0.95f))
                drawPath(waveFill(center.y + fr * 0.78f, 6f * u, 1.5f, 0.6f, center.y + fr, center.x - fr, center.x + fr), Color.Black.al(0.35f))
            }
        }
    }
    drawCircle(f.ring.al(0.5f), fr, center, style = Stroke(2f * u))
    trackRing(f, rad * 0.90f, 4f * u, 0.18f)
    glowArc(f, f.ring, 360f * f.p, rad * 0.90f, 4.5f * u)
}

// ------------------------------------------------------------------ 14) خط عربي أنيق
internal fun DrawScope.engCalli(f: CFrame) {
    val u = uu; val r = rad * 0.86f
    faceDisc(f, rad * 0.76f)
    drawIntoCanvas { cv ->
        val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = android.graphics.Paint.Align.CENTER
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.SERIF, android.graphics.Typeface.BOLD)
            textSize = rad * 0.62f
            color = android.graphics.Color.argb(30, (f.ring.red * 255).toInt(), (f.ring.green * 255).toInt(), (f.ring.blue * 255).toInt())
        }
        cv.nativeCanvas.drawText("الله", center.x, center.y + rad * 0.20f, p) // علامة مائية خلف الرقم
    }
    drawCircle(f.ring.al(0.95f), r, center, style = Stroke(2.2f * u))
    drawCircle(f.ring.al(0.45f), r - 7f * u, center, style = Stroke(1f * u))
    arcRing(f.hi.al(0.95f), 0f, 360f * f.p, r - 3.5f * u, 4f * u)
    for (i in 0 until 4) { // معينات زخرفية على الجهات الأربع
        val pos = cPt(i * 90f, r)
        val d = Path().apply { moveTo(pos.x, pos.y - 8f * u); lineTo(pos.x + 6f * u, pos.y); lineTo(pos.x, pos.y + 8f * u); lineTo(pos.x - 6f * u, pos.y); close() }
        drawPath(d, f.acc)
        drawPath(d, f.hi.al(0.8f), style = Stroke(1f * u))
    }
    val sp = cPt(360f * f.t, r)
    glowDisc(sp, 14f * u, f.hi, 0.55f * f.glow + 0.3f * f.tap)
    drawCircle(Color.White.al(0.9f), 2.2f * u, sp)
    if (f.st.variant == 2) drawCircle(f.acc.al(0.5f), r + 8f * u, center, style = Stroke(1f * u))
}

// ------------------------------------------------------------------ 15) لهب ناري خفيف
private fun DrawScope.flame(base: Offset, h: Float, w: Float, col1: Color, col2: Color, col3: Color, flick: Float) {
    val hh = h * (0.92f + 0.14f * flick)
    val p = Path().apply {
        moveTo(base.x, base.y)
        cubicTo(base.x - w, base.y - hh * 0.25f, base.x - w * 0.55f, base.y - hh * 0.65f, base.x + w * 0.1f * flick, base.y - hh)
        cubicTo(base.x + w * 0.65f, base.y - hh * 0.6f, base.x + w, base.y - hh * 0.25f, base.x, base.y)
        close()
    }
    drawPath(p, Brush.verticalGradient(listOf(col3, col1, col2), startY = base.y - hh, endY = base.y))
}

internal fun DrawScope.engEmber(f: CFrame) {
    val u = uu; val r = rad * 0.85f
    val flick = 0.5f + 0.25f * cWave(f.t, 9f) + 0.25f * cWave(f.t, 14f, 0.3f)
    faceDisc(f, rad * 0.74f)
    clipPath(circlePath(center, rad * 0.74f)) {
        glowDisc(Offset(center.x, center.y + rad * 0.62f), rad * 0.95f, f.ring, (0.26f + 0.12f * flick + 0.25f * f.tap) * f.glow)
        when (f.st.variant) {
            0 -> flame(Offset(center.x, center.y + rad * 0.62f), rad * 0.62f, rad * 0.22f, f.ring.al(0.38f), f.hi.al(0.38f), f.acc.al(0.32f), flick)
            1 -> for (i in 0 until 16) { // جمر صاعد
                val q = cFrac(cRnd(i) + f.t * (1 + i % 3))
                val pos = Offset(center.x + (cRnd(i, 2) - 0.5f) * rad * 1.1f + 8f * u * cWave(f.t, 3f, cRnd(i, 5)), center.y + rad * 0.72f - q * rad * 1.4f)
                drawCircle((if (i % 2 == 0) f.ring else f.hi).al(0.85f * (1f - q)), (1.4f + 2f * cRnd(i, 3)) * u * (1f - q * 0.5f), pos)
            }
            else -> { // شمعة صغيرة أعلى الوجه
                glowDisc(Offset(center.x, center.y - rad * 0.50f), rad * 0.34f, f.hi, 0.35f * flick * f.glow)
                flame(Offset(center.x, center.y - rad * 0.40f), rad * 0.22f, rad * 0.075f, f.ring, f.hi, f.acc, flick)
            }
        }
    }
    trackRing(f, r, 7f * u, 0.15f)
    val fl = 0.78f + 0.22f * flick
    arcRing(f.ring.al(0.14f * f.glow), 0f, 360f * f.p, r, 16f * u)
    arcRing(f.ring.al(fl), 0f, 360f * f.p, r, 7f * u)
    if (f.p > 0.01f) glowDisc(cPt(360f * f.p, r), 15f * u, f.hi, 0.6f * flick * f.glow)
}

// ------------------------------------------------------------------ 16) حبات المسبحة
internal fun DrawScope.engBeads(f: CFrame) {
    val u = uu; val r = rad * 0.84f
    faceDisc(f, rad * 0.70f)
    drawCircle(f.acc.al(0.55f), r, center, style = Stroke(1.6f * u)) // الخيط
    val n = 33
    val litCount = (f.p * n + 0.001f).toInt()
    for (i in 0 until n) {
        val pos = cPt((i + 1) * 360f / (n + 1), r)
        val on = i < litCount
        val cur = i == litCount - 1
        val k = 1f + (if (cur) 0.25f * cWave(f.t, 3f) + 0.5f * f.tap else 0f)
        val br = 7f * u * k
        if (on) {
            glowDisc(pos, br * 2.4f, f.hi, (if (cur) 0.6f else 0.25f) * f.glow)
            drawCircle(Brush.radialGradient(listOf(f.hi, f.ring, f.acc), center = pos - Offset(br * 0.3f, br * 0.3f), radius = br * 1.5f), br, pos)
        } else {
            drawCircle(Brush.radialGradient(listOf(f.ring.al(0.45f), f.acc.al(0.35f)), center = pos - Offset(br * 0.3f, br * 0.3f), radius = br * 1.5f), br, pos)
        }
    }
    // الخرزة الإمام وشرّابتها عند الأعلى
    val top = cPt(0f, r)
    drawCircle(Brush.radialGradient(listOf(f.hi, f.ring, f.acc), center = top - Offset(3f * u, 3f * u), radius = 14f * u), 9.5f * u, top)
    drawLine(f.ring.al(0.9f), top + Offset(0f, 9f * u), top + Offset(0f, 24f * u), strokeWidth = 3f * u)
    drawCircle(f.hi.al(0.55f), rad * 0.62f, center, style = Stroke(1f * u))
}

// ------------------------------------------------------------------ 17) نجمة ثمانية تمتلئ بالتقدّم
internal fun DrawScope.engStar8(f: CFrame) {
    val u = uu
    val star = starPath(center, rad * 0.88f, rad * 0.64f, 8, 22.5f)
    drawPath(star, f.ring.al(0.12f))
    clipPath(star) {
        val top = center.y + rad * 0.88f - rad * 1.76f * f.p
        drawPath(
            waveFill(top, 4.5f * u * (1f + f.tap), 1.5f, f.t * 2f, center.y + rad, center.x - rad, center.x + rad),
            Brush.verticalGradient(listOf(f.hi.al(0.9f), f.ring.al(0.85f)), startY = top, endY = center.y + rad),
        )
        for (i in 0 until 5) { // لمعات صغيرة تصعد داخل النجمة
            val q = cFrac(cRnd(i) + f.t * (1 + i % 2))
            drawCircle(Color.White.al(0.5f * (1f - q)), 2f * u, Offset(center.x + (cRnd(i, 2) - 0.5f) * rad, center.y + rad * 0.8f - q * rad * 1.5f))
        }
    }
    drawPath(star, f.ring.al(0.95f), style = Stroke(2.6f * u))
    glowDisc(center, rad * 0.9f, f.ring, 0.12f * f.glow + 0.2f * f.tap)
    for (i in 0 until 16) { // نجيمات تدور حول الشكل
        val pos = cPt(i * 22.5f + 360f * f.t, rad * 0.95f)
        drawCircle(f.acc.al(0.5f + 0.5f * cWave(f.t, 4f, i * 0.06f)), 1.8f * u, pos)
    }
    drawCircle(f.face.al(f.bgA.coerceAtLeast(0.88f)), rad * 0.46f, center)
    drawCircle(f.ring.al(0.9f), rad * 0.46f, center, style = Stroke(2f * u))
}

// ------------------------------------------------------------------ 18) شروق: الشمس تعلو مع التقدّم
internal fun DrawScope.engSunrise(f: CFrame) {
    val u = uu; val fr = rad * 0.80f
    clipPath(circlePath(center, fr)) {
        drawCircle(Brush.verticalGradient(listOf(f.face.al(f.bgA), lerp(f.face, f.acc, 0.45f).al(f.bgA)), startY = center.y - fr, endY = center.y + fr * 0.4f), fr, center)
        val horizon = center.y + fr * 0.40f
        val sunR = fr * 0.22f
        val sy = horizon + sunR * 0.9f - f.p * fr * 0.95f
        glowDisc(Offset(center.x, sy), fr * 1.0f, f.ring, (0.30f + 0.2f * f.tap) * f.glow)
        for (i in 0 until 12) { // أشعة بطيئة الدوران
            val a = i * 30f + 360f * f.t / 3f
            drawLine(f.hi.al(0.22f), cPt(a, sunR * 1.2f, Offset(center.x, sy)), cPt(a, fr * 1.5f, Offset(center.x, sy)), strokeWidth = 3f * u)
        }
        drawCircle(Brush.radialGradient(listOf(f.hi, f.ring), center = Offset(center.x, sy), radius = sunR), sunR, Offset(center.x, sy))
        drawPath(waveFill(horizon, 5f * u, 1f, 0.2f, center.y + fr, center.x - fr, center.x + fr), f.face.al(0.96f))
        drawPath(waveFill(horizon + fr * 0.18f, 5f * u, 1.6f, 0.7f, center.y + fr, center.x - fr, center.x + fr), Color.Black.al(0.28f))
    }
    drawCircle(f.ring.al(0.6f), fr, center, style = Stroke(2f * u))
    trackRing(f, rad * 0.90f, 4f * u, 0.18f)
    glowArc(f, f.ring, 360f * f.p, rad * 0.90f, 4.5f * u)
}

// ------------------------------------------------------------------ 19) فوانيس صغيرة على الحلقة تضيء بالتقدّم
internal fun DrawScope.engLantern(f: CFrame) {
    val u = uu; val r = rad * 0.82f
    faceDisc(f, rad * 0.68f)
    // فانوس كبير باهت خلف الرقم
    val big = Path().apply {
        moveTo(center.x - rad * 0.16f, center.y - rad * 0.38f); lineTo(center.x + rad * 0.16f, center.y - rad * 0.38f)
        lineTo(center.x + rad * 0.28f, center.y + rad * 0.20f); lineTo(center.x + rad * 0.14f, center.y + rad * 0.40f)
        lineTo(center.x - rad * 0.14f, center.y + rad * 0.40f); lineTo(center.x - rad * 0.28f, center.y + rad * 0.20f); close()
    }
    drawPath(big, f.ring.al(0.08f))
    drawPath(big, f.ring.al(0.25f), style = Stroke(1.4f * u))
    val n = 12
    for (i in 0 until n) {
        val on = (i + 1f) / n <= f.p + 0.001f
        val ang = i * 360f / n
        val sway = 3f * cWave(f.t, 2f, i * 0.08f)
        val pos = cPt(ang, r)
        val flick = 0.75f + 0.25f * cWave(f.t, 8f, i * 0.11f)
        val w = 9f * u; val h = 15f * u
        if (on) glowDisc(pos, 24f * u, f.ring, 0.45f * flick * f.glow)
        val body = androidx.compose.ui.geometry.Offset(pos.x - w / 2f + sway, pos.y - h / 2f)
        drawLine(f.acc.al(if (on) 0.9f else 0.35f), Offset(pos.x + sway, pos.y - h / 2f - 5f * u), Offset(pos.x + sway, pos.y - h / 2f), strokeWidth = 1.4f * u)
        drawRoundRect(
            if (on) Brush.verticalGradient(listOf(f.hi, f.ring), startY = body.y, endY = body.y + h) else Brush.verticalGradient(listOf(f.acc.al(0.35f), f.acc.al(0.20f)), startY = body.y, endY = body.y + h),
            body, Size(w, h), androidx.compose.ui.geometry.CornerRadius(w * 0.35f),
        )
        if (on) drawCircle(Color.White.al(0.85f * flick), 1.8f * u, Offset(pos.x + sway, pos.y))
    }
    drawCircle(f.acc.al(0.25f), r - 14f * u, center, style = Stroke(1f * u))
}

// ------------------------------------------------------------------ 20) بتلات تتفتح مع التقدّم
private fun petalPath(base: Offset, len: Float, wid: Float, deg: Float): Path = leafPath(
    Offset(base.x, base.y), len, wid, deg,
)

internal fun DrawScope.engPetals(f: CFrame) {
    val u = uu
    val n = 14
    val rot = 360f * f.t / 2f
    // طبقة داخلية أصغر
    for (i in 0 until n) {
        val g = ((f.p * n - i) + 1f).coerceIn(0f, 1f)
        val ang = i * 360f / n + rot * -1f + 360f / n / 2f
        val len = rad * 0.26f * (0.35f + 0.65f * g)
        val c = cPt(ang, rad * 0.50f)
        drawPath(petalPath(c, len, len * 0.30f, ang), f.acc.al(0.20f + 0.50f * g))
    }
    for (i in 0 until n) {
        val g = ((f.p * n - i) + 1f).coerceIn(0f, 1f)
        val ang = i * 360f / n + rot
        val len = rad * 0.34f * (0.35f + 0.65f * g) * (1f + 0.1f * f.tap)
        val c = cPt(ang, rad * 0.72f)
        val col = lerp(f.ring, f.hi, i / n.toFloat())
        if (g > 0.99f) glowDisc(c, len * 1.0f, col, 0.18f * f.glow)
        drawPath(petalPath(c, len, len * 0.36f, ang), col.al(0.20f + 0.75f * g))
    }
    drawCircle(f.face.al(f.bgA.coerceAtLeast(0.85f)), rad * 0.50f, center)
    drawCircle(f.hi.al(0.7f), rad * 0.50f, center, style = Stroke(2f * u))
}
