package com.unsee.app.notify

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader

/**
 * هوية الإشعارات بلغة «الحرير الحي»: لون تمييز بنفسجي للإشعار، وأيقونة كبيرة زجاجية (كرة متدرجة بلمعة وهلال).
 * الأيقونة الصغيرة في شريط الحالة يفرض النظام أن تكون صورة ظلّية بيضاء، لذلك صُمّمت كهلال ونجمة (res/drawable/ic_notification).
 */
object NotifyStyle {
    val ACCENT: Int = 0xFF6D3FD8.toInt()

    @Volatile private var cached: Bitmap? = null

    fun largeIcon(@Suppress("UNUSED_PARAMETER") ctx: Context): Bitmap {
        cached?.let { return it }
        val px = 192
        val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val cx = px / 2f
        val r = px / 2f - 4f
        val orb = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(cx - r * 0.3f, cx - r * 0.35f, r * 1.7f, intArrayOf(0xFFB794FF.toInt(), 0xFF6D3FD8.toInt(), 0xFF2B1075.toInt()), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        }
        c.drawCircle(cx, cx, r, orb)
        c.drawCircle(cx, cx, r, Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f; color = 0x66FFFFFF })
        // هلال أبيض
        val moon = Path().apply {
            addCircle(cx - 4f, cx + 2f, r * 0.46f, Path.Direction.CW)
        }
        val cut = Path().apply { addCircle(cx + r * 0.22f, cx - r * 0.08f, r * 0.40f, Path.Direction.CW) }
        moon.op(cut, Path.Op.DIFFERENCE)
        c.drawPath(moon, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFF6E0.toInt() })
        // لمعة علوية
        c.drawOval(RectF(cx - r * 0.62f, cx - r * 0.9f, cx + r * 0.1f, cx - r * 0.35f), Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x40FFFFFF })
        cached = bmp
        return bmp
    }
}
