package com.unsee.app.voice

import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.unsee.app.core.QuranGuard
import com.unsee.app.core.QueueDecision
import com.unsee.app.core.SkipReason
import com.unsee.app.core.SpeechDeduper
import com.unsee.app.core.SpeechPriority
import com.unsee.app.core.SpeechQueuePolicy
import com.unsee.app.core.VoiceGate
import com.unsee.app.core.VoiceSection
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withTimeoutOrNull
import java.time.LocalTime
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

enum class EngineState { IDLE, INITIALIZING, READY, FAILED, NO_ARABIC }

enum class VoiceStatus(val label: String) { AVAILABLE("متاح"), NEEDS_DOWNLOAD("يحتاج تنزيلًا"), UNSUPPORTED("غير مدعوم") }

/** صوت حقيقي مثبّت على الجهاز كما يعرضه محرك TTS (لا أصوات وهمية). */
data class DeviceVoice(
    val name: String,
    val locale: String,
    val quality: Int,
    val needsNetwork: Boolean,
    val status: VoiceStatus,
) {
    val offline: Boolean get() = !needsNetwork && status == VoiceStatus.AVAILABLE
    val qualityLabel: String get() = when {
        quality >= 500 -> "جودة عالية جدًا"
        quality >= 400 -> "جودة عالية"
        quality >= 300 -> "جودة عادية"
        else -> "جودة أساسية"
    }
}

data class SpeakResult(val spoken: Boolean, val skipped: SkipReason? = null)

/**
 * Unsee Voice Engine: طبقة مركزية وحيدة فوق Android TextToSpeech (بلا أي API مدفوع أو سيرفر).
 *  - تهيئة كسولة مرة واحدة، وطلبات تُحفظ حتى جاهزية المحرك.
 *  - لا تداخل: كل الكلام يمر من طابور المحرك (HIGH يقطع، NORMAL يضاف، LOW يُهمل إن كان مشغولًا).
 *  - Audio Focus (قطع مؤقت مع خفض الوسائط الأخرى) وإلغاء الكلام عند فقده (مكالمة مثلًا).
 *  - يحترم الصامت وعدم الإزعاج وساعات الهدوء للإشعارات، ولا يطلب أي صلاحية.
 *  - لا يقرأ آيات القرآن آليًا أبدًا (التلاوة بتسجيل قارئ فقط).
 */
object VoiceEngine {
    private const val UTT_PREFIX = "unsee_"
    private val seq = AtomicInteger(0)
    private val dedupe = SpeechDeduper()

    private val _state = MutableStateFlow(EngineState.IDLE)
    val state: StateFlow<EngineState> = _state.asStateFlow()
    private val _speaking = MutableStateFlow(false)
    val speaking: StateFlow<Boolean> = _speaking.asStateFlow()
    private val _voices = MutableStateFlow<List<DeviceVoice>>(emptyList())
    val voices: StateFlow<List<DeviceVoice>> = _voices.asStateFlow()

    private var app: Context? = null
    private var tts: TextToSpeech? = null
    private var focusReq: AudioFocusRequest? = null
    private val pending = ArrayList<() -> Unit>()
    private val active = HashSet<String>()
    private val waiters = HashMap<String, CompletableDeferred<Unit>>()
    private var lastError: String? = null
    fun lastError(): String? = lastError

    // ---------------------------------------------------------------- دورة الحياة
    @Synchronized
    fun init(ctx: Context) {
        if (app == null) app = ctx.applicationContext
        if (tts != null || _state.value == EngineState.INITIALIZING) return
        _state.value = EngineState.INITIALIZING
        try {
            tts = TextToSpeech(app) { status -> onInit(status) }
        } catch (e: Exception) {
            lastError = e.message
            tts = null
            _state.value = EngineState.FAILED
        }
    }

    @Synchronized
    private fun onInit(status: Int) {
        val t = tts
        if (status != TextToSpeech.SUCCESS || t == null) {
            lastError = "فشلت تهيئة محرك النطق (الحالة $status)"
            runCatching { t?.shutdown() }
            tts = null
            _state.value = EngineState.FAILED
            pending.clear()
            return
        }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String) { _speaking.value = true }
            override fun onDone(id: String) { finish(id) }
            @Deprecated("Deprecated in Java") override fun onError(id: String) { finish(id) }
            override fun onError(id: String, errorCode: Int) { lastError = "خطأ نطق ($errorCode)"; finish(id) }
            override fun onStop(id: String, interrupted: Boolean) { finish(id) }
        })
        val lang = t.isLanguageAvailable(Locale("ar"))
        refreshVoices()
        _state.value = if (lang == TextToSpeech.LANG_MISSING_DATA || lang == TextToSpeech.LANG_NOT_SUPPORTED) EngineState.NO_ARABIC else EngineState.READY
        val q = ArrayList(pending); pending.clear()
        q.forEach { runCatching { it() } }
    }

    /** يحرّر المحرك بالكامل (عند إغلاق التطبيق نهائيًا). يُعاد إنشاؤه كسولًا عند أول طلب جديد. */
    @Synchronized
    fun release() {
        runCatching { tts?.stop() }
        runCatching { tts?.shutdown() }
        tts = null
        pending.clear(); active.clear()
        waiters.values.forEach { it.complete(Unit) }; waiters.clear()
        _speaking.value = false
        _state.value = EngineState.IDLE
        abandonFocus()
    }

    @Synchronized
    private fun finish(id: String) {
        active.remove(id)
        waiters.remove(id)?.complete(Unit)
        if (active.isEmpty()) { _speaking.value = false; abandonFocus() }
    }

    // ---------------------------------------------------------------- اكتشاف الأصوات
    @Synchronized
    fun refreshVoices() {
        val t = tts ?: return
        val list = runCatching {
            (t.voices ?: emptySet()).filter { it.locale.language == "ar" }.map { v ->
                val notInstalled = v.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) == true
                DeviceVoice(
                    name = v.name, locale = v.locale.toLanguageTag(), quality = v.quality,
                    needsNetwork = v.isNetworkConnectionRequired,
                    status = if (notInstalled) VoiceStatus.NEEDS_DOWNLOAD else VoiceStatus.AVAILABLE,
                )
            }.sortedWith(compareBy<DeviceVoice> { it.status.ordinal }.thenByDescending { it.quality }.thenBy { it.name })
        }.getOrDefault(emptyList())
        _voices.value = list
    }

    // ---------------------------------------------------------------- بيئة الجهاز
    private fun silentMode(c: Context): Boolean = runCatching {
        c.getSystemService(AudioManager::class.java).ringerMode != AudioManager.RINGER_MODE_NORMAL
    }.getOrDefault(false)

    private fun dndOn(c: Context): Boolean = runCatching {
        c.getSystemService(NotificationManager::class.java).currentInterruptionFilter > NotificationManager.INTERRUPTION_FILTER_ALL
    }.getOrDefault(false)

    private fun requestFocus(c: Context, notification: Boolean): Boolean {
        val am = c.getSystemService(AudioManager::class.java) ?: return true
        val attrs = AudioAttributes.Builder()
            .setUsage(if (notification) AudioAttributes.USAGE_NOTIFICATION else AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            .setAudioAttributes(attrs).setAcceptsDelayedFocusGain(false)
            .setOnAudioFocusChangeListener { change ->
                if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) stop()
            }.build()
        focusReq = req
        return am.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun abandonFocus() {
        val c = app ?: return
        val r = focusReq ?: return
        runCatching { c.getSystemService(AudioManager::class.java)?.abandonAudioFocusRequest(r) }
        focusReq = null
    }

    // ---------------------------------------------------------------- النطق
    /**
     * @param key مفتاح منع التكرار (إن وُجد): الشيء نفسه لا يُنطق مرتين خلال 10 دقائق.
     * @param notification هل هو نطق لإشعار؟ (يخضع لساعات الهدوء وعدم الإزعاج وخيار «نطق الإشعارات»)
     * @return معرّف الكلام لانتظاره، أو null مع سبب التخطّي في [lastSkip].
     */
    @Synchronized
    fun speak(
        ctx: Context, text: String, section: VoiceSection, priority: SpeechPriority = SpeechPriority.NORMAL,
        key: String? = null, notification: Boolean = false, ignoreGate: Boolean = false, title: String = "",
        voiceName: String? = null,
    ): String? {
        val c = ctx.applicationContext
        if (app == null) app = c
        val s = VoiceStore.get(c).current()
        lastSkip = null
        if (QuranGuard.isQuranic(title, text)) { lastSkip = SkipReason.QURAN; return null }
        if (!ignoreGate) {
            val now = LocalTime.now().let { it.hour * 60 + it.minute }
            VoiceGate.check(s, section, notification, now, silentMode(c), dndOn(c), text)?.let { lastSkip = it; return null }
        } else if (text.isBlank()) { lastSkip = SkipReason.EMPTY; return null }
        if (key != null && !dedupe.shouldSpeak(key, System.currentTimeMillis())) { lastSkip = SkipReason.DUPLICATE; return null }
        val decision = SpeechQueuePolicy.decide(priority, active.isNotEmpty())
        if (decision == QueueDecision.DROP) { key?.let { dedupe.forget(it) }; return null }
        val id = UTT_PREFIX + seq.incrementAndGet()
        waiters[id] = CompletableDeferred()   // قبل أي تنفيذ كي لا يضيع إكمال مبكر
        val job = {
            doSpeak(c, text, voiceName ?: s.voiceFor(section), id, decision, notification, s.rate, s.pitch, s.volume)
        }
        init(c)
        when (_state.value) {
            EngineState.READY, EngineState.NO_ARABIC -> job()
            EngineState.INITIALIZING, EngineState.IDLE -> pending.add(job)
            EngineState.FAILED -> { waiters.remove(id); return null }
        }
        return id
    }

    @Volatile var lastSkip: SkipReason? = null
        private set

    /** المحركات تقبل نصًا محدودًا (عادة 4000 حرف): نقسّمه عند علامات الوقف. */
    internal fun chunks(text: String, max: Int = 3500): List<String> {
        if (text.length <= max) return listOf(text)
        val out = ArrayList<String>()
        var rest = text
        while (rest.length > max) {
            var cut = rest.lastIndexOfAny(charArrayOf('.', '،', '؛', '؟', '!', '\n', ' '), max)
            if (cut < max / 2) cut = max
            out.add(rest.substring(0, cut + 1).trim()); rest = rest.substring(cut + 1)
        }
        if (rest.isNotBlank()) out.add(rest.trim())
        return out
    }

    private fun doSpeak(c: Context, text: String, voiceName: String, id: String, decision: QueueDecision, notification: Boolean, rate: Float, pitch: Float, volume: Float) {
        val t = tts ?: run { finish(id); return }
        if (active.isEmpty() && !requestFocus(c, notification)) { finish(id); return }
        runCatching {
            t.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(if (notification) AudioAttributes.USAGE_NOTIFICATION else AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build(),
            )
            var chosen = false
            if (voiceName.isNotBlank()) {
                val v = t.voices?.firstOrNull { it.name == voiceName }
                if (v != null && t.setVoice(v) == TextToSpeech.SUCCESS) chosen = true
            }
            if (!chosen) t.setLanguage(Locale("ar"))
            t.setSpeechRate(rate); t.setPitch(pitch)
            val params = Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume) }
            val parts = chunks(text)
            parts.forEachIndexed { i, part ->
                val uid = if (i == parts.lastIndex) id else "${id}_$i"
                active.add(uid)
                val mode = if (i == 0 && decision == QueueDecision.FLUSH) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
                if (t.speak(part, mode, params, uid) != TextToSpeech.SUCCESS) { lastError = "رفض المحرك الطلب"; finish(uid) }
            }
        }.onFailure { lastError = it.message; finish(id) }
    }

    @Synchronized
    fun stop() {
        runCatching { tts?.stop() }
        pending.clear()
        val ids = ArrayList(active)
        ids.forEach { finish(it) }
        _speaking.value = false
    }

    /** ينتظر انتهاء كلام معيّن (أو مهلة) — يحمي العملية من الإنهاء داخل Worker أثناء النطق. */
    suspend fun await(id: String?, timeoutMs: Long = 60_000L) {
        if (id == null) return
        val d = synchronized(this) { waiters[id] } ?: return
        withTimeoutOrNull(timeoutMs) { d.await() }
    }
}
