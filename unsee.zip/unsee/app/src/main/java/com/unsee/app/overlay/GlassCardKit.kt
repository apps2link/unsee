package com.unsee.app.overlay

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import com.unsee.app.core.BubbleLook
import com.unsee.app.core.CardKind
import com.unsee.app.core.LogKind
import com.unsee.app.core.Voice
import com.unsee.app.notify.CompanionAct as Act
import com.unsee.app.core.PendingItem
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * مجموعة بناء «بطاقة التذكير الزجاجية» لنافذة الفقاعة (Views عادية لأنها نافذة System Overlay خارج Compose).
 * لغة بصرية واحدة مع الفقاعة: زجاج داكن شبه شفاف، حدّ رفيع مضيء، خط ذهبي علوي، زخرفة نجمة ثمانية خافتة جدًا،
 * وأزرار زجاجية كبيرة (≥48dp) بحركة ضغط. النص هو العنصر الأساسي والزخرفة بالكاد ترى.
 */
internal enum class Glyph { STAR8, CRESCENT, RING, SPARK, MOON_SOFT }

internal class CardStyle(
    val top: Int, val bottom: Int, val accent: Int,
    val btnStart: Int, val btnEnd: Int, val btnText: Int,
    val glyph: Glyph, val kindLabel: String,
)

internal object CardStyles {
    fun of(kind: CardKind): CardStyle = when (kind) {
        CardKind.DHIKR -> CardStyle(0x0F4A3F, 0x0A2A33, 0xFFE2B857.toInt(), 0xFFF2D27F.toInt(), 0xFFD9A93E.toInt(), 0xFF1A1405.toInt(), Glyph.STAR8, "ذكر")
        CardKind.PRAYER -> CardStyle(0x111E4D, 0x0A1030, 0xFFC9DAFF.toInt(), 0xFFE3EBFF.toInt(), 0xFFA9BFF0.toInt(), 0xFF0A1233.toInt(), Glyph.CRESCENT, "صلاة")
        CardKind.REFLECT -> CardStyle(0x221C5C, 0x0E0E33, 0xFFC9B6FF.toInt(), 0xFFDCD0FF.toInt(), 0xFF9D86F0.toInt(), 0xFF150F3A.toInt(), Glyph.RING, "محاسبة")
        CardKind.ENCOURAGE -> CardStyle(0x134F3E, 0x0A2A33, 0xFFFFD66B.toInt(), 0xFFFFE08A.toInt(), 0xFFE2B03A.toInt(), 0xFF1A1405.toInt(), Glyph.SPARK, "تشجيع")
        CardKind.COMFORT -> CardStyle(0x2A3A55, 0x141C2E, 0xFFB6C8E0.toInt(), 0xFFDDE6F3.toInt(), 0xFF9FB3D1.toInt(), 0xFF101828.toInt(), Glyph.MOON_SOFT, "مواساة")
        CardKind.URGENT -> CardStyle(0x1A2A4A, 0x0A1428, 0xFFFFB454.toInt(), 0xFFFFCB80.toInt(), 0xFFF0962E.toInt(), 0xFF2A1500.toInt(), Glyph.STAR8, "عاجل")
    }
}

/** خلفية زجاجية مرسومة: تدرّج + إضاءة داخلية + زخرفة خافتة + خط ذهبي علوي + حدّ متدرج. تُبنى الـShaders عند تغيّر الحجم فقط. */
internal class GlassDrawable(private val style: CardStyle, private val radius: Float, private val d: Float, private val blurred: Boolean) : Drawable() {
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val lightP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ornP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = d * 0.9f }
    private val lineP = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = d * 1.2f; strokeCap = Paint.Cap.ROUND }
    private val edgeP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = d * 1.2f }
    private val rect = RectF()
    private val clip = Path()
    private val star = Path()
    private val alphaBase = if (blurred) 0xC6 else 0xEC   // مع الطمس نترك شفافية أعلى؛ بدونه نرفع الكثافة لحفظ التباين

    private fun col(rgb: Int, a: Int) = Color.argb(a, Color.red(rgb), Color.green(rgb), Color.blue(rgb))

    override fun onBoundsChange(b: android.graphics.Rect) {
        val w = b.width().toFloat(); val h = b.height().toFloat()
        rect.set(b.left + d * 0.6f, b.top + d * 0.6f, b.right - d * 0.6f, b.bottom - d * 0.6f)
        clip.reset(); clip.addRoundRect(rect, radius, radius, Path.Direction.CW)
        fillP.shader = LinearGradient(0f, 0f, 0f, h, col(style.top, alphaBase), col(style.bottom, alphaBase), Shader.TileMode.CLAMP)
        lightP.shader = RadialGradient(w * 0.3f, 0f, w * 0.75f, Color.argb(46, 255, 255, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        lineP.shader = LinearGradient(w * 0.12f, 0f, w * 0.88f, 0f, intArrayOf(Color.TRANSPARENT, withA(style.accent, 190), Color.TRANSPARENT), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        edgeP.shader = LinearGradient(0f, 0f, w, h, intArrayOf(Color.argb(120, 255, 255, 255), withA(style.accent, 70), Color.argb(34, 255, 255, 255)), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        ornP.color = withA(style.accent, 30)
    }

    private fun withA(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    private fun starPath(cx: Float, cy: Float, r: Float, inner: Float) {
        star.reset()
        for (i in 0 until 16) {
            val ang = (PI / 8 * i - PI / 2).toFloat()
            val rr = if (i % 2 == 0) r else r * inner
            val x = cx + cos(ang) * rr; val y = cy + sin(ang) * rr
            if (i == 0) star.moveTo(x, y) else star.lineTo(x, y)
        }
        star.close()
    }

    override fun draw(c: Canvas) {
        c.drawRoundRect(rect, radius, radius, fillP)
        c.save(); c.clipPath(clip)
        c.drawRect(rect, lightP)
        // زخرفة نجمة ثمانية خافتة جدًا في الزاوية العليا (تكاد لا ترى)
        val ox = rect.right - d * 46f; val oy = rect.top + d * 40f
        starPath(ox, oy, d * 64f, 0.62f); c.drawPath(star, ornP)
        starPath(ox, oy, d * 40f, 0.62f); c.drawPath(star, ornP)
        c.restore()
        c.drawLine(rect.left + radius, rect.top + d * 0.8f, rect.right - radius, rect.top + d * 0.8f, lineP)
        c.drawRoundRect(rect, radius, radius, edgeP)
    }

    override fun getOutline(outline: Outline) { outline.setRoundRect(bounds, radius); outline.alpha = 0.9f }
    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Deprecated("Deprecated in Java") override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** أيقونة صغيرة متحركة بحركة بطيئة جدًا (نجمة تدور/هلال يتلألأ…)، وتتوقف حين تُفصل أو تُخفى أو مع «تقليل الحركة». */
internal class GlyphView(ctx: Context, private val glyph: Glyph, private val color: Int, private val animate: Boolean) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = this@GlyphView.color }
    private val path = Path()
    private val cut = Path()
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 12000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    private fun sync() { if (animate && isAttachedToWindow && isShown) { if (!anim.isStarted) anim.start() } else anim.cancel() }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); sync() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onVisibilityChanged(v: View, visibility: Int) { super.onVisibilityChanged(v, visibility); sync() }

    private fun star(cx: Float, cy: Float, r: Float, pts: Int, inner: Float, rot: Float) {
        path.reset()
        for (i in 0 until pts * 2) {
            val a = (PI / pts * i - PI / 2).toFloat() + rot
            val rr = if (i % 2 == 0) r else r * inner
            val x = cx + cos(a) * rr; val y = cy + sin(a) * rr
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val cx = w / 2f; val cy = height / 2f; val r = w * 0.42f
        val ph = t * (2 * PI).toFloat()
        p.style = Paint.Style.FILL
        when (glyph) {
            Glyph.STAR8 -> { star(cx, cy, r, 8, 0.42f, ph * 0.5f); p.alpha = 235; c.drawPath(path, p); p.alpha = 255 }
            Glyph.CRESCENT -> {
                path.reset(); path.addCircle(cx - r * 0.1f, cy, r, Path.Direction.CW)
                cut.reset(); cut.addCircle(cx + r * 0.38f, cy - r * 0.12f, r * 0.82f, Path.Direction.CW)
                path.op(cut, Path.Op.DIFFERENCE); c.drawPath(path, p)
                val tw = 0.65f + 0.35f * sin(ph * 2f)
                star(cx + r * 0.62f, cy - r * 0.5f, r * 0.34f * tw, 4, 0.4f, 0f); c.drawPath(path, p)
            }
            Glyph.RING -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = w * 0.07f
                c.drawCircle(cx, cy, r, p); c.drawCircle(cx, cy, r * 0.6f * (0.9f + 0.1f * sin(ph)), p)
                p.style = Paint.Style.FILL; c.drawCircle(cx, cy, r * 0.16f, p)
            }
            Glyph.SPARK -> {
                val s = 0.9f + 0.1f * sin(ph * 2f)
                star(cx, cy, r * s, 4, 0.22f, 0f); c.drawPath(path, p)
                star(cx + r * 0.7f, cy - r * 0.6f, r * 0.34f, 4, 0.25f, 0f); c.drawPath(path, p)
            }
            Glyph.MOON_SOFT -> {
                path.reset(); path.addCircle(cx - r * 0.1f, cy, r, Path.Direction.CW)
                cut.reset(); cut.addCircle(cx + r * 0.38f, cy - r * 0.12f, r * 0.82f, Path.Direction.CW)
                path.op(cut, Path.Op.DIFFERENCE); p.alpha = 200; c.drawPath(path, p); p.alpha = 255
            }
        }
    }
}

internal object GlassUi {
    fun roundBg(color: Int, stroke: Int?, radiusPx: Float, strokeW: Float): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = radiusPx; if (stroke != null) setStroke(strokeW.toInt().coerceAtLeast(1), stroke)
    }

    /** زر زجاجي بحركة ضغط (انكماش ثم ارتداد). styleKind: 0 رئيسي متدرج، 1 ثانوي شفاف، 2 زر هادئ بحدّ. الحد الأدنى للارتفاع 48dp. */
    fun button(ctx: Context, d: Float, label: String, primary: Boolean, st: CardStyle, onClick: () -> Unit): TextView = TextView(ctx).apply {
        text = label; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; maxLines = 2
        minHeight = (48 * d).toInt()
        val r = 24 * d
        if (primary) {
            setTextColor(st.btnText)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(st.btnStart, st.btnEnd)).apply {
                cornerRadius = r; setStroke((1 * d).toInt().coerceAtLeast(1), Color.argb(130, 255, 255, 255))
            }
        } else {
            setTextColor(st.accent)
            background = roundBg(Color.argb(22, 255, 255, 255), Color.argb(150, Color.red(st.accent), Color.green(st.accent), Color.blue(st.accent)), r, 1.2f * d)
        }
        setPadding((10 * d).toInt(), (10 * d).toInt(), (10 * d).toInt(), (10 * d).toInt())
        isClickable = true
        contentDescription = label
        setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(OvershootInterpolator(2.2f)).start()
            }
            false
        }
        setOnClickListener { onClick() }
    }

    /** زر إخفاء صغير وأنيق (دائرة زجاجية 40dp). */
    fun hideButton(ctx: Context, d: Float, st: CardStyle, onClick: () -> Unit): TextView = TextView(ctx).apply {
        text = "✕"; textSize = 14f; gravity = Gravity.CENTER; setTextColor(Color.argb(200, 255, 244, 214))
        val s = (40 * d).toInt(); minWidth = s; minHeight = s
        background = roundBg(Color.argb(26, 255, 255, 255), Color.argb(60, 255, 255, 255), 20 * d, 1f * d)
        contentDescription = "إخفاء"; isClickable = true
        setOnClickListener { onClick() }
        setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.88f).scaleY(0.88f).setDuration(80).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(200).setInterpolator(OvershootInterpolator(2f)).start()
            }
            false
        }
    }

    /** بطاقة تذكير كاملة. onAct تُستدعى بالفعل المختار؛ الإخفاء (✕) يرسل DISMISS. */
    fun reminderCard(ctx: Context, d: Float, item: PendingItem, total: Int, v: Voice, blurred: Boolean, animateGlyph: Boolean, onAct: (Act) -> Unit): LinearLayout {
        val ck = BubbleLook.cardKind(item.kind, item.priority)
        val st = CardStyles.of(ck)
        val cream = 0xFFFFF4D6.toInt()
        val dim = 0xFFC9C1A5.toInt()
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding((18 * d).toInt(), (14 * d).toInt(), (18 * d).toInt(), (16 * d).toInt())
            background = GlassDrawable(st, 28 * d, d, blurred)
            elevation = 10 * d
        }
        // الشريط العلوي: أيقونة متحركة + نوع التذكير + العدد + إخفاء
        val strip = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        strip.addView(GlyphView(ctx, st.glyph, st.accent, animateGlyph).apply { layoutParams = LinearLayout.LayoutParams((22 * d).toInt(), (22 * d).toInt()) })
        strip.addView(TextView(ctx).apply {
            text = (if (item.priority) "${v.bubblePriority} · " else "") + item.kind.label
            textSize = 12f; typeface = Typeface.DEFAULT_BOLD; setTextColor(st.accent); letterSpacing = 0.04f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = (8 * d).toInt() }
        })
        if (total > 1) strip.addView(TextView(ctx).apply { text = "$total"; textSize = 12f; setTextColor(dim); setPadding((8 * d).toInt(), 0, (8 * d).toInt(), 0) })
        if (!item.priority) strip.addView(hideButton(ctx, d, st) { onAct(Act.DISMISS) })
        root.addView(strip)
        // العنوان
        root.addView(TextView(ctx).apply {
            text = item.title; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(st.accent)
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START; setPadding(0, (8 * d).toInt(), 0, 0)
        })
        // النص: العنصر الأساسي
        root.addView(TextView(ctx).apply {
            text = item.text; textSize = 18f; setTextColor(cream); setLineSpacing(0f, 1.32f)
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START; setPadding(0, (8 * d).toInt(), 0, 0)
        })
        if (!item.sub.isNullOrBlank()) root.addView(TextView(ctx).apply {
            text = item.sub; textSize = 12f; setTextColor(st.accent); alpha = 0.9f
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START; setPadding(0, (6 * d).toInt(), 0, 0)
        })
        // الأزرار: رئيسي أكبر + ثانوي + فتح
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, (14 * d).toInt(), 0, 0) }
        val isPlan = item.kind == LogKind.PLAN
        fun cell(b: TextView, weight: Float, first: Boolean) {
            b.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, weight).apply { if (!first) marginStart = (8 * d).toInt() }
            row.addView(b)
        }
        cell(button(ctx, d, item.primary, true, st) { onAct(Act.PRIMARY) }, 1.25f, true)
        if (item.secondary.isNotBlank()) cell(button(ctx, d, item.secondary, false, st) { onAct(if (isPlan) Act.SLIP else Act.SNOOZE) }, 1f, false)
        if (item.open.isNotBlank()) cell(button(ctx, d, item.open, false, st) { onAct(Act.OPEN) }, 1f, false)
        root.addView(row)
        if (item.priority) root.addView(TextView(ctx).apply {
            text = v.t("الفقاعة دي هتفضل معاك لحد ما تردّ عليها.", "هالفقاعة تبقى معك لين ترد عليها.")
            textSize = 11f; setTextColor(dim); textAlignment = View.TEXT_ALIGNMENT_VIEW_START; setPadding(0, (8 * d).toInt(), 0, 0)
        })
        return root
    }

    /** بطاقة نتيجة: تشجيع احتفالي هادئ (ذهبي) أو مواساة (فضي/أزرق)، بلا رموز تعبيرية. */
    fun resultCard(ctx: Context, d: Float, text: String, good: Boolean, blurred: Boolean, animateGlyph: Boolean): LinearLayout {
        val st = CardStyles.of(if (good) CardKind.ENCOURAGE else CardKind.COMFORT)
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER
            setPadding((20 * d).toInt(), (18 * d).toInt(), (20 * d).toInt(), (18 * d).toInt())
            background = GlassDrawable(st, 28 * d, d, blurred)
            elevation = 10 * d
            addView(GlyphView(ctx, st.glyph, st.accent, animateGlyph).apply { layoutParams = LinearLayout.LayoutParams((34 * d).toInt(), (34 * d).toInt()) })
            addView(TextView(ctx).apply {
                this.text = text; textSize = 17f; setTextColor(0xFFFFF4D6.toInt()); gravity = Gravity.CENTER; setLineSpacing(0f, 1.3f); setPadding(0, (8 * d).toInt(), 0, 0)
            })
        }
    }
}
