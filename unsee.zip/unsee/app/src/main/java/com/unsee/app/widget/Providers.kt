package com.unsee.app.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import com.unsee.app.data.Store

abstract class BaseWidgetProvider(private val style: WidgetStyle) : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) WidgetRenderer.update(context, appWidgetManager, id, style)
    }

    override fun onAppWidgetOptionsChanged(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: android.os.Bundle?) {
        WidgetRenderer.update(context, appWidgetManager, appWidgetId, style)
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        val store = Store.get(context)
        for (id in appWidgetIds) store.removeWidget(id)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val action = intent.action ?: return
        if (action != WidgetRenderer.ACTION_NEXT && action != WidgetRenderer.ACTION_PREV && action != WidgetRenderer.ACTION_TAP) return
        val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        if (id == AppWidgetManager.INVALID_APPWIDGET_ID) return
        val store = Store.get(context)
        when (action) {
            WidgetRenderer.ACTION_NEXT -> shift(context, store, id, +1)
            WidgetRenderer.ACTION_PREV -> shift(context, store, id, -1)
            WidgetRenderer.ACTION_TAP -> if (style == WidgetStyle.TASBIH || style == WidgetStyle.COUNTER_ART) tapTasbih(context, store) else tapZikr(context, store, id)
        }
    }

    private fun shift(context: Context, store: Store, id: Int, delta: Int) {
        store.setWidgetOffset(id, store.widgetOffset(id) + delta)
        WidgetRenderer.update(context, AppWidgetManager.getInstance(context), id, style)
    }

    private fun tapZikr(context: Context, store: Store, id: Int) {
        val s = store.settings()
        val z = WidgetRenderer.resolve(id, style, store, s).zikr ?: return
        val res = store.tapZikr(z)
        if (!res.counted) {
            // الذكر مكتمل: الضغطة التالية تنقلك إلى الذي بعده
            store.setWidgetOffset(id, store.widgetOffset(id) + 1)
        } else if (s.haptics) {
            vibrate(context, if (res.completed) 45 else 15)
        }
        WidgetRenderer.update(context, AppWidgetManager.getInstance(context), id, style)
    }

    private fun tapTasbih(context: Context, store: Store) {
        val s = store.settings()
        val r = store.tasbihTap()
        if (s.haptics) vibrate(context, if (r.completedRound) 60 else 15)
        WidgetRenderer.updateTasbihFamily(context, flash = true)
        // تأثير التوهج: نُبقيه لحظة قصيرة ثم نعيد الودجت لحالتها العادية.
        val pending = goAsync()
        Handler(Looper.getMainLooper()).postDelayed({
            try {
                WidgetRenderer.updateTasbihFamily(context, flash = false)
            } finally {
                pending.finish()
            }
        }, 220L)
    }

    private fun vibrate(context: Context, ms: Int) {
        runCatching {
            val v = context.getSystemService(Vibrator::class.java) ?: return
            if (v.hasVibrator()) v.vibrate(VibrationEffect.createOneShot(ms.toLong(), VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }
}

class CinematicWidget : BaseWidgetProvider(WidgetStyle.CINEMATIC)
class TransparentWidget : BaseWidgetProvider(WidgetStyle.TRANSPARENT)
class GlassWidget : BaseWidgetProvider(WidgetStyle.GLASS)
class MiniWidget : BaseWidgetProvider(WidgetStyle.MINI)
class LargeWidget : BaseWidgetProvider(WidgetStyle.LARGE)
class TasbihWidget : BaseWidgetProvider(WidgetStyle.TASBIH)
class PeriodWidget : BaseWidgetProvider(WidgetStyle.PERIOD)
class LuxeWidget : BaseWidgetProvider(WidgetStyle.LUXE)
class CustomWidget : BaseWidgetProvider(WidgetStyle.CUSTOM)
class CounterArtWidget : BaseWidgetProvider(WidgetStyle.COUNTER_ART)
