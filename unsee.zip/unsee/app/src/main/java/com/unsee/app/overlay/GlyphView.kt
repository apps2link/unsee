package com.unsee.app.overlay

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * أيقونة صغيرة مرسومة (هلال، نجمة ثمانية، علامة صح، درع، قلب، لمعة) بدل الرموز التعبيرية.
 * حركتها تنفّس هادئ واحد (ValueAnimator) يبدأ عند الظهور على الشاشة ويتوقف عند الإخفاء أو الفصل، ويُعطَّل عند [animate]=false.
 */
class GlyphView(
    ctx: Context,
    private val kind: GlyphKind,
    private val color: Int,
    private val animate: Boolean,
    private val sizeDp: Float = 26f,
) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = this@GlyphView.color }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = this@GlyphView.color; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; strokeWidth = 2.4f * d
    }
    private val path = Path()
    private val cut = Path()
    private var k = 0f

    private val breathe = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2400
        repeatCount = ValueAnimator.INFINITE
        repeatMode = ValueAnimator.REVERSE
        interpolator = AccelerateDecelerateInterpolator()
        addUpdateListener { k = it.animatedValue as Float; invalidate() }
    }

    override fun onMeasure(w: Int, h: Int) {
        val s = (sizeDp * d).toInt()
        setMeasuredDimension(s, s)
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); syncAnim() }
    override fun onDetachedFromWindow() { breathe.cancel(); super.onDetachedFromWindow() }
    override fun onWindowVisibilityChanged(visibility: Int) { super.onWindowVisibilityChanged(visibility); syncAnim() }
    override fun onVisibilityChanged(changedView: View, visibility: Int) { super.onVisibilityChanged(changedView, visibility); syncAnim() }

    private fun syncAnim() {
        val on = animate && isAttachedToWindow && windowVisibility == VISIBLE && visibility == VISIBLE
        if (on) { if (!breathe.isStarted) breathe.start() } else breathe.cancel()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val cx = w / 2f
        val cy = w / 2f
        val r = min(w, height.toFloat()) * 0.40f
        val s = 1f + 0.07f * k
        c.save()
        c.scale(s, s, cx, cy)
        fill.alpha = (205 + 50 * k).toInt()
        when (kind) {
            GlyphKind.CRESCENT -> {
                // هلال = دائرة مطروح منها دائرة مزاحة (Path.op يتطلب API 19 فقط)
                path.reset(); path.addCircle(cx, cy, r, Path.Direction.CW)
                cut.reset(); cut.addCircle(cx + r * 0.55f, cy - r * 0.18f, r * 0.82f, Path.Direction.CW)
                path.op(cut, Path.Op.DIFFERENCE)
                c.drawPath(path, fill)
                drawStar(c, cx + r * 0.52f, cy - r * 0.40f, r * 0.30f)
            }
            GlyphKind.STAR -> drawStar(c, cx, cy, r)
            GlyphKind.CHECK -> {
                c.drawCircle(cx, cy, r, stroke)
                path.reset()
                path.moveTo(cx - r * 0.45f, cy + r * 0.02f)
                path.lineTo(cx - r * 0.10f, cy + r * 0.38f)
                path.lineTo(cx + r * 0.50f, cy - r * 0.34f)
                c.drawPath(path, stroke)
            }
            GlyphKind.SHIELD -> {
                path.reset()
                path.moveTo(cx, cy - r)
                path.lineTo(cx + r * 0.85f, cy - r * 0.55f)
                path.lineTo(cx + r * 0.75f, cy + r * 0.20f)
                path.quadTo(cx + r * 0.45f, cy + r * 0.80f, cx, cy + r)
                path.quadTo(cx - r * 0.45f, cy + r * 0.80f, cx - r * 0.75f, cy + r * 0.20f)
                path.lineTo(cx - r * 0.85f, cy - r * 0.55f)
                path.close()
                c.drawPath(path, stroke)
                c.drawLine(cx, cy - r * 0.35f, cx, cy + r * 0.15f, stroke)
                c.drawCircle(cx, cy + r * 0.42f, 1.3f * d, fill)
            }
            GlyphKind.HEART -> {
                path.reset()
                path.moveTo(cx, cy + r * 0.85f)
                path.cubicTo(cx - r * 1.35f, cy - r * 0.05f, cx - r * 0.75f, cy - r * 1.05f, cx, cy - r * 0.38f)
                path.cubicTo(cx + r * 0.75f, cy - r * 1.05f, cx + r * 1.35f, cy - r * 0.05f, cx, cy + r * 0.85f)
                path.close()
                c.drawPath(path, fill)
            }
            GlyphKind.SPARKLE -> {
                drawSparkle(c, cx, cy, r)
                drawSparkle(c, cx + r * 0.70f, cy - r * 0.62f, r * 0.34f)
            }
        }
        c.restore()
    }

    private fun drawStar(c: Canvas, cx: Float, cy: Float, r: Float) {
        path.reset()
        val inner = r * 0.45f
        for (i in 0 until 16) {
            val a = (PI / 8 * i - PI / 2).toFloat()
            val rr = if (i % 2 == 0) r else inner
            val x = cx + cos(a) * rr
            val y = cy + sin(a) * rr
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        c.drawPath(path, fill)
    }

    private fun drawSparkle(c: Canvas, cx: Float, cy: Float, r: Float) {
        path.reset()
        path.moveTo(cx, cy - r)
        path.quadTo(cx, cy, cx + r, cy)
        path.quadTo(cx, cy, cx, cy + r)
        path.quadTo(cx, cy, cx - r, cy)
        path.quadTo(cx, cy, cx, cy - r)
        path.close()
        c.drawPath(path, fill)
    }
}
