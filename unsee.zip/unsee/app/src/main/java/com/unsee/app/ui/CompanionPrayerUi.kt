package com.unsee.app.ui

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.unsee.app.core.AsrMethod
import com.unsee.app.core.Arabic
import com.unsee.app.core.CalcMethod
import com.unsee.app.core.Cities
import com.unsee.app.core.CompanionSchedule
import com.unsee.app.core.DateText
import com.unsee.app.core.Muhasaba
import com.unsee.app.core.MuhasabaLogic
import com.unsee.app.core.MuhasabaText
import com.unsee.app.core.Prayer
import com.unsee.app.core.PrayerLog
import com.unsee.app.core.PrayerStats
import com.unsee.app.core.TimeLogic
import com.unsee.app.data.CompanionStore
import com.unsee.app.notify.CompanionScheduler
import java.time.LocalDate
import java.time.ZoneId

private val IcoRemove = Icons.Rounded.Remove

private fun dayLabel(offset: Int, date: LocalDate): String = when (offset) {
    0 -> "اليوم"
    1 -> "أمس"
    else -> DateText.weekDay(date.dayOfWeek)
}

// ============================================================ مواقيت الصلاة
@Composable
fun PrayerScreen(nav: NavController) {
    val ctx = LocalContext.current
    val cs = remember { CompanionStore.get(ctx) }
    val s by cs.observeAsState { cs.settings() }
    val map by cs.observeAsState { cs.prayerMap(30) }
    val gate = rememberNotifGate()
    var offset by rememberSaveable { mutableIntStateOf(0) }
    var coordDialog by remember { mutableStateOf(false) }
    val zone = remember { ZoneId.systemDefault() }
    val today = LocalDate.now()
    val date = today.minusDays(offset.toLong())
    val times = remember(date, s.lat, s.lng, s.method, s.asr, s.adjust) { CompanionSchedule.prayerDay(date, s, zone) }

    fun status(d: LocalDate, p: Prayer): Int = map["$d|${p.key}"] ?: PrayerLog.NONE
    fun reschedule() = CompanionScheduler.rescheduleAll(ctx)

    val week = PrayerStats.range((0..6).map { today.minusDays(it.toLong()) }) { d, p -> status(d, p) }
    val prayed30 = map.values.count { it == PrayerLog.PRAYED }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ScreenHeader("مواقيت الصلاة", { nav.popBackStack() })

        ChipRow((0..6).toList(), { it == offset }, { dayLabel(it, today.minusDays(it.toLong())) }) { offset = it }
        Text(
            "${DateText.weekDay(date.dayOfWeek)}، " + (DateText.hijri(date) ?: DateText.gregorian(date)),
            color = UColors.CreamDim, fontSize = 13.sp,
        )
        Text("الموقع: ${s.placeName} · ${s.method.label}", color = UColors.CreamDim, fontSize = 12.sp)

        Prayer.values().forEach { p ->
            val st = status(date, p)
            val t = times.of(p)
            GlassCard(Modifier.fillMaxWidth(), glow = st == PrayerLog.PRAYED) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(if (p == Prayer.FAJR) Ico.Sun else if (p == Prayer.MAGHRIB || p == Prayer.ISHA) Ico.Night else Ico.Mosque)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(p.label, color = UColors.Cream, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text(if (t != null) fmtZoned(t) else "غير متاح في هذا الموقع", color = UColors.CreamDim, fontSize = 13.sp)
                    }
                }
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillButton("صليت الحمد لله", { cs.setPrayerStatus(date, p, if (st == PrayerLog.PRAYED) PrayerLog.NONE else PrayerLog.PRAYED) }, icon = Ico.Check, filled = st == PrayerLog.PRAYED)
                    PillButton("فاتتني", { cs.setPrayerStatus(date, p, if (st == PrayerLog.MISSED) PrayerLog.NONE else PrayerLog.MISSED) }, filled = st == PrayerLog.MISSED)
                }
            }
        }
        times.sunrise?.let { Text("الشروق: ${fmtZoned(it)}", color = UColors.CreamDim, fontSize = 12.sp) }
        Text("اضغط الزر مرة ثانية لمسح التسجيل. التسجيل اختيارك أنت: ما لم تسجّله لا يُحتسب تقصيرًا.", color = UColors.CreamDim, fontSize = 12.sp)

        SectionLabel("إحصائياتك")
        GlassCard(Modifier.fillMaxWidth()) {
            Text(
                "آخر ٧ أيام: سجّلت ${Arabic.digits(week.sumOf { it.prayed })} صلاة، وسجّلت ${Arabic.digits(week.sumOf { it.missed })} فاتتك، " +
                    "و${Arabic.digits(week.sumOf { it.unrecorded })} غير مسجّلة.",
                color = UColors.Cream, fontSize = 13.sp,
            )
            Text("آخر ٣٠ يومًا: ${Arabic.digits(prayed30)} صلاة سجّلتها.", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            week.forEach { d ->
                val label = dayLabel((today.toEpochDay() - d.date.toEpochDay()).toInt(), d.date)
                Text("$label: ${Arabic.digits(d.prayed)} من ٥ مسجّلة صلاة", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
            }
            Text("الأرقام من تسجيلك أنت فقط، وغير المسجّل ليس دليلًا على عدم الصلاة.", color = UColors.CreamDim, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
        }

        SectionLabel("التذكير بالصلاة")
        GlassCard(Modifier.fillMaxWidth()) {
            SwitchRow("تذكير بدخول وقت الصلاة", "إشعار أو فقاعة بأزرار «صليت» و«فكّرني لاحقًا»", s.prayerEnabled) { on ->
                if (on) gate { commitCompanion(ctx, cs) { putBoolean("cmp_pray", true) } } else commitCompanion(ctx, cs) { putBoolean("cmp_pray", false) }
            }
            Prayer.values().forEach { p ->
                SwitchRow(p.label, null, s.prayerOn(p)) { commitCompanion(ctx, cs) { putInt("cmp_pmask", s.prayerMask xor p.bit) } }
            }
            Text("تذكير قبل الصلاة", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            ChipRow(listOf(0, 5, 10, 15, 30), { it == s.beforeMin }, { if (it == 0) "بدون" else "قبلها بـ ${Arabic.digits(it)} د" }) { v -> commitCompanion(ctx, cs) { putInt("cmp_before", v) } }
            Text("تذكير بعد دخول الوقت (إن لم تسجّل الصلاة)", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            ChipRow(listOf(0, 10, 20, 30, 45), { it == s.afterMin }, { if (it == 0) "بدون" else "بعدها بـ ${Arabic.digits(it)} د" }) { v -> commitCompanion(ctx, cs) { putInt("cmp_after", v) } }
            Text("مدة «فكّرني لاحقًا»", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            ChipRow(listOf(5, 10, 15, 20, 30), { it == s.snoozeMin }, { "${Arabic.digits(it)} د" }) { v -> cs.edit { putInt("cmp_psnooze", v) } }
        }

        SectionLabel("الموقع وطريقة الحساب")
        GlassCard(Modifier.fillMaxWidth()) {
            Text("المدينة", color = UColors.CreamDim, fontSize = 12.sp)
            ChipRow(Cities.ALL, { it.name == s.placeName && it.lat == s.lat && it.lng == s.lng }, { it.name }) { c -> cs.savePlace(c.name, c.lat, c.lng); reschedule() }
            PillButton("إدخال إحداثيات يدويًا", { coordDialog = true }, Modifier.padding(top = 8.dp), icon = Ico.Edit, filled = false)
            Text("طريقة الحساب", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
            ChipRow(CalcMethod.values().toList(), { it == s.method }, { it.label }) { m -> cs.saveMethod(m); reschedule() }
            Text("المذهب في العصر", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
            ChipRow(AsrMethod.values().toList(), { it == s.asr }, { it.label }) { a -> cs.saveAsr(a); reschedule() }
            Text("تعديل يدوي بالدقائق", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
            Prayer.values().forEachIndexed { i, p ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(p.label, color = UColors.Cream, modifier = Modifier.weight(1f))
                    IconBtn(IcoRemove, "إنقاص دقيقة", { cs.saveAdjust(s.adjust.toMutableList().also { it[i] = (it[i] - 1).coerceAtLeast(-30) }); reschedule() })
                    Text(Arabic.digits(s.adjust[i]), color = UColors.Cream, modifier = Modifier.width(40.dp))
                    IconBtn(Ico.Add, "زيادة دقيقة", { cs.saveAdjust(s.adjust.toMutableList().also { it[i] = (it[i] + 1).coerceAtMost(30) }); reschedule() })
                }
            }
            Text(
                "الحساب فلكي محلي بلا إنترنت وبلا إذن الموقع، والأوقات بتوقيت جهازك. قد تختلف بدقائق عن مسجدك أو الإمساكية المعتمدة في بلدك، " +
                    "فاستخدم التعديل اليدوي للمطابقة. الإحداثيات تقريبية لمركز المدينة.",
                color = UColors.CreamDim, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp),
            )
        }
    }

    if (coordDialog) {
        var name by remember { mutableStateOf("") }
        var lat by remember { mutableStateOf("") }
        var lng by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { coordDialog = false },
            containerColor = UColors.CardSolid,
            title = { Text("موقع مخصص", color = UColors.Cream) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(name, { name = it.take(24) }, singleLine = true, label = { Text("اسم المكان") }, colors = fieldColors())
                    OutlinedTextField(lat, { lat = it.take(10) }, singleLine = true, label = { Text("خط العرض (مثال 30.04)") }, colors = fieldColors(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                    OutlinedTextField(lng, { lng = it.take(10) }, singleLine = true, label = { Text("خط الطول (مثال 31.23)") }, colors = fieldColors(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val la = lat.replace(',', '.').toDoubleOrNull()
                    val lo = lng.replace(',', '.').toDoubleOrNull()
                    if (la == null || lo == null || la < -90.0 || la > 90.0 || lo < -180.0 || lo > 180.0) {
                        Toast.makeText(ctx, "أدخل إحداثيات صحيحة بأرقام لاتينية", Toast.LENGTH_LONG).show()
                    } else {
                        cs.savePlace(name.ifBlank { "موقع مخصص" }, la, lo)
                        reschedule()
                        coordDialog = false
                    }
                }) { Text("حفظ", color = UColors.Gold) }
            },
            dismissButton = { TextButton(onClick = { coordDialog = false }) { Text("إلغاء", color = UColors.CreamDim) } },
        )
    }
}

// ============================================================ محاسبة النفس
private fun muhasabaExport(list: List<Muhasaba>, map: Map<String, Int>): String = list.joinToString("\n\n") { m ->
    val prayed = Prayer.values().count { map["${m.date}|${it.key}"] == PrayerLog.PRAYED }
    val missed = Prayer.values().count { map["${m.date}|${it.key}"] == PrayerLog.MISSED }
    val rec = prayed + missed
    val lines = MuhasabaLogic.summary(m, if (rec > 0) prayed else null, if (rec > 0) 5 else null)
    val plan = MuhasabaLogic.plan(m)
    "— ${m.date}\n" + lines.joinToString("\n") + "\nخطة اليوم التالي:\n" + plan.joinToString("\n") { "• $it" }
}

@Composable
fun MuhasabaScreen(nav: NavController) {
    val ctx = LocalContext.current
    val cs = remember { CompanionStore.get(ctx) }
    val s by cs.observeAsState { cs.settings() }
    val all by cs.observeAsState { cs.allMuhasaba() }
    val map by cs.observeAsState { cs.prayerMap(30) }
    val gate = rememberNotifGate()
    val today = LocalDate.now()
    var dateStr by rememberSaveable { mutableStateOf(today.toString()) }
    val existing = all.firstOrNull { it.date == dateStr }

    var prayers by remember(dateStr) { mutableIntStateOf(existing?.prayers ?: 0) }
    var tongue by remember(dateStr) { mutableIntStateOf(existing?.tongue ?: 0) }
    var quran by remember(dateStr) { mutableIntStateOf(existing?.quran ?: 0) }
    var good by remember(dateStr) { mutableIntStateOf(existing?.good ?: 0) }
    var win by remember(dateStr) { mutableStateOf(existing?.win ?: "") }
    var improve by remember(dateStr) { mutableStateOf(existing?.improve ?: "") }
    var g1 by remember(dateStr) { mutableStateOf(existing?.goals?.getOrNull(0) ?: "") }
    var g2 by remember(dateStr) { mutableStateOf(existing?.goals?.getOrNull(1) ?: "") }
    var g3 by remember(dateStr) { mutableStateOf(existing?.goals?.getOrNull(2) ?: "") }
    var shown by remember(dateStr) { mutableStateOf(existing != null) }
    var delDate by remember { mutableStateOf<String?>(null) }
    var delAll by remember { mutableStateOf(false) }

    val current = Muhasaba(
        dateStr, prayers, tongue, quran, good, win.trim(), improve.trim(),
        listOf(g1, g2, g3).map { it.trim() }.filter { it.isNotEmpty() },
    )
    val prayedRec = Prayer.values().count { map["$dateStr|${it.key}"] == PrayerLog.PRAYED }
    val missedRec = Prayer.values().count { map["$dateStr|${it.key}"] == PrayerLog.MISSED }
    val hasRec = prayedRec + missedRec > 0

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ScreenHeader("خلينا نحاسب نفسنا يا صاحبي", { nav.popBackStack() })
        Text("قبل ما تنام، تعالى نقعد دقيقتين مع نفسنا. مش علشان نجلد نفسنا، علشان بكرة نبقى أحسن. إجاباتك على جهازك فقط.", color = UColors.CreamDim, fontSize = 13.sp)

        ChipRow((0..6).toList(), { today.minusDays(it.toLong()).toString() == dateStr }, { dayLabel(it, today.minusDays(it.toLong())) }) { dateStr = today.minusDays(it.toLong()).toString() }

        GlassCard(Modifier.fillMaxWidth()) {
            Text("صلاتك النهارده كانت عاملة إيه؟", color = UColors.Gold, fontWeight = FontWeight.Bold)
            ChipRow(listOf(1, 2, 3), { it == prayers }, { MuhasabaText.PRAYERS[it - 1] }) { prayers = if (prayers == it) 0 else it }
            if (hasRec) Text("المسجّل في أُنسي لهذا اليوم: ${Arabic.digits(prayedRec)} صليت، ${Arabic.digits(missedRec)} فاتتك.", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Text("لسانك كان عامل إيه؟", color = UColors.Gold, fontWeight = FontWeight.Bold)
            ChipRow(listOf(1, 2), { it == tongue }, { MuhasabaText.TONGUE[it - 1] }) { tongue = if (tongue == it) 0 else it }
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Text("علاقتك بالقرآن والذكر؟", color = UColors.Gold, fontWeight = FontWeight.Bold)
            ChipRow(listOf(1, 2, 3), { it == quran }, { MuhasabaText.QURAN[it - 1] }) { quran = if (quran == it) 0 else it }
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Text("عملت خير النهارده؟ (اختار اللي ينطبق)", color = UColors.Gold, fontWeight = FontWeight.Bold)
            ChipRow(MuhasabaText.GOOD, { (good and it.first) != 0 }, { it.second }) { good = good xor it.first }
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Text("إيه الحاجة الحلوة اللي عملتها النهارده؟", color = UColors.Gold, fontWeight = FontWeight.Bold)
            OutlinedTextField(win, { win = it.take(120) }, label = { Text("إنجاز اليوم (اختياري)") }, colors = fieldColors(), modifier = Modifier.fillMaxWidth())
            Text("إيه الحاجة اللي نفسك تصلحها بكرة؟", color = UColors.Gold, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
            OutlinedTextField(improve, { improve = it.take(120) }, label = { Text("مثلًا: أصحى للفجر وأقلل وقت الموبايل") }, colors = fieldColors(), modifier = Modifier.fillMaxWidth())
            Text("إيه هدفك الصغير لبكرة؟ (لحد ٣)", color = UColors.Gold, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
            OutlinedTextField(g1, { g1 = it.take(80) }, singleLine = true, label = { Text("الهدف الأول") }, colors = fieldColors(), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(g2, { g2 = it.take(80) }, singleLine = true, label = { Text("الهدف الثاني") }, colors = fieldColors(), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(g3, { g3 = it.take(80) }, singleLine = true, label = { Text("الهدف الثالث") }, colors = fieldColors(), modifier = Modifier.fillMaxWidth())
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PillButton("حفظ المراجعة", {
                if (!current.answered) Toast.makeText(ctx, "جاوب على سؤال واحد على الأقل", Toast.LENGTH_SHORT).show()
                else { cs.saveMuhasaba(current); shown = true; Toast.makeText(ctx, "تم الحفظ على جهازك", Toast.LENGTH_SHORT).show() }
            }, icon = Ico.Check)
            if (existing != null) PillButton("حذف", { delDate = existing.date }, icon = Ico.Delete, filled = false)
        }

        if (shown && current.answered) {
            SectionLabel("تقريرك")
            GlassCard(Modifier.fillMaxWidth(), glow = true) {
                MuhasabaLogic.summary(current, if (hasRec) prayedRec else null, if (hasRec) 5 else null).forEach {
                    Text(it, color = UColors.Cream, fontSize = 14.sp, modifier = Modifier.padding(vertical = 2.dp))
                }
                Text("خطة بكرة", color = UColors.Gold, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
                MuhasabaLogic.plan(current).forEachIndexed { i, t ->
                    Text("${Arabic.digits(i + 1)}. $t", color = UColors.Cream, fontSize = 14.sp, modifier = Modifier.padding(vertical = 2.dp))
                }
                Text(MuhasabaText.CLOSING, color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
            }
        }

        SectionLabel("تذكير يومي بالمراجعة")
        GlassCard(Modifier.fillMaxWidth()) {
            SwitchRow("ذكّرني كل ليلة", "إشعار واحد يفتح الجلسة، ولا يصل إن راجعت نفسك بالفعل", s.muhasabaEnabled) { on ->
                if (on) gate { commitCompanion(ctx, cs) { putBoolean("cmp_muh", true) } } else commitCompanion(ctx, cs) { putBoolean("cmp_muh", false) }
            }
            PillButton(TimeLogic.formatMinute(s.muhasabaMin), { pickTime(ctx, s.muhasabaMin) { m -> commitCompanion(ctx, cs) { putInt("cmp_muhmin", m) } } }, Modifier.padding(top = 6.dp), icon = Ico.Alarm, filled = false)
        }

        SectionLabel("المراجعات السابقة")
        if (all.isEmpty()) {
            EmptyState(Ico.History, "لسه مفيش مراجعات", "احفظ أول مراجعة وتظهر هنا. كلها محلية على جهازك.")
        }
        all.take(30).forEach { m ->
            val title = runCatching { DateText.gregorian(LocalDate.parse(m.date)) }.getOrDefault(m.date)
            GlassCard(Modifier.fillMaxWidth()) {
                Text(title, color = UColors.Cream, fontWeight = FontWeight.Bold)
                MuhasabaLogic.summary(m, null, null).take(3).forEach { Text(it, color = UColors.CreamDim, fontSize = 12.sp) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                    PillButton("تعديل", { dateStr = m.date }, icon = Ico.Edit, filled = false)
                    PillButton("حذف", { delDate = m.date }, icon = Ico.Delete, filled = false)
                }
            }
        }
        if (all.isNotEmpty()) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PillButton("تصدير كنص", {
                    val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, muhasabaExport(all, map))
                    runCatching { ctx.startActivity(Intent.createChooser(send, "تصدير المراجعات").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                }, icon = Ico.Share, filled = false)
                PillButton("حذف كل المراجعات", { delAll = true }, icon = Ico.Delete, filled = false)
            }
        }
    }

    delDate?.let { d -> ConfirmDialog("حذف المراجعة؟", "تُحذف مراجعة هذا اليوم فقط.", "حذف", { cs.deleteMuhasaba(d); if (d == dateStr) shown = false }) { delDate = null } }
    if (delAll) ConfirmDialog("حذف كل المراجعات؟", "تُحذف كل مراجعات محاسبة النفس من جهازك. لا يمكن التراجع.", "حذف", { cs.clearMuhasaba(); shown = false }) { delAll = false }
}
