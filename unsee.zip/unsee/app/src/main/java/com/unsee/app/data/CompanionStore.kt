package com.unsee.app.data

import android.content.Context
import android.content.SharedPreferences
import com.unsee.app.core.AsrMethod
import com.unsee.app.core.CalcMethod
import com.unsee.app.core.CompanionPersona
import com.unsee.app.core.CompanionSettings
import com.unsee.app.core.LogAction
import com.unsee.app.core.LogCodec
import com.unsee.app.core.LogEntry
import com.unsee.app.core.LogKind
import com.unsee.app.core.Muhasaba
import com.unsee.app.core.MuhasabaCodec
import com.unsee.app.core.Prayer
import com.unsee.app.core.PrayerLog
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import java.time.LocalDate
import java.time.ZoneId

/**
 * مخزن «رفيق أُنسي». يستخدم نفس ملف التفضيلات المحلي للتطبيق (لا حساب ولا خادم ولا تحليلات)،
 * بمفاتيح ببادئات خاصة (cmp_ و pr_ و mh_) لا تتداخل مع مفاتيح [Store] ولا تمسّها دوال المسح فيه.
 * كل شيء هنا محلي على الجهاز.
 */
class CompanionStore private constructor(context: Context) {
    private val sp: SharedPreferences = context.getSharedPreferences("unsee_prefs", Context.MODE_PRIVATE)

    companion object {
        @Volatile private var instance: CompanionStore? = null
        fun get(context: Context): CompanionStore =
            instance ?: synchronized(this) {
                instance ?: CompanionStore(context.applicationContext).also { instance = it }
            }

        private const val MAX_LOG = 300
        private const val MAX_RECENT = 12
    }

    fun <T> observe(read: () -> T): Flow<T> = callbackFlow {
        val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> trySend(read()) }
        sp.registerOnSharedPreferenceChangeListener(listener)
        trySend(read())
        awaitClose { sp.unregisterOnSharedPreferenceChangeListener(listener) }
    }.distinctUntilChanged()

    fun edit(block: SharedPreferences.Editor.() -> Unit) = sp.edit().apply(block).apply()

    // ============================================================ الإعدادات
    private inline fun <reified T : Enum<T>> enumOr(key: String, def: T): T =
        runCatching { enumValueOf<T>(sp.getString(key, def.name) ?: def.name) }.getOrDefault(def)

    fun settings(): CompanionSettings {
        val d = CompanionSettings()
        val adjust = (sp.getString("cmp_adj", null) ?: "0,0,0,0,0").split(',')
            .map { it.toIntOrNull()?.coerceIn(-30, 30) ?: 0 }
            .let { l -> List(5) { i -> l.getOrElse(i) { 0 } } }
        return CompanionSettings(
            enabled = sp.getBoolean("cmp_enabled", d.enabled),
            persona = enumOr("cmp_persona", d.persona),
            categories = (sp.getString("cmp_cats", "") ?: "").split(',').filter { it.isNotBlank() }.toSet(),
            startMin = sp.getInt("cmp_start", d.startMin).coerceIn(0, 1439),
            endMin = sp.getInt("cmp_end", d.endMin).coerceIn(0, 1439),
            intervalMin = sp.getInt("cmp_interval", d.intervalMin).coerceIn(15, 720),
            maxPerDay = sp.getInt("cmp_max", d.maxPerDay).coerceIn(1, 30),
            quietEnabled = sp.getBoolean("cmp_quiet", d.quietEnabled),
            quietStartMin = sp.getInt("cmp_qs", d.quietStartMin).coerceIn(0, 1439),
            quietEndMin = sp.getInt("cmp_qe", d.quietEndMin).coerceIn(0, 1439),
            bubble = sp.getBoolean("cmp_bubble", d.bubble),
            bubbleSeconds = sp.getInt("cmp_bsec", d.bubbleSeconds).coerceIn(4, 60),
            bubbleStyle = sp.getInt("cmp_bstyle", d.bubbleStyle).coerceIn(0, 2),
            prayerEnabled = sp.getBoolean("cmp_pray", d.prayerEnabled),
            prayerMask = sp.getInt("cmp_pmask", d.prayerMask).and(Prayer.ALL_MASK),
            method = enumOr("cmp_method", d.method),
            asr = enumOr("cmp_asr", d.asr),
            placeName = sp.getString("cmp_place", d.placeName) ?: d.placeName,
            lat = sp.getString("cmp_lat", null)?.toDoubleOrNull()?.coerceIn(-90.0, 90.0) ?: d.lat,
            lng = sp.getString("cmp_lng", null)?.toDoubleOrNull()?.coerceIn(-180.0, 180.0) ?: d.lng,
            beforeMin = sp.getInt("cmp_before", d.beforeMin).coerceIn(0, 60),
            afterMin = sp.getInt("cmp_after", d.afterMin).coerceIn(0, 120),
            snoozeMin = sp.getInt("cmp_psnooze", d.snoozeMin).coerceIn(5, 60),
            adjust = adjust,
            muhasabaEnabled = sp.getBoolean("cmp_muh", d.muhasabaEnabled),
            muhasabaMin = sp.getInt("cmp_muhmin", d.muhasabaMin).coerceIn(0, 1439),
        )
    }

    fun savePersona(p: CompanionPersona) = edit { putString("cmp_persona", p.name) }
    fun saveMethod(m: CalcMethod) = edit { putString("cmp_method", m.name) }
    fun saveAsr(a: AsrMethod) = edit { putString("cmp_asr", a.name) }
    fun saveCategories(names: Set<String>) = edit { putString("cmp_cats", names.joinToString(",")) }
    fun savePlace(name: String, lat: Double, lng: Double) = edit {
        putString("cmp_place", name.replace('|', ' ').trim().ifEmpty { "موقع مخصص" })
        putString("cmp_lat", lat.toString())
        putString("cmp_lng", lng.toString())
    }
    fun saveAdjust(list: List<Int>) = edit { putString("cmp_adj", list.take(5).joinToString(",")) }

    // ============================================================ سجل الصلاة (تسجيل المستخدم فقط)
    fun prayerStatus(date: LocalDate, p: Prayer): Int = sp.getInt("pr_${date}_${p.key}", PrayerLog.NONE)

    fun setPrayerStatus(date: LocalDate, p: Prayer, status: Int) = edit {
        if (status == PrayerLog.NONE) remove("pr_${date}_${p.key}") else putInt("pr_${date}_${p.key}", status)
    }

    /** حالات الصلاة المسجّلة لآخر [days] يومًا: المفتاح «yyyy-MM-dd|fajr» والقيمة حالة المستخدم. الصلوات غير المسجّلة لا تظهر. */
    fun prayerMap(days: Int): Map<String, Int> {
        val out = HashMap<String, Int>()
        val now = LocalDate.now()
        for (i in 0 until days) {
            val d = now.minusDays(i.toLong())
            for (p in Prayer.values()) {
                val v = sp.getInt("pr_${d}_${p.key}", PrayerLog.NONE)
                if (v != PrayerLog.NONE) out["$d|${p.key}"] = v
            }
        }
        return out
    }

    fun clearPrayerLog() = edit {
        for (k in sp.all.keys) if (k.startsWith("pr_")) remove(k)
    }

    // ============================================================ سجل التذكيرات
    fun log(): List<LogEntry> = LogCodec.decode(sp.getString("cmp_log", "") ?: "")

    fun appendLog(kind: LogKind, ref: String, action: LogAction) {
        val line = LogEntry(System.currentTimeMillis(), kind, ref, action)
        val list = (log() + line).takeLast(MAX_LOG)
        edit { putString("cmp_log", LogCodec.encode(list)) }
    }

    fun clearLog() = edit { remove("cmp_log") }

    private fun startOfTodayMillis(): Long = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()

    /** عدد رسائل الذكر التي عُرضت فعلًا اليوم (فقاعة أو إشعار). */
    fun dhikrShownToday(): Int {
        val from = startOfTodayMillis()
        return log().count {
            it.ts >= from && it.kind == LogKind.DHIKR &&
                (it.action == LogAction.SHOWN_BUBBLE || it.action == LogAction.SHOWN_NOTIF)
        }
    }

    // ============================================================ منع التكرار
    fun lastKey(type: String): String? = sp.getString("cmp_lastkey_$type", null)
    fun setLastKey(type: String, key: String) = edit { putString("cmp_lastkey_$type", key) }

    fun recentIds(): List<String> = (sp.getString("cmp_recent", "") ?: "").split(',').filter { it.isNotBlank() }

    fun pushRecent(id: String) {
        val list = (recentIds() + id).takeLast(MAX_RECENT)
        edit { putString("cmp_recent", list.joinToString(",")) }
    }

    // ============================================================ الفقاعة
    fun bubbleY(): Int = sp.getInt("cmp_by", -1)
    fun setBubbleY(y: Int) = edit { putInt("cmp_by", y) }

    // ============================================================ محاسبة النفس
    fun muhasaba(date: String): Muhasaba? = sp.getString("mh_$date", null)?.let { MuhasabaCodec.decode(it) }

    fun saveMuhasaba(m: Muhasaba) = edit { putString("mh_${m.date}", MuhasabaCodec.encode(m.copy(updated = System.currentTimeMillis()))) }

    fun deleteMuhasaba(date: String) = edit { remove("mh_$date") }

    /** كل المراجعات، الأحدث أولًا. */
    fun allMuhasaba(): List<Muhasaba> =
        sp.all.entries.filter { it.key.startsWith("mh_") && it.value is String }
            .mapNotNull { MuhasabaCodec.decode(it.value as String) }
            .sortedByDescending { it.date }

    fun clearMuhasaba() = edit {
        for (k in sp.all.keys) if (k.startsWith("mh_")) remove(k)
    }

    /** يمسح كل بيانات «رفيق أُنسي» (الإعدادات والسجلات والمراجعات) ولا يمس بقية التطبيق. */
    fun deleteAllCompanionData() = edit {
        for (k in sp.all.keys) if (k.startsWith("cmp_") || k.startsWith("pr_") || k.startsWith("mh_")) remove(k)
    }
}
