package com.unsee.app.overlay

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * الفقاعة العائمة: أيقونة التطبيق داخل دائرة بتوهج نابض، نجوم صغيرة تدور حولها، طفو هادئ،
 * ونقطة حمراء نابضة (وموجات تتسع منها) عند وجود رسالة جديدة. تنفجر بقصاصات ملوّنة عند الإنجاز.
 *
 * النافذة أكبر من الدائرة بهامش شفاف ([PAD_DP]) كي يظهر التوهج والقصاصات، ومركز الدائرة = مركز النافذة.
 * الرسم كله على خيط الواجهة بمحرّك واحد (ValueAnimator) يتوقف عند الإخفاء، فلا استهلاك للبطارية وهي مخفية.
 */
class BubbleView(ctx: Context) : View(ctx) {
    companion object {
        const val CIRCLE_DP = 54f
        const val PAD_DP = 18f
        const val WINDOW_DP = CIRCLE_DP + 2 * PAD_DP
    }

    private val d = ctx.resources.displayMetrics.density
    private fun dp(v: Float) = v * d

    private var icon: Drawable? = null
    private var badgeCount = 0
    private var badgePriority = false
    private var fx = true
    private var t = 0f                 // 0..1 يدور كل ٤ ثوانٍ
    private var pressed = false
    private var popStart = -1L         // لحظة آخر «قفزة» عند وصول رسالة
    private var burstStart = -1L
    private var burstColors = intArrayOf(Color.parseColor("#FF4ADE80"), Color.parseColor("#FFFFD54F"), Color.WHITE)
    private data class P(val ang: Float, val speed: Float, val size: Float, val colorIdx: Int, val spin: Float)
    private var particles: List<P> = emptyList()

    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dp(2.2f) }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; isFakeBoldText = true }
    private val star = Path()
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 4000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; if (fx || badgeCount > 0) invalidate() }
    }

    fun setIcon(dr: Drawable?) { icon = dr; invalidate() }

    fun setFx(on: Boolean) { fx = on; invalidate() }

    /** [count] = عدد الرسائل المعلّقة (0 = بلا نقطة). [priority] = نقطة أكبر وأسرع وبعلامة تعجب. */
    fun setBadge(count: Int, priority: Boolean) {
        badgeCount = max(0, count); badgePriority = priority; invalidate()
    }

    /** قفزة ورجّة عند وصول رسالة جديدة. */
    fun pop() { popStart = System.currentTimeMillis(); invalidate() }

    /** انفجار قصاصات ملوّنة (احتفال) أو رذاذ رمادي هادئ (حزن) حول الدائرة. */
    fun burst(good: Boolean) {
        burstColors = if (good) intArrayOf(Color.parseColor("#FF4ADE80"), Color.parseColor("#FFFFD54F"), Color.parseColor("#FFFFFFFF"), Color.parseColor("#FF60A5FA"))
        else intArrayOf(Color.parseColor("#FF94A3B8"), Color.parseColor("#FF64748B"), Color.parseColor("#FFCBD5E1"))
        val r = Random(System.nanoTime())
        particles = List(if (good) 22 else 12) {
            P(r.nextFloat() * 2f * PI.toFloat(), 0.55f + r.nextFloat() * 0.45f, dp(2.5f + r.nextFloat() * 2.5f), r.nextInt(burstColors.size), r.nextFloat() * 6f)
        }
        burstStart = System.currentTimeMillis()
        invalidate()
    }

    fun setPressedLook(p: Boolean) { pressed = p; invalidate() }

    override fun onMeasure(w: Int, h: Int) {
        val s = dp(WINDOW_DP).toInt()
        setMeasuredDimension(s, s)
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (!anim.isStarted) anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE) { if (isAttachedToWindow && !anim.isStarted) anim.start() } else anim.cancel()
    }

    private fun starPath(cx: Float, cy: Float, r: Float) {
        star.reset()
        val inner = r * 0.38f
        for (i in 0 until 8) {
            val a = (PI / 4 * i - PI / 2).toFloat()
            val rr = if (i % 2 == 0) r else inner
            val x = cx + cos(a) * rr
            val y = cy + sin(a) * rr
            if (i == 0) star.moveTo(x, y) else star.lineTo(x, y)
        }
        star.close()
    }

    override fun onDraw(c: Canvas) {
        val now = System.currentTimeMillis()
        val w = width.toFloat()
        val cx = w / 2f
        val baseR = dp(CIRCLE_DP) / 2f
        val phase = (t * 2f * PI).toFloat()
        val bob = if (fx) sin(phase) * dp(2.5f) else 0f
        val cy = w / 2f + bob

        // قفزة الوصول: تكبير مرتد خلال ٦٠٠ مللي ورجّة جانبية
        var scale = if (pressed) 0.92f else 1f
        var wiggle = 0f
        if (popStart > 0) {
            val k = (now - popStart) / 600f
            if (k in 0f..1f) {
                scale *= 1f + 0.28f * sin(k * PI.toFloat()) * (1f - k)
                wiggle = sin(k * 4f * PI.toFloat()) * (1f - k) * 10f
                invalidate()
            } else popStart = -1
        }
        val urgent = badgeCount > 0
        val accent = if (badgePriority) Color.parseColor("#FFFF5A4F") else Color.parseColor("#FFE2B857")

        c.save()
        c.rotate(wiggle, cx, cy)
        c.scale(scale, scale, cx, cy)

        // توهج نابض (أقوى مع وجود رسالة)
        val pulse = 0.5f + 0.5f * sin(phase * (if (badgePriority) 2f else 1f))
        val glowR = baseR * (1.55f + 0.18f * pulse)
        glow.shader = RadialGradient(cx, cy, glowR, intArrayOf(withAlpha(accent, if (urgent) 150 else 90), withAlpha(accent, 0)), floatArrayOf(0.45f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, glowR, glow)

        // موجات حمراء تتسع من الدائرة عند وجود رسالة
        if (urgent && fx) {
            for (i in 0 until 2) {
                val k = ((t * (if (badgePriority) 2f else 1f) + i * 0.5f) % 1f)
                ring.color = withAlpha(if (badgePriority) Color.parseColor("#FFFF3B30") else accent, ((1f - k) * 150).toInt())
                c.drawCircle(cx, cy, baseR * (1.0f + 0.55f * k), ring)
            }
        }

        // جسم الدائرة + الأيقونة
        fill.shader = null
        fill.color = Color.parseColor("#FF0B1B3A")
        c.drawCircle(cx, cy, baseR, fill)
        val ic = icon
        if (ic != null) {
            val inset = dp(3f)
            c.save()
            val clip = Path().apply { addCircle(cx, cy, baseR - inset, Path.Direction.CW) }
            c.clipPath(clip)
            ic.setBounds((cx - baseR + inset).toInt(), (cy - baseR + inset).toInt(), (cx + baseR - inset).toInt(), (cy + baseR - inset).toInt())
            ic.draw(c)
            c.restore()
        }
        ring.color = withAlpha(accent, 235)
        c.drawCircle(cx, cy, baseR - dp(0.5f), ring)

        // نجوم تدور حول الدائرة
        if (fx) {
            fill.color = withAlpha(Color.parseColor("#FFFFE9A8"), 230)
            for (i in 0 until 3) {
                val a = phase + i * (2f * PI.toFloat() / 3f)
                val orbit = baseR + dp(7f) + dp(1.5f) * sin(phase * 2f + i)
                val sx = cx + cos(a) * orbit
                val sy = cy + sin(a) * orbit
                val sr = dp(2.6f + 0.9f * sin(phase * 3f + i * 2f))
                starPath(sx, sy, sr)
                c.drawPath(star, fill)
            }
        }
        c.restore()

        // النقطة الحمراء (لا تتأثر بالدوران حتى تبقى ثابتة المكان)
        if (urgent) {
            val bx = cx + baseR * 0.72f * scale
            val by = cy - baseR * 0.72f * scale
            val br = dp(if (badgePriority) 10f else 8.5f) * (1f + 0.10f * pulse)
            fill.color = Color.WHITE
            c.drawCircle(bx, by, br + dp(1.6f), fill)
            fill.color = if (badgePriority) Color.parseColor("#FFE11D48") else Color.parseColor("#FFEF4444")
            c.drawCircle(bx, by, br, fill)
            val label = when { badgePriority -> "!"; badgeCount > 1 -> min(badgeCount, 9).toString(); else -> "" }
            if (label.isNotEmpty()) {
                txt.textSize = dp(11f)
                c.drawText(label, bx, by - (txt.descent() + txt.ascent()) / 2f, txt)
            }
        }

        // قصاصات الاحتفال
        if (burstStart > 0) {
            val k = (now - burstStart) / 1100f
            if (k in 0f..1f) {
                val maxR = dp(PAD_DP + CIRCLE_DP / 2f - 3f)
                for (p in particles) {
                    val rr = baseR * 0.6f + (maxR - baseR * 0.6f) * (1f - (1f - k) * (1f - k)) * p.speed
                    val px = cx + cos(p.ang) * rr
                    val py = cy + sin(p.ang) * rr + dp(6f) * k * k
                    fill.color = withAlpha(burstColors[p.colorIdx], ((1f - k) * 255).toInt())
                    if (p.colorIdx % 2 == 0) c.drawCircle(px, py, p.size, fill)
                    else {
                        c.save(); c.rotate(p.spin * k * 120f, px, py)
                        c.drawRect(px - p.size, py - p.size * 0.6f, px + p.size, py + p.size * 0.6f, fill)
                        c.restore()
                    }
                }
                invalidate()
            } else { burstStart = -1; particles = emptyList() }
        }
    }

    private fun withAlpha(color: Int, a: Int): Int = Color.argb(a.coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))
}
