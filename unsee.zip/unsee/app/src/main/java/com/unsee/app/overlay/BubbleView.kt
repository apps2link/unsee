package com.unsee.app.overlay

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.view.View
import android.view.animation.LinearInterpolator
import com.unsee.app.core.BubbleLook
import com.unsee.app.core.BubbleMood
import com.unsee.app.core.LogKind
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * الفقاعة العائمة بتصميم «Glass Orb»: جسم زجاجي داكن شبه شفاف (Midnight Navy ← Deep Emerald) بحافة مضيئة
 * وانعكاس علوي، هالة محيطية تتنفس، خاتم زخرفي دقيق يدور ببطء، شريط لمعان يمر على الزجاج، وذرات ضوء قليلة.
 * الحالات (انظر [BubbleMood]) تغيّر لون الإضاءة وإيقاعها بهدوء: عادي، تذكير، عاجل، صلاة، ذكر، محاسبة، احتفال، مواساة.
 *
 * الأداء: محرّك حركة واحد (ValueAnimator دورته 6 ثوانٍ) يعمل فقط حين تكون الفقاعة ظاهرة ومتصلة بنافذة
 * ويوجد ما يتحرك (مؤثرات مفعّلة أو تذكير أو نبضة/احتفال)؛ وإلا يُلغى فلا استهلاك. لا تُنشأ كائنات داخل onDraw
 * (الـShaders والـPaths مخزّنة وتُبنى فقط عند تغيّر الحجم أو الحالة).
 *
 * النافذة أكبر من الدائرة بهامش شفاف ([PAD_DP]) ليظهر التوهج والجسيمات، ومركز الدائرة = مركز النافذة.
 */
class BubbleView(ctx: Context) : View(ctx) {
    companion object {
        const val CIRCLE_DP = 56f
        const val PAD_DP = 22f
        const val WINDOW_DP = CIRCLE_DP + 2 * PAD_DP
        private const val CYCLE_MS = 6000L
        private const val TAU = (2.0 * PI).toFloat()
    }

    private val d = ctx.resources.displayMetrics.density
    private fun dp(v: Float) = v * d

    private class Look(val accent: Int, val bodyIn: Int, val bodyOut: Int, val pulseSpeed: Float, val glowAlpha: Int)

    private fun look(m: BubbleMood): Look = when (m) {
        BubbleMood.NORMAL -> Look(0xFFE2B857.toInt(), 0xE6103A4A.toInt(), 0xEE0A1A33.toInt(), 1f, 70)
        BubbleMood.REMINDER -> Look(0xFFE8C46A.toInt(), 0xE6134A55.toInt(), 0xEE0A1A33.toInt(), 1.4f, 120)
        BubbleMood.DHIKR -> Look(0xFFE2B857.toInt(), 0xE60F5A47.toInt(), 0xEE08241F.toInt(), 1.3f, 120)
        BubbleMood.PRAYER -> Look(0xFFB4CCFF.toInt(), 0xE61B2C63.toInt(), 0xEE0A1233.toInt(), 1.1f, 115)
        BubbleMood.REFLECT -> Look(0xFFC9B6FF.toInt(), 0xE62A2466.toInt(), 0xEE10103A.toInt(), 0.9f, 105)
        BubbleMood.URGENT -> Look(0xFFFFB454.toInt(), 0xE6244650.toInt(), 0xEE0A1A33.toInt(), 2.2f, 170)
        BubbleMood.CELEBRATE -> Look(0xFFFFD66B.toInt(), 0xE60F5A47.toInt(), 0xEE08241F.toInt(), 1.8f, 190)
        BubbleMood.COMFORT -> Look(0xFFB6C8E0.toInt(), 0xE62A3A55.toInt(), 0xEE141C2E.toInt(), 0.6f, 85)
    }

    private var icon: Drawable? = null
    private var badgeCount = 0
    private var badgePriority = false
    private var firstKind: LogKind? = null
    private var moodOverride: BubbleMood? = null
    private var moodUntil = 0L
    private var mood = BubbleMood.NORMAL
    private var cur = look(BubbleMood.NORMAL)
    private var fx = true
    private var t = 0f
    private var pressed = false
    private var popStart = -1L
    private var burstStart = -1L
    private var burstGood = true

    private class Mote(val ang: Float, val speed: Float, val size: Float, val colorIdx: Int, val spin: Float)
    private var motes: List<Mote> = emptyList()
    private var burstColors = intArrayOf(0xFFFFD66B.toInt(), 0xFF7EE7C7.toInt(), Color.WHITE)

    // ----- أدوات الرسم المخزّنة
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val body = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dp(1.6f) }
    private val innerRing = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dp(1f) }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dp(2f) }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sheen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; isFakeBoldText = true }
    private val clipPath = Path()
    private val orn = Path()
    private val rect = RectF()
    private var glowShader: Shader? = null
    private var shadowShader: Shader? = null
    private var bodyShader: Shader? = null
    private var rimShader: Shader? = null
    private var shaderMood: BubbleMood? = null
    private var shaderSize = -1

    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = CYCLE_MS
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    // ============================================================ واجهة التحكم
    fun setIcon(dr: Drawable?) { icon = dr; invalidate() }

    fun setFx(on: Boolean) { fx = on; syncAnim(); invalidate() }

    /** عدد المعلّق، وهل فيه أولوية، ونوع أول عنصر (لاختيار المزاج). */
    fun setState(count: Int, priority: Boolean, kind: LogKind?) {
        badgeCount = max(0, count); badgePriority = priority; firstKind = kind
        updateMood(); syncAnim(); invalidate()
    }

    fun setBadge(count: Int, priority: Boolean) = setState(count, priority, firstKind)

    /** نبضة مميزة عند وصول تذكير جديد: تكبير مرتد خفيف مع موجة ضوء. */
    fun pop() { popStart = System.currentTimeMillis(); syncAnim(); invalidate() }

    /** احتفال أنيق (حسنة) أو مواساة هادئة (سيئة): تغيّر مؤقت في اللون مع ذرات ضوء قليلة، دون مبالغة. */
    fun burst(good: Boolean) {
        burstGood = good
        burstColors = if (good) intArrayOf(0xFFFFD66B.toInt(), 0xFF7EE7C7.toInt(), 0xFFFFFFFF.toInt(), 0xFFB794FF.toInt())
        else intArrayOf(0xFFB6C8E0.toInt(), 0xFF8FA3C4.toInt(), 0xFFDDE6F3.toInt())
        val r = Random(System.nanoTime())
        motes = List(if (good) 16 else 8) {
            Mote(r.nextFloat() * TAU, 0.55f + r.nextFloat() * 0.45f, dp(2f + r.nextFloat() * 2f), r.nextInt(burstColors.size), r.nextFloat() * 6f)
        }
        burstStart = System.currentTimeMillis()
        moodOverride = if (good) BubbleMood.CELEBRATE else BubbleMood.COMFORT
        moodUntil = burstStart + (if (good) 1800L else 2600L)
        updateMood(); syncAnim(); invalidate()
    }

    fun setPressedLook(p: Boolean) { pressed = p; invalidate() }

    private fun updateMood() {
        val now = System.currentTimeMillis()
        if (moodOverride != null && now >= moodUntil) moodOverride = null
        val m = BubbleLook.mood(badgeCount, badgePriority, firstKind, moodOverride)
        if (m != mood) { mood = m; cur = look(m) }
    }

    // ============================================================ دورة الحركة
    private fun needsAnim(): Boolean {
        val busy = popStart > 0 || burstStart > 0 || moodOverride != null
        return isAttachedToWindow && isShown && (fx || badgeCount > 0 || busy)
    }

    private fun syncAnim() {
        if (needsAnim()) { if (!anim.isStarted) anim.start() } else if (anim.isStarted) anim.cancel()
    }

    override fun onMeasure(w: Int, h: Int) {
        val s = dp(WINDOW_DP).toInt()
        setMeasuredDimension(s, s)
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); syncAnim() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onVisibilityChanged(changedView: View, visibility: Int) { super.onVisibilityChanged(changedView, visibility); syncAnim() }
    override fun onWindowVisibilityChanged(visibility: Int) { super.onWindowVisibilityChanged(visibility); syncAnim() }

    // ============================================================ الرسم
    private fun withAlpha(color: Int, a: Int): Int = Color.argb(a.coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))

    private fun ensureShaders(cx: Float, cy: Float, baseR: Float) {
        val size = (baseR * 100).toInt()
        if (shaderMood == mood && shaderSize == size) return
        shaderMood = mood; shaderSize = size
        val a = cur.accent
        glowShader = RadialGradient(0f, 0f, baseR * 1.9f, intArrayOf(withAlpha(a, cur.glowAlpha), withAlpha(a, cur.glowAlpha / 3), withAlpha(a, 0)), floatArrayOf(0.35f, 0.7f, 1f), Shader.TileMode.CLAMP)
        shadowShader = RadialGradient(0f, 0f, baseR * 1.25f, intArrayOf(0x55040A18, 0x00040A18), floatArrayOf(0.6f, 1f), Shader.TileMode.CLAMP)
        // مركز الإضاءة أعلى-يسار قليلًا فيبدو الجسم كرويًا
        bodyShader = RadialGradient(-baseR * 0.28f, -baseR * 0.34f, baseR * 1.45f, intArrayOf(cur.bodyIn, cur.bodyOut), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
        rimShader = LinearGradient(-baseR, -baseR, baseR, baseR, intArrayOf(withAlpha(Color.WHITE, 190), withAlpha(a, 90), withAlpha(Color.WHITE, 40)), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
    }

    private fun ornament(r: Float, rot: Float) {
        // ثمانية معينات صغيرة على حلقة (خاتم زخرفي هندسي) — يدور ببطء
        orn.reset()
        for (i in 0 until 8) {
            val a = rot + i * TAU / 8f
            val x = cos(a) * r; val y = sin(a) * r
            val s = dp(1.7f)
            orn.moveTo(x, y - s); orn.lineTo(x + s, y); orn.lineTo(x, y + s); orn.lineTo(x - s, y); orn.close()
        }
    }

    override fun onDraw(c: Canvas) {
        val now = System.currentTimeMillis()
        updateMood()
        val w = width.toFloat()
        val cx = w / 2f
        val baseR = dp(CIRCLE_DP) / 2f
        val phase = t * TAU
        val reduce = !fx
        val bob = if (reduce) 0f else sin(phase) * dp(2.2f)      // طفو بسيط
        val cy = w / 2f + bob
        ensureShaders(cx, cy, baseR)
        val a = cur.accent
        val urgent = badgeCount > 0

        // قفزة الوصول: تكبير مرتد خفيف + موجة ضوء (أقل من 700ms)
        var scale = if (pressed) 0.94f else 1f
        var popK = -1f
        if (popStart > 0) {
            val k = (now - popStart) / 700f
            if (k in 0f..1f) { popK = k; scale *= 1f + 0.16f * sin(k * PI.toFloat()) * (1f - k); invalidate() } else { popStart = -1; syncAnim() }
        }

        // ظل محيطي ناعم أسفل الجسم
        c.save()
        c.translate(cx, cy + baseR * 0.22f)
        shadow.shader = shadowShader
        c.drawCircle(0f, 0f, baseR * 1.25f, shadow)
        c.restore()

        c.save()
        c.translate(cx, cy)
        c.scale(scale, scale)

        // هالة محيطية تتنفس (النبض أسرع قليلًا مع التذكير/العاجل)
        val breathe = 0.5f + 0.5f * sin(phase * cur.pulseSpeed)
        val gs = 1f + (if (reduce) 0f else 0.07f) * breathe
        glow.shader = glowShader
        c.save(); c.scale(gs, gs); c.drawCircle(0f, 0f, baseR * 1.9f, glow); c.restore()

        // موجات تتسع عند وجود تذكير أو نبضة وصول
        if (!reduce && urgent) {
            for (i in 0 until 2) {
                val k = (t * cur.pulseSpeed * 0.5f + i * 0.5f) % 1f
                ring.color = withAlpha(a, ((1f - k) * 120).toInt())
                c.drawCircle(0f, 0f, baseR * (1.02f + 0.5f * k), ring)
            }
        }
        if (popK >= 0f) {
            ring.color = withAlpha(a, ((1f - popK) * 200).toInt())
            c.drawCircle(0f, 0f, baseR * (1f + 0.7f * popK), ring)
        }

        // جسم زجاجي داكن شبه شفاف
        body.shader = bodyShader
        c.drawCircle(0f, 0f, baseR, body)

        // الأيقونة داخل الجسم
        val ic = icon
        if (ic != null) {
            val inset = dp(7f)
            c.save()
            clipPath.reset(); clipPath.addCircle(0f, 0f, baseR - dp(3f), Path.Direction.CW)
            c.clipPath(clipPath)
            ic.setBounds((-baseR + inset).toInt(), (-baseR + inset).toInt(), (baseR - inset).toInt(), (baseR - inset).toInt())
            ic.alpha = 235
            ic.draw(c)
            c.restore()
        }

        // طبقات الزجاج: حلقة داخلية، لمعان علوي، شريط ضوء يمر
        innerRing.color = withAlpha(Color.WHITE, 46)
        c.drawCircle(0f, 0f, baseR - dp(4f), innerRing)
        c.save()
        clipPath.reset(); clipPath.addCircle(0f, 0f, baseR - dp(1f), Path.Direction.CW)
        c.clipPath(clipPath)
        // انعكاس علوي (قوس هلالي من الضوء)
        sheen.shader = null
        sheen.color = withAlpha(Color.WHITE, 52)
        rect.set(-baseR * 0.78f, -baseR * 0.96f, baseR * 0.55f, -baseR * 0.18f)
        c.drawOval(rect, sheen)
        if (!reduce) {
            // شريط لمعان قطري يعبر الزجاج مرة كل دورة (بين 15% و45% من الدورة فقط)
            val k = ((t - 0.15f) / 0.30f)
            if (k in 0f..1f) {
                val x = -baseR * 1.6f + baseR * 3.2f * k
                c.save(); c.rotate(24f)
                sheen.color = withAlpha(Color.WHITE, (60 * sin(k * PI.toFloat())).toInt())
                c.drawRect(x - dp(5f), -baseR * 1.5f, x + dp(5f), baseR * 1.5f, sheen)
                c.restore()
            }
        }
        c.restore()

        // حافة زجاجية رفيعة متدرجة
        rim.shader = rimShader
        c.drawCircle(0f, 0f, baseR - dp(0.5f), rim)
        rim.shader = null

        // خاتم زخرفي دقيق يدور ببطء حول الجسم
        if (!reduce || urgent) {
            ornament(baseR + dp(6f), phase * 0.25f)
            fill.color = withAlpha(a, if (urgent) 210 else 150)
            c.drawPath(orn, fill)
        }
        c.restore()

        // ذرات ضوء صغيرة وهادئة (3 فقط، تطفو للأعلى وتتلاشى)
        if (!reduce) {
            for (i in 0 until 3) {
                val k = (t * 1f + i / 3f) % 1f
                val ang = (-PI / 2).toFloat() + (i - 1) * 0.9f + sin(phase + i) * 0.2f
                val rr = baseR * (0.9f + 0.75f * k)
                val px = cx + cos(ang) * rr
                val py = cy + sin(ang) * rr
                fill.color = withAlpha(a, (sin(k * PI.toFloat()) * 150).toInt())
                c.drawCircle(px, py, dp(1.5f + 0.6f * (1f - k)), fill)
            }
        }

        // شارة التذكير: نقطة صغيرة بلون الحالة (للعاجل تحمل علامة تعجب)، بدل النقطة الحمراء الصارخة
        if (urgent) {
            val bx = cx + baseR * 0.74f
            val by = cy - baseR * 0.74f
            val br = dp(if (badgePriority) 9.5f else 8f) * (1f + 0.07f * breathe)
            fill.color = withAlpha(Color.WHITE, 235)
            c.drawCircle(bx, by, br + dp(1.4f), fill)
            fill.color = if (badgePriority) 0xFFE8892B.toInt() else a
            c.drawCircle(bx, by, br, fill)
            val label = when { badgePriority -> "!"; badgeCount > 1 -> min(badgeCount, 9).toString(); else -> "" }
            if (label.isNotEmpty()) {
                txt.color = 0xFF0B1B3A.toInt(); txt.textSize = dp(11f)
                c.drawText(label, bx, by - (txt.descent() + txt.ascent()) / 2f, txt)
            }
        }

        // ذرات الاحتفال/المواساة
        if (burstStart > 0) {
            val k = (now - burstStart) / (if (burstGood) 1300f else 1800f)
            if (k in 0f..1f) {
                val maxR = dp(PAD_DP + CIRCLE_DP / 2f - 3f)
                for (p in motes) {
                    val rr = baseR * 0.7f + (maxR - baseR * 0.7f) * (1f - (1f - k) * (1f - k)) * p.speed
                    val px = cx + cos(p.ang) * rr
                    val py = cy + sin(p.ang) * rr + (if (burstGood) -dp(4f) * k else dp(7f) * k * k)
                    fill.color = withAlpha(burstColors[p.colorIdx], ((1f - k) * 235).toInt())
                    c.drawCircle(px, py, p.size, fill)
                }
                invalidate()
            } else { burstStart = -1; motes = emptyList(); syncAnim() }
        }
        if (moodOverride != null && now >= moodUntil) { moodOverride = null; syncAnim() }
    }
}
