package com.unsee.app.overlay

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.drawable.Drawable
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * الفقاعة العائمة بتصميم «زجاج محيطي حيّ»: كرة زجاجية شبه شفافة بتدرّج عميق، حافة تلمع وتدور ببطء،
 * بقعة انعكاس ضوئي، توهج محيطي نابض بلون الحالة، وأيقونة التطبيق في قلبها.
 *
 * الحالات ([BubbleMood]): عادي، تذكير جديد، عاجل، صلاة، ذكر، احتفال، مواساة. لكل حالة لونان ونبض مختلف.
 * - نبضة التذكير: موجات تتسع من الكرة + قفزة ([pop]).
 * - الاحتفال: وميض + قصاصات ونجوم ([burst]) تُعيد الفقاعة لحالتها بعد ثانية ونصف.
 *
 * الأداء: كل الـ Shaders تُبنى مرة واحدة (عند تغيّر الحجم أو الحالة) ومتمركزة على (0,0) ثم تُنقل الـ Canvas،
 * فلا تخصيص ذاكرة في onDraw. محرّك الحركة الواحد يعمل فقط حين: الفقاعة ظاهرة + (الحركة مفعّلة أو توجد نقطة تذكير).
 * عند الإخفاء أو الفصل يتوقف تمامًا فلا استهلاك للمعالج.
 */
class BubbleView(ctx: Context) : View(ctx) {
    companion object {
        const val CIRCLE_DP = 54f
        const val PAD_DP = 18f
        const val WINDOW_DP = CIRCLE_DP + 2 * PAD_DP
        private const val CELEBRATE_MS = 1500L
    }

    private val d = ctx.resources.displayMetrics.density
    private fun dp(v: Float) = v * d

    private var icon: Drawable? = null
    private var badgeCount = 0
    private var badgePriority = false
    private var fx = true
    private var t = 0f                 // 0..1 يدور كل ٦ ثوانٍ
    private var pressed = false
    private var popStart = -1L
    private var burstStart = -1L
    private var burstGood = true
    private var baseMood = BubbleMood.NORMAL
    private var overrideMood: BubbleMood? = null
    private var overrideUntil = 0L
    private var endPosted = false
    private var shaderMood: BubbleMood? = null
    private var shaderSize = 0

    private data class P(val ang: Float, val speed: Float, val size: Float, val colorIdx: Int, val spin: Float)
    private var particles: List<P> = emptyList()
    private var burstColors = intArrayOf(Color.WHITE)

    // Paints ثابتة (تُعاد تهيئة الـ Shader فقط عند تغيّر الحالة/الحجم)
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bodyP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tintP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rimP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dp(2.2f) }
    private val specP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val waveP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dp(2f) }
    private val flashP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; isFakeBoldText = true }
    private val star = Path()
    private val emblemFill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val emblemGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND }
    private val emblemPath = Path()
    private val emblemCut = Path()
    private val emblemExtra = Path()
    private var emblemStroke = false
    private var emblemSpins = false
    private val raysP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shineP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val clip = Path()
    private val specRect = RectF()

    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 6000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    // ------------------------------------------------------------------ واجهة الخدمة
    fun setIcon(dr: Drawable?) { icon = dr; invalidate() }

    fun setFx(on: Boolean) { fx = on; syncAnim(); invalidate() }

    /** [count] = عدد الرسائل المعلّقة (0 = بلا نقطة). [priority] = نقطة أكبر وأسرع وبعلامة تعجب. */
    fun setBadge(count: Int, priority: Boolean) {
        badgeCount = max(0, count); badgePriority = priority; syncAnim(); invalidate()
    }

    /** الحالة الأساسية للفقاعة (تتغيّر مع ما هو معلّق). */
    fun setMood(m: BubbleMood) {
        if (m == baseMood) return
        baseMood = m
        invalidate()
    }

    /** نبضة الوصول: قفزة ورجّة وموجات. */
    fun pop() { popStart = System.currentTimeMillis(); invalidate() }

    /** احتفال (حسنة) أو مواساة (زلّة): وميض وقصاصات ثم عودة الحالة الأساسية بعد [CELEBRATE_MS]. */
    fun burst(good: Boolean) {
        burstGood = good
        burstColors = if (good) intArrayOf(Color.parseColor("#FF4ADE80"), Color.parseColor("#FFFDE047"), Color.WHITE, Color.parseColor("#FF5EEAD4"))
        else intArrayOf(Color.parseColor("#FFA5B4FC"), Color.parseColor("#FFCBD5E1"), Color.parseColor("#FF94A3B8"))
        val r = Random(System.nanoTime())
        particles = List(if (good) 24 else 12) {
            P(r.nextFloat() * 2f * PI.toFloat(), 0.55f + r.nextFloat() * 0.45f, dp(2.2f + r.nextFloat() * 2.4f), r.nextInt(burstColors.size), r.nextFloat() * 6f)
        }
        val now = System.currentTimeMillis()
        burstStart = now
        overrideMood = if (good) BubbleMood.CELEBRATE else BubbleMood.COMFORT
        overrideUntil = now + CELEBRATE_MS
        endPosted = false
        invalidate()
    }

    fun setPressedLook(p: Boolean) { pressed = p; invalidate() }

    // ------------------------------------------------------------------ دورة الحياة
    override fun onMeasure(w: Int, h: Int) {
        val s = dp(WINDOW_DP).toInt()
        setMeasuredDimension(s, s)
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); syncAnim() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        syncAnim()
    }

    /** المحرّك يعمل فقط عند الحاجة: ظاهر + مرتبط بالنافذة + (حركة مفعّلة أو نقطة تذكير). */
    private fun syncAnim() {
        val need = isAttachedToWindow && visibility == VISIBLE && (fx || badgeCount > 0)
        if (need) { if (!anim.isStarted) anim.start() } else if (anim.isStarted) anim.cancel()
    }

    // ------------------------------------------------------------------ بناء الـ Shaders (مرة لكل حالة/حجم)
    private fun ensureShaders(mood: BubbleMood) {
        if (shaderMood == mood && shaderSize == width) return
        shaderMood = mood
        shaderSize = width
        val skin = GlassSkin.of(mood, true)
        val r = dp(CIRCLE_DP) / 2f
        val a = skin.accentA
        val b = skin.accentB

        // توهج محيطي (متمركز على 0,0)
        val glowR = r * 1.75f
        glowP.shader = RadialGradient(0f, 0f, glowR, intArrayOf(GlassSkin.withAlpha(a, 170), GlassSkin.withAlpha(a, 60), 0x00000000), floatArrayOf(0.40f, 0.72f, 1f), Shader.TileMode.CLAMP)

        // جسم الكرة: زجاج داكن عميق بانعكاس لوني من أعلى اليسار
        bodyP.shader = RadialGradient(-r * 0.30f, -r * 0.38f, r * 1.45f,
            intArrayOf(0xFF2A4F8F.toInt(), 0xFF12294F.toInt(), 0xFF081327.toInt()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)

        // صبغة لونية أسفل الكرة (تجعل الحالة مقروءة من بعيد)
        tintP.shader = LinearGradient(0f, -r, 0f, r,
            intArrayOf(0x00000000, GlassSkin.withAlpha(a, 38), GlassSkin.withAlpha(b, 96)), floatArrayOf(0.25f, 0.65f, 1f), Shader.TileMode.CLAMP)

        // حافة مضيئة تدور ببطء (SweepGradient يدور بتدوير الـ Canvas وليس بإعادة البناء)
        rimP.shader = SweepGradient(0f, 0f,
            intArrayOf(GlassSkin.withAlpha(a, 240), GlassSkin.withAlpha(0xFFFFFFFF.toInt(), 235), GlassSkin.withAlpha(b, 200), GlassSkin.withAlpha(a, 90), GlassSkin.withAlpha(a, 240)),
            floatArrayOf(0f, 0.22f, 0.5f, 0.78f, 1f))

        // انعكاس ضوئي علوي
        specP.shader = LinearGradient(0f, -r * 0.85f, 0f, -r * 0.20f, intArrayOf(0xB3FFFFFF.toInt(), 0x00FFFFFF), null, Shader.TileMode.CLAMP)
        specRect.set(-r * 0.62f, -r * 0.88f, r * 0.30f, -r * 0.28f)

        clip.reset(); clip.addCircle(0f, 0f, r - dp(1f), Path.Direction.CW)
        raysP.shader = SweepGradient(0f, 0f,
            intArrayOf(0x00FFFFFF, 0x33FFFFFF, 0x00FFFFFF, 0x00FFFFFF, 0x26FFFFFF, 0x00FFFFFF, 0x00FFFFFF, 0x2EFFFFFF, 0x00FFFFFF),
            null)
        shineP.shader = LinearGradient(-dp(15f), 0f, dp(15f), 0f, intArrayOf(0x00FFFFFF, 0x8CFFFFFF.toInt(), 0x00FFFFFF), null, Shader.TileMode.CLAMP)
        buildEmblem(mood, r * 0.50f)

        flashP.shader = RadialGradient(0f, 0f, r * 2.2f, intArrayOf(0xCCFFFFFF.toInt(), GlassSkin.withAlpha(b, 90), 0x00000000), floatArrayOf(0f, 0.35f, 1f), Shader.TileMode.CLAMP)
    }

    private fun starInto(p: Path, cx: Float, cy: Float, r: Float, innerK: Float = 0.38f, points: Int = 8) {
        val n = points * 2
        for (i in 0 until n) {
            val a = (PI / points * i - PI / 2).toFloat()
            val rr = if (i % 2 == 0) r else r * innerK
            val x = cx + cos(a) * rr
            val y = cy + sin(a) * rr
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
    }

    private fun sparkleInto(p: Path, cx: Float, cy: Float, r: Float) {
        p.moveTo(cx, cy - r)
        p.quadTo(cx, cy, cx + r, cy)
        p.quadTo(cx, cy, cx, cy + r)
        p.quadTo(cx, cy, cx - r, cy)
        p.quadTo(cx, cy, cx, cy - r)
        p.close()
    }

    /** الرمز المرسوم في قلب الكرة: يتغيّر مع الحالة (هلال، نجمة، لمعة، جرس، علامة صح، قلب). يُبنى مرة واحدة لكل حالة. */
    private fun buildEmblem(mood: BubbleMood, er: Float) {
        emblemPath.reset(); emblemCut.reset(); emblemExtra.reset()
        emblemStroke = false
        emblemSpins = false
        when (mood) {
            BubbleMood.NORMAL, BubbleMood.DHIKR -> {
                emblemPath.addCircle(-er * 0.10f, 0f, er, Path.Direction.CW)
                emblemCut.addCircle(er * 0.42f, -er * 0.14f, er * 0.82f, Path.Direction.CW)
                emblemPath.op(emblemCut, Path.Op.DIFFERENCE)
                starInto(emblemExtra, er * 0.50f, -er * 0.36f, er * 0.30f)
            }
            BubbleMood.PRAYER -> {
                emblemSpins = true
                starInto(emblemPath, 0f, 0f, er * 1.08f, 0.62f, 8)
                emblemExtra.addCircle(0f, 0f, er * 0.22f, Path.Direction.CW)
            }
            BubbleMood.NEW -> {
                emblemSpins = true
                sparkleInto(emblemPath, -er * 0.10f, er * 0.08f, er * 1.0f)
                sparkleInto(emblemExtra, er * 0.66f, -er * 0.62f, er * 0.38f)
            }
            BubbleMood.URGENT -> {
                emblemPath.moveTo(-er * 0.82f, er * 0.52f)
                emblemPath.cubicTo(-er * 0.55f, er * 0.36f, -er * 0.62f, -er * 0.10f, -er * 0.46f, -er * 0.46f)
                emblemPath.cubicTo(-er * 0.30f, -er * 0.84f, er * 0.30f, -er * 0.84f, er * 0.46f, -er * 0.46f)
                emblemPath.cubicTo(er * 0.62f, -er * 0.10f, er * 0.55f, er * 0.36f, er * 0.82f, er * 0.52f)
                emblemPath.close()
                emblemExtra.addCircle(0f, er * 0.80f, er * 0.20f, Path.Direction.CW)
                emblemExtra.addCircle(0f, -er * 0.90f, er * 0.12f, Path.Direction.CW)
            }
            BubbleMood.CELEBRATE -> {
                emblemStroke = true
                emblemPath.moveTo(-er * 0.68f, er * 0.04f)
                emblemPath.lineTo(-er * 0.18f, er * 0.54f)
                emblemPath.lineTo(er * 0.74f, -er * 0.48f)
                sparkleInto(emblemExtra, -er * 0.58f, -er * 0.56f, er * 0.30f)
                sparkleInto(emblemExtra, er * 0.62f, er * 0.62f, er * 0.22f)
            }
            BubbleMood.COMFORT -> {
                emblemPath.moveTo(0f, er * 0.88f)
                emblemPath.cubicTo(-er * 1.40f, -er * 0.05f, -er * 0.78f, -er * 1.08f, 0f, -er * 0.40f)
                emblemPath.cubicTo(er * 0.78f, -er * 1.08f, er * 1.40f, -er * 0.05f, 0f, er * 0.88f)
                emblemPath.close()
            }
        }
        val skin = GlassSkin.of(mood, true)
        emblemFill.shader = LinearGradient(0f, -er, 0f, er, intArrayOf(0xFFFFFFFF.toInt(), skin.accentB, skin.accentA), floatArrayOf(0f, 0.38f, 1f), Shader.TileMode.CLAMP)
        emblemFill.style = if (emblemStroke) Paint.Style.STROKE else Paint.Style.FILL
        emblemFill.strokeWidth = er * 0.34f
        emblemFill.strokeCap = Paint.Cap.ROUND
        emblemFill.strokeJoin = Paint.Join.ROUND
        emblemGlow.color = GlassSkin.withAlpha(skin.accentA, 110)
        emblemGlow.strokeWidth = if (emblemStroke) er * 0.62f else dp(5f)
    }

    // ------------------------------------------------------------------ الرسم
    override fun onDraw(c: Canvas) {
        val now = System.currentTimeMillis()
        if (overrideMood != null && now > overrideUntil) overrideMood = null
        val mood = overrideMood ?: baseMood
        ensureShaders(mood)
        val skin = GlassSkin.of(mood, true)

        val w = width.toFloat()
        val cx = w / 2f
        val baseR = dp(CIRCLE_DP) / 2f
        val phase = (t * 2f * PI).toFloat()
        val bob = if (fx) sin(phase * 1.5f) * dp(2.5f) else 0f
        val cy = w / 2f + bob

        // قفزة الوصول: تكبير مرتد خلال ٦٠٠ مللي ورجّة جانبية
        var scale = (if (pressed) 0.92f else 1f) * (if (fx) 1f + 0.018f * sin(phase * 2f) else 1f)
        var wiggle = 0f
        if (popStart > 0) {
            val k = (now - popStart) / 600f
            if (k in 0f..1f) {
                scale *= 1f + 0.28f * sin(k * PI.toFloat()) * (1f - k)
                wiggle = sin(k * 4f * PI.toFloat()) * (1f - k) * 10f
                invalidate()
            } else popStart = -1
        }
        val alerting = badgeCount > 0
        val speed = if (badgePriority) 2f else 1f
        val pulse = 0.5f + 0.5f * sin(phase * 2f * speed)

        c.save()
        c.translate(cx, cy)
        c.rotate(wiggle)
        c.scale(scale, scale)

        // توهج محيطي نابض (يكبر ويقوى مع وجود تذكير)
        val gs = 1f + (if (alerting) 0.16f else 0.08f) * pulse
        c.save(); c.scale(gs, gs)
        glowP.alpha = if (alerting) 255 else 170
        c.drawCircle(0f, 0f, baseR * 1.75f, glowP)
        c.restore()

        // نبضة التذكير: موجتان تتسعان وتخفتان (لا ترسمان إلا مع وجود تذكير أو في الاحتفال)
        if ((alerting && fx) || burstStart > 0) {
            for (i in 0 until 2) {
                val k = ((t * 2f * speed + i * 0.5f) % 1f)
                waveP.color = GlassSkin.withAlpha(skin.accentA, ((1f - k) * 170).toInt())
                c.drawCircle(0f, 0f, baseR * (1.02f + 0.62f * k), waveP)
            }
        }

        // جسم الكرة الزجاجية
        c.drawCircle(0f, 0f, baseR, bodyP)

        // أشعة ضوء ناعمة تدور ببطء داخل الزجاج
        if (fx) {
            c.save(); c.rotate(-t * 180f)
            c.drawCircle(0f, 0f, baseR - dp(1f), raysP)
            c.restore()
        }

        // الرمز المضيء في القلب (يتنفّس، والنجمة/اللمعة تدور ببطء)
        val er = baseR * 0.50f
        c.save()
        val es = 1f + 0.05f * pulse
        c.scale(es, es)
        if (emblemSpins && fx) c.rotate(t * 60f) else if (fx) c.rotate(sin(phase) * 4f)
        c.drawPath(emblemPath, emblemGlow)
        c.drawPath(emblemPath, emblemFill)
        emblemFill.style = Paint.Style.FILL
        c.drawPath(emblemExtra, emblemFill)
        emblemFill.style = if (emblemStroke) Paint.Style.STROKE else Paint.Style.FILL
        c.restore()
        c.drawCircle(0f, 0f, baseR, tintP)

        // لمعة زجاجية تعبر الكرة كل بضع ثوانٍ
        if (fx && t < 0.30f) {
            c.save(); c.clipPath(clip)
            c.translate(-baseR * 2f + baseR * 4f * (t / 0.30f), 0f)
            c.rotate(20f)
            c.drawRect(-dp(15f), -baseR * 1.8f, dp(15f), baseR * 1.8f, shineP)
            c.restore()
        }

        // انعكاس ضوئي علوي
        c.save(); c.rotate(-18f)
        c.drawOval(specRect, specP)
        c.restore()

        // حافة زجاجية تدور ببطء
        c.save(); c.rotate(if (fx) t * 360f else 0f)
        c.drawCircle(0f, 0f, baseR - dp(0.6f), rimP)
        c.restore()

        // نجوم صغيرة تدور حول الكرة (بلون الحالة)
        if (fx) {
            fill.color = GlassSkin.withAlpha(skin.accentB, 235)
            for (i in 0 until 3) {
                val a = phase + i * (2f * PI.toFloat() / 3f)
                val orbit = baseR + dp(7f) + dp(1.5f) * sin(phase * 2f + i)
                val sr = dp(2.4f + 0.9f * sin(phase * 3f + i * 2f))
                star.reset(); starInto(star, cos(a) * orbit, sin(a) * orbit, sr)
                c.drawPath(star, fill)
            }
        }
        c.restore()

        // النقطة (لا تدور مع الكرة حتى يبقى مكانها ثابتًا)
        if (alerting) {
            val bx = cx + baseR * 0.74f * scale
            val by = cy - baseR * 0.74f * scale
            val br = dp(if (badgePriority) 10f else 8.5f) * (1f + 0.10f * pulse)
            fill.color = GlassSkin.withAlpha(0xFFFFFFFF.toInt(), 245)
            c.drawCircle(bx, by, br + dp(1.6f), fill)
            fill.color = if (badgePriority) 0xFFE11D48.toInt() else 0xFFEF4444.toInt()
            c.drawCircle(bx, by, br, fill)
            val label = when { badgePriority -> "!"; badgeCount > 1 -> min(badgeCount, 9).toString(); else -> "" }
            if (label.isNotEmpty()) {
                txt.textSize = dp(11f)
                c.drawText(label, bx, by - (txt.descent() + txt.ascent()) / 2f, txt)
            }
        }

        // وميض الاحتفال + القصاصات
        if (burstStart > 0) {
            val k = (now - burstStart) / 1100f
            if (k in 0f..1f) {
                if (burstGood && k < 0.45f) {
                    c.save(); c.translate(cx, cy)
                    flashP.alpha = ((1f - k / 0.45f) * 255).toInt()
                    c.drawCircle(0f, 0f, baseR * 2.2f, flashP)
                    c.restore()
                }
                val maxR = dp(PAD_DP + CIRCLE_DP / 2f - 3f)
                for (p in particles) {
                    val rr = baseR * 0.6f + (maxR - baseR * 0.6f) * (1f - (1f - k) * (1f - k)) * p.speed
                    val px = cx + cos(p.ang) * rr
                    val py = cy + sin(p.ang) * rr + dp(6f) * k * k
                    fill.color = GlassSkin.withAlpha(burstColors[p.colorIdx], ((1f - k) * 255).toInt())
                    if (p.colorIdx % 2 == 0) c.drawCircle(px, py, p.size, fill)
                    else {
                        c.save(); c.rotate(p.spin * k * 120f, px, py)
                        c.drawRect(px - p.size, py - p.size * 0.6f, px + p.size, py + p.size * 0.6f, fill)
                        c.restore()
                    }
                }
                invalidate()
            } else { burstStart = -1; particles = emptyList() }
        }
        // عودة الحالة الأساسية بعد انتهاء الاحتفال حتى لو توقف المحرّك
        if (overrideMood != null && !endPosted) { endPosted = true; postInvalidateDelayed(max(16L, overrideUntil - now + 16L)) }
    }
}
