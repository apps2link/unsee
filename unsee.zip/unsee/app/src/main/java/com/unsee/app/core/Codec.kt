package com.unsee.app.core

enum class ReminderKind { MORNING, EVENING, CUSTOM }

/** days: قناع بتات؛ البت (DayOfWeek.value - 1) يمثل اليوم (الإثنين=0 … الأحد=6). */
data class Reminder(
    val id: String,
    val kind: ReminderKind,
    val label: String,
    val minute: Int,
    val days: Int = ALL_DAYS,
    val enabled: Boolean = false,
    val category: String = "",
) {
    companion object { const val ALL_DAYS = 127 }
    fun runsOn(dayValue: Int): Boolean = ((days shr (dayValue - 1)) and 1) == 1
}

data class TasbihSession(
    val id: String,
    val text: String,
    val target: Int,
    val count: Int = 0,
    val total: Int = 0,
    val updated: Long = 0L,
    val rounds: Int = 0,
)

object Codec {
    private fun clean(s: String) = s.replace('|', '¦').replace('\n', ' ').trim()

    fun encodeReminders(list: List<Reminder>): String = list.joinToString("\n") {
        listOf(it.id, it.kind.name, clean(it.label), it.minute, it.days, if (it.enabled) 1 else 0, it.category).joinToString("|")
    }

    fun decodeReminders(s: String): List<Reminder> = s.split('\n').mapNotNull { line ->
        val p = line.split('|')
        if (p.size < 7) return@mapNotNull null
        val kind = runCatching { ReminderKind.valueOf(p[1]) }.getOrNull() ?: return@mapNotNull null
        Reminder(
            id = p[0], kind = kind, label = p[2],
            minute = (p[3].toIntOrNull() ?: return@mapNotNull null).coerceIn(0, 1439),
            days = (p[4].toIntOrNull() ?: Reminder.ALL_DAYS).coerceIn(0, 127),
            enabled = p[5] == "1", category = p[6],
        )
    }

    fun encodeSessions(list: List<TasbihSession>): String = list.joinToString("\n") {
        listOf(it.id, clean(it.text), it.target, it.count, it.total, it.updated, it.rounds).joinToString("|")
    }

    fun decodeSessions(s: String): List<TasbihSession> = s.split('\n').mapNotNull { line ->
        val p = line.split('|')
        if (p.size < 7) return@mapNotNull null
        TasbihSession(
            id = p[0], text = p[1],
            target = (p[2].toIntOrNull() ?: return@mapNotNull null).coerceAtLeast(1),
            count = p[3].toIntOrNull() ?: 0, total = p[4].toIntOrNull() ?: 0,
            updated = p[5].toLongOrNull() ?: 0L, rounds = p[6].toIntOrNull() ?: 0,
        )
    }
}
