package com.unsee.app.core

/** اللهجة التي يكلّمك بها الرفيق. المصرية افتراضيًا، والخليجية لمن بلده خليجي. */
enum class Dialect { EGYPT, GULF }

/** اختيار المستخدم: تلقائي (حسب دولة الجهاز) أو يدوي. */
enum class DialectPref(val label: String) {
    AUTO("تلقائي حسب بلدك"),
    EGYPT("مصري"),
    GULF("خليجي"),
}

object DialectResolve {
    private val GULF_COUNTRIES = setOf("SA", "AE", "KW", "QA", "BH", "OM")

    fun fromCountry(countryCode: String?): Dialect =
        if ((countryCode ?: "").uppercase() in GULF_COUNTRIES) Dialect.GULF else Dialect.EGYPT

    fun resolve(pref: DialectPref, countryCode: String?): Dialect = when (pref) {
        DialectPref.EGYPT -> Dialect.EGYPT
        DialectPref.GULF -> Dialect.GULF
        DialectPref.AUTO -> fromCountry(countryCode)
    }
}

/**
 * كل كلام الرفيق بالعامية. دالة [t] تختار بين النص المصري والخليجي، والقوائم تُختار بـ seed حتمي
 * (فيُمكن اختبارها ولا تتكرر الجملة نفسها دائمًا).
 */
class Voice(val dialect: Dialect) {
    val gulf: Boolean get() = dialect == Dialect.GULF

    fun t(eg: String, gulfText: String): String = if (gulf) gulfText else eg

    private fun pick(eg: List<String>, gu: List<String>, seed: Int): String {
        val l = if (gulf) gu else eg
        return l[Math.floorMod(seed, l.size)]
    }

    // ------------------------------------------------------------ تحية
    fun greeting(hour: Int): String = when (hour) {
        in 4..11 -> t("صباح النور", "صباح الخير")
        in 12..15 -> t("نهارك مبارك", "يا هلا والله")
        in 16..18 -> t("مساء النور", "مساء الخير")
        else -> t("ليلة هادئة", "ليلة سعيدة")
    }

    // ------------------------------------------------------------ تشجيع عند فعل الخير
    val cheersEg = listOf(
        "كمّل يا بطل!",
        "عاوزين ندخل الجنة، يلا ورينا همتك!",
        "ما شاء الله عليك، حسنة جديدة!",
        "ربنا يتقبل منك يا صاحبي",
        "شغل عالي! كمّل كده",
        "حسنة تجر حسنة، كمّل",
        "إنت ماشي صح يا وحش، كمّل",
        "الله ينوّر عليك!",
        "يا سلام! اليوم ده هيبقى يوم عظيم",
        "متقفش، الجنة محتاجة همّة",
    )
    val cheersGulf = listOf(
        "كمّل يا بطل!",
        "نبي الجنة، يلا وريني همّتك!",
        "ما شاء الله عليك، حسنة جديدة!",
        "الله يتقبل منك يا خوي",
        "أبشر بالخير، كمّل!",
        "حسنة تجر حسنة، لا تبطّي",
        "ماشي زين! كمّل على هالطريق",
        "الله يزيدك من فضله، كمّل",
        "عاش من يعرفك! كمّل",
        "الله يبارك فيك",
    )

    fun cheer(seed: Int): String = pick(cheersEg, cheersGulf, seed)

    /** رسالة خاصة عند بلوغ نقطة مهمة (كل ٥ حسنات). */
    fun milestone(points: Int): String = t(
        "${Arabic.digits(points)} حسنات النهارده! ما شاء الله، إنت بتبني بيتك في الجنة حتة حتة 🌟",
        "${Arabic.digits(points)} حسنات اليوم! ما شاء الله، تبني بيتك في الجنة خطوة خطوة 🌟",
    )

    // ------------------------------------------------------------ مواساة عند تسجيل ذنب
    val comfortEg = listOf(
        "ولا يهمك يا صاحبي، كلنا بنغلط. المهم متيأسش.",
        "توب لربنا، هو بيفرح بتوبتك أكتر منك.",
        "الباب لسه مفتوح، ارجع لربنا دلوقتي.",
        "ربنا غفور رحيم، متقنطش من رحمته أبدًا.",
        "اللي حصل حصل. استغفر وكمّل بقلب جديد.",
    )
    val comfortGulf = listOf(
        "عادي يا خوي، كلنا نغلط. بس لا تيأس.",
        "توب لربك، هو يفرح بتوبتك.",
        "الباب مفتوح، ارجع لربك الحين.",
        "ربك غفور رحيم، لا تقنط من رحمته أبدًا.",
        "اللي صار صار. استغفر وكمّل بقلب جديد.",
    )

    fun comfort(seed: Int): String = pick(comfortEg, comfortGulf, seed)

    fun planOffer(sin: String): String = t(
        "طب تعالى نشوف هتقلع عن «$sin» إزاي؟ حط خطة وأنا هساعدك وهفكّرك بيها.",
        "تعال نشوف كيف نترك «$sin»؟ سوّ خطة وأنا أساعدك وأذكّرك فيها.",
    )

    // ------------------------------------------------------------ الأساسيات
    fun essentialQuestion(e: Essential): String = when (e) {
        Essential.FAJR, Essential.DHUHR, Essential.ASR, Essential.MAGHRIB, Essential.ISHA ->
            t("صليت ${e.prayer!!.label}؟", "صليت ${e.prayer!!.label}؟")
        Essential.ADHKAR_AM -> t("قريت أذكار الصباح؟", "قريت أذكار الصباح؟")
        Essential.ADHKAR_PM -> t("قريت أذكار المساء؟", "قريت أذكار المساء؟")
        Essential.QURAN -> t("قريت وردك من القرآن؟", "قريت وردك من القرآن؟")
    }

    fun essentialTitle(e: Essential): String = when (e) {
        Essential.FAJR, Essential.DHUHR, Essential.ASR, Essential.MAGHRIB, Essential.ISHA -> "صلّيت ${e.prayer!!.label}"
        Essential.ADHKAR_AM -> "قرأت أذكار الصباح"
        Essential.ADHKAR_PM -> "قرأت أذكار المساء"
        Essential.QURAN -> "قرأت وردي من القرآن"
    }

    val yesLabel: String get() = t("أيوه الحمد لله", "إي الحمد لله")
    val notYetLabel: String get() = t("لسه", "للحين")

    fun notYetNudge(e: Essential): String = when (e) {
        Essential.QURAN -> t("لسه الوقت قدامك. افتح المصحف ولو صفحة.", "للحين في وقت. افتح المصحف ولو صفحة.")
        Essential.ADHKAR_AM, Essential.ADHKAR_PM -> t("خمس دقايق بس وتخلصها. يلا!", "خمس دقايق بس وتخلصها. يلا!")
        else -> t("قوم صلّيها دلوقتي لو الوقت لسه موجود. ربنا يعينك.", "قم صلّها الحين لو الوقت باقي. الله يعينك.")
    }

    // ------------------------------------------------------------ تذكير العادات الحلوة
    fun habitReminder(title: String): String = t(
        "إمبارح عملت «$title» وكان شكلك حلو قوي. متبطلهاش! يلا اعملها تاني النهارده 💪",
        "أمس سوّيت «$title» وكانت حلوة منك. لا توقف عنها! يلا سوّها اليوم 💪",
    )
    val habitTitle: String get() = t("متبطلهاش يا بطل", "لا توقف يا بطل")
    val habitDone: String get() = t("عملتها", "سوّيتها")
    val habitLater: String get() = t("ذكّرني لاحقًا", "ذكّرني بعدين")

    // ------------------------------------------------------------ خطط الإقلاع
    fun planTitle(): String = t("خطتك للإقلاع", "خطتك للترك")
    fun planReminder(sin: String, replacement: String): String {
        val base = t(
            "خطتك إنك تبطّل «$sin». لسه ماشي عليها النهارده؟ كمّل يا بطل، أنا معاك.",
            "خطتك إنك تترك «$sin». للحين ماشي عليها اليوم؟ كمّل يا بطل، أنا معاك.",
        )
        return if (replacement.isBlank()) base else base + "\n" + t("لو جاتلك الرغبة: $replacement", "لو جتك الرغبة: $replacement")
    }
    val planKept: String get() = t("التزمت النهارده", "التزمت اليوم")
    val planSlip: String get() = t("وقعت تاني", "طحت مرة ثانية")
    fun planKeptReply(days: Int): String = t(
        "ما شاء الله! ${Arabic.digits(days)} يوم على الطريق الصح. ربنا يثبّتك 🌿",
        "ما شاء الله! ${Arabic.digits(days)} يوم على الطريق الصح. الله يثبّتك 🌿",
    )
    val planSlipReply: String
        get() = t(
            "ولا يهمك، متيأسش. استغفر وقوم تاني، يوم جديد بيبدأ دلوقتي.",
            "لا تيأس. استغفر وقم من جديد، يوم جديد يبدأ الحين.",
        )

    // ------------------------------------------------------------ نصوص الفقاعة
    val bubbleTitle: String get() = t("رفيق أُنسي", "رفيق أُنسي")
    val bubbleDone: String get() = t("تم الذكر", "تم الذكر")
    val bubbleLater: String get() = t("ذكّرني لاحقًا", "ذكّرني بعدين")
    val bubbleOpen: String get() = t("فتح أُنسي", "افتح أُنسي")
    val bubbleAnother: String get() = t("رسالة تانية", "رسالة ثانية")
    val bubblePriority: String get() = t("أولوية", "أولوية")
    val bubbleThanks: String get() = t("تقبّل الله! +١ حسنة ✨", "تقبّل الله! +١ حسنة ✨")
    val bubbleOffToast: String get() = t("اتقفلت الفقاعة. تقدر تفتحها من رفيق أُنسي.", "انقفلت الفقاعة. تقدر تفتحها من رفيق أُنسي.")
    val bubbleHint: String get() = t("اضغط عليّ وهقولك حاجة حلوة", "اضغط عليّ وأقولك شي حلو")

    // ------------------------------------------------------------ تذكير الصلاة
    fun prayerBefore(label: String, minutes: Int): String = t(
        "يا صاحبي، فاضل ${Arabic.digits(minutes)} دقيقة على صلاة $label. جهّز نفسك.",
        "يا خوي، باقي ${Arabic.digits(minutes)} دقيقة على صلاة $label. جهّز نفسك.",
    )
    fun prayerFajr(): String = t("يا صاحبي، دخل وقت الفجر. قوم صلّي ونوّر يومك.", "يا خوي، دخل وقت الفجر. قم صلّ ونوّر يومك.")
    fun prayerAdhan(label: String): String = t(
        "يا صاحبي، دخل وقت صلاة $label. يلا نصلي ونرجع نكمل يومنا.",
        "يا خوي، دخل وقت صلاة $label. يلا نصلي ونرجع نكمل يومنا.",
    )
    fun prayerAfter(label: String, minutes: Int): String = t(
        "عدّى ${Arabic.digits(minutes)} دقيقة على دخول وقت $label. لو صليت سجّلها، ولو لسه يلا نلحقها.",
        "مرّ ${Arabic.digits(minutes)} دقيقة على دخول وقت $label. لو صليت سجّلها، ولو للحين يلا نلحقها.",
    )
    fun prayerSnoozed(label: String): String = t(
        "يا صاحبي، فكّرتك تاني بصلاة $label. صليت ولا لسه؟",
        "يا خوي، ذكّرتك مرة ثانية بصلاة $label. صليت ولا للحين؟",
    )
    val prayedLabel: String get() = t("صليت الحمد لله", "صليت الحمد لله")
    val prayerLater: String get() = t("فكّرني لاحقًا", "ذكّرني بعدين")
    val prayerOpen: String get() = t("افتح مواقيت الصلاة", "افتح مواقيت الصلاة")
}
