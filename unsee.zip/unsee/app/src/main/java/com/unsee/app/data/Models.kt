package com.unsee.app.data

enum class Category(val title: String, val emoji: String, val blurb: String) {
    MORNING("أذكار الصباح", "🌅", "من الفجر إلى الضحى"),
    EVENING("أذكار المساء", "🌙", "من العصر إلى الليل"),
    AFTER_PRAYER("أذكار بعد الصلاة", "🕌", "بعد السلام من الفريضة"),
    SLEEP_WAKE("النوم والاستيقاظ", "🛏", "عند المنام وعند القيام"),
    MISC("أذكار متنوعة", "📿", "استغفار وتسبيح وصلاة على النبي ﷺ"),
}

/**
 * count = 0 يعني: لا عدد محدد ثابتًا في النص المعتمد (ذكر مفتوح)، فلا نفرض عددًا غير موثّق.
 * grade: درجة الحديث تُكتب فقط حيث تم التثبت منها (قرآن / متفق عليه)، وإلا تبقى null.
 */
data class Zikr(
    val id: String,
    val category: Category,
    val title: String,
    val text: String,
    val count: Int,
    val source: String,
    val grade: String? = null,
    val note: String? = null,
) {
    val isShort: Boolean get() = text.length <= 140
}
