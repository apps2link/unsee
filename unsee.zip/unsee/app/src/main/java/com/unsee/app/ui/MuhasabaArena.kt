package com.unsee.app.ui

import android.view.HapticFeedbackConstants
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.unsee.app.core.Arabic
import com.unsee.app.core.Essential
import com.unsee.app.core.LedgerEntry
import com.unsee.app.core.LedgerLogic
import com.unsee.app.core.LedgerType
import com.unsee.app.core.LogKind
import com.unsee.app.core.PlanLogic
import com.unsee.app.core.PrayerLog
import com.unsee.app.core.QuitPlan
import com.unsee.app.core.TimeLogic
import com.unsee.app.core.Voice
import com.unsee.app.data.Category
import com.unsee.app.data.CompanionStore
import com.unsee.app.data.Store
import com.unsee.app.notify.CompanionScheduler
import com.unsee.app.notify.Sfx
import com.unsee.app.overlay.BubbleController
import java.time.LocalDate

private val GREEN: Color get() = goodArenaColor()
private val RED: Color get() = badArenaColor()

/**
 * محاسبة النفس التفاعلية: شاشة عرض عملاقة بالنتيجة، وتحتها قسمان متجاوران (حسنات يمينًا/سيئات يسارًا).
 * كل تسجيل يُحسب نقطة فورية على الشاشة مع قصاصات (حسنة) أو مواساة ومطر وحزن لطيف (سيئة).
 * الذنب يقترح خطة إقلاع بتذكير أولوية في الفقاعة. والأعمال الحلوة تُذكَّر بها إن لم تكررها.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MuhasabaScreen(nav: NavController) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val v = LocalVoice.current
    val cs = remember { CompanionStore.get(ctx) }
    val store = remember { Store.get(ctx) }
    val today = remember { LocalDate.now() }
    val todayStr = today.toString()
    val entries by cs.observeAsState { cs.ledger(todayStr) }
    val answers by cs.observeAsState { cs.essentialAnswers(todayStr) }
    val range by cs.observeAsState { cs.ledgerRange(45) }
    val plans by cs.observeAsState { cs.plans() }
    val score = LedgerLogic.score(entries)

    var event by remember { mutableStateOf<ArenaEvent?>(null) }
    var counter by remember { mutableIntStateOf(0) }
    var ticker by remember { mutableStateOf("") }
    var sheet by remember { mutableStateOf<LedgerType?>(null) }
    var offerSin by remember { mutableStateOf<String?>(null) }
    var planDraft by remember { mutableStateOf<String?>(null) }
    var endPlan by remember { mutableStateOf<QuitPlan?>(null) }

    val idle = v.t("سجّل حسناتك وسيئاتك بصراحة، وأنا معاك يا صاحبي", "سجّل حسناتك وسيئاتك بصراحة، وأنا معك يا خوي")

    fun fire(good: Boolean, countAfter: Int) {
        val milestone = good && countAfter > 0 && countAfter % 5 == 0
        counter++
        val msg = if (good) (if (milestone) v.milestone(countAfter) else v.cheer(counter + countAfter)) else v.comfort(counter + countAfter)
        event = ArenaEvent(counter, good, milestone, msg)
        ticker = msg
        runCatching { com.unsee.app.voice.VoiceHooks.encourage(ctx, good) }
        view.performHapticFeedback(if (good) HapticFeedbackConstants.KEYBOARD_TAP else HapticFeedbackConstants.LONG_PRESS)
    }

    fun logGood(title: String, key: String = "") {
        if (cs.addLedger(LedgerType.GOOD, title, key) != null) fire(true, score.good + 1)
    }

    fun logSin(title: String) {
        if (cs.addLedger(LedgerType.SIN, title) != null) {
            fire(false, score.sin + 1)
            offerSin = LedgerLogic.norm(title)
        }
    }

    fun removeEntry(e: LedgerEntry) {
        cs.removeLedger(todayStr, e.id)
        if (e.key.startsWith("ess:")) {
            val ess = Essential.fromKey(e.key.removePrefix("ess:"))
            if (ess != null) {
                cs.setEssentialAnswer(todayStr, ess.key, null)
                ess.prayer?.let { cs.setPrayerStatus(today, it, PrayerLog.NONE) }
            }
        }
    }

    fun essentialYes(e: Essential) {
        if (answers[e.key] == 1) {
            cs.removeLedgerKey(todayStr, e.ledgerKey)
            cs.setEssentialAnswer(todayStr, e.key, null)
            e.prayer?.let { cs.setPrayerStatus(today, it, PrayerLog.NONE) }
            return
        }
        cs.setEssentialAnswer(todayStr, e.key, 1)
        e.prayer?.let { cs.setPrayerStatus(today, it, PrayerLog.PRAYED) }
        logGood(v.essentialTitle(e), e.ledgerKey)
    }

    fun essentialNo(e: Essential) {
        if (answers[e.key] == 1) {
            cs.removeLedgerKey(todayStr, e.ledgerKey)
            e.prayer?.let { cs.setPrayerStatus(today, it, PrayerLog.NONE) }
        }
        cs.setEssentialAnswer(todayStr, e.key, 0)
        ticker = v.notYetNudge(e)
    }

    fun go(e: Essential) {
        when (e) {
            Essential.ADHKAR_AM -> nav.navigate("list/${Category.MORNING.name}")
            Essential.ADHKAR_PM -> nav.navigate("list/${Category.EVENING.name}")
            Essential.QURAN -> Toast.makeText(ctx, v.t("افتح مصحفك واقرأ ولو صفحة 🤍", "افتح مصحفك واقرأ ولو صفحة 🤍"), Toast.LENGTH_SHORT).show()
            else -> nav.navigate("prayer")
        }
    }

    fun refreshBubble() = BubbleController.sync(ctx)

    // ما سجّله المستخدم فعلًا في أُنسي (صلوات/أذكار) يُحسب تلقائيًا دون احتفال، كي لا يضطر لتسجيله مرتين
    LaunchedEffect(todayStr) {
        val prog = store.todayProgress()
        for (e in Essential.values()) {
            if (cs.essentialAnswers(todayStr)[e.key] != null) continue
            val done = when {
                e.prayer != null -> cs.prayerStatus(today, e.prayer) == PrayerLog.PRAYED
                e == Essential.ADHKAR_AM -> categoryProgress(Category.MORNING, prog).let { it.second > 0 && it.first == it.second }
                e == Essential.ADHKAR_PM -> categoryProgress(Category.EVENING, prog).let { it.second > 0 && it.first == it.second }
                else -> false
            }
            if (done) {
                cs.setEssentialAnswer(todayStr, e.key, 1)
                cs.addLedger(LedgerType.GOOD, v.essentialTitle(e), key = e.ledgerKey)
            }
        }
    }

    BackHandler(enabled = sheet != null || planDraft != null) {
        if (planDraft != null) planDraft = null else sheet = null
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            ScreenHeader(v.t("محاسبة النفس", "محاسبة النفس"), { nav.popBackStack() }) {
                IconBtn(Ico.Edit, v.t("المراجعة المكتوبة", "المراجعة المكتوبة"), { nav.navigate("muhasaba_notes") }, UColors.CreamDim)
            }
            ScoreBoard(score.good, score.sin, ticker.ifEmpty { idle })
            Spacer(Modifier.height(10.dp))

            // قسمان متجاوران: يسار = سيئات، يمين = حسنات (LTR مقصود)
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(Modifier.fillMaxWidth().height(104.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    HalfButton(Modifier.weight(1f), v.t("السيئات", "السيئات"), v.t("اضغط وسجّل غلطاتك", "اضغط وسجّل غلطاتك"), false, score.sin) { sheet = LedgerType.SIN }
                    HalfButton(Modifier.weight(1f), v.t("الحسنات", "الحسنات"), v.t("اضغط وسجّل أعمالك الصالحة", "اضغط وسجّل أعمالك الصالحة"), true, score.good) { sheet = LedgerType.GOOD }
                }
            }

            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(top = 6.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // ---- الأساسيات
                SectionLabel(v.t("الأساسيات اللي مش بنفرّط فيها", "الأساسيات اللي ما نفرّط فيها"))
                GlassCard(Modifier.fillMaxWidth()) {
                    Text(
                        v.t("جاوب بصراحة. «لسه» مش ذنب، دي بس فرصة تلحقها.", "جاوب بصراحة. «للحين» مو ذنب، هذي بس فرصة تلحقها."),
                        color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp),
                    )
                    Essential.values().forEach { e ->
                        val a = answers[e.key]
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(v.essentialQuestion(e), color = UColors.Cream, fontSize = 14.sp, modifier = Modifier.weight(1f))
                            Pill(v.t("آه", "إي"), a == 1, GREEN) { essentialYes(e) }
                            Spacer(Modifier.width(6.dp))
                            Pill(v.notYetLabel, a == 0, Color(0xFFF59E0B)) { essentialNo(e) }
                        }
                        if (a == 0) {
                            Row(Modifier.fillMaxWidth().padding(bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(v.notYetNudge(e), color = Color(0xFFF59E0B), fontSize = 12.sp, modifier = Modifier.weight(1f))
                                if (e != Essential.QURAN) PillButton(v.t("يلا", "يلا"), { go(e) }, filled = false)
                            }
                        }
                    }
                }

                // ---- عاداتك الحلوة
                val chips = LedgerLogic.habitChips(range, today)
                if (chips.isNotEmpty()) {
                    SectionLabel(v.t("حاجاتك الحلوة", "أعمالك الحلوة"))
                    GlassCard(Modifier.fillMaxWidth()) {
                        Text(
                            v.t("اضغط على أي عمل تعمله تاني النهارده. لو بطّلته هفكّرك بيه.", "اضغط على أي عمل تسويه اليوم. لو وقفت عنه بذكّرك فيه."),
                            color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp),
                        )
                        val doneToday = entries.filter { it.type == LedgerType.GOOD }.map { LedgerLogic.norm(it.title) }.toSet()
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            chips.forEach { (title, streak) ->
                                val done = title in doneToday
                                Pill(
                                    (if (streak > 0) "🔥${Arabic.digits(streak)} " else "") + title + if (done) " ✓" else "",
                                    done, if (done) GREEN else Color(0xFFF59E0B),
                                ) { if (!done) logGood(title) else Toast.makeText(ctx, v.t("اتسجلت النهارده ✓", "انسجلت اليوم ✓"), Toast.LENGTH_SHORT).show() }
                            }
                        }
                    }
                }

                // ---- خطط الإقلاع
                SectionLabel(v.t("خطط الإقلاع", "خطط الترك"))
                if (plans.isEmpty()) {
                    GlassCard(Modifier.fillMaxWidth()) {
                        Text(
                            v.t("لما تسجّل ذنب هعرض عليك تعمل خطة تبطّله. وتقدر تعمل واحدة دلوقتي.", "لما تسجّل ذنب بعرض عليك تسوي خطة تتركه. وتقدر تسوي وحدة الحين."),
                            color = UColors.CreamDim, fontSize = 13.sp,
                        )
                        PillButton(v.t("خطة جديدة", "خطة جديدة"), { planDraft = "" }, Modifier.padding(top = 8.dp), icon = Ico.Add, filled = false)
                    }
                } else {
                    plans.forEach { p ->
                        val clean = PlanLogic.cleanDays(p, today)
                        GlassCard(Modifier.fillMaxWidth(), glow = p.active) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(v.t("بطّل: ", "اترك: ") + p.sin, color = UColors.Cream, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    if (p.replacement.isNotBlank()) Text(v.t("بدل ما: ", "بدال ما: ") + p.replacement, color = UColors.CreamDim, fontSize = 12.sp)
                                    Text(
                                        v.t("تذكير الساعة: ", "تذكير الساعة: ") + p.times.joinToString("، ") { TimeLogic.formatMinute(it) },
                                        color = UColors.CreamDim, fontSize = 12.sp,
                                    )
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(Arabic.digits(clean), color = GREEN, fontWeight = FontWeight.Black, fontSize = 30.sp)
                                    Text(v.t("يوم التزام", "يوم التزام"), color = UColors.CreamDim, fontSize = 11.sp)
                                }
                            }
                            if (p.bestStreak > 0) Text(v.t("أطول التزام: ", "أطول التزام: ") + Arabic.digits(p.bestStreak) + v.t(" يوم", " يوم"), color = UColors.CreamDim, fontSize = 11.sp)
                            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                PillButton(v.planKept, {
                                    val before = score.good
                                    cs.keepPlanToday(p.id)
                                    cs.removePending(LogKind.PLAN, "plan:${p.id}")
                                    refreshBubble()
                                    fire(true, before + 1)
                                }, icon = Ico.Check)
                                PillButton(v.planSlip, {
                                    cs.slipPlan(p.id)
                                    cs.removePending(LogKind.PLAN, "plan:${p.id}")
                                    refreshBubble()
                                    fire(false, score.sin + 1)
                                    ticker = v.planSlipReply
                                }, filled = false)
                                IconBtn(Ico.Delete, v.t("إنهاء الخطة", "إنهاء الخطة"), { endPlan = p }, UColors.CreamDim)
                            }
                        }
                    }
                    PillButton(v.t("خطة جديدة", "خطة جديدة"), { planDraft = "" }, icon = Ico.Add, filled = false)
                }

                // ---- سجل اليوم
                SectionLabel(v.t("سجل النهارده", "سجل اليوم"))
                if (entries.isEmpty()) {
                    GlassCard(Modifier.fillMaxWidth()) { Text(v.t("لسه مفيش تسجيلات. ابدأ بحسنة صغيرة 🌱", "للحين ما في تسجيلات. ابدأ بحسنة صغيرة 🌱"), color = UColors.CreamDim, fontSize = 13.sp) }
                } else {
                    GlassCard(Modifier.fillMaxWidth()) {
                        entries.asReversed().forEach { e ->
                            val good = e.type == LedgerType.GOOD
                            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(10.dp).clip(RoundedCornerShape(5.dp)).background(if (good) GREEN else RED))
                                Spacer(Modifier.width(10.dp))
                                Text(e.title, color = UColors.Cream, fontSize = 14.sp, modifier = Modifier.weight(1f))
                                IconBtn(Ico.Close, v.t("حذف", "حذف"), { removeEntry(e) }, UColors.CreamDim)
                            }
                        }
                    }
                }

                // ---- آخر ٧ أيام
                val week = (6 downTo 0).map { i ->
                    val d = today.minusDays(i.toLong()).toString()
                    LedgerLogic.score(range[d].orEmpty())
                }
                if (week.any { it.good + it.sin > 0 }) {
                    SectionLabel(v.t("آخر ٧ أيام", "آخر ٧ أيام"))
                    GlassCard(Modifier.fillMaxWidth()) { WeekBars(week) }
                }

                GlassCard(Modifier.fillMaxWidth(), glow = true, onClick = { nav.navigate("comeback") }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconBadge(Ico.Heart)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(v.t("أنا محتاج أرجع لربنا", "أبي أرجع لربي"), color = UColors.Gold, fontWeight = FontWeight.Bold)
                            Text(v.t("صفحة هادية: استغفار ودعاء وخطوات للبداية من جديد", "صفحة هادية: استغفار ودعاء وخطوات للبداية من جديد"), color = UColors.CreamDim, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        CelebrationLayer(event)
        CheerBanner(event, Modifier.align(Alignment.TopCenter))

        // ---- ورقة التسجيل
        AnimatedVisibility(sheet != null, enter = fadeIn(), exit = fadeOut()) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.35f)).clickable { sheet = null })
        }
        Box(Modifier.align(Alignment.BottomCenter)) {
            AnimatedVisibility(sheet != null, enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()) {
                val type = sheet ?: LedgerType.GOOD
                RecordSheet(
                    type = type,
                    entries = entries.filter { it.type == type },
                    offerSin = if (type == LedgerType.SIN) offerSin else null,
                    onAdd = { t -> if (type == LedgerType.GOOD) logGood(t) else logSin(t) },
                    onRemove = { removeEntry(it) },
                    onPlan = { sin -> offerSin = null; sheet = null; planDraft = sin },
                    onSkipOffer = { offerSin = null },
                    onClose = { sheet = null; offerSin = null },
                )
            }
        }
        AnimatedVisibility(planDraft != null, enter = fadeIn(), exit = fadeOut()) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f)).clickable { planDraft = null })
        }
        Box(Modifier.align(Alignment.BottomCenter)) {
            AnimatedVisibility(planDraft != null, enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()) {
                PlanEditor(
                    initialSin = planDraft.orEmpty(),
                    bubbleOn = cs.settings().bubble,
                    onSave = { p ->
                        cs.savePlan(p)
                        CompanionScheduler.rescheduleAll(ctx)
                        ticker = v.t("تمام! الخطة اتسجلت وهفكّرك بيها. أنا معاك 💪", "تمام! الخطة انسجلت وبذكّرك فيها. أنا معك 💪")
                        planDraft = null
                    },
                    onClose = { planDraft = null },
                )
            }
        }
    }

    endPlan?.let { p ->
        ConfirmDialog(
            v.t("إنهاء الخطة؟", "إنهاء الخطة؟"),
            v.t("هتتمسح الخطة وتذكيراتها (والفقاعة بتاعتها). الحسنات والسيئات اللي سجلتها قبل كده تفضل زي ما هي.", "بتنمسح الخطة وتذكيراتها (وفقاعتها). الحسنات والسيئات اللي سجلتها قبل تبقى مثل ما هي."),
            v.t("إنهاء", "إنهاء"),
            {
                cs.deletePlan(p.id)
                cs.removePending(LogKind.PLAN, "plan:${p.id}")
                CompanionScheduler.rescheduleAll(ctx)
            },
        ) { endPlan = null }
    }
}

// ============================================================ مكوّنات صغيرة
@Composable
private fun Pill(label: String, selected: Boolean, color: Color, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Text(
        label, color = if (selected) Color.White else UColors.Cream, fontSize = 13.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.clip(shape)
            .background(if (selected) color else color.copy(alpha = 0.14f))
            .border(1.dp, color.copy(alpha = if (selected) 1f else 0.5f), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp),
    )
}

@Composable
private fun HalfButton(modifier: Modifier, title: String, hint: String, good: Boolean, count: Int, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) 0.95f else 1f, label = "press")
    val tint = if (good) goodArenaColor() else badArenaColor()
    val shape = if (good) RoundedCornerShape(topStart = 6.dp, bottomStart = 6.dp, topEnd = 26.dp, bottomEnd = 26.dp)
    else RoundedCornerShape(topStart = 26.dp, bottomStart = 26.dp, topEnd = 6.dp, bottomEnd = 6.dp)
    Column(
        modifier.scale(s).softSurface(shape, 8.dp)
            .background(Brush.verticalGradient(listOf(tint.copy(alpha = 0.22f), tint.copy(alpha = 0.06f))))
            .border(1.4.dp, tint.copy(alpha = 0.65f), shape)
            .clickable(interactionSource = src, indication = null, onClick = onClick)
            .padding(12.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text((if (good) "＋ " else "－ ") + title, color = tint, fontWeight = FontWeight.Black, fontSize = 20.sp)
        Text(hint, color = UColors.CreamDim, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 2.dp))
        Text(Arabic.digits(count), color = UColors.Cream, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
private fun WeekBars(week: List<com.unsee.app.core.DayScore>) {
    val max = (week.maxOfOrNull { maxOf(it.good, it.sin) } ?: 1).coerceAtLeast(1)
    Canvas(Modifier.fillMaxWidth().height(70.dp)) {
        val colW = size.width / 7f
        week.forEachIndexed { i, d ->
            val x = colW * i + colW / 2f
            val gh = size.height * d.good / max
            val sh = size.height * d.sin / max
            val bw = colW * 0.26f
            drawLine(GREEN, Offset(x + bw * 0.6f, size.height), Offset(x + bw * 0.6f, size.height - gh), bw, StrokeCap.Round)
            drawLine(RED, Offset(x - bw * 0.6f, size.height), Offset(x - bw * 0.6f, size.height - sh), bw, StrokeCap.Round)
        }
    }
}

// ============================================================ بطاقة التسجيل
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RecordSheet(
    type: LedgerType,
    entries: List<LedgerEntry>,
    offerSin: String?,
    onAdd: (String) -> Unit,
    onRemove: (LedgerEntry) -> Unit,
    onPlan: (String) -> Unit,
    onSkipOffer: () -> Unit,
    onClose: () -> Unit,
) {
    val v = LocalVoice.current
    val good = type == LedgerType.GOOD
    val accent = if (good) GREEN else RED
    var text by remember(type) { mutableStateOf("") }
    val presets = if (good) listOf(
        "صليت في وقتها", "قرأت قرآن", "ساعدت حد", "برّيت أهلي", "تصدقت", "استغفرت", "صليت على النبي ﷺ",
        "كلمة طيبة", "صلة رحم", "غضيت بصري", "سامحت حد", "ابتسمت في وش حد",
    ) else listOf(
        "غيبة", "كذب", "ضيّعت صلاة", "أخّرت الصلاة", v.t("اتعصبت", "غضبت"), "نظرة حرام", "ضيّعت وقتي",
        "ضيّعت ورد القرآن", "أذيت حد بكلامي", "سهرت من غير فايدة",
    )
    val shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    Column(
        Modifier.fillMaxWidth().heightIn(max = 430.dp).clip(shape).background(UColors.CardSolid)
            .border(2.dp, accent.copy(alpha = 0.7f), shape)
            .clickable(enabled = false) {}
            .verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (good) v.t("سجّل أعمالك الصالحة", "سجّل أعمالك الصالحة") else v.t("سجّل اللي غلطت فيه", "سجّل اللي غلطت فيه"),
                color = accent, fontWeight = FontWeight.Black, fontSize = 19.sp, modifier = Modifier.weight(1f),
            )
            IconBtn(Ico.Close, v.t("إغلاق", "إغلاق"), onClose, UColors.CreamDim)
        }
        if (!good && offerSin != null) {
            // اقتراح الخطة بعد تسجيل ذنب
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(accent.copy(alpha = 0.12f)).border(1.dp, accent.copy(alpha = 0.5f), RoundedCornerShape(20.dp)).padding(14.dp),
            ) {
                Text(v.comfort(offerSin.length), color = UColors.Cream, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(v.planOffer(offerSin), color = UColors.CreamDim, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillButton(v.t("أيوه نعمل خطة", "إي سوّ خطة"), { onPlan(offerSin) })
                    PillButton(v.t("مش دلوقتي", "مو الحين"), onSkipOffer, filled = false)
                }
            }
        }
        Text(v.t("اضغط على اللي عملته، أو اكتبه بنفسك:", "اضغط على اللي سويته، أو اكتبه بنفسك:"), color = UColors.CreamDim, fontSize = 12.sp)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            presets.forEach { p -> Pill(p, false, accent) { onAdd(p) } }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                text, { text = it.take(60) }, singleLine = true, modifier = Modifier.weight(1f).keepVisibleOnIme(), colors = fieldColors(),
                label = { Text(if (good) v.t("عمل صالح تاني", "عمل صالح ثاني") else v.t("حاجة تانية", "شي ثاني")) },
            )
            PillButton(v.t("سجّل", "سجّل"), { if (text.isNotBlank()) { onAdd(text); text = "" } }, icon = Ico.Add)
        }
        if (entries.isNotEmpty()) {
            Text(v.t("اللي سجلته النهارده:", "اللي سجلته اليوم:"), color = UColors.CreamDim, fontSize = 12.sp)
            entries.asReversed().forEach { e ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(e.title, color = UColors.Cream, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    IconBtn(Ico.Close, v.t("حذف", "حذف"), { onRemove(e) }, UColors.CreamDim)
                }
            }
        }
        Spacer(Modifier.height(6.dp))
    }
}

// ============================================================ محرر الخطة
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PlanEditor(initialSin: String, bubbleOn: Boolean, onSave: (QuitPlan) -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val v = LocalVoice.current
    val cs = remember { CompanionStore.get(ctx) }
    var sin by remember(initialSin) { mutableStateOf(initialSin) }
    var repl by remember(initialSin) { mutableStateOf("") }
    val times = remember(initialSin) { mutableStateListOf(14 * 60, 21 * 60) }
    val replPresets = listOf(
        v.t("أستغفر وأتوضى", "أستغفر وأتوضأ"), v.t("أقوم أغيّر مكاني", "أقوم أغيّر مكاني"),
        v.t("أفتح المصحف", "أفتح المصحف"), v.t("أكلّم حد أثق فيه", "أكلّم أحد أثق فيه"), v.t("أمشي شوية", "أمشي شوي"),
    )
    val shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    Column(
        Modifier.fillMaxWidth().heightIn(max = 520.dp).clip(shape).background(UColors.CardSolid)
            .border(2.dp, GREEN.copy(alpha = 0.7f), shape)
            .clickable(enabled = false) {}
            .verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(v.t("خطة الإقلاع", "خطة الترك"), color = GREEN, fontWeight = FontWeight.Black, fontSize = 19.sp, modifier = Modifier.weight(1f))
            IconBtn(Ico.Close, v.t("إغلاق", "إغلاق"), onClose, UColors.CreamDim)
        }
        OutlinedTextField(
            sin, { sin = it.take(60) }, singleLine = true, modifier = Modifier.fillMaxWidth().keepVisibleOnIme(), colors = fieldColors(),
            label = { Text(v.t("عايز تبطّل إيه؟", "وش تبي تترك؟")) },
        )
        Text(v.t("لو جاتلك الرغبة، هتعمل إيه بدالها؟", "لو جتك الرغبة، وش تسوي بدالها؟"), color = UColors.CreamDim, fontSize = 12.sp)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            replPresets.forEach { p -> Pill(p, repl == p, GREEN) { repl = if (repl == p) "" else p } }
        }
        OutlinedTextField(
            repl, { repl = it.take(60) }, singleLine = true, modifier = Modifier.fillMaxWidth().keepVisibleOnIme(), colors = fieldColors(),
            label = { Text(v.t("أو اكتب بدالك", "أو اكتب بنفسك")) },
        )
        Text(v.t("هفكّرك في الأوقات دي (لحد ٣):", "بذكّرك في هالأوقات (لين ٣):"), color = UColors.CreamDim, fontSize = 12.sp)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            times.forEachIndexed { i, m ->
                PillButton(TimeLogic.formatMinute(m), { pickTime(ctx, m) { nm -> times[i] = nm } }, icon = Ico.Alarm, filled = false)
                IconBtn(Ico.Close, v.t("حذف الوقت", "حذف الوقت"), { if (times.size > 1) times.removeAt(i) }, UColors.CreamDim)
            }
            if (times.size < 3) PillButton(v.t("وقت", "وقت"), { pickTime(ctx, 18 * 60) { nm -> times.add(nm) } }, icon = Ico.Add, filled = false)
        }
        Text(
            v.t(
                "التذكير بيظهر كفقاعة أولوية على الشاشة الرئيسية، ومش بيتمسح ولا بيتأجّل إلا لما تردّ عليه (التزمت / وقعت).",
                "التذكير يطلع كفقاعة أولوية على الشاشة الرئيسية، وما ينمسح ولا يتأجّل إلا لين ترد عليه (التزمت / طحت).",
            ),
            color = UColors.CreamDim, fontSize = 12.sp,
        )
        if (!bubbleOn) Text(
            v.t("الفقاعة مقفولة دلوقتي، فالتذكير هيوصلك كإشعار ثابت. فعّل الفقاعة من رفيق أُنسي.", "الفقاعة مقفولة الحين، فالتذكير يوصلك كإشعار ثابت. فعّلها من رفيق أُنسي."),
            color = Color(0xFFF59E0B), fontSize = 12.sp,
        )
        PillButton(v.t("ابدأ الخطة", "ابدأ الخطة"), {
            val s = LedgerLogic.norm(sin)
            if (s.isEmpty()) Toast.makeText(ctx, v.t("اكتب إيه اللي عايز تبطّله", "اكتب وش تبي تترك"), Toast.LENGTH_SHORT).show()
            else onSave(QuitPlan(cs.newPlanId(), s, LedgerLogic.norm(repl), times.toList().sorted(), LocalDate.now().toString()))
        }, Modifier.fillMaxWidth(), icon = Ico.Check)
        Spacer(Modifier.height(6.dp))
    }
}
