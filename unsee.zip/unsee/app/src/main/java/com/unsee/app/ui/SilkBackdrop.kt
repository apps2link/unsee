package com.unsee.app.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private const val TAU = (2.0 * PI).toFloat()

private class SilkStar(val x: Float, val y: Float, val r: Float, val ph: Float, val cyc: Int)
private class SilkBlob(
    val bx: Float, val by: Float, val rad: Float, val k: Int, val ph: Float,
    val day: Color, val night: Color, val dayA: Float, val nightA: Float,
)
private class SilkCloud(val y: Float, val scale: Float, val ph: Float, val cyc: Int, val a: Float)

private val silkRnd = Random(11)
private val silkStars = List(72) { SilkStar(silkRnd.nextFloat(), silkRnd.nextFloat() * 0.62f, 0.5f + silkRnd.nextFloat() * 1.1f, silkRnd.nextFloat(), 1 + silkRnd.nextInt(3)) }

// «الإضاءة المحيطة»: كتل ضوئية ناعمة بألوان الباليت (وردي لؤلؤي/لافندر/خوخي نهارًا — توتي/بنفسجي/نيلي ليلًا)
private val silkBlobs = listOf(
    SilkBlob(0.18f, 0.16f, 0.78f, 1, 0.00f, Color(0xFFFF9EC0), Color(0xFFB0307A), 0.50f, 0.42f),
    SilkBlob(0.86f, 0.30f, 0.70f, 2, 0.33f, Color(0xFFC9A8FF), Color(0xFF5B3BD0), 0.48f, 0.40f),
    SilkBlob(0.30f, 0.66f, 0.74f, 1, 0.61f, Color(0xFFFFC7A8), Color(0xFF8E3FB5), 0.40f, 0.34f),
    SilkBlob(0.82f, 0.92f, 0.66f, 3, 0.17f, Color(0xFFF2B6E8), Color(0xFF3F2A9C), 0.42f, 0.36f),
)
private val silkClouds = listOf(
    SilkCloud(0.30f, 1.00f, 0.05f, 1, 0.58f),
    SilkCloud(0.46f, 0.72f, 0.48f, 1, 0.42f),
    SilkCloud(0.18f, 0.58f, 0.80f, 2, 0.36f),
)

private val DAY_TOP = Color(0xFFFFF7FA)
private val DAY_MID = Color(0xFFFBE3EE)
private val DAY_BOT = Color(0xFFEBDDF6)
private val NIGHT_TOP = Color(0xFF120822)
private val NIGHT_MID = Color(0xFF2A1240)
private val NIGHT_BOT = Color(0xFF3B1A5C)

/**
 * خلفية «الحرير الحي»: تدرّج لؤلؤي/وردي نهارًا يتحول إلى بنفسجي عميق ليلًا، مع إضاءة محيطية تتنفس ببطء،
 * وشمس تعبر القوس وسحب خفيفة نهارًا، وقمر ونجوم متلألئة ليلًا. كل القيم المتحركة تُقرأ في مرحلة الرسم فقط
 * (لا إعادة تركيب)، ومؤقّت واحد بطيء (90 ث)، ويتوقف كليًا عند «بلا حركة».
 * [level]: 1 كامل، 0.5 خفيف (يقلّص النجوم والسحب والكتل).
 */
@Composable
fun SilkBackdrop(sky: LiveSky, reduceMotion: Boolean, level: Float, modifier: Modifier = Modifier) {
    val t: State<Float> = if (reduceMotion) {
        remember { mutableStateOf(0.22f) }
    } else {
        rememberInfiniteTransition(label = "silk").animateFloat(
            initialValue = 0f, targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(90_000, easing = LinearEasing)),
            label = "silkT",
        )
    }
    Box(
        modifier.fillMaxSize().drawBehind {
            drawSilk(sky.skyBlend.value, t.value, sky.sunP.value, sky.moonP.value, level)
        },
    )
}

private fun DrawScope.drawSilk(b: Float, t: Float, sunP: Float, moonP: Float, level: Float) {
    val w = size.width
    val h = size.height
    val night = 1f - b

    // 1) التدرّج الأساسي
    drawRect(
        Brush.verticalGradient(
            listOf(lerp(NIGHT_TOP, DAY_TOP, b), lerp(NIGHT_MID, DAY_MID, b), lerp(NIGHT_BOT, DAY_BOT, b)),
        ),
    )

    // 2) إضاءة محيطية تتنفس (حركة جيبية بدورات صحيحة فتتكرر بسلاسة)
    val blobCount = if (level >= 1f) silkBlobs.size else 3
    for (i in 0 until blobCount) {
        val bl = silkBlobs[i]
        val cx = w * (bl.bx + 0.05f * sin(TAU * (t * bl.k + bl.ph)))
        val cy = h * (bl.by + 0.04f * cos(TAU * (t * bl.k + bl.ph)))
        val breathe = 1f + 0.05f * sin(TAU * (t * bl.k + bl.ph + 0.25f))
        val r = minOf(w, h) * bl.rad * breathe
        val col = lerp(bl.night, bl.day, b)
        val a = bl.nightA + (bl.dayA - bl.nightA) * b
        drawCircle(
            Brush.radialGradient(listOf(col.copy(alpha = a), Color.Transparent), center = Offset(cx, cy), radius = r),
            radius = r, center = Offset(cx, cy),
        )
    }

    // 3) النهار: هالة الشمس وقرصها + سحب ناعمة
    if (b > 0.01f) {
        val sx = w * (0.14f + 0.72f * sunP)
        val sy = h * (0.24f - 0.12f * sin(PI.toFloat() * sunP))
        val halo = w * 0.62f
        drawCircle(
            Brush.radialGradient(listOf(Color(0xFFFFE2B8).copy(alpha = 0.60f * b), Color.Transparent), center = Offset(sx, sy), radius = halo),
            radius = halo, center = Offset(sx, sy),
        )
        drawCircle(Color(0xFFFFF3D6).copy(alpha = 0.92f * b), radius = w * 0.062f, center = Offset(sx, sy))
        drawCircle(Color.White.copy(alpha = 0.55f * b), radius = w * 0.085f, center = Offset(sx, sy), style = Stroke(1.dp.toPx()))
        val cloudCount = if (level >= 1f) silkClouds.size else 2
        for (i in 0 until cloudCount) {
            val c = silkClouds[i]
            val prog = (t * c.cyc + c.ph) % 1f
            val cx = -0.25f * w + prog * 1.5f * w
            val cy = h * c.y
            val u = w * 0.11f * c.scale
            val col = Color.White.copy(alpha = c.a * b * 0.55f)
            drawCircle(col, u * 1.0f, Offset(cx, cy))
            drawCircle(col, u * 1.35f, Offset(cx + u * 1.1f, cy - u * 0.35f))
            drawCircle(col, u * 1.1f, Offset(cx + u * 2.3f, cy + u * 0.05f))
            drawCircle(col, u * 0.8f, Offset(cx + u * 3.2f, cy + u * 0.25f))
        }
    }

    // 4) الليل: نجوم متلألئة وهلال مضيء
    if (night > 0.01f) {
        val starCount = if (level >= 1f) silkStars.size else silkStars.size / 2
        for (i in 0 until starCount) {
            val s = silkStars[i]
            val tw = 0.5f + 0.5f * sin(TAU * (t * s.cyc + s.ph))
            drawCircle(Color(0xFFFFF1F7).copy(alpha = (0.28f + 0.72f * tw) * night), s.r * density, Offset(s.x * w, s.y * h))
        }
        val mx = w * (0.14f + 0.72f * moonP)
        val my = h * (0.22f - 0.11f * sin(PI.toFloat() * moonP))
        val mr = w * 0.07f
        val glow = w * 0.40f
        drawCircle(
            Brush.radialGradient(listOf(Color(0xFFFFE9C9).copy(alpha = 0.34f * night), Color.Transparent), center = Offset(mx, my), radius = glow),
            radius = glow, center = Offset(mx, my),
        )
        val disc = Path().apply { addOval(Rect(Offset(mx, my), mr)) }
        val cut = Path().apply { addOval(Rect(Offset(mx + mr * 0.55f, my - mr * 0.15f), mr * 0.92f)) }
        val crescent = Path().apply { op(disc, cut, PathOperation.Difference) }
        drawPath(crescent, Color(0xFFFFF1D0).copy(alpha = 0.96f * night))
    }
}
