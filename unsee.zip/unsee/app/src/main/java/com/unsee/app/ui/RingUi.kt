package com.unsee.app.ui

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.view.HapticFeedbackConstants
import android.view.SoundEffectConstants
import android.view.View
import android.widget.Toast
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.unsee.app.core.Arabic
import com.unsee.app.core.RingCodec
import com.unsee.app.core.RingConfig
import com.unsee.app.core.RingDesign
import com.unsee.app.data.Settings
import com.unsee.app.data.Store
import com.unsee.app.widget.RingWidget
import com.unsee.app.widget.RingWidgetRenderer
import kotlinx.coroutines.launch

// ================================================================ تغذية راجعة (اهتزاز/صوت) حسب إعداد العدّاد

private object Tones {
    private var gen: ToneGenerator? = null
    fun play(kind: Int) {
        runCatching {
            val g = gen ?: ToneGenerator(AudioManager.STREAM_SYSTEM, 35).also { gen = it }
            if (kind == 2) g.startTone(ToneGenerator.TONE_PROP_BEEP, 40) else g.startTone(ToneGenerator.TONE_CDMA_PIP, 30)
        }
    }
}

fun ringFeedback(view: View, cfg: RingConfig, strong: Boolean) {
    if (cfg.haptic) view.performHapticFeedback(if (strong) HapticFeedbackConstants.LONG_PRESS else HapticFeedbackConstants.KEYBOARD_TAP)
    when (cfg.sound) {
        1 -> view.playSoundEffect(SoundEffectConstants.CLICK)
        2, 3 -> Tones.play(cfg.sound)
    }
}

@Composable
fun ringDark(cfg: RingConfig): Boolean = when (cfg.variant) { 1 -> true; 2 -> false; else -> UColors.isDark }

// ================================================================ المكوّنات

/** ساعة الحركة: تتراكم بسرعة الحركة المختارة (فتتغير السرعة بسلاسة دون قفزة). متوقفة تمامًا عند [active] = false. */
@Composable
fun rememberRingPhase(active: Boolean, speed: Float): State<Float> {
    val phase = remember { mutableFloatStateOf(0f) }
    val spd by rememberUpdatedState(speed)
    LaunchedEffect(active) {
        if (!active) return@LaunchedEffect
        var last = 0L
        while (true) {
            androidx.compose.runtime.withFrameNanos { n ->
                if (last != 0L) phase.floatValue = (phase.floatValue + (n - last) / 1_000_000_000f * spd) % 3600f
                last = n
            }
        }
    }
    return phase
}

@Composable
fun RingCanvas(cfg: RingConfig, st: RingState, dark: Boolean, phase: State<Float>, kick: () -> Float, modifier: Modifier = Modifier) {
    val painter = remember { RingPainter() }
    Canvas(modifier) {
        drawIntoCanvas { cv -> painter.draw(cv.nativeCanvas, size.width, size.height, cfg, st, dark, phase.value, kick(), density) }
    }
}

/** العدّاد الدائري التفاعلي: يرسم التصميم المختار، ويطلق نبضة عند الضغط، ويحترم «تقليل الحركة». */
@Composable
fun RingCounter(
    count: Int, target: Int, name: String, cfg: RingConfig, reduceMotion: Boolean, size: Dp,
    onTap: () -> Unit, modifier: Modifier = Modifier,
) {
    val eff = if (reduceMotion) cfg.copy(animate = false) else cfg
    val phase = rememberRingPhase(eff.animate, eff.speed)
    val kick = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val st = RingState(count, target, name)
    Box(
        modifier
            .size(size)
            .semantics { contentDescription = "عدّاد التسبيح ${Arabic.digits(count)} من ${Arabic.digits(target)}" }
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                if (eff.animate) scope.launch { kick.snapTo(1f); kick.animateTo(0f, tween(750)) }
                onTap()
            },
    ) {
        RingCanvas(eff, st, ringDark(eff), phase, { kick.value }, Modifier.fillMaxSize())
    }
}

/** صورة مصغّرة حيّة لتصميم؛ تشارك ساعة حركة واحدة مع بقية الصور فلا تتضاعف التكلفة. */
@Composable
fun RingThumb(design: RingDesign, base: RingConfig, selected: Boolean, phase: State<Float>, onClick: () -> Unit) {
    val cfg = base.copy(design = design, showName = false, showGoal = false, ringSize = 1f)
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier.width(104.dp).clip(shape)
            .background(if (selected) UColors.Gold.copy(alpha = 0.14f) else Color.Transparent)
            .border(if (selected) 2.dp else 1.dp, if (selected) UColors.Gold else UColors.Cream.copy(alpha = 0.12f), shape)
            .clickable(onClick = onClick).padding(vertical = 8.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        RingCanvas(cfg, RingState(18, 33, ""), ringDark(cfg), phase, { 0f }, Modifier.size(86.dp))
        Text(design.label, color = if (selected) UColors.Gold else UColors.Cream, fontSize = 11.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal, textAlign = TextAlign.Center, maxLines = 1)
    }
}

/** شريط أفقي بكل التصاميم الـ15 (لا يرسم إلا ما يظهر على الشاشة). */
@Composable
fun RingGalleryRow(current: RingConfig, phase: State<Float>, onPick: (RingDesign) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(RingDesign.values().toList()) { d -> RingThumb(d, current, d == current.design, phase) { onPick(d) } }
    }
}

// ================================================================ الودجت: طلب إضافة

fun requestPinRingWidget(ctx: Context) {
    val mgr = AppWidgetManager.getInstance(ctx)
    if (mgr.isRequestPinAppWidgetSupported) {
        val ok = mgr.requestPinAppWidget(ComponentName(ctx, RingWidget::class.java), null, null)
        if (!ok) Toast.makeText(ctx, "تعذّر الطلب. أضِفه يدويًا: اضغط مطولًا على الشاشة الرئيسية ← الودجت ← أُنسي ← العدّاد الدائري", Toast.LENGTH_LONG).show()
    } else {
        Toast.makeText(ctx, "الشاشة الرئيسية لا تدعم الإضافة المباشرة. اضغط مطولًا على الشاشة ← الودجت ← أُنسي", Toast.LENGTH_LONG).show()
    }
}

// ================================================================ استوديو التخصيص

private val SWATCHES = listOf(0xFFFFFFFFL, 0xFFFFF4D6L, 0xFFE2B857L, 0xFF5BD6A8L, 0xFF5BD9FFL, 0xFFFF8A3DL, 0xFFF0A3C0L, 0xFFD9B8FFL, 0xFF1A1A1AL)

@Composable
private fun ColorChoice(title: String, current: Long, onPick: (Long) -> Unit) {
    Text(title, color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.height(34.dp).clip(RoundedCornerShape(50))
                .border(if (current == 0L) 3.dp else 1.dp, if (current == 0L) UColors.Gold else Color.Gray.copy(alpha = 0.6f), RoundedCornerShape(50))
                .clickable { onPick(0L) }.padding(horizontal = 12.dp),
            contentAlignment = Alignment.Center,
        ) { Text("تلقائي", color = UColors.Cream, fontSize = 12.sp) }
        SWATCHES.forEach { c -> ColorDot(Color(c), current == c) { onPick(c) } }
    }
}

/**
 * محتوى الاستوديو (يُستخدم في شاشة التطبيق وفي شاشة إعداد الودجت).
 * المسوّدة [draft] لا تُطبَّق إلا بزر التطبيق، فالمعاينة آمنة ولا تغيّر العدّاد الحقيقي.
 * تبديل التصميم يحتفظ بكل ما اخترته (الحجم والألوان والحركة) دون أن تبدأ من الصفر.
 */
@Composable
fun RingStudioContent(
    store: Store, s: Settings, initial: RingConfig, applyLabel: String, showTarget: Boolean,
    onApply: (RingConfig) -> Unit, onAddWidget: ((RingConfig) -> Unit)? = null,
) {
    val view = LocalView.current
    val t by store.observeAsState { store.tasbih() }
    val presets by store.observeAsState { store.ringPresets() }
    var draft by remember { mutableStateOf(initial) }
    var demo by remember { mutableIntStateOf(12) }
    var presetName by remember { mutableStateOf("") }
    var confirmReset by remember { mutableStateOf(false) }
    var customTarget by remember { mutableStateOf(false) }
    val target = t.target.coerceAtLeast(1)
    val galleryPhase = rememberRingPhase(!s.reduceMotion, 1f)

    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        GlassCard(Modifier.fillMaxWidth(), glow = true) {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("معاينة حيّة — اضغط على العدّاد لتجربته", color = UColors.CreamDim, fontSize = 12.sp)
                RingCounter(
                    count = demo.coerceAtMost(target), target = target, name = t.text, cfg = draft, reduceMotion = s.reduceMotion, size = 250.dp,
                    onTap = { demo = if (demo >= target) 1 else demo + 1; ringFeedback(view, draft, demo >= target) },
                )
                ChipRow(listOf(0, 25, 50, 75, 100), { demo == (target * it / 100) }, { "${Arabic.digits(it)}٪" }) { demo = target * it / 100 }
                Text("المعاينة لا تغيّر عدّادك الحقيقي.", color = UColors.CreamDim, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }

        SectionLabel("التصميم (${Arabic.digits(RingDesign.values().size)})")
        RingGalleryRow(draft, galleryPhase) { draft = draft.copy(design = it) }
        Text("${draft.design.label}: ${draft.design.blurb}", color = UColors.CreamDim, fontSize = 12.sp)
        Text("تبديل التصميم يحتفظ بحجمك وألوانك وإعداداتك.", color = UColors.CreamDim, fontSize = 11.sp)

        SectionLabel("الحجم والخط")
        GlassCard(Modifier.fillMaxWidth()) {
            LabeledSlider("حجم العدّاد: ${Arabic.digits((draft.ringSize * 100).toInt())}٪", draft.ringSize, 0.6f..1.1f) { draft = draft.copy(ringSize = it) }
            LabeledSlider("حجم الرقم: ${Arabic.digits((draft.digitScale * 100).toInt())}٪", draft.digitScale, 0.6f..1.6f) { draft = draft.copy(digitScale = it) }
            LabeledSlider("سُمك الحلقة: ${Arabic.digits((draft.thickness * 100).toInt())}٪", draft.thickness, 0.5f..1.6f) { draft = draft.copy(thickness = it) }
            Text("خط الرقم", color = UColors.CreamDim, fontSize = 12.sp)
            ChipRow(listOf(0, 1, 2, 3), { it == draft.font }, { RingConfig.FONTS[it] }) { draft = draft.copy(font = it) }
        }

        SectionLabel("الألوان")
        GlassCard(Modifier.fillMaxWidth()) {
            ColorChoice("لون الأرقام", draft.digitColor) { draft = draft.copy(digitColor = it) }
            ColorChoice("لون الحلقة", draft.ringColor) { draft = draft.copy(ringColor = it) }
            ColorChoice("لون الخلفية", draft.bgColor) { draft = draft.copy(bgColor = it) }
            LabeledSlider("شفافية الخلفية: ${Arabic.digits(draft.bgAlpha)}٪", draft.bgAlpha.toFloat(), 0f..100f) { draft = draft.copy(bgAlpha = it.toInt()) }
            Text("الوضع", color = UColors.CreamDim, fontSize = 12.sp)
            ChipRow(listOf(0, 1, 2), { it == draft.variant }, { RingConfig.VARIANTS[it] }) { draft = draft.copy(variant = it) }
            Text("لكل تصميم نسخة داكنة وأخرى فاتحة.", color = UColors.CreamDim, fontSize = 11.sp)
            Row(Modifier.padding(top = 6.dp)) {
                PillButton("إعادة الألوان للافتراضي", { draft = draft.copy(digitColor = 0L, ringColor = 0L, bgColor = 0L, bgAlpha = 100) }, filled = false)
            }
        }

        SectionLabel("الحركة والإضاءة")
        GlassCard(Modifier.fillMaxWidth()) {
            SwitchRow("التأثيرات المتحركة", "إيقافها يوفّر البطارية ويُبقي الرسم ثابتًا", draft.animate) { draft = draft.copy(animate = it) }
            LabeledSlider("سرعة الحركة: ${Arabic.digits((draft.speed * 100).toInt())}٪", draft.speed, 0.4f..2.5f) { draft = draft.copy(speed = it) }
            LabeledSlider("شدة الإضاءة: ${Arabic.digits((draft.glow * 100).toInt())}٪", draft.glow, 0f..1.5f) { draft = draft.copy(glow = it) }
        }

        SectionLabel("النصوص والتفاعل")
        GlassCard(Modifier.fillMaxWidth()) {
            SwitchRow("إظهار اسم الذكر", null, draft.showName) { draft = draft.copy(showName = it) }
            SwitchRow("إظهار الهدف", null, draft.showGoal) { draft = draft.copy(showGoal = it) }
            SwitchRow("اهتزاز خفيف عند الضغط", null, draft.haptic) { draft = draft.copy(haptic = it) }
            Text("صوت النقرة", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            ChipRow(listOf(0, 1, 2, 3), { it == draft.sound }, { RingConfig.SOUNDS[it] }) {
                draft = draft.copy(sound = it); ringFeedback(view, draft, false)
            }
        }

        if (showTarget) {
            SectionLabel("عدد التسبيحات المستهدف")
            GlassCard(Modifier.fillMaxWidth()) {
                ChipRow(listOf(33, 99, 100, 500, 1000), { it == t.target }, { Arabic.digits(it) }) { store.setTasbihTarget(it); RingWidgetRenderer.updateAll(view.context) }
                Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillButton("رقم مخصص", { customTarget = true }, icon = Ico.Edit, filled = false)
                    PillButton("تصفير العدّاد", { confirmReset = true }, icon = Ico.Refresh, filled = false)
                }
                Text("تغيير الهدف يبدأ العدّ من الصفر، ويبقى سجل اليوم كما هو.", color = UColors.CreamDim, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }

        SectionLabel("تصميماتي المحفوظة")
        GlassCard(Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = presetName, onValueChange = { presetName = it.take(24) }, singleLine = true,
                label = { Text("اسم التصميم") }, colors = fieldColors(), modifier = Modifier.fillMaxWidth(),
            )
            Row(Modifier.padding(top = 6.dp)) {
                PillButton("حفظ باسم", {
                    store.saveRingPreset(presetName, draft); presetName = ""
                    Toast.makeText(view.context, "تم حفظ التصميم", Toast.LENGTH_SHORT).show()
                }, icon = Ico.Check)
            }
            if (presets.isEmpty()) {
                Text("لم تحفظ تصميمًا بعد. اضبط عدّادك كما تحب ثم احفظه باسم تختاره.", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
            presets.forEach { (name, cfg) ->
                Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(name, color = UColors.Cream, fontWeight = FontWeight.Bold)
                        Text(cfg.design.label, color = UColors.CreamDim, fontSize = 11.sp)
                    }
                    PillButton("معاينة", { draft = cfg }, filled = false)
                    IconBtn(Ico.Delete, "حذف", { store.deleteRingPreset(name) })
                }
            }
        }

        val changed = draft != initial
        if (changed) Text("لديك تغييرات لم تُطبَّق بعد.", color = UColors.Gold, fontSize = 12.sp)
        PillButton(applyLabel, { onApply(draft) }, Modifier.fillMaxWidth(), icon = Ico.CheckCircle)
        if (onAddWidget != null) PillButton("إضافة كودجت بهذا التصميم", { onAddWidget(draft) }, Modifier.fillMaxWidth(), icon = Ico.Widgets, filled = false)
        PillButton("استعادة الإعدادات الافتراضية", { draft = RingConfig() }, Modifier.fillMaxWidth(), icon = Ico.Refresh, filled = false)
        Spacer(Modifier.height(24.dp))
    }

    if (customTarget) NumberDialog("الهدف المخصص", "العدد", t.target, { customTarget = false }) { store.setTasbihTarget(it); RingWidgetRenderer.updateAll(view.context) }
    if (confirmReset) ConfirmDialog("تصفير العدّاد؟", "سيعود عدّاد هذه الجلسة إلى الصفر. لا يتأثر سجل اليوم.", "تصفير", { store.tasbihReset(); RingWidgetRenderer.updateAll(view.context) }) { confirmReset = false }
}

@Composable
fun RingStudioScreen(store: Store, s: Settings, nav: NavController) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        ScreenHeader("استوديو العدّاد", { nav.popBackStack() })
        RingStudioContent(
            store = store, s = s, initial = remember { store.ringConfig() }, applyLabel = "تطبيق على المسبحة", showTarget = true,
            onApply = { store.setRingConfig(it); RingWidgetRenderer.updateAll(ctx); Toast.makeText(ctx, "تم تطبيق التصميم", Toast.LENGTH_SHORT).show() },
            onAddWidget = { store.setRingConfig(it); requestPinRingWidget(ctx) },
        )
    }
}
