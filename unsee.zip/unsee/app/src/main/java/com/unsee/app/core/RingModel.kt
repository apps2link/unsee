package com.unsee.app.core

/**
 * العدّاد الدائري: 15 تصميمًا لكل منها رسم وحركة وشخصية بصرية خاصة (يرسمها RingPainter).
 * هذا الملف نقي (بلا Android) ليبقى قابلًا للاختبار على JVM.
 */
enum class RingDesign(val label: String, val blurb: String) {
    GOLD_HALO("الهالة الذهبية", "حلقة ذهبية مضيئة تتحرك مع كل تسبيحة"),
    EMERALD_GLASS("الزمرد الزجاجي", "حلقة زمردية بتأثير الزجاج الشفاف"),
    CRESCENT_STARS("الهلال والنجوم", "هلال ونجوم تدور حول الرقم"),
    LIGHT_ORBIT("مدار الضوء", "جزيئات ضوئية تدور حول الحلقة"),
    GRADIENT_PROGRESS("حلقة الإنجاز", "ألوانها تتدرّج حسب نسبة الإنجاز"),
    WATER_RIPPLE("الماء والتموّج", "مستوى ماء يرتفع مع التقدّم وتموجات"),
    GALAXY("المجرة", "مجرة حلزونية ونجوم متلألئة"),
    LUXE_GEOMETRY("الزخرفة الفاخرة", "زخارف هندسية متحركة وحلقة مجزّأة"),
    PULSE("النبض الضوئي", "نبضة ضوء تنتشر مع كل ضغطة"),
    DEPTH_3D("ثلاثي الأبعاد", "عمق وإضاءة وظلال حقيقية"),
    LEAF_NATURE("ورق الشجر", "أوراق خضراء هادئة تتمايل"),
    CLEAR_GLASS("الزجاج الشفاف", "زجاج شفاف فوق خلفية متحركة"),
    MOON_NIGHT("القمر والليل", "قمر وسماء ليلية وسحب"),
    CALLIGRAPHY("الخط الأنيق", "أرقام كبيرة وخط عربي أنيق"),
    SOFT_FIRE("الوهج الناري", "ضوء ناري خفيف دون مبالغة"),
}

/** إعدادات التخصيص. القيمة 0 في الألوان تعني «لون التصميم الافتراضي». تبديل التصميم لا يمسّ هذه الإعدادات. */
data class RingConfig(
    val design: RingDesign = RingDesign.GOLD_HALO,
    val ringSize: Float = 1f,        // 0.6 .. 1.1  حجم العدّاد داخل المساحة المتاحة
    val digitScale: Float = 1f,      // 0.6 .. 1.6  حجم الرقم
    val font: Int = 0,               // 0 تلقائي حسب التصميم، 1 نسخ، 2 عصري نحيف، 3 عريض
    val thickness: Float = 1f,       // 0.5 .. 1.6  سُمك الحلقة
    val digitColor: Long = 0L,
    val ringColor: Long = 0L,
    val bgColor: Long = 0L,
    val bgAlpha: Int = 100,          // 0 .. 100  شفافية خلفية العدّاد
    val animate: Boolean = true,
    val speed: Float = 1f,           // 0.4 .. 2.5
    val glow: Float = 1f,            // 0 .. 1.5  شدة الإضاءة
    val showName: Boolean = false,   // الاسم يظهر فوق العدّاد افتراضيًا؛ فعّله لإظهاره داخل الحلقة
    val showGoal: Boolean = true,
    val haptic: Boolean = true,
    val sound: Int = 0,              // 0 بلا صوت، 1 نقرة، 2 نغمة ناعمة، 3 تكّة
    val variant: Int = 0,            // 0 حسب الثيم، 1 داكن، 2 فاتح
) {
    companion object {
        val DEFAULT = RingConfig()
        val FONTS = listOf("حسب التصميم", "نسخ كلاسيكي", "عصري نحيف", "عريض")
        val SOUNDS = listOf("بلا صوت", "نقرة", "نغمة ناعمة", "تكّة")
        val VARIANTS = listOf("حسب الثيم", "داكن", "فاتح")
    }
}

object RingCodec {
    private fun clampF(v: Float?, lo: Float, hi: Float, def: Float) = (v ?: def).coerceIn(lo, hi)

    fun encode(c: RingConfig): String = listOf(
        "d=${c.design.name}", "rs=${c.ringSize}", "ds=${c.digitScale}", "f=${c.font}", "th=${c.thickness}",
        "dc=${c.digitColor}", "rc=${c.ringColor}", "bc=${c.bgColor}", "ba=${c.bgAlpha}",
        "an=${if (c.animate) 1 else 0}", "sp=${c.speed}", "gl=${c.glow}",
        "sn=${if (c.showName) 1 else 0}", "sg=${if (c.showGoal) 1 else 0}",
        "hp=${if (c.haptic) 1 else 0}", "so=${c.sound}", "va=${c.variant}",
    ).joinToString(";")

    /** يتسامح مع أي نص تالف: القيم الناقصة أو الخاطئة ترجع للافتراضي، والأرقام تُقصّ إلى مداها المسموح. */
    fun decode(raw: String?): RingConfig {
        if (raw.isNullOrBlank()) return RingConfig()
        val m = HashMap<String, String>()
        for (part in raw.split(';')) {
            val i = part.indexOf('=')
            if (i > 0) m[part.substring(0, i)] = part.substring(i + 1)
        }
        val d = RingConfig()
        fun flag(k: String, def: Boolean) = m[k]?.let { it == "1" } ?: def
        return RingConfig(
            design = m["d"]?.let { n -> RingDesign.values().firstOrNull { it.name == n } } ?: d.design,
            ringSize = clampF(m["rs"]?.toFloatOrNull(), 0.6f, 1.1f, d.ringSize),
            digitScale = clampF(m["ds"]?.toFloatOrNull(), 0.6f, 1.6f, d.digitScale),
            font = (m["f"]?.toIntOrNull() ?: d.font).coerceIn(0, 3),
            thickness = clampF(m["th"]?.toFloatOrNull(), 0.5f, 1.6f, d.thickness),
            digitColor = m["dc"]?.toLongOrNull() ?: 0L,
            ringColor = m["rc"]?.toLongOrNull() ?: 0L,
            bgColor = m["bc"]?.toLongOrNull() ?: 0L,
            bgAlpha = (m["ba"]?.toIntOrNull() ?: d.bgAlpha).coerceIn(0, 100),
            animate = flag("an", d.animate),
            speed = clampF(m["sp"]?.toFloatOrNull(), 0.4f, 2.5f, d.speed),
            glow = clampF(m["gl"]?.toFloatOrNull(), 0f, 1.5f, d.glow),
            showName = flag("sn", d.showName),
            showGoal = flag("sg", d.showGoal),
            haptic = flag("hp", d.haptic),
            sound = (m["so"]?.toIntOrNull() ?: d.sound).coerceIn(0, 3),
            variant = (m["va"]?.toIntOrNull() ?: d.variant).coerceIn(0, 2),
        )
    }

    const val MAX_PRESETS = 30

    fun cleanName(name: String): String =
        name.replace('|', ' ').replace(';', ' ').replace('\n', ' ').trim().take(24).ifEmpty { "تصميمي" }

    fun encodePresets(list: List<Pair<String, RingConfig>>): String =
        list.joinToString("\n") { (n, c) -> "${cleanName(n)}|${encode(c)}" }

    fun decodePresets(raw: String?): List<Pair<String, RingConfig>> =
        (raw ?: "").split('\n').mapNotNull { line ->
            val i = line.indexOf('|')
            if (i <= 0) null else cleanName(line.substring(0, i)) to decode(line.substring(i + 1))
        }

    /** يضيف أو يستبدل تصميمًا بنفس الاسم، ويحافظ على الحد الأقصى. */
    fun upsert(list: List<Pair<String, RingConfig>>, name: String, cfg: RingConfig): List<Pair<String, RingConfig>> {
        val n = cleanName(name)
        val out = list.filterNot { it.first == n } + (n to cfg)
        return out.takeLast(MAX_PRESETS)
    }
}

/** نسبة الإنجاز: بلا هدف (0) تعني حلقة مكتملة كما في العدّاد القديم. */
fun ringFraction(count: Int, target: Int): Float =
    if (target > 0) (count.toFloat() / target).coerceIn(0f, 1f) else 1f
