package com.unsee.app.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.unsee.app.core.Arabic
import com.unsee.app.core.TimeLogic
import com.unsee.app.data.AdhkarData
import com.unsee.app.data.Category
import com.unsee.app.data.Settings
import com.unsee.app.data.Store
import com.unsee.app.data.TasbihPhrases
import com.unsee.app.data.Zikr
import com.unsee.app.widget.WidgetRenderer
import com.unsee.app.widget.WidgetStyle
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.LocalTime

private fun open(nav: NavController, z: Zikr) = nav.navigate("list/${z.category.name}?start=${z.id}")

@Composable
private fun Title(text: String, modifier: Modifier = Modifier) =
    Text(text, modifier, color = UColors.Gold, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

// ============================================================ الرئيسية
@Composable
fun HomeScreen(store: Store, settings: Settings, nav: NavController) {
    val hour = remember { LocalTime.now().hour }
    val progress by store.observeAsState { store.todayProgress() }
    val tas by store.observeAsState { store.tasbih() }
    val stats by store.observeAsState { store.dayStats(1) }
    val lastId by store.observeAsState { store.lastZikrId() }
    val suggested = TimeLogic.suggestedCategory(hour)
    val (done, total) = categoryProgress(suggested, progress)
    val last = lastId?.let { AdhkarData.byId(it) }
    val today = stats.lastOrNull()

    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Appear {
                Column(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("أُنسي", color = UColors.Gold, fontSize = 44.sp, fontWeight = FontWeight.Bold)
                    Text("UNSEE", color = UColors.CreamDim, fontSize = 12.sp, letterSpacing = 6.sp)
                    Text("أذكارك أقرب، وقلبك أهدأ", color = UColors.Cream, fontSize = 16.sp, modifier = Modifier.padding(top = 4.dp))
                    Text(TimeLogic.greeting(hour), color = UColors.GoldSoft, fontSize = 20.sp, modifier = Modifier.padding(top = 14.dp))
                }
            }
        }
        item {
            Appear(120) {
                GlassCard(Modifier.fillMaxWidth(), glow = true, onClick = { nav.navigate("list/${suggested.name}") }) {
                    Text("الورد المقترح الآن", color = UColors.CreamDim, fontSize = 12.sp)
                    Text("${suggested.emoji}  ${suggested.title}", color = UColors.Gold, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    LinearProgressIndicator(
                        progress = { if (total == 0) 0f else done.toFloat() / total },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                        color = UColors.Gold, trackColor = UColors.Gold.copy(alpha = 0.2f),
                    )
                    Text("أُنجز ${Arabic.digits(done)} من ${Arabic.digits(total)} — اضغط للمتابعة", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                }
            }
        }
        if (last != null) item {
            Appear(220) {
                GlassCard(Modifier.fillMaxWidth(), onClick = { open(nav, last) }) {
                    Text("آخر ذكر قرأته", color = UColors.CreamDim, fontSize = 12.sp)
                    Text(last.title, color = UColors.Gold, fontWeight = FontWeight.Bold)
                    Text(last.text.take(110) + if (last.text.length > 110) "…" else "", color = UColors.Cream, fontSize = 15.sp, maxLines = 2)
                }
            }
        }
        item {
            Appear(320) {
                GlassCard(Modifier.fillMaxWidth(), onClick = { nav.navigate("stats") }) {
                    Text("اليوم في لمحة", color = UColors.CreamDim, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        Stat("ضغطات", Arabic.digits(today?.taps ?: 0))
                        Stat("أذكار مكتملة", Arabic.digits(today?.completed ?: 0))
                        Stat("سبحة اليوم", Arabic.digits(tas.todayTotal))
                    }
                }
            }
        }
        item {
            Appear(420) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("اختصارات", color = UColors.CreamDim, fontSize = 12.sp)
                    val cats = Category.values().toList()
                    cats.chunked(2).forEach { pair ->
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            pair.forEach { c ->
                                GlassCard(Modifier.weight(1f), onClick = { nav.navigate("list/${c.name}") }) {
                                    Text(c.emoji, fontSize = 26.sp)
                                    Text(c.title, color = UColors.Cream, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                }
                            }
                            if (pair.size == 1) {
                                GlassCard(Modifier.weight(1f), onClick = { nav.navigate("tasbih") }) {
                                    Text("📿", fontSize = 26.sp)
                                    Text("السبحة", color = UColors.Cream, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Stat(label: String, value: String) =
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = UColors.Cream, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text(label, color = UColors.CreamDim, fontSize = 12.sp)
    }

// ============================================================ الأقسام
@Composable
fun AdhkarScreen(store: Store, nav: NavController) {
    val progress by store.observeAsState { store.todayProgress() }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Title("الأذكار") }
        items(Category.values().toList()) { c ->
            val (done, total) = categoryProgress(c, progress)
            Appear(c.ordinal * 80) {
                GlassCard(Modifier.fillMaxWidth(), onClick = { nav.navigate("list/${c.name}") }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(c.emoji, fontSize = 34.sp)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(c.title, color = UColors.Cream, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text("${c.blurb} · ${Arabic.digits(AdhkarData.forCategory(c).size)} ذكرًا", color = UColors.CreamDim, fontSize = 12.sp)
                        }
                    }
                    if (total > 0) {
                        Spacer(Modifier.height(10.dp))
                        LinearProgressIndicator(
                            progress = { done.toFloat() / total },
                            modifier = Modifier.fillMaxWidth().height(5.dp).clip(CircleShape),
                            color = UColors.Gold, trackColor = UColors.Gold.copy(alpha = 0.2f),
                        )
                    }
                }
            }
        }
    }
}

// ============================================================ صفحة الأذكار (الصباح/المساء/…)
@Composable
fun AdhkarPagerScreen(cat: Category, startId: String, store: Store, settings: Settings, nav: NavController) {
    val items = remember(cat) { AdhkarData.forCategory(cat) }
    val progress by store.observeAsState { store.todayProgress() }
    val favs by store.observeAsState { store.favorites() }
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    val startPage = remember(cat, startId) {
        val byId = items.indexOfFirst { it.id == startId }
        if (byId >= 0) byId else items.indexOfFirst { it.count > 0 && store.progress(it.id) < it.count }.coerceAtLeast(0)
    }
    val pager = rememberPagerState(initialPage = startPage) { items.size }
    val (done, total) = categoryProgress(cat, progress)

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { nav.popBackStack() }) { Text("→ رجوع", color = UColors.GoldSoft) }
            Spacer(Modifier.weight(1f))
            Text(cat.title, color = UColors.Gold, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text("${Arabic.digits(pager.currentPage + 1)}/${Arabic.digits(items.size)}", color = UColors.CreamDim)
        }
        LinearProgressIndicator(
            progress = { if (total == 0) 0f else done.toFloat() / total },
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
            color = UColors.Gold, trackColor = UColors.Gold.copy(alpha = 0.2f),
        )
        if (total > 0) Text("أُنجز ${Arabic.digits(done)} من ${Arabic.digits(total)}", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))

        HorizontalPager(state = pager, modifier = Modifier.weight(1f).padding(top = 8.dp), pageSpacing = 16.dp, key = { items[it].id }) { page ->
            val z = items[page]
            val p = progress[z.id] ?: 0
            val isFav = z.id in favs
            Column(Modifier.fillMaxSize()) {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    Column(Modifier.verticalScroll(rememberScrollState()).padding(vertical = 6.dp)) {
                        GlassCard(Modifier.fillMaxWidth(), glow = isFav) {
                            Text(z.title, color = UColors.Gold, fontWeight = FontWeight.Bold, fontSize = 17.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                            Spacer(Modifier.height(12.dp))
                            ZikrText(z.text, Modifier.fillMaxWidth())
                            Spacer(Modifier.height(12.dp))
                            Text("المصدر: ${z.source}", color = UColors.CreamDim, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                            z.grade?.let { Text(it, color = UColors.GoldSoft, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()) }
                            z.note?.let { Text(it, color = UColors.CreamDim, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 6.dp)) }
                        }
                    }
                }
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    CounterButton(
                        count = p, target = z.count, size = 150.dp,
                        caption = if (z.count > 0) "من ${Arabic.digits(z.count)}" else "بلا عدد محدد",
                        reduceMotion = settings.reduceMotion,
                        onTap = {
                            val r = store.tapZikr(z)
                            if (!r.counted) {
                                if (page < items.lastIndex) scope.launch { pager.animateScrollToPage(page + 1) }
                            } else {
                                feedback(view, settings, r.completed)
                                if (r.completed && page < items.lastIndex) scope.launch { delay(600); pager.animateScrollToPage(page + 1) }
                            }
                        },
                    )
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { if (page > 0) scope.launch { pager.animateScrollToPage(page - 1) } }) { Text("السابق", color = UColors.GoldSoft) }
                        TextButton(onClick = { store.toggleFavorite(z.id) }) { Text(if (isFav) "♥ مفضّل" else "♡ مفضلة", color = UColors.Gold) }
                        TextButton(onClick = { store.resetZikr(z) }) { Text("↺ إعادة", color = UColors.GoldSoft) }
                        TextButton(onClick = { if (page < items.lastIndex) scope.launch { pager.animateScrollToPage(page + 1) } }) { Text("التالي", color = UColors.GoldSoft) }
                    }
                }
            }
        }
    }
}

// ============================================================ السبحة
@Composable
fun TasbihScreen(store: Store, settings: Settings) {
    val t by store.observeAsState { store.tasbih() }
    val log by store.observeAsState { store.achievements() }
    val view = LocalView.current
    val ctx = LocalContext.current
    var custom by remember { mutableStateOf(false) }
    var confirmReset by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Title("السبحة الإلكترونية")
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TasbihPhrases.all.forEachIndexed { i, ph ->
                FilterChip(selected = i == t.phrase, onClick = { store.setTasbihPhrase(i); WidgetRenderer.updateStyle(ctx, WidgetStyle.TASBIH) }, label = { Text(ph, fontSize = 14.sp) })
            }
        }
        Spacer(Modifier.height(14.dp))
        AnimatedContent(targetState = t.phrase, transitionSpec = { fadeIn(tween(300)) togetherWith fadeOut(tween(200)) }, label = "phrase") { i ->
            Text(TasbihPhrases.get(i), color = UColors.Cream, fontSize = 24.sp, textAlign = TextAlign.Center, fontFamily = rememberArabicFamily())
        }
        Spacer(Modifier.height(14.dp))
        CounterButton(
            count = t.count, target = t.target, size = 270.dp,
            caption = "الهدف ${Arabic.digits(t.target)}",
            reduceMotion = settings.reduceMotion,
            onTap = {
                val r = store.tasbihTap()
                feedback(view, settings, r.completedRound)
                WidgetRenderer.updateStyle(ctx, WidgetStyle.TASBIH)
            },
        )
        Spacer(Modifier.height(10.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(33, 99, 100, 500, 1000).forEach { n ->
                FilterChip(selected = t.target == n, onClick = { store.setTasbihTarget(n); WidgetRenderer.updateStyle(ctx, WidgetStyle.TASBIH) }, label = { Text(Arabic.digits(n)) })
            }
            FilterChip(selected = false, onClick = { custom = true }, label = { Text("هدف مخصص") })
        }
        Spacer(Modifier.height(12.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Stat("اليوم", Arabic.digits(t.todayTotal))
                Stat("الإجمالي", Arabic.digits(t.lifetime))
            }
        }
        OutlinedButton(onClick = { confirmReset = true }, modifier = Modifier.padding(top = 10.dp)) { Text("↺ تصفير العدّاد", color = UColors.Gold) }

        if (log.isNotEmpty()) {
            Spacer(Modifier.height(14.dp))
            Text("سجل الإنجازات", color = UColors.CreamDim, fontSize = 13.sp, modifier = Modifier.align(Alignment.Start))
            log.take(8).forEach { (date, ph, target) ->
                GlassCard(Modifier.fillMaxWidth().padding(top = 6.dp)) {
                    Text("🏁 ${TasbihPhrases.get(ph)} × ${Arabic.digits(target)}", color = UColors.Cream)
                    Text(Arabic.digits(date), color = UColors.CreamDim, fontSize = 12.sp)
                }
            }
        }
    }

    if (custom) {
        var text by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { custom = false },
            title = { Text("الهدف المخصص") },
            text = {
                OutlinedTextField(
                    value = text, onValueChange = { text = it.filter(Char::isDigit).take(6) },
                    singleLine = true, label = { Text("العدد") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    text.toIntOrNull()?.takeIf { it > 0 }?.let { store.setTasbihTarget(it); WidgetRenderer.updateStyle(ctx, WidgetStyle.TASBIH) }
                    custom = false
                }) { Text("حفظ") }
            },
            dismissButton = { TextButton(onClick = { custom = false }) { Text("إلغاء") } },
        )
    }
    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("تصفير العدّاد؟") },
            confirmButton = { TextButton(onClick = { store.tasbihReset(); WidgetRenderer.updateStyle(ctx, WidgetStyle.TASBIH); confirmReset = false }) { Text("تصفير") } },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("إلغاء") } },
        )
    }
}

// ============================================================ المفضلة
@Composable
fun FavoritesScreen(store: Store, nav: NavController) {
    val favs by store.observeAsState { store.favorites() }
    val list = AdhkarData.all.filter { it.id in favs }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Title("المفضلة") }
        if (list.isEmpty()) item {
            GlassCard(Modifier.fillMaxWidth()) {
                Text("لا توجد أذكار مفضلة بعد. افتح أي ذكر واضغط «♡ مفضلة» ليظهر هنا، ويمكنك اختيار «المفضلة» كمصدر للودجت من الإعدادات.", color = UColors.CreamDim)
            }
        }
        items(list, key = { it.id }) { z ->
            GlassCard(Modifier.fillMaxWidth(), glow = true, onClick = { open(nav, z) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${z.category.emoji} ${z.title}", color = UColors.Gold, fontWeight = FontWeight.Bold)
                        Text(z.text.take(120) + if (z.text.length > 120) "…" else "", color = UColors.Cream, fontSize = 15.sp, maxLines = 3)
                        Text(if (z.count > 0) "التكرار: ${Arabic.digits(z.count)}" else "بلا عدد محدد", color = UColors.CreamDim, fontSize = 12.sp)
                    }
                    TextButton(onClick = { store.toggleFavorite(z.id) }) { Text("♥", color = UColors.Gold, fontSize = 24.sp) }
                }
            }
        }
    }
}

// ============================================================ السجل
private val DAY_NAMES = listOf("الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد")

@Composable
fun StatsScreen(store: Store, settings: Settings, nav: NavController) {
    val stats by store.observeAsState { store.dayStats(7) }
    val progress by store.observeAsState { store.todayProgress() }
    val maxTaps = stats.maxOf { it.taps }.coerceAtLeast(1)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { nav.popBackStack() }) { Text("→ رجوع", color = UColors.GoldSoft) }
            Title("سجل الأذكار")
        }
        if (!settings.statsEnabled) {
            GlassCard(Modifier.fillMaxWidth()) { Text("تسجيل الإحصائيات متوقف من الإعدادات.", color = UColors.CreamDim) }
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Text("آخر ٧ أيام (عدد الضغطات)", color = UColors.CreamDim, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth().height(170.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Bottom) {
                stats.forEach { d ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(Arabic.digits(d.taps), color = UColors.Cream, fontSize = 11.sp)
                        Box(
                            Modifier.padding(vertical = 3.dp).width(24.dp).height((110f * d.taps / maxTaps).coerceAtLeast(3f).dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(Brush.verticalGradient(listOf(UColors.GoldSoft, UColors.Emerald))),
                        )
                        Text(DAY_NAMES[d.date.dayOfWeek.value - 1].take(3), color = UColors.CreamDim, fontSize = 10.sp)
                    }
                }
            }
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Text("تقدّم اليوم حسب القسم", color = UColors.CreamDim, fontSize = 12.sp)
            Category.values().forEach { c ->
                val (done, total) = categoryProgress(c, progress)
                if (total > 0) {
                    Text("${c.emoji} ${c.title}: ${Arabic.digits(done)}/${Arabic.digits(total)}", color = UColors.Cream, modifier = Modifier.padding(top = 8.dp))
                    LinearProgressIndicator(
                        progress = { done.toFloat() / total },
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp).height(5.dp).clip(CircleShape),
                        color = UColors.Gold, trackColor = UColors.Gold.copy(alpha = 0.2f),
                    )
                }
            }
        }
    }
}
