package com.unsee.app.core

import java.net.URLDecoder
import java.net.URLEncoder
import java.time.LocalDate
import java.time.temporal.ChronoUnit

// ============================================================================ الأساسيات التي لا نفرّط فيها
/** أمور يسأل عنها الرفيق كل يوم. «لسه» لا تُحسب ذنبًا؛ هي تذكير لطيف فقط. */
enum class Essential(val key: String, val prayer: Prayer?) {
    FAJR("fajr", Prayer.FAJR),
    DHUHR("dhuhr", Prayer.DHUHR),
    ASR("asr", Prayer.ASR),
    MAGHRIB("maghrib", Prayer.MAGHRIB),
    ISHA("isha", Prayer.ISHA),
    ADHKAR_AM("adhkar_am", null),
    ADHKAR_PM("adhkar_pm", null),
    QURAN("quran", null),
    ;

    /** مفتاح القيد في الدفتر؛ ثابت لكل يوم فلا يتكرر. */
    val ledgerKey: String get() = "ess:$key"

    companion object {
        fun fromKey(k: String): Essential? = values().firstOrNull { it.key == k }
    }
}

// ============================================================================ دفتر الحسنات والسيئات
enum class LedgerType { GOOD, SIN }

/**
 * قيد واحد في دفتر اليوم. [key] غير فارغ للقيود التلقائية (أساسيات/التزام بخطة) كي لا تُحسب مرتين؛
 * وفارغ للقيود التي يكتبها المستخدم.
 */
data class LedgerEntry(
    val id: String,
    val ts: Long,
    val date: String,
    val type: LedgerType,
    val title: String,
    val key: String = "",
)

object LedgerCodec {
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun dec(s: String) = runCatching { URLDecoder.decode(s, "UTF-8") }.getOrDefault("")

    fun encode(list: List<LedgerEntry>): String =
        list.joinToString("\n") { "${it.id}|${it.ts}|${it.date}|${it.type.name}|${enc(it.title)}|${enc(it.key)}" }

    fun decode(raw: String): List<LedgerEntry> = raw.split('\n').mapNotNull { line ->
        val p = line.split('|')
        if (p.size != 6) return@mapNotNull null
        val ts = p[1].toLongOrNull() ?: return@mapNotNull null
        val type = runCatching { LedgerType.valueOf(p[3]) }.getOrNull() ?: return@mapNotNull null
        LedgerEntry(p[0], ts, p[2], type, dec(p[4]), dec(p[5]))
    }
}

data class DayScore(val good: Int, val sin: Int) {
    /** نسبة الحسنات من المجموع (0.5 إن لم يُسجَّل شيء، لتبقى شريط الميزان في المنتصف). */
    val goodShare: Float get() = if (good + sin == 0) 0.5f else good.toFloat() / (good + sin)
}

object LedgerLogic {
    fun score(entries: List<LedgerEntry>): DayScore =
        DayScore(entries.count { it.type == LedgerType.GOOD }, entries.count { it.type == LedgerType.SIN })

    /** عنوان موحّد للمقارنة بين الأيام (إزالة الفراغات الزائدة وحرف المسافة). */
    fun norm(title: String): String = title.trim().replace(Regex("\\s+"), " ")

    /** هل القيد مما يكتبه المستخدم بنفسه (يصلح ليكون «عادة» نذكّره بها)؟ */
    private fun isHabitCandidate(e: LedgerEntry) = e.type == LedgerType.GOOD && e.key.isEmpty() && norm(e.title).isNotEmpty()

    /** عدد الأيام المتتالية التي سُجّل فيها هذا العمل، تنتهي عند اليوم أو أمس (أيهما أحدث). */
    fun streak(title: String, byDate: Map<String, List<LedgerEntry>>, today: LocalDate): Int {
        val n = norm(title)
        fun done(d: LocalDate) = byDate[d.toString()].orEmpty().any { isHabitCandidate(it) && norm(it.title) == n }
        var d = if (done(today)) today else today.minusDays(1)
        var count = 0
        while (done(d) && count < 400) { count++; d = d.minusDays(1) }
        return count
    }

    /** الأعمال الصالحة التي سُجّلت أمس ولم تُسجَّل اليوم بعد، الأطول سلسلةً أولًا. */
    fun habitsToRemind(byDate: Map<String, List<LedgerEntry>>, today: LocalDate, max: Int = 2): List<String> {
        val todayTitles = byDate[today.toString()].orEmpty().filter { isHabitCandidate(it) }.map { norm(it.title) }.toSet()
        val yesterday = byDate[today.minusDays(1).toString()].orEmpty().filter { isHabitCandidate(it) }
        return yesterday.map { norm(it.title) }.distinct()
            .filter { it !in todayTitles }
            .sortedByDescending { streak(it, byDate, today.minusDays(1)) }
            .take(max)
    }

    /** الأعمال الصالحة التي كتبها المستخدم في آخر الأيام مع سلاسلها (الأطول أولًا)، لعرضها كشرائح سريعة. */
    fun habitChips(byDate: Map<String, List<LedgerEntry>>, today: LocalDate): List<Pair<String, Int>> =
        byDate.values.flatten().filter { isHabitCandidate(it) }.map { norm(it.title) }.distinct()
            .map { it to streak(it, byDate, today) }
            .sortedByDescending { it.second }
            .take(8)
}

// ============================================================================ خطة الإقلاع عن ذنب/عادة
data class QuitPlan(
    val id: String,
    val sin: String,
    val replacement: String = "",
    val times: List<Int> = listOf(14 * 60, 21 * 60),
    val startDate: String,
    val lastSlip: String = "",
    val lastKept: String = "",
    val bestStreak: Int = 0,
    val active: Boolean = true,
)

object PlanCodec {
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun dec(s: String) = runCatching { URLDecoder.decode(s, "UTF-8") }.getOrDefault("")

    fun encode(list: List<QuitPlan>): String = list.joinToString("\n") {
        listOf(
            it.id, enc(it.sin), enc(it.replacement), it.times.joinToString(","), it.startDate,
            it.lastSlip, it.lastKept, it.bestStreak, if (it.active) 1 else 0,
        ).joinToString("|")
    }

    fun decode(raw: String): List<QuitPlan> = raw.split('\n').mapNotNull { line ->
        val p = line.split('|')
        if (p.size != 9) return@mapNotNull null
        QuitPlan(
            id = p[0],
            sin = dec(p[1]),
            replacement = dec(p[2]),
            times = p[3].split(',').mapNotNull { it.toIntOrNull()?.coerceIn(0, 1439) }.take(3),
            startDate = p[4],
            lastSlip = p[5],
            lastKept = p[6],
            bestStreak = p[7].toIntOrNull() ?: 0,
            active = p[8] == "1",
        )
    }
}

object PlanLogic {
    /** أيام الالتزام الحالية: من آخر وقعة (أو من بداية الخطة) حتى اليوم. وقعة اليوم = صفر. */
    fun cleanDays(p: QuitPlan, today: LocalDate): Int {
        val base = (if (p.lastSlip.isNotBlank()) p.lastSlip else p.startDate).let { runCatching { LocalDate.parse(it) }.getOrNull() } ?: return 0
        return ChronoUnit.DAYS.between(base, today).toInt().coerceAtLeast(0)
    }

    fun afterSlip(p: QuitPlan, today: LocalDate): QuitPlan =
        p.copy(lastSlip = today.toString(), bestStreak = maxOf(p.bestStreak, cleanDays(p, today)))

    fun afterKept(p: QuitPlan, today: LocalDate): QuitPlan =
        p.copy(lastKept = today.toString(), bestStreak = maxOf(p.bestStreak, cleanDays(p, today)))

    /** أقرب تذكير قادم عبر كل الخطط النشطة. الخطة التي سجّل المستخدم التزامه بها اليوم لا تُذكَّر إلا من الغد. */
    fun nextReminder(plans: List<QuitPlan>, now: java.time.ZonedDateTime): Pair<QuitPlan, java.time.ZonedDateTime>? {
        var best: Pair<QuitPlan, java.time.ZonedDateTime>? = null
        for (p in plans) {
            if (!p.active || p.times.isEmpty()) continue
            for (offset in 0..1) {
                val date = now.toLocalDate().plusDays(offset.toLong())
                if (offset == 0 && p.lastKept == date.toString()) continue
                for (m in p.times) {
                    val t = date.atTime(m / 60, m % 60).atZone(now.zone)
                    if (t.isAfter(now) && (best == null || t.isBefore(best.second))) best = p to t
                }
            }
        }
        return best
    }
}

// ============================================================================ العناصر المعلّقة في الفقاعة
/** عنصر ينتظر في الفقاعة (ذكر/صلاة/عادة/خطة). [priority] = لا يُلغى ولا يُؤجَّل ولا يُمسح إلا بالرد عليه. */
data class PendingItem(
    val kind: LogKind,
    val ref: String,
    val title: String,
    val text: String,
    val sub: String?,
    val primary: String,
    val secondary: String,
    val open: String,
    val openRoute: String,
    val notifId: Int,
    val priority: Boolean,
    val ts: Long,
)

object PendingCodec {
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun dec(s: String) = runCatching { URLDecoder.decode(s, "UTF-8") }.getOrDefault("")

    fun encode(list: List<PendingItem>): String = list.joinToString("\n") {
        listOf(
            it.kind.name, enc(it.ref), enc(it.title), enc(it.text), enc(it.sub ?: ""), enc(it.primary), enc(it.secondary),
            enc(it.open), enc(it.openRoute), it.notifId, if (it.priority) 1 else 0, it.ts,
        ).joinToString("|")
    }

    fun decode(raw: String): List<PendingItem> = raw.split('\n').mapNotNull { line ->
        val p = line.split('|')
        if (p.size != 12) return@mapNotNull null
        val kind = runCatching { LogKind.valueOf(p[0]) }.getOrNull() ?: return@mapNotNull null
        PendingItem(
            kind, dec(p[1]), dec(p[2]), dec(p[3]), dec(p[4]).ifEmpty { null }, dec(p[5]), dec(p[6]), dec(p[7]), dec(p[8]),
            p[9].toIntOrNull() ?: 0, p[10] == "1", p[11].toLongOrNull() ?: 0L,
        )
    }

    /** الأولوية أولًا ثم الأحدث. */
    fun ordered(list: List<PendingItem>): List<PendingItem> = list.sortedWith(compareByDescending<PendingItem> { it.priority }.thenByDescending { it.ts })
}
