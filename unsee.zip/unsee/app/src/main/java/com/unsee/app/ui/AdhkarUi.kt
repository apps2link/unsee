package com.unsee.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.unsee.app.core.Arabic
import com.unsee.app.core.ArabicText
import com.unsee.app.data.AdhkarData
import com.unsee.app.data.Category
import com.unsee.app.data.Settings
import com.unsee.app.data.Store
import com.unsee.app.data.Zikr
import com.unsee.app.data.ZikrKind
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ============================================================ مكتبة الأذكار + البحث
@Composable
fun AdhkarScreen(store: Store, nav: NavController) {
    val progress by store.observeAsState { store.todayProgress() }
    val favs by store.observeAsState { store.favorites() }
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf<Category?>(null) }
    var onlyFav by remember { mutableStateOf(false) }
    val active = query.isNotBlank() || onlyFav
    val results = remember(query, filter, onlyFav, favs) {
        val base = if (query.isBlank()) (filter?.let { AdhkarData.forCategory(it) } ?: AdhkarData.all)
        else AdhkarData.search(query, filter, 200)
        (if (onlyFav) base.filter { it.id in favs } else base).take(80)
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { ScreenHeader("مكتبة الأذكار") }
        item {
            OutlinedTextField(
                value = query, onValueChange = { query = it.take(60) }, singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("ابحث في الأذكار…", color = UColors.CreamDim) },
                leadingIcon = { Icon(Ico.Search, null, tint = UColors.Gold) },
                trailingIcon = { if (query.isNotEmpty()) IconBtn(Ico.Close, "مسح", { query = "" }, UColors.CreamDim) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = UColors.Cream, unfocusedTextColor = UColors.Cream,
                    focusedBorderColor = UColors.Gold, unfocusedBorderColor = UColors.Gold.copy(alpha = 0.4f), cursorColor = UColors.Gold,
                ),
            )
        }
        item {
            ChipRow(listOf<Category?>(null) + Category.values().toList(), { it == filter }, { it?.title ?: "كل الأقسام" }) { filter = it }
        }
        item {
            ChipRow(listOf(false, true), { it == onlyFav }, { if (it) "المفضلة فقط" else "كل الأذكار" }) { onlyFav = it }
        }
        if (active) {
            if (results.isEmpty()) item {
                EmptyState(Ico.Search, "لا نتائج", "جرّب كلمة أخرى (يتجاهل البحث التشكيل)، أو اكتب رقم الذكر في الكتاب، أو غيّر القسم.", "مسح البحث") { query = ""; filter = null; onlyFav = false }
            } else items(results, key = { it.id }) { z ->
                GlassCard(Modifier.fillMaxWidth(), onClick = { nav.navigate(AdhkarData.sectionKeyOf(z)?.let { "section/$it?start=${z.id}" } ?: "list/${z.category.name}?start=${z.id}") }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconBadge(z.category.icon(), 36.dp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(z.title, color = UColors.Gold, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(z.text, color = UColors.Cream, maxLines = 2, fontSize = 14.sp)
                            Text(z.category.title + (if (z.bookNo > 0) " · ذكر رقم ${Arabic.digits(z.bookNo)}" else ""), color = UColors.CreamDim, fontSize = 11.sp)
                        }
                    }
                }
            }
        } else {
            val shown = AdhkarData.sections.filter { filter == null || it.category == filter }
            items(shown, key = { it.key }) { sec ->
                val (done, total) = listProgress(sec.items, progress)
                GlassCard(Modifier.fillMaxWidth(), onClick = { nav.navigate("section/${sec.key}") }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconBadge(sec.category.icon(), 48.dp)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(sec.title, color = UColors.Cream, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text("${sec.category.title} · ${Arabic.digits(sec.items.count { it.countable })} ذكرًا", color = UColors.CreamDim, fontSize = 12.sp)
                        }
                        Icon(Ico.Forward, null, tint = UColors.Gold)
                    }
                    if (total > 0) {
                        Spacer(Modifier.height(10.dp))
                        GlowProgressBar(progress = { done.toFloat() / total }, modifier = Modifier.fillMaxWidth().height(5.dp).clip(CircleShape))
                    }
                }
            }
        }
    }
}

// ============================================================ شاشة القراءة
@Composable
fun AdhkarPagerScreen(title: String, cat: Category, items: List<Zikr>, posKey: String, startId: String, store: Store, s: Settings, nav: NavController) {
    val ctx = LocalContext.current
    val progress by store.observeAsState { store.todayProgress() }
    val favs by store.observeAsState { store.favorites() }
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    var panel by remember { mutableStateOf(false) }
    val startPage = remember(posKey, startId) {
        val byId = items.indexOfFirst { it.id == startId }
        if (byId >= 0) byId else store.lastPageKey(posKey).coerceIn(0, items.lastIndex)
    }
    val pager = rememberPagerState(initialPage = startPage) { items.size }
    LaunchedEffect(pager.currentPage) { store.setLastPageKey(posKey, pager.currentPage) } // يحفظ موضع القراءة
    val (done, total) = listProgress(items, progress)

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        ScreenHeader(title, onBack = { nav.popBackStack() }) {
            Text("${Arabic.digits(pager.currentPage + 1)}/${Arabic.digits(items.size)}", color = UColors.CreamDim, fontSize = 13.sp)
            IconBtn(Ico.Tune, "إعدادات القراءة", { panel = !panel })
        }
        AnimatedVisibility(panel) {
            GlassCard(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                LabeledSlider("حجم الخط", s.readerScale, 0.7f..1.8f) { v -> store.edit { putFloat("reader_scale", v) } }
                LabeledSlider("تباعد الأسطر", s.lineSpacing, 1.4f..2.6f) { v -> store.edit { putFloat("line_spacing", v) } }
                SwitchRow("وضع القراءة الليلي", "خلفية داكنة مريحة أثناء القراءة فقط", s.readerNight) { v -> store.edit { putBoolean("reader_night", v) } }
            }
        }
        if (total > 0) {
            GlowProgressBar(progress = { done.toFloat() / total }, modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape))
            Text("أُنجز ${Arabic.digits(done)} من ${Arabic.digits(total)}", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        }

        HorizontalPager(state = pager, modifier = Modifier.weight(1f).padding(top = 8.dp), pageSpacing = 16.dp, key = { items[it].id }) { page ->
            val z = items[page]
            val p = progress[z.id] ?: 0
            val isFav = z.id in favs
            val finished = z.count > 0 && p >= z.count
            Column(Modifier.fillMaxSize()) {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    Column(Modifier.verticalScroll(rememberScrollState()).padding(vertical = 6.dp)) {
                        GlassCard(Modifier.fillMaxWidth().animateContentSize(), glow = isFav) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text(z.title, color = UColors.Gold, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
                                if (finished) {
                                    Icon(Ico.CheckCircle, "تم", tint = UColors.Gold)
                                    Text(" تم", color = UColors.Gold, fontSize = 13.sp)
                                }
                            }
                            Spacer(Modifier.height(12.dp))
                            ZikrText(z.text, s, Modifier.fillMaxWidth())
                            if (z.kind != com.unsee.app.data.ZikrKind.NOTE) {
                                SpeakPill(
                                    z.text,
                                    if (cat == Category.MORNING || cat == Category.EVENING) com.unsee.app.core.VoiceSection.ADHKAR_DAY else com.unsee.app.core.VoiceSection.ADHKAR_SLEEP,
                                    z.title, Modifier.padding(top = 8.dp),
                                )
                            }
                            val eveningNotes = if (cat == Category.EVENING) z.footnotes.filter { it.text.startsWith("وإذا أمسى") } else emptyList()
                            if (eveningNotes.isNotEmpty()) {
                                Spacer(Modifier.height(10.dp))
                                Text("صيغة المساء (كما في الكتاب)", color = UColors.Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                eveningNotes.forEach { f ->
                                    Text(f.text, color = UColors.Cream, fontSize = 14.sp, modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
                                }
                            }
                            z.countText?.let {
                                Spacer(Modifier.height(8.dp))
                                Text("التكرار في الكتاب: $it", color = UColors.Gold, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                            }
                            if (z.kind == ZikrKind.NOTE || z.kind == ZikrKind.FADL) {
                                Spacer(Modifier.height(6.dp))
                                Text(if (z.kind == ZikrKind.FADL) "للقراءة والتذكّر (بلا عدّاد)" else "تنبيه من الكتاب (بلا عدّاد)", color = UColors.CreamDim, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                            }
                            Spacer(Modifier.height(12.dp))
                            Text("المصدر: ${z.source}", color = UColors.CreamDim, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                            z.grade?.let { Text(it, color = UColors.Gold, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()) }
                            z.note?.let { Text(it, color = UColors.CreamDim, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 6.dp)) }
                            val restNotes = z.footnotes.filter { it !in eveningNotes }
                            if (restNotes.isNotEmpty()) {
                                Spacer(Modifier.height(12.dp))
                                Text("التخريج والحواشي (من الكتاب)", color = UColors.Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                restNotes.forEach { f ->
                                    Text(
                                        f.text,
                                        color = UColors.CreamDim, fontSize = 12.sp,
                                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                                    )
                                }
                            }
                        }
                    }
                }
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    if (z.countable) CounterButton(
                        count = p, target = z.count, size = 150.dp,
                        caption = if (z.count > 0) "من ${Arabic.digits(z.count)}" else "بلا عدد محدد",
                        reduceMotion = s.reduceMotion,
                        onTap = {
                            val r = store.tapZikr(z)
                            if (!r.counted) {
                                if (page < items.lastIndex) scope.launch { pager.animateScrollToPage(page + 1) }
                            } else {
                                feedback(view, s, r.completed)
                                if (r.completed && page < items.lastIndex) scope.launch { delay(600); pager.animateScrollToPage(page + 1) }
                            }
                        },
                    )
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                        IconBtn(Ico.Back, "السابق", { if (page > 0) scope.launch { pager.animateScrollToPage(page - 1) } })
                        if (z.countable) IconBtn(if (isFav) Ico.Heart else Ico.HeartOutline, "المفضلة", { store.toggleFavorite(z.id) })
                        IconBtn(Ico.Copy, "نسخ", { copyZikr(ctx, z) })
                        IconBtn(Ico.Share, "مشاركة", { shareZikr(ctx, z) })
                        if (z.countable) IconBtn(Ico.Refresh, "إعادة العدّ", { store.resetZikr(z) })
                        IconBtn(Ico.Forward, "التالي", { if (page < items.lastIndex) scope.launch { pager.animateScrollToPage(page + 1) } })
                    }
                }
            }
        }
    }
}
