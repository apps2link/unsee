package com.unsee.app.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.unsee.app.core.Appearance
import com.unsee.app.core.LiveClock
import com.unsee.app.core.SunWindow
import com.unsee.app.data.CompanionStore
import com.unsee.app.data.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId

/**
 * حالة السماء الحية.
 *  - [uiDay]: 0/1 متحرك (لمدة 1.6 ث عند التبديل فقط) لألوان البطاقات والنصوص؛ يُقرأ في التركيب.
 *  - [skyBlend] / [sunP] / [moonP]: قيم متدرجة ناعمة تُقرأ في مرحلة الرسم فقط، فلا تُعيد تركيب الواجهة كل إطار.
 */
class LiveSky(
    val uiDay: Float,
    val skyBlend: State<Float>,
    val sunP: State<Float>,
    val moonP: State<Float>,
    val phaseLabel: String,
)

val LocalReduceMotion = staticCompositionLocalOf { false }

private fun nowMinutes(): Float {
    val t = LocalTime.now()
    return t.hour * 60f + t.minute + t.second / 60f
}

/**
 * يحسب السماء الحية من: وضع المظهر، الوقت الحقيقي (يتجدد كل دقيقة وعند العودة للتطبيق فقط)،
 * وشروق وغروب مدينة المستخدم (المحفوظة في «رفيق أُنسي»؛ وإلا القاهرة، وإلا 6:00 و18:00).
 */
@Composable
fun rememberLiveSky(settings: Settings): LiveSky {
    val ctx = LocalContext.current
    val sysDark = isSystemInDarkTheme()
    var minutes by remember { mutableFloatStateOf(nowMinutes()) }
    var window by remember { mutableStateOf(SunWindow.DEFAULT) }
    var refresh by remember { mutableIntStateOf(0) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { minutes = nowMinutes(); refresh++ }
    LaunchedEffect(Unit) {
        while (true) {
            delay(60_000L)
            minutes = nowMinutes()
        }
    }
    LaunchedEffect(refresh) {
        window = withContext(Dispatchers.Default) {
            runCatching {
                val c = CompanionStore.get(ctx).settings()
                LiveClock.sunWindow(c.lat, c.lng, LocalDate.now(), ZoneId.systemDefault())
            }.getOrDefault(SunWindow.DEFAULT)
        }
    }

    val auto = settings.appearance == Appearance.AUTO_TIME
    val target = LiveClock.targetBlend(settings.appearance, minutes, window, sysDark)
    val ms = if (settings.reduceMotion) 0 else 1600
    val sky = animateFloatAsState(target, tween(ms, easing = FastOutSlowInEasing), label = "skyBlend")
    val uiTarget = LiveClock.uiDay(target)
    val ui by animateFloatAsState(uiTarget, tween(ms, easing = FastOutSlowInEasing), label = "uiDay")

    val sunTarget = if (auto) LiveClock.sunProgress(minutes, window) else 0.42f
    val moonTarget = if (auto) LiveClock.moonProgress(minutes, window) else 0.45f
    val sun = animateFloatAsState(sunTarget, tween(ms), label = "sunP")
    val moon = animateFloatAsState(moonTarget, tween(ms), label = "moonP")

    val label = LiveClock.phase(if (auto) minutes else if (target >= 0.5f) 12 * 60f else 0f, window).label
    return LiveSky(ui, sky, sun, moon, label)
}

/** سماء ثابتة للمعاينات الصغيرة (بطاقات الثيمات) دون ساعة ولا حركة. */
@Composable
fun rememberStaticSky(day: Float, sun: Float = 0.42f, moon: Float = 0.45f): LiveSky =
    remember(day, sun, moon) { LiveSky(day, mutableStateOf(day), mutableStateOf(sun), mutableStateOf(moon), "") }
