package com.unsee.app.ui

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import com.unsee.app.core.Arabic
import com.unsee.app.core.RingConfig
import com.unsee.app.core.RingDesign
import com.unsee.app.core.ringFraction
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/** حالة العدّاد وقت الرسم. */
class RingState(val count: Int, val target: Int, val name: String) {
    val fraction: Float get() = ringFraction(count, target)
    val done: Boolean get() = target > 0 && count >= target
}

/**
 * يرسم أحد 15 تصميمًا للعدّاد الدائري على أي Canvas (داخل التطبيق متحركًا، أو في Bitmap للودجت).
 * - [tm]: الزمن بالثواني (يدور كل 3600 ثانية؛ كل الحركات بدورات تقسم 3600 فلا تظهر قفزة).
 * - [kick]: دفعة الضغط من 1 (لحظة الضغط) إلى 0 (انتهى التأثير).
 * - لا يستخدم BlurMaskFilter (غير مدعوم دائمًا على Canvas المسرّع)؛ التوهج طبقات خطوط شفافة.
 */
class RingPainter {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val rect = RectF()
    private val path = Path()
    private val path2 = Path()

    private class Pal(
        val face1: Int, val face2: Int, val ring1: Int, val ring2: Int, val digit: Int, val sub: Int,
    )

    private class G(
        val cx: Float, val cy: Float, val r: Float, val outerRadius: Float, val sw: Float,
        val f: Float, val t: Float, val kick: Float, val glow: Float, val fa: Float,
        val pal: Pal, val cfg: RingConfig, val st: RingState, val dens: Float, val dark: Boolean,
    ) {
        val inner: Float get() = outerRadius - sw * 0.6f
    }

    // ------------------------------------------------------------------ نقطة الدخول
    fun draw(c: Canvas, w: Float, h: Float, cfg: RingConfig, st: RingState, dark: Boolean, tm: Float, kick: Float, density: Float) {
        val animated = cfg.animate
        val t = if (animated) tm else 2.3f
        val k = if (animated) kick.coerceIn(0f, 1f) else 0f
        val cx = w / 2f
        val cy = h / 2f
        val d = min(w, h) * cfg.ringSize.coerceIn(0.5f, 1.15f)
        val r = d / 2f
        val sw = d * 0.062f * cfg.thickness * (1f + 0.30f * k)
        val g = G(cx, cy, r, r * 0.84f, sw, st.fraction, t, k, cfg.glow.coerceIn(0f, 1.5f), cfg.bgAlpha / 100f, palette(cfg, dark), cfg, st, density, dark)
        when (cfg.design) {
            RingDesign.GOLD_HALO -> goldHalo(c, g)
            RingDesign.EMERALD_GLASS -> emeraldGlass(c, g)
            RingDesign.CRESCENT_STARS -> crescentStars(c, g)
            RingDesign.LIGHT_ORBIT -> lightOrbit(c, g)
            RingDesign.GRADIENT_PROGRESS -> gradientProgress(c, g)
            RingDesign.WATER_RIPPLE -> waterRipple(c, g)
            RingDesign.GALAXY -> galaxy(c, g)
            RingDesign.LUXE_GEOMETRY -> luxeGeometry(c, g)
            RingDesign.PULSE -> pulse(c, g)
            RingDesign.DEPTH_3D -> depth3d(c, g)
            RingDesign.LEAF_NATURE -> leafNature(c, g)
            RingDesign.CLEAR_GLASS -> clearGlass(c, g)
            RingDesign.MOON_NIGHT -> moonNight(c, g)
            RingDesign.CALLIGRAPHY -> calligraphy(c, g)
            RingDesign.SOFT_FIRE -> softFire(c, g)
        }
        if (st.done && animated) {
            val pu = 0.6f + 0.4f * sin(2f * PI.toFloat() * t / 3f)
            for (i in 1..3) {
                stroke(al(g.pal.ring2, g.glow * 0.10f * pu / i), sw * (1f + i * 0.9f))
                c.drawCircle(cx, cy, g.outerRadius, p)
            }
        }
    }

    // ------------------------------------------------------------------ الألوان
    private fun hx(v: Long): Int = v.toInt()

    private fun palette(cfg: RingConfig, dark: Boolean): Pal {
        val b = base(cfg.design, dark)
        val ring1 = if (cfg.ringColor != 0L) hx(cfg.ringColor) else b.ring1
        val ring2 = if (cfg.ringColor != 0L) mix(hx(cfg.ringColor), Color.WHITE, 0.38f) else b.ring2
        val f1 = if (cfg.bgColor != 0L) hx(cfg.bgColor) else b.face1
        val f2 = if (cfg.bgColor != 0L) mix(hx(cfg.bgColor), Color.BLACK, 0.25f) else b.face2
        val dg = if (cfg.digitColor != 0L) hx(cfg.digitColor) else b.digit
        return Pal(f1, f2, ring1, ring2, dg, b.sub)
    }

    private fun base(d: RingDesign, dark: Boolean): Pal = when (d) {
        RingDesign.GOLD_HALO -> if (dark) Pal(hx(0xFF0B2A22), hx(0xFF04120F), hx(0xFFF2C14E), hx(0xFFFFE9A8), hx(0xFFFFF4D6), hx(0xFFE2B857))
        else Pal(hx(0xFFFFFBEF), hx(0xFFF3E6C2), hx(0xFFB8861B), hx(0xFFE8B84A), hx(0xFF3A2A06), hx(0xFF8A6410))
        RingDesign.EMERALD_GLASS -> if (dark) Pal(hx(0x552EE6A8), hx(0x11062A20), hx(0xFF2EE6A8), hx(0xFF0B7A5A), hx(0xFFFFFFFF), hx(0xFFB5F5DD))
        else Pal(hx(0x663ACFA0), hx(0x22FFFFFF), hx(0xFF0F8F6B), hx(0xFF5BD6A8), hx(0xFF08382B), hx(0xFF0F6B52))
        RingDesign.CRESCENT_STARS -> if (dark) Pal(hx(0xFF14214F), hx(0xFF070C26), hx(0xFFE2B857), hx(0xFFFFE6A3), hx(0xFFFFF6DC), hx(0xFFE2B857))
        else Pal(hx(0xFFEAF0FF), hx(0xFFCDD9F5), hx(0xFF3B4FA0), hx(0xFF7F95E0), hx(0xFF14214F), hx(0xFF3B4FA0))
        RingDesign.LIGHT_ORBIT -> if (dark) Pal(hx(0xFF0A1A3A), hx(0xFF050B1C), hx(0xFF5BD9FF), hx(0xFFC9F3FF), hx(0xFFF2FBFF), hx(0xFF8FDFFF))
        else Pal(hx(0xFFEFF9FF), hx(0xFFD3EEFA), hx(0xFF1479A8), hx(0xFF5BC0E8), hx(0xFF0B2A3F), hx(0xFF1479A8))
        RingDesign.GRADIENT_PROGRESS -> if (dark) Pal(hx(0xFF182233), hx(0xFF0B111B), hx(0xFF5BD6A8), hx(0xFFB8F0D2), hx(0xFFFFFFFF), hx(0xFFC9D4E6))
        else Pal(hx(0xFFFFFFFF), hx(0xFFEEF2F8), hx(0xFF0E7A5F), hx(0xFF5BC4A0), hx(0xFF14233A), hx(0xFF4C5E78))
        RingDesign.WATER_RIPPLE -> if (dark) Pal(hx(0xFF0B2E4A), hx(0xFF04162A), hx(0xFF4FC3F7), hx(0xFF0288D1), hx(0xFFFFFFFF), hx(0xFFB3E5FC))
        else Pal(hx(0xFFE3F5FF), hx(0xFFC4E6FA), hx(0xFF0288D1), hx(0xFF4FC3F7), hx(0xFF06354F), hx(0xFF0B6FA8))
        RingDesign.GALAXY -> if (dark) Pal(hx(0xFF2A1458), hx(0xFF05030F), hx(0xFF9EC5FF), hx(0xFFFF9ECF), hx(0xFFFFFFFF), hx(0xFFD0C4F5))
        else Pal(hx(0xFFF1E9FF), hx(0xFFD8C8F5), hx(0xFF5B3FC4), hx(0xFFC4488F), hx(0xFF2A1458), hx(0xFF5B3FC4))
        RingDesign.LUXE_GEOMETRY -> if (dark) Pal(hx(0xFF0D4A3B), hx(0xFF04251E), hx(0xFFE2B857), hx(0xFFFFE9A8), hx(0xFFFFF4D6), hx(0xFFF3D98B))
        else Pal(hx(0xFFFFF8E6), hx(0xFFF1E2B8), hx(0xFF9A6F12), hx(0xFFD9A93A), hx(0xFF083D30), hx(0xFF0F6B52))
        RingDesign.PULSE -> if (dark) Pal(hx(0xFF0F3D3A), hx(0xFF082523), hx(0xFF4DE0C8), hx(0xFFB7FFF3), hx(0xFFFFFFFF), hx(0xFFA8EFE4))
        else Pal(hx(0xFFE6FFFB), hx(0xFFC8F3EC), hx(0xFF0E9C86), hx(0xFF4DE0C8), hx(0xFF06352F), hx(0xFF0E7F6D))
        RingDesign.DEPTH_3D -> if (dark) Pal(hx(0xFF3A4A58), hx(0xFF121A22), hx(0xFF5CE0B8), hx(0xFF1A9E7A), hx(0xFFF5FBFF), hx(0xFFB8C8D6))
        else Pal(hx(0xFFFFFFFF), hx(0xFFC9D4DE), hx(0xFF18A27C), hx(0xFF5CE0B8), hx(0xFF1F2D3A), hx(0xFF51657A))
        RingDesign.LEAF_NATURE -> if (dark) Pal(hx(0xFF1E5A34), hx(0xFF0B2A18), hx(0xFF8FE37A), hx(0xFF3FA55A), hx(0xFFF1FFE8), hx(0xFFC5EBB3))
        else Pal(hx(0xFFF2FFE9), hx(0xFFD6F0C2), hx(0xFF3C8F3A), hx(0xFF86CC62), hx(0xFF16401F), hx(0xFF3C8F3A))
        RingDesign.CLEAR_GLASS -> if (dark) Pal(hx(0x33FFFFFF), hx(0x11FFFFFF), hx(0xFFFFFFFF), hx(0xFFB8E6FF), hx(0xFFFFFFFF), hx(0xFFE0F3FF))
        else Pal(hx(0x66FFFFFF), hx(0x33FFFFFF), hx(0xFF2B6F9E), hx(0xFF7FC4F0), hx(0xFF0E2F46), hx(0xFF2B6F9E))
        RingDesign.MOON_NIGHT -> if (dark) Pal(hx(0xFF1B2A6B), hx(0xFF050A24), hx(0xFFD6DEF5), hx(0xFFFFE9A8), hx(0xFFFFF6DC), hx(0xFFD6DEF5))
        else Pal(hx(0xFFFFE9D0), hx(0xFFC9D8F5), hx(0xFF5B6FB8), hx(0xFFE0A24A), hx(0xFF2A2E5C), hx(0xFF5B6FB8))
        RingDesign.CALLIGRAPHY -> if (dark) Pal(hx(0xFF2A2218), hx(0xFF16110B), hx(0xFFD9A441), hx(0xFFEBC77A), hx(0xFFF5EBD5), hx(0xFFD9A441))
        else Pal(hx(0xFFFBF5E6), hx(0xFFEFE2C0), hx(0xFF8A6410), hx(0xFFC9A04A), hx(0xFF2B2113), hx(0xFF8A6410))
        RingDesign.SOFT_FIRE -> if (dark) Pal(hx(0xFF3A160C), hx(0xFF140603), hx(0xFFFF8A3D), hx(0xFFFFD36B), hx(0xFFFFF1DC), hx(0xFFFFB878))
        else Pal(hx(0xFFFFF1E4), hx(0xFFFFD9B8), hx(0xFFD9561A), hx(0xFFFF9A4D), hx(0xFF4A1E0A), hx(0xFFB5481A))
    }

    private fun al(color: Int, m: Float): Int =
        Color.argb((Color.alpha(color) * m).toInt().coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))

    private fun mix(a: Int, b: Int, f: Float): Int {
        val k = f.coerceIn(0f, 1f)
        fun ch(x: Int, y: Int) = (x + (y - x) * k).toInt().coerceIn(0, 255)
        return Color.argb(ch(Color.alpha(a), Color.alpha(b)), ch(Color.red(a), Color.red(b)), ch(Color.green(a), Color.green(b)), ch(Color.blue(a), Color.blue(b)))
    }

    // ------------------------------------------------------------------ أدوات الرسم
    private fun fill(color: Int) { p.reset(); p.isAntiAlias = true; p.style = Paint.Style.FILL; p.color = color }

    private fun stroke(color: Int, w: Float, cap: Paint.Cap = Paint.Cap.ROUND) {
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.strokeWidth = w; p.strokeCap = cap; p.color = color
    }

    private fun radial(cx: Float, cy: Float, rad: Float, c1: Int, c2: Int): Shader =
        RadialGradient(cx, cy, max(rad, 1f), intArrayOf(c1, c2), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)

    private fun disc(c: Canvas, g: G, radius: Float, c1: Int, c2: Int, offX: Float = 0f, offY: Float = 0f) {
        fill(Color.WHITE)
        p.shader = radial(g.cx + offX, g.cy + offY, radius * 1.15f, al(c1, g.fa), al(c2, g.fa))
        c.drawCircle(g.cx, g.cy, radius, p)
        p.shader = null
    }

    private fun clipCircle(c: Canvas, cx: Float, cy: Float, radius: Float) {
        path.reset(); path.addCircle(cx, cy, radius, Path.Direction.CW); c.clipPath(path)
    }

    private fun pos(g: G, radius: Float, angleRad: Float) = floatArrayOf(g.cx + radius * cos(angleRad), g.cy + radius * sin(angleRad))

    private fun headAngle(g: G): Float = (-90f + 360f * g.f) * PI.toFloat() / 180f

    private fun track(c: Canvas, g: G, radius: Float, width: Float, color: Int) {
        stroke(color, width); c.drawCircle(g.cx, g.cy, radius, p)
    }

    /** قوس التقدّم: يبدأ من أعلى الدائرة وينتهي عند لون ثانوي أفتح (رأس القوس). */
    private fun progressArc(c: Canvas, g: G, radius: Float, width: Float, c1: Int, c2: Int, sweepOverride: Float? = null) {
        val sweep = sweepOverride ?: (360f * g.f)
        if (sweep <= 0.2f) return
        val f = (sweep / 360f).coerceIn(0.02f, 0.98f)
        rect.set(g.cx - radius, g.cy - radius, g.cx + radius, g.cy + radius)
        stroke(c1, width)
        p.shader = SweepGradient(g.cx, g.cy, intArrayOf(c1, c2, c2), floatArrayOf(0f, f, 1f))
        c.save(); c.rotate(-90f, g.cx, g.cy); c.drawArc(rect, 0f, sweep, false, p); c.restore()
        p.shader = null
    }

    private fun glowArc(c: Canvas, g: G, radius: Float, width: Float, color: Int, strength: Float, sweepOverride: Float? = null) {
        val sweep = sweepOverride ?: (360f * g.f)
        if (sweep <= 0.2f || strength <= 0.01f) return
        rect.set(g.cx - radius, g.cy - radius, g.cx + radius, g.cy + radius)
        c.save(); c.rotate(-90f, g.cx, g.cy)
        for (i in 4 downTo 1) {
            stroke(al(color, strength * 0.15f / i), width * (1f + i * 0.7f))
            c.drawArc(rect, 0f, sweep, false, p)
        }
        c.restore()
    }

    private fun softDot(c: Canvas, x: Float, y: Float, rad: Float, color: Int, a: Float) {
        if (a <= 0.01f || rad <= 0.5f) return
        fill(Color.WHITE)
        p.shader = RadialGradient(x, y, rad, intArrayOf(al(color, a), al(color, 0f)), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(x, y, rad, p)
        p.shader = null
    }

    private fun starShape(out: Path, cx: Float, cy: Float, rOut: Float, rIn: Float, points: Int, rotRad: Float) {
        out.reset()
        for (i in 0 until points * 2) {
            val rr = if (i % 2 == 0) rOut else rIn
            val a = rotRad + i * PI.toFloat() / points - PI.toFloat() / 2f
            val x = cx + rr * cos(a)
            val y = cy + rr * sin(a)
            if (i == 0) out.moveTo(x, y) else out.lineTo(x, y)
        }
        out.close()
    }

    private fun sparkle(c: Canvas, x: Float, y: Float, rad: Float, color: Int, a: Float, width: Float) {
        if (a <= 0.01f) return
        stroke(al(color, a), width, Paint.Cap.ROUND)
        c.drawLine(x - rad, y, x + rad, y, p)
        c.drawLine(x, y - rad, x, y + rad, p)
    }

    private fun typeface(g: G, defaultSerif: Boolean): Typeface = when (g.cfg.font) {
        1 -> Typeface.create(Typeface.SERIF, Typeface.BOLD)
        2 -> Typeface.create("sans-serif-light", Typeface.NORMAL)
        3 -> Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        else -> if (defaultSerif) Typeface.create(Typeface.SERIF, Typeface.BOLD) else Typeface.DEFAULT_BOLD
    }

    private fun fit(text: String, maxW: Float): String {
        if (tp.measureText(text) <= maxW) return text
        var s = text
        while (s.length > 1 && tp.measureText("$s…") > maxW) s = s.dropLast(1)
        return "$s…"
    }

    /**
     * الأرقام والاسم والهدف. [yShift] يُزيح الكتلة رأسيًا، [emboss] يرسم الرقم بنحت، [scale] تكبير نبضة الضغط،
     * [nameTop] يضع اسم الذكر أعلى الرقم (للخط الأنيق).
     */
    private fun texts(
        c: Canvas, g: G, yShift: Float = 0f, emboss: Boolean = false, sizeMul: Float = 1f,
        nameTop: Boolean = false, extra: String? = null, extraColor: Int = 0, serif: Boolean = false,
    ) {
        val d = g.r * 2f
        val maxW = g.inner * 1.45f
        val label = Arabic.digits(min(g.st.count, if (g.st.target > 0) g.st.target else g.st.count))
        tp.typeface = typeface(g, serif)
        var size = d * 0.26f * g.cfg.digitScale * sizeMul
        tp.textSize = size
        val mw = tp.measureText(label)
        if (mw > maxW) { size *= maxW / mw; tp.textSize = size }
        val hasName = g.cfg.showName && g.st.name.isNotBlank()
        val hasGoal = g.cfg.showGoal || extra != null
        val lift = (if (hasName && !nameTop) d * 0.03f else 0f) + (if (hasGoal) d * 0.02f else 0f)
        val baseY = g.cy + size * 0.34f - lift + yShift
        val bump = 1f + 0.07f * g.kick
        c.save(); c.scale(bump, bump, g.cx, baseY - size * 0.3f)
        if (emboss) {
            tp.color = al(Color.BLACK, 0.45f); c.drawText(label, g.cx + d * 0.006f, baseY + d * 0.007f, tp)
            tp.color = al(Color.WHITE, 0.30f); c.drawText(label, g.cx - d * 0.004f, baseY - d * 0.005f, tp)
        } else if (g.glow > 0.2f && g.pal.digit != Color.BLACK) {
            tp.color = al(Color.BLACK, 0.20f * min(g.glow, 1f)); c.drawText(label, g.cx, baseY + d * 0.006f, tp)
        }
        tp.color = g.pal.digit
        c.drawText(label, g.cx, baseY, tp)
        c.restore()

        tp.typeface = if (g.cfg.font == 2) Typeface.create("sans-serif-light", Typeface.NORMAL) else Typeface.DEFAULT
        if (hasName) {
            tp.textSize = d * (if (nameTop) 0.07f else 0.052f)
            tp.color = if (nameTop) g.pal.ring1 else g.pal.sub
            if (nameTop) tp.typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
            val y = if (nameTop) g.cy - g.inner * 0.46f else baseY + d * 0.075f
            c.drawText(fit(g.st.name, maxW), g.cx, y, tp)
        }
        if (hasGoal) {
            tp.textSize = d * 0.046f
            tp.color = if (extra != null && extraColor != 0) extraColor else g.pal.sub
            tp.typeface = Typeface.DEFAULT
            val txt = extra ?: if (g.st.done) "اكتمل ✓" else "الهدف ${Arabic.digits(g.st.target)}"
            val y = if (hasName && !nameTop) baseY + d * 0.135f else baseY + d * 0.085f
            c.drawText(txt, g.cx, y, tp)
        }
    }

    // ================================================================== 1) الهالة الذهبية
    private fun goldHalo(c: Canvas, g: G) {
        disc(c, g, g.inner, g.pal.face1, g.pal.face2, -g.outerRadius * 0.2f, -g.outerRadius * 0.25f)
        val ticks = 60
        for (i in 0 until ticks) {
            val a = (i * 360f / ticks - 90f) * PI.toFloat() / 180f
            val lit = i < g.f * ticks
            val len = g.sw * (if (i % 5 == 0) 0.55f else 0.32f)
            val r0 = g.outerRadius + g.sw * 0.95f
            stroke(if (lit) al(g.pal.ring2, 0.95f) else al(g.pal.ring1, 0.22f), g.dens * (if (i % 5 == 0) 1.6f else 1f), Paint.Cap.ROUND)
            c.drawLine(g.cx + r0 * cos(a), g.cy + r0 * sin(a), g.cx + (r0 + len) * cos(a), g.cy + (r0 + len) * sin(a), p)
        }
        track(c, g, g.outerRadius, g.sw, al(g.pal.ring1, 0.18f))
        val breathe = 0.65f + 0.18f * sin(2f * PI.toFloat() * g.t / 4f)
        glowArc(c, g, g.outerRadius, g.sw, g.pal.ring1, (breathe + g.kick * 0.7f) * g.glow)
        progressArc(c, g, g.outerRadius, g.sw, g.pal.ring1, g.pal.ring2)
        track(c, g, g.outerRadius - g.sw * 0.95f, g.dens, al(g.pal.ring1, 0.35f))
        if (g.f > 0.003f) {
            val h = pos(g, g.outerRadius, headAngle(g))
            for (j in 1..6) {
                val a2 = headAngle(g) - j * 0.07f
                val q = pos(g, g.outerRadius, a2)
                softDot(c, q[0], q[1], g.sw * (0.85f - j * 0.1f), g.pal.ring2, (0.55f - j * 0.08f) * g.glow)
            }
            softDot(c, h[0], h[1], g.sw * (1.7f + g.kick * 1.3f), g.pal.ring2, 0.95f * max(g.glow, 0.3f))
            fill(Color.WHITE); c.drawCircle(h[0], h[1], g.sw * 0.34f, p)
        }
        texts(c, g)
    }

    // ================================================================== 2) الزمرد الزجاجي
    private fun emeraldGlass(c: Canvas, g: G) {
        c.save(); clipCircle(c, g.cx, g.cy, g.inner)
        for (i in 0 until 3) {
            val a = 2f * PI.toFloat() * (g.t / (20f + i * 6f) + i / 3f)
            val x = g.cx + g.inner * 0.45f * cos(a)
            val y = g.cy + g.inner * 0.4f * sin(a * 1.3f)
            softDot(c, x, y, g.inner * 0.75f, if (i == 1) g.pal.ring2 else g.pal.ring1, 0.55f * g.fa)
        }
        fill(Color.WHITE)
        p.shader = LinearGradient(g.cx - g.inner, g.cy - g.inner, g.cx + g.inner, g.cy + g.inner, al(g.pal.face1, g.fa), al(g.pal.face2, g.fa), Shader.TileMode.CLAMP)
        c.drawCircle(g.cx, g.cy, g.inner, p); p.shader = null
        c.restore()
        track(c, g, g.inner, g.sw * 0.1f, al(Color.WHITE, 0.35f))
        track(c, g, g.outerRadius, g.sw, al(Color.WHITE, 0.12f))
        glowArc(c, g, g.outerRadius, g.sw, g.pal.ring1, (0.45f + g.kick * 0.6f) * g.glow)
        progressArc(c, g, g.outerRadius, g.sw, g.pal.ring2, g.pal.ring1)
        progressArc(c, g, g.outerRadius - g.sw * 0.22f, g.sw * 0.18f, al(Color.WHITE, 0.55f), al(Color.WHITE, 0.15f))
        rect.set(g.cx - g.inner * 0.86f, g.cy - g.inner * 0.86f, g.cx + g.inner * 0.86f, g.cy + g.inner * 0.86f)
        stroke(al(Color.WHITE, 0.32f), g.sw * 0.34f); c.drawArc(rect, 200f, 60f, false, p)
        stroke(al(Color.WHITE, 0.22f), g.sw * 0.2f); c.drawArc(rect, 268f, 14f, false, p)
        if (g.f > 0.003f) {
            val h = pos(g, g.outerRadius, headAngle(g))
            fill(al(Color.WHITE, 0.9f)); c.drawCircle(h[0], h[1], g.sw * 0.30f, p)
        }
        texts(c, g)
    }

    // ================================================================== 3) الهلال والنجوم
    private fun crescentStars(c: Canvas, g: G) {
        disc(c, g, g.inner, g.pal.face1, g.pal.face2, 0f, -g.outerRadius * 0.3f)
        c.save(); clipCircle(c, g.cx, g.cy, g.inner)
        for (i in 0 until 16) {
            val a = i * 2.399f
            val rr = g.inner * (0.25f + 0.7f * ((i * 37 % 100) / 100f))
            val tw = 0.35f + 0.65f * (0.5f + 0.5f * sin(2f * PI.toFloat() * (g.t / (4f + i % 4) + i * 0.13f)))
            fill(al(g.pal.ring2, tw * 0.85f))
            c.drawCircle(g.cx + rr * cos(a), g.cy + rr * sin(a), g.dens * (0.7f + (i % 3) * 0.5f), p)
        }
        c.restore()
        track(c, g, g.outerRadius, g.sw * 0.55f, al(g.pal.ring1, 0.22f))
        glowArc(c, g, g.outerRadius, g.sw * 0.55f, g.pal.ring1, (0.35f + g.kick * 0.6f) * g.glow)
        progressArc(c, g, g.outerRadius, g.sw * 0.55f, g.pal.ring1, g.pal.ring2)
        // الهلال يدور حول الرقم
        val ang = 2f * PI.toFloat() * g.t / 24f
        val orbit = g.inner * 0.66f
        val rc = g.inner * 0.17f * (1f + 0.25f * g.kick)
        path.reset(); path.addCircle(0f, 0f, rc, Path.Direction.CW)
        path2.reset(); path2.addCircle(rc * 0.55f, -rc * 0.15f, rc * 0.85f, Path.Direction.CW)
        path.op(path2, Path.Op.DIFFERENCE)
        c.save()
        c.translate(g.cx + orbit * cos(ang), g.cy + orbit * sin(ang))
        c.rotate(ang * 180f / PI.toFloat() + 90f)
        softDot(c, 0f, 0f, rc * 2.4f, g.pal.ring2, 0.30f * g.glow)
        fill(g.pal.ring2); c.drawPath(path, p)
        c.restore()
        // نجوم تدور بمدارات وسرعات مختلفة
        for (i in 0 until 5) {
            val a = 2f * PI.toFloat() * (g.t / (14f + i * 5f)) * (if (i % 2 == 0) -1f else 1f) + i * 1.3f
            val rr = g.inner * (0.40f + 0.1f * i)
            val tw = 0.45f + 0.55f * (0.5f + 0.5f * sin(2f * PI.toFloat() * (g.t / 3f + i * 0.2f)))
            sparkle(c, g.cx + rr * cos(a), g.cy + rr * sin(a), g.sw * (0.55f + 0.5f * g.kick), g.pal.ring2, tw, g.dens * 1.3f)
        }
        texts(c, g)
    }

    // ================================================================== 4) مدار الضوء
    private fun lightOrbit(c: Canvas, g: G) {
        disc(c, g, g.inner, g.pal.face1, g.pal.face2, 0f, -g.outerRadius * 0.2f)
        track(c, g, g.outerRadius, g.sw * 0.5f, al(g.pal.ring1, 0.20f))
        glowArc(c, g, g.outerRadius, g.sw * 0.5f, g.pal.ring1, (0.4f + g.kick * 0.7f) * g.glow)
        progressArc(c, g, g.outerRadius, g.sw * 0.5f, g.pal.ring1, g.pal.ring2)
        for (i in 0 until 14) {
            val dir = if (i % 3 == 0) -1f else 1f
            val period = 9f + (i % 4) * 3f
            val a0 = 2f * PI.toFloat() * (g.t / period) * dir + i * 0.9f
            val wob = g.sw * 0.7f * sin(2f * PI.toFloat() * (g.t / 6f + i * 0.17f))
            val rr = g.outerRadius + wob + g.kick * g.sw * 1.4f
            val size = g.sw * (0.45f + 0.35f * ((i * 53 % 100) / 100f))
            for (j in 4 downTo 1) {
                val q = pos(g, rr, a0 - dir * j * 0.07f)
                softDot(c, q[0], q[1], size * (1f - j * 0.15f), g.pal.ring2, (0.35f - j * 0.06f) * g.glow)
            }
            val q = pos(g, rr, a0)
            softDot(c, q[0], q[1], size * 2.2f, g.pal.ring2, 0.55f * max(g.glow, 0.3f))
            fill(Color.WHITE); c.drawCircle(q[0], q[1], size * 0.38f, p)
        }
        if (g.kick > 0.02f) {
            stroke(al(g.pal.ring2, g.kick * 0.6f), g.dens * 2f)
            c.drawCircle(g.cx, g.cy, g.outerRadius + (1f - g.kick) * (g.r - g.outerRadius) * 1.2f, p)
        }
        texts(c, g)
    }

    // ================================================================== 5) حلقة الإنجاز المتدرجة
    private fun progHue(f: Float): Int {
        val hue = if (f < 0.85f) 120f * f / 0.85f else 120f - 72f * ((f - 0.85f) / 0.15f)
        return Color.HSVToColor(floatArrayOf(hue.coerceIn(0f, 360f), 0.82f, 0.96f))
    }

    private fun gradientProgress(c: Canvas, g: G) {
        disc(c, g, g.inner, g.pal.face1, g.pal.face2, 0f, -g.outerRadius * 0.25f)
        val cur = progHue(g.f)
        track(c, g, g.outerRadius, g.sw, al(cur, 0.16f))
        for (m in listOf(0.25f, 0.5f, 0.75f)) {
            val a = (-90f + 360f * m) * PI.toFloat() / 180f
            stroke(al(g.pal.sub, 0.5f), g.dens * 1.4f)
            c.drawLine(g.cx + (g.outerRadius - g.sw * 0.9f) * cos(a), g.cy + (g.outerRadius - g.sw * 0.9f) * sin(a), g.cx + (g.outerRadius + g.sw * 0.9f) * cos(a), g.cy + (g.outerRadius + g.sw * 0.9f) * sin(a), p)
        }
        glowArc(c, g, g.outerRadius, g.sw, cur, (0.6f + g.kick * 0.6f) * g.glow)
        val sweep = 360f * g.f
        if (sweep > 0.2f) {
            val f = (sweep / 360f).coerceIn(0.02f, 0.98f)
            val cols = IntArray(6) { progHue(g.f * it / 4f).let { col -> if (it == 5) cur else col } }
            val posn = FloatArray(6) { if (it == 5) 1f else f * it / 4f }
            rect.set(g.cx - g.outerRadius, g.cy - g.outerRadius, g.cx + g.outerRadius, g.cy + g.outerRadius)
            stroke(cur, g.sw); p.shader = SweepGradient(g.cx, g.cy, cols, posn)
            c.save(); c.rotate(-90f, g.cx, g.cy); c.drawArc(rect, 0f, sweep, false, p); c.restore(); p.shader = null
            val h = pos(g, g.outerRadius, headAngle(g))
            softDot(c, h[0], h[1], g.sw * (1.5f + g.kick), cur, 0.8f * max(g.glow, 0.3f))
            fill(Color.WHITE); c.drawCircle(h[0], h[1], g.sw * 0.3f, p)
        }
        texts(c, g, extra = "${Arabic.digits((g.f * 100).toInt())}٪", extraColor = cur)
    }

    // ================================================================== 6) الماء والتموّج
    private fun waterRipple(c: Canvas, g: G) {
        val rin = g.inner
        c.save(); clipCircle(c, g.cx, g.cy, rin)
        fill(Color.WHITE)
        p.shader = LinearGradient(g.cx, g.cy - rin, g.cx, g.cy + rin, al(g.pal.face1, g.fa), al(g.pal.face2, g.fa), Shader.TileMode.CLAMP)
        c.drawRect(g.cx - rin, g.cy - rin, g.cx + rin, g.cy + rin, p); p.shader = null
        val level = g.cy + rin - 2f * rin * (0.04f + 0.92f * g.f)
        for (layer in 0 until 2) {
            path.reset()
            val amp = rin * (0.04f + 0.01f * layer) * (1f + 0.5f * g.kick)
            val steps = 28
            path.moveTo(g.cx - rin, g.cy + rin)
            for (i in 0..steps) {
                val x = g.cx - rin + 2f * rin * i / steps
                val y = level + amp * sin(2f * PI.toFloat() * (i / steps.toFloat() * 1.3f + g.t / (5f + layer * 3f)) + layer * 1.7f)
                path.lineTo(x, y)
            }
            path.lineTo(g.cx + rin, g.cy + rin); path.close()
            fill(al(if (layer == 0) g.pal.ring2 else g.pal.ring1, if (layer == 0) 0.50f else 0.42f)); c.drawPath(path, p)
        }
        for (i in 0 until 5) {
            val ph = (g.t / (6f + i) + i * 0.21f) % 1f
            val bx = g.cx + rin * (-0.5f + 0.25f * i) + rin * 0.05f * sin(2f * PI.toFloat() * (g.t / 3f + i))
            val by = g.cy + rin - (g.cy + rin - level) * ph
            if (by > level) { stroke(al(Color.WHITE, 0.5f * (1f - ph)), g.dens); c.drawCircle(bx, by, g.dens * (1.5f + i % 3), p) }
        }
        val idle = (g.t / 5f) % 1f
        stroke(al(Color.WHITE, 0.22f * (1f - idle)), g.dens * 1.4f); c.drawCircle(g.cx, g.cy, rin * (0.15f + 0.8f * idle), p)
        if (g.kick > 0.02f) {
            stroke(al(Color.WHITE, g.kick * 0.65f), g.dens * 2f); c.drawCircle(g.cx, g.cy, rin * (0.2f + 0.75f * (1f - g.kick)), p)
        }
        c.restore()
        track(c, g, rin + g.sw * 0.1f, g.sw * 0.4f, al(g.pal.ring1, 0.95f))
        track(c, g, rin + g.sw * 0.45f, g.dens, al(Color.WHITE, 0.3f))
        glowArc(c, g, rin + g.sw * 0.1f, g.sw * 0.4f, g.pal.ring1, 0.3f * g.glow, 360f)
        texts(c, g)
    }

    // ================================================================== 7) المجرة
    private fun galaxy(c: Canvas, g: G) {
        val rin = g.inner
        c.save(); clipCircle(c, g.cx, g.cy, rin)
        disc(c, g, rin, g.pal.face1, g.pal.face2)
        softDot(c, g.cx, g.cy, rin * (0.55f + 0.1f * g.kick), g.pal.ring2, 0.35f * g.glow)
        softDot(c, g.cx, g.cy, rin * 0.22f, Color.WHITE, 0.5f * g.glow)
        val rot = 2f * PI.toFloat() * g.t / 45f
        val n = 46
        for (arm in 0 until 2) for (i in 0 until n) {
            val f = i / n.toFloat()
            val rr = f.pow(0.75f) * rin * 0.96f
            val a = arm * PI.toFloat() + f * 4.6f + rot
            val x = g.cx + rr * cos(a)
            val y = g.cy + rr * sin(a) * 0.62f
            val tw = 0.6f + 0.4f * sin(2f * PI.toFloat() * (g.t / 4f + i * 0.11f))
            fill(al(if (f < 0.35f) Color.WHITE else if (f < 0.7f) g.pal.ring1 else g.pal.ring2, (0.85f - 0.4f * f) * tw))
            c.drawCircle(x, y, g.dens * (0.5f + 1.2f * (1f - f) * (0.4f + 0.6f * ((i * 29 % 10) / 10f))), p)
        }
        for (i in 0 until 14) {
            val a = i * 2.399f
            val rr = rin * (0.2f + 0.78f * ((i * 61 % 100) / 100f))
            val tw = 0.3f + 0.7f * (0.5f + 0.5f * sin(2f * PI.toFloat() * (g.t / (3f + i % 3) + i * 0.3f)))
            fill(al(Color.WHITE, 0.8f * tw)); c.drawCircle(g.cx + rr * cos(a), g.cy + rr * sin(a), g.dens * 0.8f, p)
        }
        c.restore()
        track(c, g, g.outerRadius, g.sw * 0.5f, al(g.pal.ring1, 0.20f))
        glowArc(c, g, g.outerRadius, g.sw * 0.5f, g.pal.ring2, (0.45f + g.kick * 0.6f) * g.glow)
        progressArc(c, g, g.outerRadius, g.sw * 0.5f, g.pal.ring1, g.pal.ring2)
        if (g.f > 0.003f) {
            val h = pos(g, g.outerRadius, headAngle(g))
            softDot(c, h[0], h[1], g.sw * 1.6f, Color.WHITE, 0.8f)
        }
        texts(c, g)
    }

    // ================================================================== 8) الزخرفة الفاخرة
    private fun luxeGeometry(c: Canvas, g: G) {
        disc(c, g, g.inner, g.pal.face1, g.pal.face2, 0f, -g.outerRadius * 0.2f)
        val segs = 48
        val lit = g.f * segs
        for (i in 0 until segs) {
            val a0 = -90f + i * 360f / segs + 360f / segs * 0.15f
            val state = (lit - i).coerceIn(0f, 1f)
            rect.set(g.cx - g.outerRadius, g.cy - g.outerRadius, g.cx + g.outerRadius, g.cy + g.outerRadius)
            stroke(if (state > 0f) mix(g.pal.ring1, g.pal.ring2, if (i % 2 == 0) 0.2f else 0.7f).let { al(it, 0.35f + 0.65f * state) } else al(g.pal.ring1, 0.16f), g.sw * 0.85f, Paint.Cap.BUTT)
            c.drawArc(rect, a0, 360f / segs * 0.7f, false, p)
        }
        track(c, g, g.outerRadius + g.sw * 0.75f, g.dens * 1.2f, al(g.pal.ring1, 0.6f))
        track(c, g, g.outerRadius + g.sw * 1.0f, g.dens * 0.8f, al(g.pal.ring1, 0.35f))
        val s = 1f + 0.07f * g.kick
        starShape(path, g.cx, g.cy, g.inner * 0.80f * s, g.inner * 0.64f * s, 16, 2f * PI.toFloat() * g.t / 90f)
        stroke(al(g.pal.ring1, 0.6f), g.dens * 1.2f); c.drawPath(path, p)
        starShape(path, g.cx, g.cy, g.inner * 0.58f * s, g.inner * 0.36f * s, 8, -2f * PI.toFloat() * g.t / 60f)
        stroke(al(g.pal.ring2, 0.55f), g.dens * 1.2f); c.drawPath(path, p)
        fill(al(g.pal.face2, 0.55f * g.fa)); c.drawCircle(g.cx, g.cy, g.inner * 0.44f, p)
        for (i in 0 until 4) {
            val a = i * PI.toFloat() / 2f - PI.toFloat() / 2f
            val q = pos(g, g.outerRadius + g.sw * 1.55f, a)
            c.save(); c.translate(q[0], q[1]); c.rotate(45f)
            fill(al(g.pal.ring2, 0.85f)); c.drawRect(-g.sw * 0.28f, -g.sw * 0.28f, g.sw * 0.28f, g.sw * 0.28f, p)
            c.restore()
        }
        if (g.kick > 0.05f) for (i in 0 until 8) {
            val a = i * PI.toFloat() / 4f + 0.4f
            val q = pos(g, g.outerRadius + g.sw * (1f + 2f * (1f - g.kick)), a)
            sparkle(c, q[0], q[1], g.sw * 0.5f * g.kick, g.pal.ring2, g.kick, g.dens * 1.2f)
        }
        texts(c, g)
    }

    // ================================================================== 9) النبض الضوئي
    private fun pulse(c: Canvas, g: G) {
        val breathe = 1f + 0.012f * sin(2f * PI.toFloat() * g.t / 3f)
        disc(c, g, g.inner * breathe, g.pal.face1, g.pal.face2, 0f, -g.outerRadius * 0.15f)
        track(c, g, g.outerRadius, g.sw * 0.7f, al(g.pal.ring1, 0.18f))
        progressArc(c, g, g.outerRadius, g.sw * 0.7f, g.pal.ring1, g.pal.ring2)
        val idle = (g.t / 4f) % 1f
        stroke(al(g.pal.ring1, 0.22f * (1f - idle) * g.glow), g.dens * 2f)
        c.drawCircle(g.cx, g.cy, g.outerRadius + (g.r - g.outerRadius) * idle, p)
        for (i in 0 until 3) {
            val pr = (1f - g.kick) - i * 0.16f
            if (g.kick > 0.01f && pr in 0f..1f) {
                stroke(al(g.pal.ring2, (1f - pr) * 0.75f * max(g.glow, 0.3f)), g.dens * (3f - i))
                c.drawCircle(g.cx, g.cy, g.outerRadius * 0.7f + (g.r - g.outerRadius * 0.7f) * pr, p)
            }
        }
        softDot(c, g.cx, g.cy, g.inner, g.pal.ring2, 0.10f + 0.22f * g.kick)
        texts(c, g)
    }

    // ================================================================== 10) ثلاثي الأبعاد
    private fun depth3d(c: Canvas, g: G) {
        fill(Color.WHITE)
        p.shader = radial(g.cx, g.cy + g.r * 0.93f, g.r * 0.7f, al(Color.BLACK, 0.40f), al(Color.BLACK, 0f))
        c.save(); c.scale(1f, 0.16f, g.cx, g.cy + g.r * 0.93f); c.drawCircle(g.cx, g.cy + g.r * 0.93f, g.r * 0.7f, p); c.restore(); p.shader = null
        val bez = g.outerRadius + g.sw * 0.62f
        fill(Color.WHITE)
        p.shader = LinearGradient(g.cx - bez, g.cy - bez, g.cx + bez, g.cy + bez, mix(g.pal.face1, Color.WHITE, 0.55f), mix(g.pal.face2, Color.BLACK, 0.2f), Shader.TileMode.CLAMP)
        c.drawCircle(g.cx, g.cy, bez, p)
        p.shader = LinearGradient(g.cx - bez, g.cy - bez, g.cx + bez, g.cy + bez, mix(g.pal.face2, Color.BLACK, 0.4f), mix(g.pal.face1, Color.WHITE, 0.3f), Shader.TileMode.CLAMP)
        c.drawCircle(g.cx, g.cy, g.outerRadius + g.sw * 0.5f, p); p.shader = null
        progressArc(c, g, g.outerRadius, g.sw * 0.72f, g.pal.ring2, g.pal.ring1)
        progressArc(c, g, g.outerRadius - g.sw * 0.18f, g.sw * 0.2f, al(Color.WHITE, 0.55f), al(Color.WHITE, 0.12f))
        glowArc(c, g, g.outerRadius, g.sw * 0.72f, g.pal.ring1, (0.25f + g.kick * 0.5f) * g.glow)
        val press = 1f - 0.045f * g.kick
        val rb = (g.outerRadius - g.sw * 0.75f) * press
        fill(Color.WHITE)
        p.shader = RadialGradient(g.cx - rb * 0.3f, g.cy - rb * 0.38f, rb * 1.5f, intArrayOf(mix(g.pal.face1, Color.WHITE, 0.45f), g.pal.face1, mix(g.pal.face2, Color.BLACK, 0.2f)), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(g.cx, g.cy, rb, p); p.shader = null
        fill(Color.WHITE)
        p.shader = LinearGradient(g.cx, g.cy - rb, g.cx, g.cy - rb * 0.1f, al(Color.WHITE, 0.30f - 0.15f * g.kick), al(Color.WHITE, 0f), Shader.TileMode.CLAMP)
        rect.set(g.cx - rb * 0.72f, g.cy - rb * 0.95f, g.cx + rb * 0.72f, g.cy - rb * 0.18f); c.drawOval(rect, p); p.shader = null
        texts(c, g, emboss = true)
    }

    // ================================================================== 11) ورق الشجر
    private fun leafNature(c: Canvas, g: G) {
        disc(c, g, g.inner, g.pal.face1, g.pal.face2, 0f, -g.outerRadius * 0.25f)
        val n = 28
        val litCount = g.f * n
        val len = g.sw * 2.7f
        for (i in 0 until n) {
            val a = (i * 360f / n - 90f)
            val sway = 7f * sin(2f * PI.toFloat() * (g.t / 6f + i * 0.06f)) * (1f + g.kick)
            val state = (litCount - i).coerceIn(0f, 1f)
            val newest = state > 0f && state < 1f || (i == (litCount.toInt() - 1) && g.kick > 0.02f)
            val sc = 1f + (if (newest) 0.35f * g.kick else 0f) + 0.2f * state
            val col = if (state > 0f) mix(g.pal.ring2, g.pal.ring1, i / n.toFloat()) else al(g.pal.ring1, 0.16f)
            c.save()
            c.rotate(a, g.cx, g.cy)
            c.translate(g.cx + g.outerRadius - g.sw * 0.3f, g.cy)
            c.rotate(38f + sway)
            c.scale(len * sc, len * 0.5f * sc)
            path.reset(); path.moveTo(0f, 0f); path.cubicTo(0.3f, -0.6f, 0.8f, -0.55f, 1f, 0f); path.cubicTo(0.8f, 0.55f, 0.3f, 0.6f, 0f, 0f)
            fill(if (state > 0f) al(col, 0.45f + 0.55f * state) else col); c.drawPath(path, p)
            if (state > 0.5f) { stroke(al(Color.WHITE, 0.35f), 0.04f); c.drawLine(0f, 0f, 0.92f, 0f, p) }
            c.restore()
        }
        progressArc(c, g, g.outerRadius - g.sw * 1.5f, g.sw * 0.16f, al(g.pal.ring1, 0.6f), al(g.pal.ring2, 0.8f))
        glowArc(c, g, g.outerRadius - g.sw * 1.5f, g.sw * 0.16f, g.pal.ring1, 0.3f * g.glow)
        texts(c, g)
    }

    // ================================================================== 12) الزجاج الشفاف
    private fun clearGlass(c: Canvas, g: G) {
        val rin = g.inner
        c.save(); clipCircle(c, g.cx, g.cy, rin)
        val blobs = intArrayOf(hx(0xFF7FD6FF), hx(0xFFFF9ECF), hx(0xFFFFE07F), hx(0xFF9EFFB8))
        for (i in 0 until 4) {
            val a = 2f * PI.toFloat() * (g.t / (9f + i * 2f) + i * 0.25f)
            val x = g.cx + rin * 0.55f * cos(a)
            val y = g.cy + rin * 0.5f * sin(a * 1.4f + i)
            softDot(c, x, y, rin * (0.8f + 0.1f * i % 3), blobs[i], 0.55f * g.fa)
        }
        fill(g.pal.face1); c.drawCircle(g.cx, g.cy, rin, p)
        c.restore()
        track(c, g, rin, g.sw * 0.14f, al(g.pal.ring1, 0.5f))
        track(c, g, rin - g.sw * 0.5f, g.dens, al(g.pal.ring1, 0.25f))
        track(c, g, g.outerRadius, g.sw * 0.6f, al(g.pal.ring1, 0.15f))
        glowArc(c, g, g.outerRadius, g.sw * 0.6f, g.pal.ring1, (0.4f + g.kick * 0.6f) * g.glow)
        progressArc(c, g, g.outerRadius, g.sw * 0.6f, al(g.pal.ring1, 0.95f), al(g.pal.ring2, 0.95f))
        rect.set(g.cx - rin * 0.9f, g.cy - rin * 0.9f, g.cx + rin * 0.9f, g.cy + rin * 0.9f)
        stroke(al(Color.WHITE, 0.5f), g.sw * 0.3f); c.drawArc(rect, 205f, 50f, false, p)
        fill(al(Color.WHITE, 0.85f)); c.drawCircle(g.cx + rin * 0.9f * cos(262f * PI.toFloat() / 180f), g.cy + rin * 0.9f * sin(262f * PI.toFloat() / 180f), g.sw * 0.22f, p)
        texts(c, g)
    }

    // ================================================================== 13) القمر والليل
    private fun moonNight(c: Canvas, g: G) {
        val rin = g.inner
        c.save(); clipCircle(c, g.cx, g.cy, rin)
        fill(Color.WHITE)
        p.shader = LinearGradient(g.cx, g.cy - rin, g.cx, g.cy + rin, al(g.pal.face1, g.fa), al(g.pal.face2, g.fa), Shader.TileMode.CLAMP)
        c.drawRect(g.cx - rin, g.cy - rin, g.cx + rin, g.cy + rin, p); p.shader = null
        for (i in 0 until 14) {
            val a = i * 2.399f
            val rr = rin * (0.2f + 0.78f * ((i * 47 % 100) / 100f))
            val tw = 0.3f + 0.7f * (0.5f + 0.5f * sin(2f * PI.toFloat() * (g.t / (3f + i % 4) + i * 0.19f)))
            fill(al(Color.WHITE, 0.8f * tw)); c.drawCircle(g.cx + rr * cos(a), g.cy + rr * sin(a) * 0.9f, g.dens * (0.6f + (i % 3) * 0.4f), p)
        }
        val mc = floatArrayOf(g.cx + rin * 0.40f, g.cy - rin * 0.42f)
        val mr = rin * 0.24f * (1f + 0.04f * g.kick)
        softDot(c, mc[0], mc[1], mr * 3f, g.pal.ring2, 0.30f * g.glow)
        fill(if (g.dark) hx(0xFFFFF1CC) else hx(0xFFFFE9A8)); c.drawCircle(mc[0], mc[1], mr, p)
        fill(al(hx(0xFFD8C78E), 0.45f)); c.drawCircle(mc[0] - mr * 0.3f, mc[1] - mr * 0.2f, mr * 0.2f, p)
        c.drawCircle(mc[0] + mr * 0.35f, mc[1] + mr * 0.25f, mr * 0.14f, p)
        for (i in 0 until 2) {
            val cxx = g.cx - rin * 1.4f + ((g.t / (40f + i * 20f) + i * 0.45f) % 1f) * rin * 3.2f
            val cyy = g.cy + rin * (0.15f + 0.3f * i)
            fill(al(if (g.dark) hx(0xFFC9D6F2) else Color.WHITE, 0.28f))
            rect.set(cxx - rin * 0.5f, cyy - rin * 0.08f, cxx + rin * 0.5f, cyy + rin * 0.08f); c.drawOval(rect, p)
            rect.set(cxx - rin * 0.25f, cyy - rin * 0.18f, cxx + rin * 0.2f, cyy + rin * 0.06f); c.drawOval(rect, p)
        }
        c.restore()
        track(c, g, g.outerRadius, g.sw * 0.5f, al(g.pal.ring1, 0.22f))
        glowArc(c, g, g.outerRadius, g.sw * 0.5f, g.pal.ring1, (0.35f + g.kick * 0.5f) * g.glow)
        progressArc(c, g, g.outerRadius, g.sw * 0.5f, g.pal.ring1, g.pal.ring2)
        texts(c, g, yShift = rin * 0.10f)
    }

    // ================================================================== 14) الخط الأنيق
    private fun calligraphy(c: Canvas, g: G) {
        disc(c, g, g.inner, g.pal.face1, g.pal.face2, 0f, -g.outerRadius * 0.2f)
        track(c, g, g.outerRadius + g.sw * 0.75f, g.dens * 1.2f, al(g.pal.ring1, 0.55f))
        track(c, g, g.outerRadius - g.sw * 0.35f, g.dens * 0.8f, al(g.pal.ring1, 0.30f))
        track(c, g, g.outerRadius, g.sw * 0.42f, al(g.pal.ring1, 0.16f))
        glowArc(c, g, g.outerRadius, g.sw * 0.42f, g.pal.ring1, (0.25f + g.kick * 0.5f) * g.glow)
        progressArc(c, g, g.outerRadius, g.sw * 0.42f, g.pal.ring1, g.pal.ring2)
        for (i in 0 until 12) {
            val a = (i * 30f - 90f) * PI.toFloat() / 180f
            val q = pos(g, g.outerRadius + g.sw * 1.35f, a)
            fill(if (i < g.f * 12f) g.pal.ring2 else al(g.pal.ring1, 0.25f))
            c.drawCircle(q[0], q[1], g.sw * (if (i % 3 == 0) 0.2f else 0.13f), p)
        }
        for (i in 0 until 4) {
            val a = i * PI.toFloat() / 2f - PI.toFloat() / 2f
            val q = pos(g, g.outerRadius + g.sw * 0.75f, a)
            c.save(); c.translate(q[0], q[1]); c.rotate(45f)
            fill(g.pal.ring2); c.drawRect(-g.sw * 0.3f, -g.sw * 0.3f, g.sw * 0.3f, g.sw * 0.3f, p)
            c.restore()
        }
        if (g.cfg.showName && g.st.name.isNotBlank()) {
            val y = g.cy - g.inner * 0.46f + g.inner * 0.06f
            stroke(al(g.pal.ring1, 0.45f), g.dens)
            c.drawLine(g.cx - g.inner * 0.62f, y - g.inner * 0.05f, g.cx - g.inner * 0.34f, y - g.inner * 0.05f, p)
            c.drawLine(g.cx + g.inner * 0.34f, y - g.inner * 0.05f, g.cx + g.inner * 0.62f, y - g.inner * 0.05f, p)
        }
        texts(c, g, sizeMul = 1.22f, nameTop = true, serif = true, yShift = g.inner * 0.04f)
    }

    // ================================================================== 15) الوهج الناري
    private fun softFire(c: Canvas, g: G) {
        disc(c, g, g.inner, g.pal.face1, g.pal.face2, 0f, g.outerRadius * 0.1f)
        val fl = 0.62f + 0.18f * sin(2f * PI.toFloat() * g.t * 0.9f) + 0.10f * sin(2f * PI.toFloat() * g.t * 2.3f) + 0.06f * sin(2f * PI.toFloat() * g.t * 5.1f)
        track(c, g, g.outerRadius, g.sw, al(g.pal.ring1, 0.14f))
        glowArc(c, g, g.outerRadius, g.sw, g.pal.ring1, (fl + g.kick * 0.7f) * g.glow)
        progressArc(c, g, g.outerRadius, g.sw, g.pal.ring1, g.pal.ring2)
        if (g.f > 0.003f) {
            val ha = headAngle(g)
            val h = pos(g, g.outerRadius, ha)
            val hh = g.sw * (1.7f + 0.55f * fl + 1.3f * g.kick) * (0.5f + 0.5f * min(g.glow, 1f) + 0.2f)
            val wob = 0.18f * sin(2f * PI.toFloat() * g.t * 3.7f)
            val out = ha + wob
            c.save(); c.translate(h[0], h[1]); c.rotate(out * 180f / PI.toFloat())
            path.reset(); path.moveTo(0f, -g.sw * 0.45f); path.cubicTo(hh * 0.55f, -g.sw * 0.6f, hh * 0.85f, -g.sw * 0.1f, hh, 0f)
            path.cubicTo(hh * 0.85f, g.sw * 0.1f, hh * 0.55f, g.sw * 0.6f, 0f, g.sw * 0.45f); path.close()
            fill(Color.WHITE)
            p.shader = LinearGradient(0f, 0f, hh, 0f, intArrayOf(al(g.pal.ring1, 0.95f), al(g.pal.ring2, 0.85f), al(g.pal.ring2, 0f)), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
            c.drawPath(path, p); p.shader = null
            fill(al(Color.WHITE, 0.85f)); c.drawCircle(0f, 0f, g.sw * 0.3f, p)
            c.restore()
        }
        for (i in 0 until 9) {
            val ph = (g.t / (3f + i % 3) + i * 0.137f) % 1f
            val a = (-90f + 360f * g.f * ((i * 53 % 100) / 100f)) * PI.toFloat() / 180f
            val q = pos(g, g.outerRadius + g.sw * 0.5f + ph * g.r * 0.14f, a)
            fill(al(g.pal.ring2, (1f - ph) * 0.8f * min(g.glow, 1f))); c.drawCircle(q[0], q[1], g.sw * 0.13f * (1f - ph) + 0.5f, p)
        }
        texts(c, g)
    }
}
