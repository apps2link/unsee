package com.unsee.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.HapticFeedbackConstants
import android.view.SoundEffectConstants
import android.view.View
import android.widget.Toast
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.core.snap
import androidx.compose.animation.scaleIn
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.composed
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.window.DialogWindowProvider
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.unsee.app.core.Arabic
import com.unsee.app.data.AdhkarData
import com.unsee.app.data.Category
import com.unsee.app.data.Settings
import com.unsee.app.data.Store
import com.unsee.app.data.Zikr
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin

// ================================================================ بيانات وأدوات
@Composable
fun <T> Store.observeAsState(read: () -> T): State<T> {
    val store = this
    val flow = remember(store) { store.observe(read) }
    val initial = remember(store) { read() }
    return flow.collectAsStateWithLifecycle(initialValue = initial)
}

fun feedback(view: View, s: Settings, strong: Boolean) {
    if (s.haptics) view.performHapticFeedback(if (strong) HapticFeedbackConstants.LONG_PRESS else HapticFeedbackConstants.KEYBOARD_TAP)
}

/** (المكتمل، الإجمالي) للأذكار ذات العدد المحدد في فئة معينة. */
fun categoryProgress(cat: Category, progress: Map<String, Int>): Pair<Int, Int> {
    val tracked = AdhkarData.forCategory(cat).filter { it.count > 0 }
    return tracked.count { (progress[it.id] ?: 0) >= it.count } to tracked.size
}

/** (المكتمل، الإجمالي) لقائمة أذكار (قسم منفرد). */
fun listProgress(items: List<Zikr>, progress: Map<String, Int>): Pair<Int, Int> {
    val tracked = items.filter { it.countable && it.count > 0 }
    return tracked.count { (progress[it.id] ?: 0) >= it.count } to tracked.size
}

/** أول ذكر لم يكتمل في الفئة (أو null). */
fun firstIncomplete(cat: Category, progress: Map<String, Int>): Zikr? =
    AdhkarData.forCategory(cat).firstOrNull { it.count > 0 && (progress[it.id] ?: 0) < it.count }

/** نص المشاركة/النسخ: الذكر كما في الكتاب + عدده + مصدره + حواشيه (التخريج) حرفيًا. */
fun zikrShareBody(z: Zikr, withFooter: Boolean): String = buildString {
    append(z.text)
    z.countText?.let { append("\n\n(").append(it).append(")") }
    append("\n\n— ").append(z.title)
    append("\nالمصدر: ").append(z.source)
    if (!z.fromBook) append(" (من المكتبة السابقة، خارج نص الكتاب)")
    if (z.footnotes.isNotEmpty()) {
        append("\n\nالتخريج والحواشي (من الكتاب):")
        z.footnotes.forEach { append("\n- ").append(it.text) }
    }
    if (withFooter) append("\n\nمن تطبيق أُنسي")
}

fun shareZikr(ctx: Context, z: Zikr) {
    val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, zikrShareBody(z, true))
    runCatching { ctx.startActivity(Intent.createChooser(send, "مشاركة الذكر").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}

fun copyZikr(ctx: Context, z: Zikr) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("zikr", zikrShareBody(z, false)))
    Toast.makeText(ctx, "تم نسخ الذكر", Toast.LENGTH_SHORT).show()
}

// ================================================================ عناصر الواجهة
/**
 * سطح زجاجي ناعم: تدرّج شبه شفاف (أفتح من أعلى)، حدّ مضيء متدرّج يحاكي انعكاس الضوء على حافة الزجاج،
 * وظل/توهّج ملوّن بلون التمييز (لا ظلال سوداء ثقيلة). أساس كل البطاقات والأزرار الدائرية والحبوب.
 * ملاحظة: Compose لا يوفّر «طمس الخلفية خلف العنصر» دون مكتبات خارجية، فالعمق هنا بالتدرّج والحدّ والإضاءة المحيطة من الخلفية.
 */
fun Modifier.softSurface(shape: Shape, elevation: Dp = 5.dp, glow: Boolean = false): Modifier {
    val dark = UColors.isDark
    val accent = UColors.Gold
    val card = UColors.Card
    val top = lerp(card, Color.White, if (dark) 0.07f else 0.35f).copy(alpha = card.alpha)
    val bottom = lerp(card, accent, if (dark) 0.05f else 0.035f).copy(alpha = card.alpha)
    val edge = if (glow) {
        Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.30f), accent.copy(alpha = 0.75f)))
    } else {
        Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = if (dark) 0.22f else 0.95f),
                Color.White.copy(alpha = if (dark) 0.05f else 0.25f),
                accent.copy(alpha = if (dark) 0.16f else 0.14f),
            ),
        )
    }
    var m = this
    if (elevation > 0.dp) {
        val tint = accent.copy(alpha = if (dark) 0.30f else 0.26f)
        m = m.shadow(elevation * (if (dark) 1.25f else 1f), shape, ambientColor = tint, spotColor = tint)
    }
    return m.clip(shape).background(Brush.verticalGradient(listOf(top, bottom))).border(if (glow) 1.5.dp else 1.dp, edge, shape)
}

/** ضغطة بنابض: ينكمش العنصر قليلًا عند اللمس ثم يرتدّ بنعومة (يحترم «تقليل الحركة»). */
fun Modifier.springClick(enabled: Boolean = true, pressedScale: Float = 0.95f, onClick: () -> Unit): Modifier = composed {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val reduce = LocalReduceMotion.current
    val scale by animateFloatAsState(
        if (pressed && !reduce) pressedScale else 1f,
        spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMediumLow),
        label = "press",
    )
    this.graphicsLayer { scaleX = scale; scaleY = scale }
        .clickable(interactionSource = source, indication = null, enabled = enabled, onClick = onClick)
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    glow: Boolean = false,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    var m = modifier
    if (onClick != null) m = m.springClick(pressedScale = 0.975f, onClick = onClick)
    Column(m.softSurface(RoundedCornerShape(UColors.radiusDp.dp), glow = glow).padding(16.dp), content = content)
}

/** زر دائري عائم بحد زجاجي (الجرس/البحث/الرجوع…). */
@Composable
fun CircleIconButton(icon: ImageVector, desc: String, onClick: () -> Unit, size: Dp = 52.dp, tint: Color = UColors.Cream) {
    Box(
        Modifier.size(size).springClick(onClick = onClick).softSurface(CircleShape, 6.dp),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, desc, tint = tint, modifier = Modifier.size(size * 0.46f)) }
}

/** حبّة صغيرة بنص وأيقونة (مثل زر «الإدارة»). */
@Composable
fun PillChip(text: String, icon: ImageVector? = null, onClick: () -> Unit) {
    Row(
        Modifier.height(44.dp).springClick(onClick = onClick).softSurface(RoundedCornerShape(50), 3.dp).padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text, color = UColors.Cream, fontWeight = FontWeight.Medium, fontSize = 14.sp)
        if (icon != null) { Spacer(Modifier.width(8.dp)); Icon(icon, null, tint = UColors.Gold, modifier = Modifier.size(20.dp)) }
    }
}

/** تدرّج الأزرار الرئيسية: من لون التمييز إلى درجته الأخف (توتي ← وردي دافئ نهارًا، وردي ← وردي فاتح ليلًا). */
private fun ctaBrush(): Brush {
    val a = UColors.Gold
    val far = if (UColors.isDark) lerp(a, Color.White, 0.28f) else lerp(a, Color(0xFFFF7FA3), 0.55f)
    return Brush.linearGradient(listOf(a, far))
}

/** الزر الرئيسي: حبّة متدرجة مضيئة مع دائرة سهم (مثل «اشحن الآن»). */
@Composable
fun CtaButton(text: String, icon: ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val a = UColors.Gold
    val shape = RoundedCornerShape(50)
    Row(
        modifier.height(60.dp).springClick(pressedScale = 0.97f, onClick = onClick)
            .shadow(14.dp, shape, ambientColor = a.copy(alpha = 0.35f), spotColor = a.copy(alpha = 0.45f))
            .clip(shape).background(ctaBrush())
            .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.55f), Color.White.copy(alpha = 0.05f))), shape)
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Spacer(Modifier.width(10.dp))
        Icon(icon, null, tint = UColors.OnAccent, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(10.dp))
        Text(text, color = UColors.OnAccent, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
        Box(
            Modifier.size(44.dp).clip(CircleShape).background(UColors.OnAccent.copy(alpha = 0.16f)).border(1.dp, UColors.OnAccent.copy(alpha = 0.35f), CircleShape),
            contentAlignment = Alignment.Center,
        ) { Icon(Ico.Chevron, null, tint = UColors.OnAccent) }
    }
}

/** ظهور ناعم بنابض: يتلاشى ويكبر ويرتفع قليلًا. مع «تقليل الحركة» يظهر فورًا. */
@Composable
fun Appear(delayMs: Int = 0, content: @Composable () -> Unit) {
    val reduce = LocalReduceMotion.current
    var visible by remember { mutableStateOf(reduce) }
    LaunchedEffect(Unit) { if (!reduce) { delay(delayMs.toLong()); visible = true } }
    AnimatedVisibility(
        visible,
        enter = if (reduce) EnterTransition.None else
            fadeIn(tween(520)) +
                scaleIn(spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessLow), initialScale = 0.94f) +
                slideInVertically(spring(dampingRatio = 0.85f, stiffness = Spring.StiffnessLow)) { it / 10 },
    ) { content() }
}

/** أيقونة داخل مساحة دائرية ناعمة بتدرّج وحدّ مضيء. */
@Composable
fun IconBadge(icon: ImageVector, size: Dp = 44.dp, tint: Color = UColors.Gold, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(size / 3)
    Box(
        modifier.size(size).clip(shape)
            .background(Brush.linearGradient(listOf(tint.copy(alpha = 0.26f), tint.copy(alpha = 0.10f))))
            .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = if (UColors.isDark) 0.18f else 0.7f), Color.Transparent)), shape),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, null, tint = tint, modifier = Modifier.size(size * 0.55f)) }
}

@Composable
fun IconBtn(icon: ImageVector, desc: String, onClick: () -> Unit, tint: Color = UColors.Gold, modifier: Modifier = Modifier) {
    Box(
        modifier.size(42.dp).clip(CircleShape).springClick(pressedScale = 0.88f, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, desc, tint = tint, modifier = Modifier.size(24.dp)) }
}

@Composable
fun PillButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, icon: ImageVector? = null, filled: Boolean = true) {
    val shape = RoundedCornerShape(50)
    val a = UColors.Gold
    val base = modifier.defaultMinSize(minHeight = 44.dp).springClick(pressedScale = 0.96f, onClick = onClick)
    val m = if (filled) {
        base.shadow(8.dp, shape, ambientColor = a.copy(alpha = 0.30f), spotColor = a.copy(alpha = 0.40f))
            .clip(shape).background(ctaBrush())
            .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.5f), Color.Transparent)), shape)
    } else {
        base.clip(shape).background(a.copy(alpha = 0.08f)).border(1.2.dp, a.copy(alpha = 0.7f), shape)
    }
    val fg = if (filled) UColors.OnAccent else a
    Row(m.padding(horizontal = 20.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
        if (icon != null) { Icon(icon, null, Modifier.size(18.dp), tint = fg); Spacer(Modifier.width(6.dp)) }
        Text(text, color = fg, fontWeight = FontWeight.Bold)
    }
}

/** شريط تقدّم متحرك بنابض: تدرّج من اللون الأخف إلى لون التمييز وتوهّج عند طرف التقدّم. يعكس الاتجاه في RTL. */
@Composable
fun GlowProgressBar(progress: () -> Float, modifier: Modifier = Modifier) {
    val reduce = LocalReduceMotion.current
    val target = progress().coerceIn(0f, 1f)
    val f by animateFloatAsState(
        target,
        if (reduce) snap() else spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessLow),
        label = "bar",
    )
    val a = UColors.Gold
    val soft = UColors.GoldSoft
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    Canvas(modifier) {
        val h = size.height
        val r = h / 2f
        drawRoundRect(a.copy(alpha = 0.18f), cornerRadius = CornerRadius(r, r))
        if (f > 0.001f) {
            val fill = maxOf(h, size.width * f)
            val x0 = if (rtl) size.width - fill else 0f
            val from = if (rtl) size.width else 0f
            val to = if (rtl) size.width - fill else fill
            drawRoundRect(
                Brush.horizontalGradient(listOf(soft, a), startX = from, endX = to),
                topLeft = Offset(x0, 0f), size = Size(fill, h), cornerRadius = CornerRadius(r, r),
            )
            val tip = Offset(if (rtl) x0 + r else x0 + fill - r, r)
            drawCircle(Brush.radialGradient(listOf(a.copy(alpha = 0.40f), Color.Transparent), center = tip, radius = h * 1.7f), radius = h * 1.7f, center = tip)
        }
    }
}

@Composable
fun ScreenHeader(title: String, onBack: (() -> Unit)? = null, actions: @Composable RowScope.() -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) { CircleIconButton(Ico.Back, "رجوع", onBack, 46.dp); Spacer(Modifier.width(10.dp)) }
        Text(title, color = UColors.Cream, fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        actions()
    }
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) =
    Text(text, color = UColors.Cream, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = modifier.padding(top = 10.dp, bottom = 2.dp))

@Composable
fun SwitchRow(title: String, sub: String? = null, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = UColors.Cream)
            if (sub != null) Text(sub, color = UColors.CreamDim, fontSize = 12.sp)
        }
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = UColors.OnAccent, checkedTrackColor = UColors.Gold,
                uncheckedThumbColor = UColors.CreamDim, uncheckedTrackColor = UColors.Gold.copy(alpha = 0.10f),
                uncheckedBorderColor = UColors.Gold.copy(alpha = 0.35f),
            ),
        )
    }
}

@Composable
fun <T> ChipRow(items: List<T>, selected: (T) -> Boolean, label: (T) -> String, onPick: (T) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { item ->
            FilterChip(
                selected = selected(item), onClick = { onPick(item) }, label = { Text(label(item)) },
                shape = RoundedCornerShape(50),
                colors = FilterChipDefaults.filterChipColors(
                    containerColor = UColors.Card,
                    labelColor = UColors.Cream,
                    selectedContainerColor = UColors.Gold.copy(alpha = 0.22f).compositeOver(UColors.CardSolid),
                    selectedLabelColor = UColors.Cream,
                ),
            )
        }
    }
}

@Composable
fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onFinished: (Float) -> Unit) {
    var draft by remember(value) { mutableFloatStateOf(value) }
    Text(label, color = UColors.CreamDim, fontSize = 12.sp)
    Slider(
        value = draft, onValueChange = { draft = it }, onValueChangeFinished = { onFinished(draft) }, valueRange = range,
        colors = SliderDefaults.colors(thumbColor = UColors.Gold, activeTrackColor = UColors.Gold, inactiveTrackColor = UColors.Gold.copy(alpha = 0.25f)),
    )
}

@Composable
fun EmptyState(icon: ImageVector, title: String, body: String, actionLabel: String? = null, onAction: (() -> Unit)? = null) {
    GlassCard(Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            IconBadge(icon, 56.dp)
            Spacer(Modifier.height(10.dp))
            Text(title, color = UColors.Cream, fontWeight = FontWeight.Bold, fontSize = 17.sp, textAlign = TextAlign.Center)
            Text(body, color = UColors.CreamDim, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 4.dp))
            if (actionLabel != null && onAction != null) {
                Spacer(Modifier.height(12.dp))
                PillButton(actionLabel, onAction)
            }
        }
    }
}

/** يطبّق طمس الخلفية خلف النافذة (Android 12+) وتعتيمًا خفيفًا؛ على الإصدارات الأقدم يبقى التعتيم فقط. */
@Composable
private fun DialogBlurEffect(radiusPx: Int = 48) {
    val view = LocalView.current
    SideEffect {
        runCatching {
            val win = (view.parent as? DialogWindowProvider)?.window ?: return@runCatching
            win.setDimAmount(0.30f)
            if (android.os.Build.VERSION.SDK_INT >= 31) {
                win.addFlags(android.view.WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
                val lp = win.attributes
                lp.blurBehindRadius = radiusPx
                win.attributes = lp
            }
        }
    }
}

/** بديل عن AlertDialog بنفس الاستخدام: زجاجي بحواف كبيرة وطمس للخلفية. */
@Composable
fun GlassAlertDialog(
    onDismissRequest: () -> Unit,
    confirmButton: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    dismissButton: (@Composable () -> Unit)? = null,
    title: (@Composable () -> Unit)? = null,
    text: (@Composable () -> Unit)? = null,
    containerColor: Color = UColors.CardSolid,
) {
    AlertDialog(
        onDismissRequest = onDismissRequest,
        confirmButton = { DialogBlurEffect(); confirmButton() },
        modifier = modifier,
        dismissButton = dismissButton,
        title = title,
        text = text,
        shape = RoundedCornerShape(30.dp),
        containerColor = containerColor.copy(alpha = if (UColors.isDark) 0.92f else 0.95f),
        tonalElevation = 0.dp,
    )
}

@Composable
fun ConfirmDialog(title: String, body: String, confirm: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    GlassAlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, color = UColors.Cream) },
        text = { Text(body, color = UColors.CreamDim) },
        confirmButton = { TextButton(onClick = { onConfirm(); onDismiss() }) { Text(confirm, color = UColors.Gold) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء", color = UColors.CreamDim) } },
    )
}

@Composable
fun ZikrText(text: String, settings: Settings, modifier: Modifier = Modifier, scaleOverride: Float? = null) {
    val base = when {
        text.length > 400 -> 19f
        text.length > 200 -> 22f
        text.length > 80 -> 25f
        else -> 30f
    }
    val size = (base * (scaleOverride ?: settings.readerScale)).sp
    Text(
        text = text, modifier = modifier, color = UColors.Cream,
        fontSize = size, lineHeight = size * settings.lineSpacing,
        textAlign = TextAlign.Center, fontFamily = LocalAppFont.current,
    )
}

/** عدّاد دائري: حلقة تقدّم، نبضة عند الضغط، Ripple، وانفجار شرارات ذهبية عند اكتمال الهدف. */
@Composable
fun CounterButton(
    count: Int,
    target: Int,           // 0 = بلا هدف
    size: Dp,
    caption: String,
    reduceMotion: Boolean,
    onTap: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val fraction = if (target > 0) (count.toFloat() / target).coerceIn(0f, 1f) else 1f
    val sweep by animateFloatAsState(fraction, tween(if (reduceMotion) 0 else 250), label = "sweep")
    val pulse = remember { Animatable(1f) }
    val burst = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val initial = remember { count }

    LaunchedEffect(count) {
        if (!reduceMotion && target > 0 && count == target && count > initial) {
            burst.snapTo(0f)
            burst.animateTo(1f, tween(900))
        }
    }

    Box(
        modifier.size(size).graphicsLayer { scaleX = pulse.value; scaleY = pulse.value },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 9.dp.toPx()
            val inset = stroke / 2 + 4.dp.toPx()
            val arcSize = Size(this.size.width - inset * 2, this.size.height - inset * 2)
            drawArc(UColors.Gold.copy(alpha = 0.2f), -90f, 360f, false, Offset(inset, inset), arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
            if (sweep > 0f) {
                drawArc(UColors.Gold, -90f, 360f * sweep, false, Offset(inset, inset), arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
            }
            val b = burst.value
            if (b > 0f && b < 1f) {
                val c = center
                val r0 = this.size.width / 2f
                for (i in 0 until 18) {
                    val a = Math.toRadians(i * 20.0).toFloat()
                    val r = r0 * (0.95f + 0.55f * b)
                    drawCircle(UColors.GoldSoft.copy(alpha = 1f - b), radius = 4.dp.toPx() * (1f - b) + 1f, center = Offset(c.x + cos(a) * r, c.y + sin(a) * r))
                }
            }
        }
        Box(
            Modifier
                .fillMaxSize(0.8f)
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(UColors.Gold.copy(alpha = 0.2f).compositeOver(UColors.CardSolid), UColors.CardSolid)))
                .clickable {
                    if (!reduceMotion) scope.launch {
                        pulse.animateTo(0.95f, tween(60))
                        pulse.animateTo(1f, spring(Spring.DampingRatioMediumBouncy))
                    }
                    onTap()
                },
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                if (reduceMotion) {
                    Text(Arabic.digits(count), color = UColors.Cream, fontSize = (size.value * 0.27f).sp, fontWeight = FontWeight.Bold)
                } else {
                    AnimatedContent(
                        targetState = count,
                        transitionSpec = { (slideInVertically(tween(140)) { -it / 3 } + fadeIn(tween(140))) togetherWith (slideOutVertically(tween(140)) { it / 3 } + fadeOut(tween(100))) },
                        label = "digits",
                    ) { n ->
                        Text(Arabic.digits(n), color = UColors.Cream, fontSize = (size.value * 0.27f).sp, fontWeight = FontWeight.Bold)
                    }
                }
                Text(caption, color = UColors.Gold, fontSize = 12.sp)
            }
        }
    }
}
