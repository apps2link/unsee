package com.unsee.app.ui

import android.view.HapticFeedbackConstants
import android.view.SoundEffectConstants
import android.view.View
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.unsee.app.core.Arabic
import com.unsee.app.data.Category
import com.unsee.app.data.AdhkarData
import com.unsee.app.data.Settings
import com.unsee.app.data.Store
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun <T> Store.observeAsState(read: () -> T): State<T> {
    val store = this
    val flow = remember(store) { store.observe(read) }
    val initial = remember(store) { read() }
    return flow.collectAsStateWithLifecycle(initialValue = initial)
}

fun feedback(view: View, s: Settings, strong: Boolean) {
    if (s.haptics) view.performHapticFeedback(if (strong) HapticFeedbackConstants.LONG_PRESS else HapticFeedbackConstants.KEYBOARD_TAP)
    if (s.sound) view.playSoundEffect(SoundEffectConstants.CLICK)
}

/** (المكتمل، الإجمالي) للأذكار ذات العدد المحدد في فئة معينة. */
fun categoryProgress(cat: Category, progress: Map<String, Int>): Pair<Int, Int> {
    val tracked = AdhkarData.forCategory(cat).filter { it.count > 0 }
    return tracked.count { (progress[it.id] ?: 0) >= it.count } to tracked.size
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    glow: Boolean = false,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val shape = RoundedCornerShape(24.dp)
    val border = if (glow) UColors.Gold else UColors.Gold.copy(alpha = 0.28f)
    var m = modifier
    if (glow) m = m.shadow(10.dp, shape, ambientColor = UColors.Gold, spotColor = UColors.Gold)
    m = m.clip(shape).background(UColors.Card).border(1.dp, border, shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(m.padding(16.dp), content = content)
}

@Composable
fun Appear(delayMs: Int = 0, content: @Composable () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(delayMs.toLong()); visible = true }
    AnimatedVisibility(visible, enter = fadeIn(tween(500)) + slideInVertically(tween(500)) { it / 6 }) { content() }
}

@Composable
fun ZikrText(text: String, modifier: Modifier = Modifier) {
    val size = when {
        text.length > 400 -> 19.sp
        text.length > 200 -> 22.sp
        text.length > 80 -> 25.sp
        else -> 30.sp
    }
    Text(
        text = text,
        modifier = modifier,
        color = UColors.Cream,
        fontSize = size,
        lineHeight = size * 1.85f,
        textAlign = TextAlign.Center,
        fontFamily = rememberArabicFamily(),
    )
}

/** عدّاد دائري: حلقة تقدّم، نبضة عند الضغط، Ripple، وانفجار شرارات ذهبية عند اكتمال الهدف. */
@Composable
fun CounterButton(
    count: Int,
    target: Int,           // 0 = بلا هدف
    size: Dp,
    caption: String,
    reduceMotion: Boolean,
    onTap: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val fraction = if (target > 0) (count.toFloat() / target).coerceIn(0f, 1f) else 1f
    val sweep by animateFloatAsState(fraction, tween(if (reduceMotion) 0 else 350), label = "sweep")
    val pulse = remember { Animatable(1f) }
    val burst = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val initial = remember { count }

    LaunchedEffect(count) {
        if (!reduceMotion && target > 0 && count == target && count > initial) {
            burst.snapTo(0f)
            burst.animateTo(1f, tween(900))
        }
    }

    Box(
        modifier
            .size(size)
            .graphicsLayer { scaleX = pulse.value; scaleY = pulse.value },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 9.dp.toPx()
            val inset = stroke / 2 + 4.dp.toPx()
            val arcSize = Size(this.size.width - inset * 2, this.size.height - inset * 2)
            drawArc(UColors.Gold.copy(alpha = 0.18f), -90f, 360f, false, Offset(inset, inset), arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
            if (sweep > 0f) {
                drawArc(UColors.Gold, -90f, 360f * sweep, false, Offset(inset, inset), arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
            }
            val b = burst.value
            if (b > 0f && b < 1f) {
                val c = center
                val r0 = this.size.width / 2f
                for (i in 0 until 18) {
                    val a = Math.toRadians(i * 20.0).toFloat()
                    val r = r0 * (0.95f + 0.55f * b)
                    drawCircle(UColors.GoldSoft.copy(alpha = 1f - b), radius = 4.dp.toPx() * (1f - b) + 1f, center = Offset(c.x + cos(a) * r, c.y + sin(a) * r))
                }
            }
        }
        Box(
            Modifier
                .fillMaxSize(0.8f)
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(Color(0xFF1E4278), Color(0xFF0A1530))))
                .clickable {
                    if (!reduceMotion) scope.launch {
                        pulse.animateTo(0.94f, tween(70))
                        pulse.animateTo(1f, spring(Spring.DampingRatioMediumBouncy))
                    }
                    onTap()
                },
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    Arabic.digits(count),
                    color = UColors.Cream,
                    fontSize = (size.value * 0.27f).sp,
                    fontWeight = FontWeight.Bold,
                )
                Text(caption, color = UColors.Gold, fontSize = 12.sp)
            }
        }
    }
}
