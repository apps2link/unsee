package com.unsee.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.navigation.NavController
import com.unsee.app.core.Arabic
import com.unsee.app.core.Palettes
import com.unsee.app.core.ThemeId
import com.unsee.app.core.ThemeMode
import com.unsee.app.data.Settings
import com.unsee.app.data.Store
import java.time.LocalTime

@Composable
fun ThemesScreen(store: Store, s: Settings, nav: NavController) {
    val systemDark = isSystemInDarkTheme()
    val dark = UColors.isDark
    val hour = remember { LocalTime.now().hour }
    var preview by remember { mutableStateOf<ThemeId?>(null) }
    val animated = ThemeId.animatedSet
    // المعاينات الصغيرة بجودة مخفّفة، وتتوقف تمامًا إن اخترت «بلا حركة»
    val cardMotion = if (s.motion == 0) 0 else 1

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { ScreenHeader("الثيمات والمظهر", { nav.popBackStack() }) }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SectionLabel("الوضع")
                ChipRow(ThemeMode.values().toList(), { it == s.mode }, { it.label }) { m -> store.edit { putString("theme_mode", m.name) } }
                if (s.themeId.fixedDark != null) {
                    Text("الثيم الحالي (${s.themeId.label}) ثابت الوضع ${if (s.themeId.fixedDark == true) "داكن" else "فاتح"} لأن خلفيته مرسومة له. اختر ثيمًا كلاسيكيًا ليتبع وضع التطبيق.", color = UColors.CreamDim, fontSize = 12.sp)
                }
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                SectionLabel("الحركة والبطارية")
                ChipRow(listOf(0, 1, 2), { it == s.motion }, { listOf("بلا حركة", "حركة خفيفة", "حركة كاملة")[it] }) { v -> store.edit { putInt("motion", v) } }
                Text("«خفيفة» تقلّل عدد العناصر المتحركة إلى النصف تقريبًا (مناسبة للأجهزة الضعيفة)، و«بلا حركة» ترسم لقطة ثابتة دون أي مؤقّت.", color = UColors.CreamDim, fontSize = 12.sp)
                SwitchRow("إيقاف الحركة عند توفير الطاقة", "تلقائيًا حين يفعّل النظام وضع توفير الطاقة", s.autoSaver) { v -> store.edit { putBoolean("auto_saver", v) } }
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                SectionLabel("الثيمات المتحركة (${Arabic.digits(animated.size)})")
                Text("اضغط على أي ثيم لمعاينته حيًّا بملء الشاشة قبل اختياره. يُحفظ اختيارك ويعود عند فتح التطبيق.", color = UColors.CreamDim, fontSize = 12.sp)
            }
        }
        items(animated.chunked(2)) { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEach { id -> AnimThemeCard(id, id == s.themeId, cardMotion, hour) { preview = id } }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }

        item { SectionLabel("الثيمات الكلاسيكية") }
        items(ThemeId.classicSet.chunked(2)) { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEach { id -> ClassicThemeCard(id, id == s.themeId, if (s.mode == ThemeMode.SYSTEM) systemDark else s.mode == ThemeMode.DARK) { store.edit { putString("theme_id", id.name) } } }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SectionLabel("اللون الرئيسي")
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    ColorDot(Color(Palettes.spec(s.themeId, dark).accent), s.accent == 0L) { store.edit { putLong("accent", 0L) } }
                    Palettes.ACCENTS.forEach { (_, pair) ->
                        ColorDot(Color(if (dark) pair.first else pair.second), s.accent == pair.first) { store.edit { putLong("accent", pair.first) } }
                    }
                }
                Text("الأولى: لون الثيم الافتراضي.", color = UColors.CreamDim, fontSize = 11.sp)
                SectionLabel("البطاقات")
                ChipRow(listOf(0, 1), { it == s.cardStyle }, { if (it == 0) "صلبة" else "ناعمة شبه شفافة" }) { v -> store.edit { putInt("card_style", v) } }
                ChipRow(listOf(0, 1, 2), { it == s.cardRadius }, { listOf("حواف صغيرة", "حواف متوسطة", "حواف كبيرة")[it] }) { v -> store.edit { putInt("card_radius", v) } }
                SectionLabel("خط نص الأذكار")
                ChipRow(listOf(0, 1, 2), { it == s.font }, { listOf("نسخ كلاسيكي", "نظيف عصري", "أميري (إن أُضيف)")[it] }) { v -> store.edit { putInt("font", v) } }
                LabeledSlider("حجم خط التطبيق: ${Arabic.digits((s.fontScale * 100).toInt())}٪", s.fontScale, 0.8f..1.5f) { v -> store.edit { putFloat("font_scale", v) } }
                GlassCard(Modifier.fillMaxWidth(), glow = true) {
                    Text("معاينة", color = UColors.CreamDim, fontSize = 12.sp)
                    ZikrText("سُبْحَانَ اللَّهِ وَبِحَمْدِهِ", s, Modifier.fillMaxWidth())
                }
                Spacer(Modifier.height(90.dp))
            }
        }
    }

    preview?.let { id ->
        ThemePreviewDialog(id, s, hour, current = id == s.themeId,
            onApply = { store.edit { putString("theme_id", id.name) }; preview = null },
            onClose = { preview = null })
    }
}

/** بطاقة ثيم متحرك: الخلفية الحية نفسها مصغّرة، واسم الثيم فوق تظليل داكن ليبقى مقروءًا فوق أي لون. */
@Composable
private fun RowScope.AnimThemeCard(id: ThemeId, selected: Boolean, motion: Int, hour: Int, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Box(
        Modifier.weight(1f).height(132.dp).clip(shape)
            .border(if (selected) 3.dp else 1.dp, if (selected) UColors.Gold else Color.Gray.copy(alpha = 0.45f), shape)
            .clickable(onClick = onClick),
    ) {
        ThemeBackdrop(id, motion, hour, Modifier.fillMaxSize(), quality = 0.5f)
        Column(
            Modifier.align(Alignment.BottomStart).fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.72f))))
                .padding(horizontal = 10.dp, vertical = 8.dp),
        ) {
            Text(id.label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1)
            Text(id.blurb, color = Color.White.copy(alpha = 0.88f), fontSize = 10.sp, maxLines = 1)
        }
        if (selected) {
            Box(Modifier.align(Alignment.TopStart).padding(8.dp).size(24.dp).clip(CircleShape).background(UColors.Gold), contentAlignment = Alignment.Center) {
                Icon(Ico.Check, "الثيم الحالي", tint = UColors.OnAccent, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
private fun RowScope.ClassicThemeCard(id: ThemeId, selected: Boolean, dark: Boolean, onClick: () -> Unit) {
    val sp = Palettes.spec(id, dark)
    val shape = RoundedCornerShape(18.dp)
    Column(
        Modifier.weight(1f).clip(shape)
            .background(Brush.verticalGradient(listOf(Color(sp.bgTop), Color(sp.bgBottom))))
            .border(if (selected) 3.dp else 1.dp, if (selected) UColors.Gold else Color.Gray.copy(alpha = 0.5f), shape)
            .clickable(onClick = onClick).padding(12.dp),
    ) {
        Box(Modifier.fillMaxWidth().height(34.dp).clip(RoundedCornerShape(10.dp)).background(Color(sp.card)).padding(8.dp), contentAlignment = Alignment.CenterStart) {
            Box(Modifier.size(14.dp).clip(CircleShape).background(Color(sp.accent)))
        }
        Text(id.label, color = Color(sp.text), fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
        Text(id.blurb, color = Color(sp.textDim), fontSize = 10.sp, maxLines = 2)
    }
}

/** معاينة حيّة بملء الشاشة بألوان الثيم نفسه (لا تغيّر ثيمك الحالي إلا بزر «تطبيق»). */
@Composable
private fun ThemePreviewDialog(id: ThemeId, s: Settings, hour: Int, current: Boolean, onApply: () -> Unit, onClose: () -> Unit) {
    val sp = remember(id) { Palettes.spec(id, true) }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Box(Modifier.fillMaxSize()) {
            ThemeBackdrop(id, s.motion, hour, Modifier.fillMaxSize())
            Column(Modifier.fillMaxSize().safeDrawingPadding().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(id.label, color = Color(sp.text), fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                Text(id.blurb, color = Color(sp.textDim), fontSize = 14.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.weight(1f))
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Color(sp.card).copy(alpha = 0.82f))
                        .border(1.dp, Color(sp.accent).copy(alpha = 0.5f), RoundedCornerShape(28.dp)).padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text("أذكار الصباح", color = Color(sp.accent), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("سُبْحَانَ اللَّهِ وَبِحَمْدِهِ", color = Color(sp.text), fontSize = 26.sp, textAlign = TextAlign.Center, fontFamily = LocalAppFont.current)
                    Text("هكذا ستظهر الأذكار والنصوص فوق هذا الثيم", color = Color(sp.textDim), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                }
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(
                        Modifier.weight(1f).height(54.dp).clip(RoundedCornerShape(27.dp)).background(Color(sp.accent)).clickable(onClick = onApply),
                        contentAlignment = Alignment.Center,
                    ) { Text(if (current) "تطبيق (الثيم الحالي)" else "تطبيق الثيم", color = Color(sp.onAccent), fontWeight = FontWeight.Bold) }
                    Box(
                        Modifier.weight(1f).height(54.dp).clip(RoundedCornerShape(27.dp)).background(Color(sp.card).copy(alpha = 0.7f))
                            .border(1.dp, Color(sp.accent).copy(alpha = 0.6f), RoundedCornerShape(27.dp)).clickable(onClick = onClose),
                        contentAlignment = Alignment.Center,
                    ) { Text("إغلاق", color = Color(sp.text), fontWeight = FontWeight.Bold) }
                }
            }
        }
    }
}
