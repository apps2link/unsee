package com.unsee.app.core

/**
 * Arabic Pronunciation Engine — طبقة مستقلة تُجهّز النص العربي قبل إرساله إلى Android TextToSpeech.
 * تعمل محليًا بلا إنترنت، وتُنتج نصًّا للنطق فقط؛ النص المعروض للمستخدم لا يتغيّر أبدًا.
 *
 * المبادئ (حسب المطلوب):
 *  - لا تشكيل عشوائيًا ولا استبدالات عامة: كل قاعدة إمّا تعبيرات كاملة معروفة (عبارات الذكر/الدعاء) وإمّا كلمات محكية
 *    لا تُطبَّق إلا داخل جملة فيها علامة عامّية صريحة (سياق)، وكلاهما لا يمسّ كلمة فيها تشكيل أصلًا.
 *  - إن لم تكن القاعدة مؤكدة يبقى النص الأصلي.
 *  - أي خطأ أثناء المعالجة يُرجع النص الأصلي كما هو.
 *  - لا تكرار للكلمات: لا نضيف كلمات، وتُحذف الجملة المكررة حرفيًا متتالية فقط.
 *
 * مراحل المعالجة: تنظيف الرموز ← توسيع الرموز الدينية (ﷺ…) ← الأرقام إلى كلمات ← عبارات الذكر المشكّلة
 * ← تهجئة اللهجة (سياقية) ← الوقف وعلامات الترقيم والمسافات وحذف المكرر.
 */
object ArabicPronunciation {
    enum class DialectSupport(val label: String) {
        NATIVE("الصوت المختار يدعم هذه اللهجة أصليًا"),
        APPROXIMATE("الصوت المختار لا يدعم هذه اللهجة أصليًا؛ تُقرأ الكلمات المحكية بتهجئة تقريبية وقد يبقى النطق فصيحًا"),
    }

    class Result(val text: String, val applied: List<String>) {
        val changed: Boolean get() = applied.isNotEmpty()
    }

    /** هل الصوت (وسمه اللغوي مثل ar-EG) يدعم لهجة الرفيق أصليًا؟ لا ندّعي الدعم إلا إن ظهر في وسم الصوت الفعلي. */
    fun dialectSupport(dialect: Dialect, voiceTag: String?): DialectSupport {
        val tag = voiceTag.orEmpty().replace('_', '-').lowercase()
        val gulf = listOf("ar-sa", "ar-ae", "ar-kw", "ar-qa", "ar-bh", "ar-om")
        return when {
            dialect == Dialect.EGYPT && tag.startsWith("ar-eg") -> DialectSupport.NATIVE
            dialect == Dialect.GULF && gulf.any { tag.startsWith(it) } -> DialectSupport.NATIVE
            else -> DialectSupport.APPROXIMATE
        }
    }

    fun prepare(text: String, dialect: Dialect, voiceTag: String? = null, enabled: Boolean = true): Result {
        if (!enabled || text.isBlank()) return Result(text, emptyList())
        val applied = ArrayList<String>()
        val native = dialectSupport(dialect, voiceTag) == DialectSupport.NATIVE
        var t = text
        t = step("تنظيف الرموز", t, applied, ::cleanSymbols)
        t = step("رموز دينية", t, applied, ::expandReligiousSymbols)
        t = step("أرقام", t, applied, ::numbersToWords)
        t = step("عبارات الذكر", t, applied, ::applyPhraseLexicon)
        if (!native) t = step("تهجئة اللهجة", t, applied) { applyDialect(it, dialect) }
        t = step("وقف ومسافات", t, applied, ::tidyPauses)
        return if (t.isBlank()) Result(text, emptyList()) else Result(t, applied)
    }

    private inline fun step(name: String, input: String, applied: MutableList<String>, f: (String) -> String): String {
        val out = try { f(input) } catch (e: Exception) { input }
        if (out != input) applied.add(name)
        return out
    }

    // ------------------------------------------------------------------ 1) تنظيف
    private val bidi = Regex("[\\u200B-\\u200F\\u202A-\\u202E\\u2066-\\u2069\\uFEFF\\u0640\\u06DD\\u06DE\\u06E9]")
    private val emoji = Regex("[\\u2190-\\u21FF\\u2300-\\u23FF\\u2460-\\u27BF\\u2B00-\\u2BFF\\uFE0F\\u200D]|[\\uD83C-\\uD83E][\\uDC00-\\uDFFF]")
    private val brackets = Regex("[«»\"“”‘’()\\[\\]{}*_#~•●▪◆★☆✓✔=|<>]")
    private val dashes = Regex("\\s*[—–]\\s*|\\s+-+\\s+")
    private val ellipsis = Regex("[…]|\\.{2,}")

    internal fun cleanSymbols(s: String): String = s
        .replace(bidi, "")
        .replace('\u00A0', ' ')
        .replace(emoji, " ")
        .replace(dashes, "، ")
        .replace(ellipsis, ". ")
        .replace(brackets, " ")
        .replace('/', ' ')
        .replace("&", " و ")
        .replace(Regex("[%٪]"), " في المئة ")

    // ------------------------------------------------------------------ 2) رموز دينية
    private fun expandReligiousSymbols(s: String): String = s
        .replace("ﷺ", "صلى الله عليه وسلم")
        .replace("ﷻ", "جل جلاله")
        .replace("ﷲ", "الله")
        .replace("﷽", "بسم الله الرحمن الرحيم")

    // ------------------------------------------------------------------ 3) الأرقام
    private val ONES_M = listOf("صفر", "واحد", "اثنان", "ثلاثة", "أربعة", "خمسة", "ستة", "سبعة", "ثمانية", "تسعة", "عشرة", "أحد عشر", "اثنا عشر", "ثلاثة عشر", "أربعة عشر", "خمسة عشر", "ستة عشر", "سبعة عشر", "ثمانية عشر", "تسعة عشر")
    private val ONES_F = listOf("صفر", "واحدة", "اثنتان", "ثلاث", "أربع", "خمس", "ست", "سبع", "ثماني", "تسع", "عشر", "إحدى عشرة", "اثنتا عشرة", "ثلاث عشرة", "أربع عشرة", "خمس عشرة", "ست عشرة", "سبع عشرة", "ثماني عشرة", "تسع عشرة")
    private val TENS = listOf("", "", "عشرين", "ثلاثين", "أربعين", "خمسين", "ستين", "سبعين", "ثمانين", "تسعين")
    private val HUNDREDS = listOf("", "مئة", "مئتين", "ثلاثمئة", "أربعمئة", "خمسمئة", "ستمئة", "سبعمئة", "ثمانمئة", "تسعمئة")

    /** معدودات مؤنثة: العدد يأتي بصيغة المؤنث (ثلاث مرات، ثلاث وثلاثين مرة). غير ذلك يُقرأ مذكّرًا (ثلاثة أيام). */
    private val feminine = setOf(
        "مره", "مرات", "ركعه", "ركعات", "ايه", "ايات", "ساعه", "ساعات", "دقيقه", "دقائق", "صلاه", "صلوات",
        "سوره", "سور", "تسبيحه", "تسبيحات", "حسنه", "حسنات", "سيئه", "سيئات", "ليله", "ليالي", "صفحه", "صفحات", "جمله",
    )

    private fun below1000(n: Int, fem: Boolean): String {
        val ones = if (fem) ONES_F else ONES_M
        val parts = ArrayList<String>()
        val h = n / 100
        val r = n % 100
        if (h > 0) parts.add(HUNDREDS[h])
        if (r in 1..19) parts.add(ones[r])
        else if (r >= 20) {
            val u = r % 10; val t = r / 10
            parts.add(if (u == 0) TENS[t] else "${ones[u]} و${TENS[t]}")
        }
        return parts.joinToString(" و")
    }

    internal fun cardinal(n: Int, fem: Boolean): String {
        if (n == 0) return "صفر"
        val th = n / 1000
        val rest = n % 1000
        val parts = ArrayList<String>()
        if (th > 0) parts.add(
            when {
                th == 1 -> "ألف"
                th == 2 -> "ألفين"
                th in 3..10 -> ONES_M[th] + " آلاف"
                else -> below1000(th, false) + " ألف"
            },
        )
        if (rest > 0) parts.add(below1000(rest, fem))
        return parts.joinToString(" و")
    }

    private fun westernDigits(s: String): String = buildString { for (c in s) append(if (c in '٠'..'٩') ('0' + (c - '٠')) else c) }
    private fun digitWords(s: String): String = westernDigits(s).filter { it.isDigit() }.map { ONES_M[it - '0'] }.joinToString(" ")

    private val timeRe = Regex("(?<![0-9٠-٩])([0-9٠-٩]{1,2}):([0-9٠-٩]{2})(?![0-9٠-٩])")
    private val numRe = Regex("[0-9٠-٩]+(?:[.,٫٬][0-9٠-٩]+)?")
    private val nextWordRe = Regex("^\\s*([\\u0621-\\u064A\\u064B-\\u0652]+)")

    /** الوقت بصيغة مفهومة: «ستة ونصف»، «تسعة وخمس دقائق»؛ لا «ستة وثلاثين» التي تُفهم 36. */
    internal fun spokenTime(h: Int, mi: Int): String = when (mi) {
        0 -> cardinal(h, false)
        15 -> "${cardinal(h, false)} وربع"
        30 -> "${cardinal(h, false)} ونصف"
        1 -> "${cardinal(h, false)} ودقيقة واحدة"
        2 -> "${cardinal(h, false)} ودقيقتين"
        in 3..10 -> "${cardinal(h, false)} و${cardinal(mi, true)} دقائق"
        else -> "${cardinal(h, false)} و${cardinal(mi, true)} دقيقة"
    }

    internal fun numbersToWords(s: String): String {
        var t = timeRe.replace(s) { m ->
            val h = westernDigits(m.groupValues[1]).toInt()
            val mi = westernDigits(m.groupValues[2]).toInt()
            if (h > 23 || mi > 59) m.value else spokenTime(h, mi)
        }
        t = numRe.replace(t) { m ->
            val raw = m.value
            val w = westernDigits(raw)
            val sepIdx = w.indexOfFirst { it == '.' || it == ',' || it == '٫' || it == '٬' }
            if (sepIdx >= 0) {
                val ip = w.substring(0, sepIdx); val fp = w.substring(sepIdx + 1)
                if (ip.length > 6 || fp.length > 6) digitWords(raw) else "${cardinal(ip.toInt(), false)} فاصلة ${digitWords(fp)}"
            } else if (w.length > 6) {
                digitWords(raw)   // أرقام طويلة (هواتف…): رقمًا رقمًا بدل عدد ضخم
            } else {
                val next = nextWordRe.find(t.substring(m.range.last + 1))?.groupValues?.get(1)
                val fem = next != null && QuranGuard.norm(next) in feminine
                cardinal(w.toInt(), fem)
            }
        }
        return t
    }

    // ------------------------------------------------------------------ 4) عبارات الذكر المشكّلة
    private val wordRe = Regex("[\\u0621-\\u064A\\u064B-\\u0652\\u0670\\u0671]+")
    private val diacRe = Regex("[\\u064B-\\u0652\\u0670\\u0653-\\u065F]")

    private fun hasDiacritics(s: String) = diacRe.containsMatchIn(s)

    /** عبارات كاملة معروفة فقط؛ المفتاح بلا تشكيل (مع توحيد الهمزات). يُستبدل المقطع فقط إن لم يكن فيه تشكيل أصلًا. */
    private val phrases: List<Pair<List<String>, String>> = listOf(
        "لا حول ولا قوة إلا بالله" to "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ",
        "بسم الله الرحمن الرحيم" to "بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ",
        "صلى الله عليه وسلم" to "صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ",
        "جزاك الله خيرا" to "جَزَاكَ اللَّهُ خَيْرًا",
        "لا إله إلا الله" to "لَا إِلَهَ إِلَّا اللَّهُ",
        "الصلاة على النبي" to "الصَّلَاة عَلَى النَّبِيِّ",
        "أذكار الصباح" to "أَذْكَار الصَّبَاحِ",
        "أذكار المساء" to "أَذْكَار الْمَسَاءِ",
        "وردك اليومي" to "وِرْدَك الْيَوْمِي",
        "وردي اليومي" to "وِرْدِي الْيَوْمِي",
        "الورد اليومي" to "الْوِرْد الْيَوْمِي",
        "إن شاء الله" to "إِنْ شَاءَ اللَّهُ",
        "ما شاء الله" to "مَا شَاءَ اللَّهُ",
        "سبحان الله" to "سُبْحَانَ اللَّهِ",
        "الحمد لله" to "الْحَمْدُ لِلَّهِ",
        "الله أكبر" to "اللَّهُ أَكْبَرُ",
        "أستغفر الله" to "أَسْتَغْفِرُ اللَّهَ",
    ).map { (p, r) -> p.split(' ').map { QuranGuard.norm(it) } to r }.sortedByDescending { it.first.size }

    internal fun applyPhraseLexicon(s: String): String {
        val toks = wordRe.findAll(s).toList()
        if (toks.isEmpty()) return s
        val sb = StringBuilder()
        var last = 0
        var i = 0
        while (i < toks.size) {
            var done = false
            for ((key, rep) in phrases) {
                val n = key.size
                if (i + n > toks.size) continue
                var ok = true
                for (j in 0 until n) {
                    if (QuranGuard.norm(toks[i + j].value) != key[j]) { ok = false; break }
                    if (j > 0 && s.substring(toks[i + j - 1].range.last + 1, toks[i + j].range.first).isNotBlank()) { ok = false; break }
                }
                if (!ok) continue
                val span = s.substring(toks[i].range.first, toks[i + n - 1].range.last + 1)
                if (hasDiacritics(span)) continue   // النص مشكّل أصلًا: لا نتدخل
                sb.append(s, last, toks[i].range.first).append(rep)
                last = toks[i + n - 1].range.last + 1
                i += n
                done = true
                break
            }
            if (!done) i++
        }
        sb.append(s, last, s.length)
        return sb.toString()
    }

    // ------------------------------------------------------------------ 5) تهجئة اللهجة (سياقية)
    private val egyptMap: Map<String, String> = mapOf(
        "ازيك" to "إِزَّيَّكْ", "ايه" to "إِيهْ", "ازاي" to "إِزَّايْ", "عامل" to "عَامِلْ", "يلا" to "يَلَّا", "بينا" to "بِينَا",
        "متنساش" to "مَتِنْسَاشْ", "متنسيش" to "مَتِنْسِيشْ", "خد" to "خُدْ", "جه" to "جَهْ", "لسه" to "لِسَّهْ", "عندك" to "عِنْدَكْ",
        "عايز" to "عَايِزْ", "عاوز" to "عَاوِزْ", "النهارده" to "النَّهَارْدَهْ", "دلوقتي" to "دِلْوَقْتِي", "كده" to "كِدَهْ",
        "ده" to "دَهْ", "دي" to "دِي", "قدامك" to "قُدَّامَكْ", "فرصه" to "فُرْصَة", "تعمل" to "تِعْمِلْ", "خلي" to "خَلِّي",
        "لسانك" to "لِسَانَكْ", "ربنا" to "رَبِّنَا", "يتقبل" to "يِتْقَبَّلْ",
    )
    private val egyptMarkers = setOf("ازيك", "ايه", "ازاي", "يلا", "متنساش", "متنسيش", "لسه", "ده", "دي", "كده", "النهارده", "دلوقتي", "عايز", "عاوز", "بينا", "جه", "قدامك")

    private val gulfMap: Map<String, String> = mapOf(
        "شلونك" to "شْلُونَكْ", "الحين" to "الْحِينْ", "خوي" to "خَوِي", "هلا" to "هَلَا", "ابشر" to "أَبْشِرْ", "يلا" to "يَلَّا",
    )
    private val gulfMarkers = setOf("شلونك", "الحين", "خوي", "هلا", "ابشر")

    private val sentenceSplit = Regex("(?<=[.!؟?\\n])")

    internal fun applyDialect(s: String, d: Dialect): String {
        val map = if (d == Dialect.EGYPT) egyptMap else gulfMap
        val markers = if (d == Dialect.EGYPT) egyptMarkers else gulfMarkers
        return s.split(sentenceSplit).joinToString("") { sentence ->
            val toks = wordRe.findAll(sentence).map { it.value }.toList()
            // السياق: لا تُطبَّق التهجئة إلا في جملة فيها علامة عامّية صريحة، وفي كلمات بلا تشكيل فقط
            if (toks.none { !hasDiacritics(it) && QuranGuard.norm(it) in markers }) sentence
            else wordRe.replace(sentence) { m ->
                val w = m.value
                if (hasDiacritics(w)) w else map[QuranGuard.norm(w)] ?: w
            }
        }
    }

    // ------------------------------------------------------------------ 6) الوقف والمسافات والتكرار
    private val punct = "[.!؟?،؛,;:]"
    private val multiPunct = Regex("($punct)(?:\\s*$punct)+")
    private val spaceBefore = Regex("\\s+($punct)")
    private val noSpaceAfter = Regex("($punct)(?=[^\\s.!؟?،؛,;:])")

    internal fun tidyPauses(s: String): String {
        var t = s.replace(Regex("\\s*\\n+\\s*"), "\n")
        t = t.replace(Regex("(?<=[.!؟?،؛,;:])\\n"), " ").replace("\n", "، ")
        t = multiPunct.replace(t) { it.groupValues[1] }
        t = spaceBefore.replace(t) { it.groupValues[1] }
        t = noSpaceAfter.replace(t) { it.groupValues[1] + " " }
        t = t.replace(Regex("[ \\t]+"), " ").trim().trimStart('،', '؛', ',', ';', '.', ' ')
        // جملة مكررة حرفيًا متتالية → مرة واحدة
        val parts = t.split(Regex("(?<=[.!؟?])\\s+"))
        val out = ArrayList<String>()
        for (p in parts) if (out.isEmpty() || QuranGuard.norm(out.last()) != QuranGuard.norm(p)) out.add(p)
        return out.joinToString(" ")
    }
}
