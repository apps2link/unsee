package com.unsee.app.notify

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.unsee.app.MainActivity
import com.unsee.app.R
import com.unsee.app.core.CompanionPicker
import com.unsee.app.core.CompanionSchedule
import com.unsee.app.core.CompanionSettings
import com.unsee.app.core.CompanionTexts
import com.unsee.app.core.LogAction
import com.unsee.app.core.LogKind
import com.unsee.app.core.Prayer
import com.unsee.app.core.PrayerEvent
import com.unsee.app.core.PrayerEventKind
import com.unsee.app.core.PrayerLog
import com.unsee.app.data.CompanionMessages
import com.unsee.app.data.CompanionStore
import com.unsee.app.data.Store
import com.unsee.app.overlay.BubbleOverlay
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.withContext
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.concurrent.TimeUnit
import kotlin.random.Random

/** أزرار التذكير: PRIMARY = «تم الذكر» أو «صليت الحمد لله» حسب النوع. */
enum class CompanionAct { PRIMARY, SNOOZE, OPEN, DISMISS }

/**
 * ما يُعرض للمستخدم (فقاعة أو إشعار). [ref]: للذكر معرّف الرسالة، وللصلاة «تاريخ|مفتاح الصلاة»، وللمحاسبة التاريخ.
 */
data class Presentation(
    val kind: LogKind,
    val ref: String,
    val title: String,
    val text: String,
    val sub: String?,
    val primary: String,
    val secondary: String,
    val open: String,
    val openRoute: String,
    val notifId: Int,
)

// ============================================================================ الإشعارات (البديل عند تعذّر الفقاعة)
object CompanionNotifier {
    const val CH_DHIKR = "companion_dhikr"
    const val CH_PRAYER = "companion_prayer"
    const val EXTRA_ACT = "cmp_act"
    const val EXTRA_KIND = "cmp_kind"
    const val EXTRA_REF = "cmp_ref"
    const val EXTRA_ROUTE = "cmp_route"
    const val EXTRA_NOTIF = "cmp_notif"
    const val ACTION = "com.unsee.app.COMPANION_ACT"

    fun createChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_DHIKR, "رفيق أُنسي: تذكيرات الذكر", NotificationManager.IMPORTANCE_LOW).apply {
                description = "رسائل قصيرة تذكّرك بالذكر والاستغفار، بلا صوت"
                setSound(null, null)
                enableVibration(false)
                setShowBadge(false)
            },
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_PRAYER, "رفيق أُنسي: الصلاة ومحاسبة النفس", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "تذكير بمواقيت الصلاة وبمراجعة آخر اليوم. يمكنك ضبط الصوت من إعدادات النظام"
                setShowBadge(false)
            },
        )
    }

    fun canNotify(ctx: Context): Boolean = Reminders.canNotify(ctx)

    fun cancel(ctx: Context, id: Int) {
        runCatching { NotificationManagerCompat.from(ctx).cancel(id) }
    }

    private fun openIntent(ctx: Context, route: String, req: Int): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
            .putExtra("route", route)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(ctx, req, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun actIntent(ctx: Context, p: Presentation, act: CompanionAct): PendingIntent {
        val i = Intent(ctx, CompanionActionReceiver::class.java)
            .setAction(ACTION)
            .putExtra(EXTRA_ACT, act.name)
            .putExtra(EXTRA_KIND, p.kind.name)
            .putExtra(EXTRA_REF, p.ref)
            .putExtra(EXTRA_ROUTE, p.openRoute)
            .putExtra(EXTRA_NOTIF, p.notifId)
        val req = "${p.kind.name}|${p.ref}|${act.name}".hashCode()
        return PendingIntent.getBroadcast(ctx, req, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun post(ctx: Context, p: Presentation) {
        if (!canNotify(ctx)) return
        val channel = if (p.kind == LogKind.DHIKR) CH_DHIKR else CH_PRAYER
        val body = if (p.sub.isNullOrBlank()) p.text else "${p.text}\n${p.sub}"
        val b = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(p.title)
            .setContentText(p.text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setContentIntent(openIntent(ctx, p.openRoute, p.notifId))
            .setAutoCancel(true)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(if (p.kind == LogKind.DHIKR) NotificationCompat.PRIORITY_LOW else NotificationCompat.PRIORITY_DEFAULT)
        if (p.kind == LogKind.DHIKR) b.setSilent(true)
        if (p.primary.isNotBlank()) b.addAction(R.drawable.ic_notification, p.primary, actIntent(ctx, p, CompanionAct.PRIMARY))
        if (p.secondary.isNotBlank()) b.addAction(R.drawable.ic_notification, p.secondary, actIntent(ctx, p, CompanionAct.SNOOZE))
        if (p.open.isNotBlank()) b.addAction(R.drawable.ic_notification, p.open, openIntent(ctx, p.openRoute, p.notifId + 1))
        runCatching { NotificationManagerCompat.from(ctx).notify(p.notifId, b.build()) }
    }
}

class CompanionActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != CompanionNotifier.ACTION) return
        val act = runCatching { CompanionAct.valueOf(intent.getStringExtra(CompanionNotifier.EXTRA_ACT) ?: "") }.getOrNull() ?: return
        val kind = runCatching { LogKind.valueOf(intent.getStringExtra(CompanionNotifier.EXTRA_KIND) ?: "") }.getOrNull() ?: return
        val ref = intent.getStringExtra(CompanionNotifier.EXTRA_REF) ?: return
        val route = intent.getStringExtra(CompanionNotifier.EXTRA_ROUTE) ?: "companion"
        val notifId = intent.getIntExtra(CompanionNotifier.EXTRA_NOTIF, -1)
        CompanionActions.handle(context, act, kind, ref, route)
        if (notifId != -1) CompanionNotifier.cancel(context, notifId)
    }
}

// ============================================================================ أفعال المستخدم (من الفقاعة أو من الإشعار)
object CompanionActions {
    const val PREVIEW_REF = "preview"

    fun handle(ctx: Context, act: CompanionAct, kind: LogKind, ref: String, route: String) {
        if (ref == PREVIEW_REF) {
            if (act == CompanionAct.OPEN) openApp(ctx, route)
            return
        }
        val cs = CompanionStore.get(ctx)
        when (act) {
            CompanionAct.PRIMARY -> when (kind) {
                LogKind.PRAYER -> {
                    val parts = ref.split('|')
                    val date = runCatching { LocalDate.parse(parts.getOrElse(0) { "" }) }.getOrNull()
                    val prayer = Prayer.fromKey(parts.getOrElse(1) { "" })
                    if (date != null && prayer != null) cs.setPrayerStatus(date, prayer, PrayerLog.PRAYED)
                    cs.appendLog(kind, ref, LogAction.PRAYED)
                }
                else -> cs.appendLog(kind, ref, LogAction.DONE)
            }
            CompanionAct.SNOOZE -> {
                val minutes = if (kind == LogKind.PRAYER) cs.settings().snoozeMin else CompanionSchedule.SNOOZE_DHIKR_MIN
                CompanionScheduler.scheduleSnooze(ctx, kind, ref, minutes)
                cs.appendLog(kind, ref, LogAction.SNOOZE)
            }
            CompanionAct.OPEN -> {
                cs.appendLog(kind, ref, LogAction.OPENED)
                openApp(ctx, route)
            }
            CompanionAct.DISMISS -> cs.appendLog(kind, ref, LogAction.DISMISSED)
        }
    }

    /** يفتح التطبيق على شاشة معينة. إن منع النظام فتح نشاط من الخلفية نترك الإشعار البديل (لا نتحايل على القيود). */
    fun openApp(ctx: Context, route: String) {
        val i = Intent(ctx, MainActivity::class.java)
            .putExtra("route", route)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        runCatching { ctx.startActivity(i) }
    }
}

// ============================================================================ العرض: فقاعة أو إشعار بديل
object CompanionEngine {
    private fun interactive(ctx: Context): Boolean =
        runCatching { ctx.getSystemService(PowerManager::class.java).isInteractive }.getOrDefault(false)

    /** وضع «عدم الإزعاج» مفعّل بأي درجة. */
    fun dndActive(ctx: Context): Boolean = runCatching {
        ctx.getSystemService(NotificationManager::class.java).currentInterruptionFilter > NotificationManager.INTERRUPTION_FILTER_ALL
    }.getOrDefault(false)

    private fun minutesLate(atMs: Long): Long =
        if (atMs <= 0L) 0L else Duration.between(Instant.ofEpochMilli(atMs), Instant.now()).toMinutes()

    private suspend fun present(ctx: Context, p: Presentation, s: CompanionSettings, allowBubble: Boolean) {
        val cs = CompanionStore.get(ctx)
        val bubbleOk = allowBubble && s.bubble && BubbleOverlay.canDraw(ctx) && interactive(ctx) && !dndActive(ctx)
        if (bubbleOk) {
            val animate = Store.get(ctx).settings().motion > 0
            val shown = withContext(Dispatchers.Main) {
                BubbleOverlay.show(
                    ctx, p, s.bubbleStyle, s.bubbleSeconds, animate, cs.bubbleY(),
                    onMoved = { cs.setBubbleY(it) },
                    onAct = { act -> CompanionActions.handle(ctx, act, p.kind, p.ref, p.openRoute) },
                )
            }
            if (shown) {
                cs.appendLog(p.kind, p.ref, LogAction.SHOWN_BUBBLE)
                try {
                    BubbleOverlay.awaitClosed(s.bubbleSeconds * 1000L + 3000L)
                } finally {
                    withContext(NonCancellable + Dispatchers.Main) { BubbleOverlay.dismiss() }
                }
                return
            }
        }
        // لا فقاعة: إشعار بديل إن كانت الإشعارات متاحة، وإلا نسجّل صراحة أن التذكير لم يُعرض.
        if (CompanionNotifier.canNotify(ctx)) {
            CompanionNotifier.post(ctx, p)
            cs.appendLog(p.kind, p.ref, LogAction.SHOWN_NOTIF)
        } else {
            cs.appendLog(p.kind, p.ref, LogAction.UNDELIVERED)
        }
    }

    private fun dhikrPresentation(msgId: String, text: String, source: String?): Presentation = Presentation(
        kind = LogKind.DHIKR,
        ref = msgId,
        title = "رفيق أُنسي",
        text = text,
        sub = source,
        primary = "تم الذكر",
        secondary = "ذكّرني لاحقًا",
        open = "فتح أُنسي",
        openRoute = "adhkar",
        notifId = 3001,
    )

    suspend fun deliverDhikr(ctx: Context, atMs: Long) {
        val cs = CompanionStore.get(ctx)
        val s = cs.settings()
        if (!s.enabled) return
        if (minutesLate(atMs) > CompanionSchedule.STALE_DHIKR_MIN) return
        if (atMs > 0 && cs.lastKey("dhikr") == atMs.toString()) return
        if (cs.dhikrShownToday() >= s.maxPerDay) return
        val now = ZonedDateTime.now()
        if (CompanionSchedule.isQuiet(now.hour * 60 + now.minute, s)) return
        val msg = CompanionPicker.pick(CompanionMessages.all, s, now.hour, cs.recentIds(), Random(System.nanoTime())) ?: return
        if (atMs > 0) cs.setLastKey("dhikr", atMs.toString())
        cs.pushRecent(msg.id)
        present(ctx, dhikrPresentation(msg.id, msg.text, msg.source?.let { "— $it" }), s, allowBubble = true)
    }

    suspend fun deliverPrayer(ctx: Context, prayerKey: String, kindName: String, atMs: Long) {
        val cs = CompanionStore.get(ctx)
        val s = cs.settings()
        if (!s.prayerEnabled) return
        val prayer = Prayer.fromKey(prayerKey) ?: return
        val kind = runCatching { PrayerEventKind.valueOf(kindName) }.getOrNull() ?: return
        if (!s.prayerOn(prayer)) return
        if (minutesLate(atMs) > CompanionSchedule.STALE_PRAYER_MIN) return
        val at = Instant.ofEpochMilli(atMs).atZone(ZoneId.systemDefault())
        val event = PrayerEvent(prayer, kind, at)
        if (cs.lastKey("prayer") == event.key) return
        val date = at.toLocalDate()
        if (kind == PrayerEventKind.AFTER && cs.prayerStatus(date, prayer) != PrayerLog.NONE) return
        cs.setLastKey("prayer", event.key)
        val (title, text) = CompanionTexts.prayer(prayer, kind, s.beforeMin, s.afterMin)
        present(ctx, prayerPresentation(date, prayer, title, text), s, allowBubble = true)
    }

    private fun prayerPresentation(date: LocalDate, prayer: Prayer, title: String, text: String) = Presentation(
        kind = LogKind.PRAYER,
        ref = "$date|${prayer.key}",
        title = title,
        text = text,
        sub = null,
        primary = "صليت الحمد لله",
        secondary = "فكّرني لاحقًا",
        open = "افتح مواقيت الصلاة",
        openRoute = "prayer",
        notifId = 4000 + prayer.ordinal,
    )

    /** إعادة عرض بعد «ذكّرني لاحقًا». للصلاة: نتوقف إن كان المستخدم قد سجّلها في الأثناء. */
    suspend fun deliverSnooze(ctx: Context, kindName: String, ref: String) {
        val cs = CompanionStore.get(ctx)
        val s = cs.settings()
        val kind = runCatching { LogKind.valueOf(kindName) }.getOrNull() ?: return
        when (kind) {
            LogKind.PRAYER -> {
                val parts = ref.split('|')
                val date = runCatching { LocalDate.parse(parts.getOrElse(0) { "" }) }.getOrNull() ?: return
                val prayer = Prayer.fromKey(parts.getOrElse(1) { "" }) ?: return
                if (cs.prayerStatus(date, prayer) != PrayerLog.NONE) return
                val (title, text) = CompanionTexts.prayerSnoozed(prayer)
                present(ctx, prayerPresentation(date, prayer, title, text), s, allowBubble = true)
            }
            LogKind.DHIKR -> {
                val msg = CompanionMessages.byId(ref) ?: return
                val now = ZonedDateTime.now()
                if (CompanionSchedule.isQuiet(now.hour * 60 + now.minute, s)) return
                present(ctx, dhikrPresentation(msg.id, msg.text, msg.source?.let { "— $it" }), s, allowBubble = true)
            }
            LogKind.MUHASABA -> deliverMuhasaba(ctx)
        }
    }

    /** محاسبة النفس: إشعار فقط (الفقاعة غير مناسبة لجلسة تتطلب كتابة). لا يُرسل إن كان المستخدم أجرى مراجعة اليوم. */
    fun deliverMuhasaba(ctx: Context) {
        val cs = CompanionStore.get(ctx)
        val s = cs.settings()
        if (!s.muhasabaEnabled) return
        val today = LocalDate.now().toString()
        if (cs.muhasaba(today)?.answered == true) return
        if (cs.lastKey("muhasaba") == today) return
        cs.setLastKey("muhasaba", today)
        val p = Presentation(
            kind = LogKind.MUHASABA,
            ref = today,
            title = CompanionTexts.MUHASABA_TITLE,
            text = CompanionTexts.MUHASABA_BODY,
            sub = null,
            primary = "",
            secondary = "",
            open = "ابدأ المراجعة",
            openRoute = "muhasaba",
            notifId = 5001,
        )
        if (CompanionNotifier.canNotify(ctx)) {
            CompanionNotifier.post(ctx, p)
            cs.appendLog(LogKind.MUHASABA, today, LogAction.SHOWN_NOTIF)
        } else {
            cs.appendLog(LogKind.MUHASABA, today, LogAction.UNDELIVERED)
        }
    }
}

// ============================================================================ الجدولة (WorkManager، دون إذن المنبّه الدقيق)
object CompanionScheduler {
    const val TYPE_DHIKR = "dhikr"
    const val TYPE_PRAYER = "prayer"
    const val TYPE_MUHASABA = "muhasaba"
    const val TYPE_SNOOZE = "snooze"
    private val TYPES = listOf(TYPE_DHIKR, TYPE_PRAYER, TYPE_MUHASABA)

    private fun name(type: String, slot: Int) = "unsee_cmp_${type}_$slot"

    fun cancelAll(ctx: Context) {
        val wm = WorkManager.getInstance(ctx)
        for (t in TYPES) { wm.cancelUniqueWork(name(t, 0)); wm.cancelUniqueWork(name(t, 1)) }
    }

    /**
     * يُستدعى عند فتح التطبيق، وعند الإقلاع، وعند تغيّر الوقت أو المنطقة الزمنية، وبعد تحديث التطبيق، وبعد تعديل أي إعداد.
     * المواعيد حتمية (تُحسب من الإعدادات والساعة)، فإعادة الجدولة لا تُنتج تذكيرًا مكررًا.
     */
    fun rescheduleAll(ctx: Context) {
        cancelAll(ctx)
        val s = CompanionStore.get(ctx).settings()
        if (s.enabled) schedule(ctx, TYPE_DHIKR, 0)
        if (s.prayerEnabled) schedule(ctx, TYPE_PRAYER, 0)
        if (s.muhasabaEnabled) schedule(ctx, TYPE_MUHASABA, 0)
    }

    fun schedule(ctx: Context, type: String, slot: Int) {
        val cs = CompanionStore.get(ctx)
        val s = cs.settings()
        val now = ZonedDateTime.now()
        var at: ZonedDateTime? = null
        var pkey = ""
        var pkind = ""
        when (type) {
            TYPE_DHIKR -> if (s.enabled) at = CompanionSchedule.nextDhikr(now, s, cs.dhikrShownToday())
            TYPE_PRAYER -> if (s.prayerEnabled) {
                val ev = CompanionSchedule.nextPrayerEvent(now, s) { d, p -> cs.prayerStatus(d, p) != PrayerLog.NONE }
                if (ev != null) { at = ev.at; pkey = ev.prayer.key; pkind = ev.kind.name }
            }
            TYPE_MUHASABA -> if (s.muhasabaEnabled) at = CompanionSchedule.nextMuhasaba(now, s)
        }
        val target = at ?: return
        val delay = Duration.between(now, target).toMillis().coerceAtLeast(1_000L)
        val req = OneTimeWorkRequestBuilder<CompanionWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setInputData(
                workDataOf(
                    "type" to type, "slot" to slot, "at" to target.toInstant().toEpochMilli(),
                    "pkey" to pkey, "pkind" to pkind,
                ),
            )
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork(name(type, slot), ExistingWorkPolicy.REPLACE, req)
    }

    fun scheduleSnooze(ctx: Context, kind: LogKind, ref: String, minutes: Int) {
        val req = OneTimeWorkRequestBuilder<CompanionWorker>()
            .setInitialDelay(minutes.coerceAtLeast(1).toLong(), TimeUnit.MINUTES)
            .setInputData(workDataOf("type" to TYPE_SNOOZE, "slot" to 0, "kind" to kind.name, "ref" to ref))
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork("unsee_cmp_snooze_${kind.name}_$ref", ExistingWorkPolicy.REPLACE, req)
    }
}

class CompanionWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val type = inputData.getString("type") ?: return Result.success()
        val slot = inputData.getInt("slot", 0)
        val at = inputData.getLong("at", 0L)
        val c = applicationContext
        try {
            when (type) {
                CompanionScheduler.TYPE_DHIKR -> CompanionEngine.deliverDhikr(c, at)
                CompanionScheduler.TYPE_PRAYER ->
                    CompanionEngine.deliverPrayer(c, inputData.getString("pkey") ?: "", inputData.getString("pkind") ?: "", at)
                CompanionScheduler.TYPE_MUHASABA -> CompanionEngine.deliverMuhasaba(c)
                CompanionScheduler.TYPE_SNOOZE ->
                    CompanionEngine.deliverSnooze(c, inputData.getString("kind") ?: "", inputData.getString("ref") ?: "")
            }
        } catch (e: CancellationException) {
            // أُلغي العمل (إعادة جدولة أو إيقاف): لا نجدول شيئًا هنا لأن من ألغاه تولّى الجدولة.
            throw e
        } catch (e: Exception) {
            // فشل عرض واحد لا يجب أن يوقف سلسلة التذكيرات
        }
        // نجدول الموعد التالي تحت اسم بديل (0/1) كي لا نُلغي هذا العمل أثناء تنفيذه.
        if (type != CompanionScheduler.TYPE_SNOOZE) CompanionScheduler.schedule(c, type, 1 - slot)
        return Result.success()
    }
}
