package com.unsee.app.notify

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.unsee.app.MainActivity
import com.unsee.app.R
import com.unsee.app.core.CompanionPicker
import com.unsee.app.core.CompanionSchedule
import com.unsee.app.core.CompanionSettings
import com.unsee.app.core.CompanionTexts
import com.unsee.app.core.Essential
import com.unsee.app.core.LedgerLogic
import com.unsee.app.core.LedgerType
import com.unsee.app.core.PendingItem
import com.unsee.app.core.PlanLogic
import com.unsee.app.core.QuitPlan
import com.unsee.app.core.Arabic
import com.unsee.app.core.Voice
import com.unsee.app.core.LogAction
import com.unsee.app.core.LogKind
import com.unsee.app.core.Prayer
import com.unsee.app.core.PrayerEvent
import com.unsee.app.core.PrayerEventKind
import com.unsee.app.core.PrayerLog
import com.unsee.app.data.CompanionMessages
import com.unsee.app.data.CompanionStore
import com.unsee.app.overlay.BubbleController
import com.unsee.app.overlay.BubbleOverlay
import kotlinx.coroutines.CancellationException
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.concurrent.TimeUnit
import kotlin.random.Random

/** أزرار التذكير: PRIMARY = «تم الذكر» أو «صليت الحمد لله» حسب النوع. */
enum class CompanionAct { PRIMARY, SNOOZE, OPEN, DISMISS, SLIP }

/**
 * ما يُعرض للمستخدم (فقاعة أو إشعار). [ref]: للذكر معرّف الرسالة، وللصلاة «تاريخ|مفتاح الصلاة»، وللمحاسبة التاريخ.
 */
data class Presentation(
    val kind: LogKind,
    val ref: String,
    val title: String,
    val text: String,
    val sub: String?,
    val primary: String,
    val secondary: String,
    val open: String,
    val openRoute: String,
    val notifId: Int,
    /** أولوية عليا: تبقى في الفقاعة ولا تُلغى ولا تُؤجَّل إلا بالرد عليها (خطط الإقلاع). */
    val priority: Boolean = false,
) {
    fun toPending(ts: Long = System.currentTimeMillis()) =
        PendingItem(kind, ref, title, text, sub, primary, secondary, open, openRoute, notifId, priority, ts)
}

// ============================================================================ الإشعارات (البديل عند تعذّر الفقاعة)
object CompanionNotifier {
    const val CH_DHIKR = "companion_dhikr"
    const val CH_PRAYER = "companion_prayer_v3"
    private const val CH_PRAYER_OLD = "companion_prayer"
    private const val CH_PRAYER_V2 = "companion_prayer_v2"
    const val EXTRA_ACT = "cmp_act"
    const val EXTRA_KIND = "cmp_kind"
    const val EXTRA_REF = "cmp_ref"
    const val EXTRA_ROUTE = "cmp_route"
    const val EXTRA_NOTIF = "cmp_notif"
    const val ACTION = "com.unsee.app.COMPANION_ACT"
    const val ACTION_BUBBLE_OFF = "com.unsee.app.BUBBLE_OFF"

    fun createChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_DHIKR, "رفيق أُنسي: تذكيرات الذكر", NotificationManager.IMPORTANCE_LOW).apply {
                description = "رسائل قصيرة تذكّرك بالذكر والاستغفار، بلا صوت"
                setSound(null, null)
                enableVibration(false)
                setShowBadge(false)
            },
        )
        // قرار المستخدم: لا أصوات سوى الثلاثة. قناة الصلاة صامتة (اهتزاز النظام الافتراضي فقط)؛ القنوات القديمة تُحذف.
        nm.deleteNotificationChannel(CH_PRAYER_OLD)
        nm.deleteNotificationChannel(CH_PRAYER_V2)
        nm.createNotificationChannel(
            NotificationChannel(CH_PRAYER, "رفيق أُنسي: الصلاة والخطط ومحاسبة النفس", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "تذكير بمواقيت الصلاة وخطط الإقلاع ومراجعة آخر اليوم، بلا صوت من التطبيق. يمكنك اختيار نغمة من إعدادات النظام"
                setSound(null, null)
                setShowBadge(false)
            },
        )
    }

    fun canNotify(ctx: Context): Boolean = Reminders.canNotify(ctx)

    fun cancel(ctx: Context, id: Int) {
        runCatching { NotificationManagerCompat.from(ctx).cancel(id) }
    }

    private fun openIntent(ctx: Context, route: String, req: Int): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
            .putExtra("route", route)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(ctx, req, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun actIntent(ctx: Context, p: Presentation, act: CompanionAct): PendingIntent {
        val i = Intent(ctx, CompanionActionReceiver::class.java)
            .setAction(ACTION)
            .putExtra(EXTRA_ACT, act.name)
            .putExtra(EXTRA_KIND, p.kind.name)
            .putExtra(EXTRA_REF, p.ref)
            .putExtra(EXTRA_ROUTE, p.openRoute)
            .putExtra(EXTRA_NOTIF, p.notifId)
        val req = "${p.kind.name}|${p.ref}|${act.name}".hashCode()
        return PendingIntent.getBroadcast(ctx, req, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun post(ctx: Context, p: Presentation) {
        if (!canNotify(ctx)) return
        val channel = if (p.kind == LogKind.DHIKR || p.kind == LogKind.HABIT) CH_DHIKR else CH_PRAYER
        val body = if (p.sub.isNullOrBlank()) p.text else "${p.text}\n${p.sub}"
        val b = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(p.title)
            .setContentText(p.text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setContentIntent(openIntent(ctx, p.openRoute, p.notifId))
            .setAutoCancel(!p.priority)
            .setOngoing(p.priority)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(if (p.kind == LogKind.DHIKR || p.kind == LogKind.HABIT) NotificationCompat.PRIORITY_LOW else NotificationCompat.PRIORITY_DEFAULT)
        if (p.kind == LogKind.DHIKR || p.kind == LogKind.HABIT) b.setSilent(true)
        if (p.primary.isNotBlank()) b.addAction(R.drawable.ic_notification, p.primary, actIntent(ctx, p, CompanionAct.PRIMARY))
        if (p.secondary.isNotBlank()) b.addAction(R.drawable.ic_notification, p.secondary, actIntent(ctx, p, if (p.kind == LogKind.PLAN) CompanionAct.SLIP else CompanionAct.SNOOZE))
        if (p.open.isNotBlank()) b.addAction(R.drawable.ic_notification, p.open, openIntent(ctx, p.openRoute, p.notifId + 1))
        runCatching { NotificationManagerCompat.from(ctx).notify(p.notifId, b.build()) }
    }
}

class CompanionActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == CompanionNotifier.ACTION_BUBBLE_OFF) {
            val store = CompanionStore.get(context)
            store.edit { putBoolean("cmp_bubble", false) }
            store.setBubbleSnoozeUntil(0L)               // إيقاف صريح من المستخدم: لا عودة تلقائية
            CompanionScheduler.cancelBubbleSnooze(context)
            BubbleController.sync(context)
            return
        }
        if (intent.action != CompanionNotifier.ACTION) return
        val act = runCatching { CompanionAct.valueOf(intent.getStringExtra(CompanionNotifier.EXTRA_ACT) ?: "") }.getOrNull() ?: return
        val kind = runCatching { LogKind.valueOf(intent.getStringExtra(CompanionNotifier.EXTRA_KIND) ?: "") }.getOrNull() ?: return
        val ref = intent.getStringExtra(CompanionNotifier.EXTRA_REF) ?: return
        val route = intent.getStringExtra(CompanionNotifier.EXTRA_ROUTE) ?: "companion"
        val notifId = intent.getIntExtra(CompanionNotifier.EXTRA_NOTIF, -1)
        CompanionActions.handle(context, act, kind, ref, route)
        if (notifId != -1) CompanionNotifier.cancel(context, notifId)
    }
}

// ============================================================================ أفعال المستخدم (من الفقاعة أو من الإشعار)
object CompanionActions {
    const val PREVIEW_REF = "preview"

    fun handle(ctx: Context, act: CompanionAct, kind: LogKind, ref: String, route: String) {
        if (ref == PREVIEW_REF) {
            if (act == CompanionAct.OPEN) openApp(ctx, route)
            return
        }
        val cs = CompanionStore.get(ctx)
        when (act) {
            CompanionAct.PRIMARY -> when (kind) {
                LogKind.PRAYER -> {
                    val parts = ref.split('|')
                    val date = runCatching { LocalDate.parse(parts.getOrElse(0) { "" }) }.getOrNull()
                    val prayer = Prayer.fromKey(parts.getOrElse(1) { "" })
                    if (date != null && prayer != null) {
                        cs.setPrayerStatus(date, prayer, PrayerLog.PRAYED)
                        // تُحسب في دفتر الحسنات مرة واحدة لكل صلاة
                        Essential.values().firstOrNull { it.prayer == prayer }?.let { e ->
                            cs.addLedger(LedgerType.GOOD, cs.voice().essentialTitle(e), key = e.ledgerKey, date = date.toString())
                            cs.setEssentialAnswer(date.toString(), e.key, 1)
                        }
                    }
                    cs.appendLog(kind, ref, LogAction.PRAYED)
                }
                LogKind.DHIKR -> {
                    cs.appendLog(kind, ref, LogAction.DONE)
                    cs.addLedger(LedgerType.GOOD, "ذكرت الله", key = "dhikr:${System.currentTimeMillis()}")
                }
                LogKind.HABIT -> {
                    cs.appendLog(kind, ref, LogAction.DONE)
                    cs.addLedger(LedgerType.GOOD, ref.removePrefix("habit:"))
                }
                LogKind.PLAN -> {
                    cs.keepPlanToday(ref.removePrefix("plan:"))
                    cs.appendLog(kind, ref, LogAction.DONE)
                }
                else -> cs.appendLog(kind, ref, LogAction.DONE)
            }
            CompanionAct.SLIP -> {
                if (kind == LogKind.PLAN) cs.slipPlan(ref.removePrefix("plan:"))
                cs.appendLog(kind, ref, LogAction.SLIPPED)
            }
            CompanionAct.SNOOZE -> {
                val minutes = when (kind) {
                    LogKind.PRAYER -> cs.settings().snoozeMin
                    LogKind.HABIT -> 120
                    else -> CompanionSchedule.SNOOZE_DHIKR_MIN
                }
                CompanionScheduler.scheduleSnooze(ctx, kind, ref, minutes)
                cs.appendLog(kind, ref, LogAction.SNOOZE)
            }
            CompanionAct.OPEN -> {
                cs.appendLog(kind, ref, LogAction.OPENED)
                openApp(ctx, route)
            }
            CompanionAct.DISMISS -> cs.appendLog(kind, ref, LogAction.DISMISSED)
        }
    }

    /** يفتح التطبيق على شاشة معينة. إن منع النظام فتح نشاط من الخلفية نترك الإشعار البديل (لا نتحايل على القيود). */
    fun openApp(ctx: Context, route: String) {
        val i = Intent(ctx, MainActivity::class.java)
            .putExtra("route", route)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        runCatching { ctx.startActivity(i) }
    }
}

// ============================================================================ العرض: فقاعة أو إشعار بديل
object CompanionEngine {
    /** وضع «عدم الإزعاج» مفعّل بأي درجة. */
    fun dndActive(ctx: Context): Boolean = runCatching {
        ctx.getSystemService(NotificationManager::class.java).currentInterruptionFilter > NotificationManager.INTERRUPTION_FILTER_ALL
    }.getOrDefault(false)

    private fun minutesLate(atMs: Long): Long =
        if (atMs <= 0L) 0L else Duration.between(Instant.ofEpochMilli(atMs), Instant.now()).toMinutes()

    /**
     * العرض: إن كانت الفقاعة مفعّلة والإذن موجودًا نضيف العنصر إلى «المعلّق» وتقفز الفقاعة بنقطة حمراء
     * (تبقى حتى يضغط المستخدم ويتفاعل). وإلا إشعار بديل، وإن تعطّلت الإشعارات أيضًا يُسجَّل «لم يُعرض».
     */
    private fun present(ctx: Context, p: Presentation, s: CompanionSettings, allowBubble: Boolean) {
        val cs = CompanionStore.get(ctx)
        if (allowBubble && s.bubble && BubbleOverlay.canDraw(ctx)) {
            cs.addPending(p.toPending())
            if (BubbleController.notifyNew(ctx)) {
                cs.appendLog(p.kind, p.ref, LogAction.SHOWN_BUBBLE)
                runCatching { com.unsee.app.voice.VoiceHooks.onPresentation(ctx, p) }
                return
            }
            cs.removePending(p.kind, p.ref)
        }
        if (CompanionNotifier.canNotify(ctx)) {
            CompanionNotifier.post(ctx, p)
            cs.appendLog(p.kind, p.ref, LogAction.SHOWN_NOTIF)
            runCatching { com.unsee.app.voice.VoiceHooks.onPresentation(ctx, p) }
        } else {
            cs.appendLog(p.kind, p.ref, LogAction.UNDELIVERED)
        }
    }

    private fun dhikrPresentation(v: Voice, msgId: String, text: String, source: String?): Presentation = Presentation(
        kind = LogKind.DHIKR,
        ref = msgId,
        title = v.bubbleTitle,
        text = text,
        sub = source,
        primary = v.bubbleDone,
        secondary = v.bubbleLater,
        open = v.bubbleOpen,
        openRoute = "adhkar",
        notifId = 3001,
    )

    fun deliverDhikr(ctx: Context, atMs: Long, ignoreDailyLimit: Boolean = false) {
        val cs = CompanionStore.get(ctx)
        val s = cs.settings()
        if (!s.enabled) return
        if (minutesLate(atMs) > CompanionSchedule.STALE_DHIKR_MIN) return
        if (atMs > 0 && cs.lastKey("dhikr") == atMs.toString()) return
        if (!ignoreDailyLimit && cs.dhikrShownToday() >= s.maxPerDay) return
        val now = ZonedDateTime.now()
        if (CompanionSchedule.isQuiet(now.hour * 60 + now.minute, s)) return
        val msg = CompanionPicker.pick(CompanionMessages.all, s, now.hour, cs.recentIds(), Random(System.nanoTime())) ?: return
        if (atMs > 0) cs.setLastKey("dhikr", atMs.toString())
        cs.pushRecent(msg.id)
        val v = cs.voice()
        present(ctx, dhikrPresentation(v, msg.id, msg.textFor(v.dialect), msg.source?.let { "— $it" }), s, allowBubble = true)
    }

    fun deliverPrayer(ctx: Context, prayerKey: String, kindName: String, atMs: Long) {
        val cs = CompanionStore.get(ctx)
        val s = cs.settings()
        if (!s.prayerEnabled) return
        val prayer = Prayer.fromKey(prayerKey) ?: return
        val kind = runCatching { PrayerEventKind.valueOf(kindName) }.getOrNull() ?: return
        if (!s.prayerOn(prayer)) return
        if (minutesLate(atMs) > CompanionSchedule.STALE_PRAYER_MIN) return
        val at = Instant.ofEpochMilli(atMs).atZone(ZoneId.systemDefault())
        val event = PrayerEvent(prayer, kind, at)
        if (cs.lastKey("prayer") == event.key) return
        val date = at.toLocalDate()
        if (kind == PrayerEventKind.AFTER && cs.prayerStatus(date, prayer) != PrayerLog.NONE) return
        cs.setLastKey("prayer", event.key)
        val v = cs.voice()
        val (title, text) = CompanionTexts.prayer(prayer, kind, s.beforeMin, s.afterMin, v)
        present(ctx, prayerPresentation(v, date, prayer, title, text), s, allowBubble = true)
    }

    private fun prayerPresentation(v: Voice, date: LocalDate, prayer: Prayer, title: String, text: String) = Presentation(
        kind = LogKind.PRAYER,
        ref = "$date|${prayer.key}",
        title = title,
        text = text,
        sub = null,
        primary = v.prayedLabel,
        secondary = v.prayerLater,
        open = v.prayerOpen,
        openRoute = "prayer",
        notifId = 4000 + prayer.ordinal,
    )

    /** تذكير بالعادات الحلوة: عمل صالح سجّلته أمس ولم تسجّله اليوم بعد. مرة واحدة يوميًا. */
    fun deliverHabit(ctx: Context, atMs: Long) {
        val cs = CompanionStore.get(ctx)
        val s = cs.settings()
        if (!s.habitEnabled) return
        if (minutesLate(atMs) > CompanionSchedule.STALE_DHIKR_MIN) return
        val today = LocalDate.now()
        if (cs.lastKey("habit") == today.toString()) return
        val now = ZonedDateTime.now()
        if (CompanionSchedule.isQuiet(now.hour * 60 + now.minute, s)) return
        val titles = LedgerLogic.habitsToRemind(cs.ledgerRange(45), today)
        if (titles.isEmpty()) return
        cs.setLastKey("habit", today.toString())
        val v = cs.voice()
        titles.forEachIndexed { i, t -> present(ctx, habitPresentation(v, t, i), s, allowBubble = true) }
    }

    private fun habitPresentation(v: Voice, title: String, index: Int) = Presentation(
        kind = LogKind.HABIT,
        ref = "habit:$title",
        title = v.habitTitle,
        text = v.habitReminder(title),
        sub = null,
        primary = v.habitDone,
        secondary = v.habitLater,
        open = v.bubbleOpen,
        openRoute = "muhasaba",
        notifId = 6001 + index,
    )

    /** تذكير خطة الإقلاع: أولوية عليا، تبقى في الفقاعة حتى يردّ المستخدم (التزمت/وقعت). */
    fun deliverPlan(ctx: Context, planId: String, atMs: Long) {
        val cs = CompanionStore.get(ctx)
        val p = cs.plan(planId) ?: return
        if (!p.active) return
        if (minutesLate(atMs) > 120) return
        if (atMs > 0 && cs.lastKey("plan_$planId") == atMs.toString()) return
        if (p.lastKept == LocalDate.now().toString()) return
        if (atMs > 0) cs.setLastKey("plan_$planId", atMs.toString())
        present(ctx, planPresentation(cs.voice(), p), cs.settings(), allowBubble = true)
    }

    fun planPresentation(v: Voice, p: QuitPlan): Presentation = Presentation(
        kind = LogKind.PLAN,
        ref = "plan:${p.id}",
        title = v.planTitle(),
        text = v.planReminder(p.sin, p.replacement),
        sub = v.t("عدّاد الالتزام: ", "عدّاد الالتزام: ") + Arabic.digits(PlanLogic.cleanDays(p, LocalDate.now())) + v.t(" يوم", " يوم"),
        primary = v.planKept,
        secondary = v.planSlip,
        open = v.t("افتح الخطة", "افتح الخطة"),
        openRoute = "muhasaba",
        notifId = 5100 + (p.id.hashCode() and 0x3F),
        priority = true,
    )

    /** إعادة عرض بعد «ذكّرني لاحقًا». للصلاة: نتوقف إن كان المستخدم قد سجّلها في الأثناء. */
    fun deliverSnooze(ctx: Context, kindName: String, ref: String) {
        val cs = CompanionStore.get(ctx)
        val s = cs.settings()
        val kind = runCatching { LogKind.valueOf(kindName) }.getOrNull() ?: return
        val v = cs.voice()
        when (kind) {
            LogKind.PRAYER -> {
                val parts = ref.split('|')
                val date = runCatching { LocalDate.parse(parts.getOrElse(0) { "" }) }.getOrNull() ?: return
                val prayer = Prayer.fromKey(parts.getOrElse(1) { "" }) ?: return
                if (cs.prayerStatus(date, prayer) != PrayerLog.NONE) return
                val (title, text) = CompanionTexts.prayerSnoozed(prayer, v)
                present(ctx, prayerPresentation(v, date, prayer, title, text), s, allowBubble = true)
            }
            LogKind.DHIKR -> {
                val msg = CompanionMessages.byId(ref) ?: return
                val now = ZonedDateTime.now()
                if (CompanionSchedule.isQuiet(now.hour * 60 + now.minute, s)) return
                present(ctx, dhikrPresentation(v, msg.id, msg.textFor(v.dialect), msg.source?.let { "— $it" }), s, allowBubble = true)
            }
            LogKind.HABIT -> {
                val title = ref.removePrefix("habit:")
                val today = LocalDate.now().toString()
                if (cs.ledger(today).any { LedgerLogic.norm(it.title) == title }) return
                present(ctx, habitPresentation(v, title, 0), s, allowBubble = true)
            }
            LogKind.MUHASABA -> deliverMuhasaba(ctx)
            LogKind.PLAN -> Unit // خطط الإقلاع لا تُؤجَّل
        }
    }

    /** محاسبة النفس: إشعار فقط (الفقاعة غير مناسبة لجلسة تتطلب كتابة). لا يُرسل إن كان المستخدم أجرى مراجعة اليوم. */
    fun deliverMuhasaba(ctx: Context) {
        val cs = CompanionStore.get(ctx)
        val s = cs.settings()
        if (!s.muhasabaEnabled) return
        val today = LocalDate.now().toString()
        if (cs.muhasaba(today)?.answered == true) return
        if (cs.lastKey("muhasaba") == today) return
        cs.setLastKey("muhasaba", today)
        val v = cs.voice()
        val p = Presentation(
            kind = LogKind.MUHASABA,
            ref = today,
            title = v.t(CompanionTexts.MUHASABA_TITLE, "خلنا نحاسب نفسنا يا خوي"),
            text = v.t(CompanionTexts.MUHASABA_BODY, "قبل لا تنام، تعال نقعد دقيقتين مع نفسنا. مو عشان نجلد نفسنا، عشان باكر نصير أحسن."),
            sub = null,
            primary = "",
            secondary = "",
            open = v.t("ابدأ المحاسبة", "ابدأ المحاسبة"),
            openRoute = "muhasaba",
            notifId = 5001,
        )
        if (CompanionNotifier.canNotify(ctx)) {
            CompanionNotifier.post(ctx, p)
            cs.appendLog(LogKind.MUHASABA, today, LogAction.SHOWN_NOTIF)
        } else {
            cs.appendLog(LogKind.MUHASABA, today, LogAction.UNDELIVERED)
        }
    }
}

// ============================================================================ الجدولة (WorkManager، دون إذن المنبّه الدقيق)
object CompanionScheduler {
    const val TYPE_DHIKR = "dhikr"
    const val TYPE_PRAYER = "prayer"
    const val TYPE_MUHASABA = "muhasaba"
    const val TYPE_HABIT = "habit"
    const val TYPE_PLAN = "plan"
    const val TYPE_SNOOZE = "snooze"
    const val TYPE_BUBBLE_SNOOZE = "bubble_snooze"
    private const val BUBBLE_SNOOZE_WORK = "unsee_cmp_bubble_snooze"
    private val TYPES = listOf(TYPE_DHIKR, TYPE_PRAYER, TYPE_MUHASABA, TYPE_HABIT, TYPE_PLAN)

    private fun name(type: String, slot: Int) = "unsee_cmp_${type}_$slot"

    fun cancelAll(ctx: Context) {
        val wm = WorkManager.getInstance(ctx)
        for (t in TYPES) { wm.cancelUniqueWork(name(t, 0)); wm.cancelUniqueWork(name(t, 1)) }
    }

    /**
     * يُستدعى عند فتح التطبيق، وعند الإقلاع، وعند تغيّر الوقت أو المنطقة الزمنية، وبعد تحديث التطبيق، وبعد تعديل أي إعداد.
     * المواعيد حتمية (تُحسب من الإعدادات والساعة)، فإعادة الجدولة لا تُنتج تذكيرًا مكررًا. وفي النهاية نوفّق حالة الفقاعة.
     */
    fun rescheduleAll(ctx: Context) {
        cancelAll(ctx)
        val cs = CompanionStore.get(ctx)
        val s = cs.settings()
        if (s.enabled) schedule(ctx, TYPE_DHIKR, 0)
        if (s.prayerEnabled) schedule(ctx, TYPE_PRAYER, 0)
        if (s.muhasabaEnabled) schedule(ctx, TYPE_MUHASABA, 0)
        if (s.habitEnabled) schedule(ctx, TYPE_HABIT, 0)
        if (cs.plans().any { it.active }) schedule(ctx, TYPE_PLAN, 0)
        BubbleController.restoreSnooze(ctx)
        BubbleController.sync(ctx)
    }

    /** عمل واحد باسم ثابت: replace=true عند تأجيل جديد، وfalse (KEEP) عند الاستعادة كي لا تتكرر المهمة. */
    fun scheduleBubbleSnooze(ctx: Context, delayMs: Long, replace: Boolean) {
        val req = OneTimeWorkRequestBuilder<CompanionWorker>()
            .setInitialDelay(delayMs.coerceAtLeast(1_000L), TimeUnit.MILLISECONDS)
            .setInputData(workDataOf("type" to TYPE_BUBBLE_SNOOZE, "slot" to 0))
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork(BUBBLE_SNOOZE_WORK, if (replace) ExistingWorkPolicy.REPLACE else ExistingWorkPolicy.KEEP, req)
    }

    fun cancelBubbleSnooze(ctx: Context) {
        WorkManager.getInstance(ctx).cancelUniqueWork(BUBBLE_SNOOZE_WORK)
    }

    fun schedule(ctx: Context, type: String, slot: Int) {
        val cs = CompanionStore.get(ctx)
        val s = cs.settings()
        val now = ZonedDateTime.now()
        var at: ZonedDateTime? = null
        var pkey = ""
        var pkind = ""
        when (type) {
            TYPE_DHIKR -> if (s.enabled) at = CompanionSchedule.nextDhikr(now, s, cs.dhikrShownToday())
            TYPE_PRAYER -> if (s.prayerEnabled) {
                val ev = CompanionSchedule.nextPrayerEvent(now, s) { d, p -> cs.prayerStatus(d, p) != PrayerLog.NONE }
                if (ev != null) { at = ev.at; pkey = ev.prayer.key; pkind = ev.kind.name }
            }
            TYPE_MUHASABA -> if (s.muhasabaEnabled) at = CompanionSchedule.nextMuhasaba(now, s)
            TYPE_HABIT -> if (s.habitEnabled) at = CompanionSchedule.nextHabit(now, s)
            TYPE_PLAN -> PlanLogic.nextReminder(cs.plans(), now)?.let { (plan, t) -> at = t; pkey = plan.id }
        }
        val target = at ?: return
        val delay = Duration.between(now, target).toMillis().coerceAtLeast(1_000L)
        val req = OneTimeWorkRequestBuilder<CompanionWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setInputData(
                workDataOf(
                    "type" to type, "slot" to slot, "at" to target.toInstant().toEpochMilli(),
                    "pkey" to pkey, "pkind" to pkind,
                ),
            )
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork(name(type, slot), ExistingWorkPolicy.REPLACE, req)
    }

    fun scheduleSnooze(ctx: Context, kind: LogKind, ref: String, minutes: Int) {
        val req = OneTimeWorkRequestBuilder<CompanionWorker>()
            .setInitialDelay(minutes.coerceAtLeast(1).toLong(), TimeUnit.MINUTES)
            .setInputData(workDataOf("type" to TYPE_SNOOZE, "slot" to 0, "kind" to kind.name, "ref" to ref))
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork("unsee_cmp_snooze_${kind.name}_$ref", ExistingWorkPolicy.REPLACE, req)
    }
}

class CompanionWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val type = inputData.getString("type") ?: return Result.success()
        val slot = inputData.getInt("slot", 0)
        val at = inputData.getLong("at", 0L)
        val c = applicationContext
        try {
            when (type) {
                CompanionScheduler.TYPE_DHIKR -> CompanionEngine.deliverDhikr(c, at)
                CompanionScheduler.TYPE_PRAYER ->
                    CompanionEngine.deliverPrayer(c, inputData.getString("pkey") ?: "", inputData.getString("pkind") ?: "", at)
                CompanionScheduler.TYPE_MUHASABA -> CompanionEngine.deliverMuhasaba(c)
                CompanionScheduler.TYPE_HABIT -> CompanionEngine.deliverHabit(c, at)
                CompanionScheduler.TYPE_PLAN -> CompanionEngine.deliverPlan(c, inputData.getString("pkey") ?: "", at)
                CompanionScheduler.TYPE_SNOOZE ->
                    CompanionEngine.deliverSnooze(c, inputData.getString("kind") ?: "", inputData.getString("ref") ?: "")
                CompanionScheduler.TYPE_BUBBLE_SNOOZE ->
                    // لا نُعيدها إن أوقف المستخدم الرفيق نهائيًا (stopForever يمسح الموعد المحفوظ)
                    if (CompanionStore.get(c).bubbleSnoozeUntil() > 0L) BubbleController.resumeNow(c, true)
            }
        } catch (e: CancellationException) {
            // أُلغي العمل (إعادة جدولة أو إيقاف): لا نجدول شيئًا هنا لأن من ألغاه تولّى الجدولة.
            throw e
        } catch (e: Exception) {
            // فشل عرض واحد لا يجب أن يوقف سلسلة التذكيرات
        }
        // نجدول الموعد التالي تحت اسم بديل (0/1) كي لا نُلغي هذا العمل أثناء تنفيذه.
        if (type != CompanionScheduler.TYPE_SNOOZE && type != CompanionScheduler.TYPE_BUBBLE_SNOOZE) CompanionScheduler.schedule(c, type, 1 - slot)
        runCatching { com.unsee.app.voice.VoiceHooks.awaitAll() }   // لا تُنهى العملية قبل انتهاء الكلام
        return Result.success()
    }
}
