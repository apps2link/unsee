package com.unsee.app.ui

import android.graphics.Bitmap
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Canvas
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.CanvasDrawScope
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import com.unsee.app.core.Arabic
import com.unsee.app.core.CounterCatalog
import com.unsee.app.core.CounterCfg
import com.unsee.app.core.CounterEngine
import com.unsee.app.core.CounterStyle
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin

/**
 * رسم عدّادات التسبيح. دالة الرسم الواحدة [drawCounter] تُستخدم في ثلاثة أماكن بنفس الشكل تمامًا:
 *  أولًا داخل التطبيق (Canvas متحرك)، ثانيًا المعاينات المصغّرة في المعرض، ثالثًا صورة Bitmap لودجت الشاشة الرئيسية ([renderCounterBitmap]).
 * كل الأبعاد نسبية لنصف القطر فيظهر التصميم نفسه بأي حجم. لا يوجد أي اعتماد على الكثافة (dp) داخل الرسم.
 */
internal class CFrame(
    val st: CounterStyle,
    val ring: Color, val hi: Color, val acc: Color, val face: Color, val ink: Color,
    val light: Boolean,
    val p: Float,        // التقدّم 0..1
    val t: Float,        // زمن دوري 0..1 (مضاعفاته الصحيحة تتكرر بسلاسة)
    val tap: Float,      // 1 عند الضغط ثم يتلاشى إلى 0
    val burst: Float,    // 0..1 عند إكمال الهدف
    val glow: Float,
    val bgA: Float,
    val count: Int,
    val target: Int,
    val name: String,
    val cfg: CounterCfg,
)

// ------------------------------------------------------------------ أدوات
private const val TAU_F = (2.0 * PI).toFloat()

internal val DrawScope.rad: Float get() = size.minDimension / 2f
internal val DrawScope.uu: Float get() = size.minDimension / 270f
internal fun cWave(t: Float, k: Float, ph: Float = 0f): Float = sin(TAU_F * (t * k + ph))
internal fun cFrac(v: Float): Float = v - floor(v)
internal fun Color.al(x: Float): Color = this.copy(alpha = x.coerceIn(0f, 1f))
internal fun cRnd(i: Int, salt: Int = 0): Float {
    val x = sin((i * 12.9898 + salt * 78.233)) * 43758.5453
    return (x - floor(x)).toFloat()
}

/** نقطة على دائرة: [deg] بالدرجات تُقاس من أعلى الدائرة باتجاه عقارب الساعة. */
internal fun DrawScope.cPt(deg: Float, r: Float, c: Offset = center): Offset {
    val a = (deg - 90f) * (PI.toFloat() / 180f)
    return Offset(c.x + r * cos(a), c.y + r * sin(a))
}

internal fun DrawScope.glowDisc(c: Offset, r: Float, col: Color, a: Float) {
    if (a <= 0.003f || r <= 0f) return
    drawCircle(Brush.radialGradient(listOf(col.al(a), Color.Transparent), center = c, radius = r), radius = r, center = c)
}

internal fun DrawScope.faceDisc(f: CFrame, r: Float) {
    drawCircle(f.face.al(f.bgA), r, center)
}

internal fun DrawScope.trackRing(f: CFrame, r: Float, w: Float, a: Float = 0.18f) {
    drawCircle(f.ring.al(a), r, center, style = Stroke(w))
}

/** قوس يبدأ من أعلى الدائرة: [fromDeg] و[sweep] بالدرجات. */
internal fun DrawScope.arcRing(col: Color, fromDeg: Float, sweep: Float, r: Float, w: Float, round: Boolean = true) {
    if (sweep <= 0.2f) return
    drawArc(
        color = col, startAngle = -90f + fromDeg, sweepAngle = sweep, useCenter = false,
        topLeft = Offset(center.x - r, center.y - r), size = Size(r * 2f, r * 2f),
        style = Stroke(w, cap = if (round) StrokeCap.Round else StrokeCap.Butt),
    )
}

/** قوس مضيء: ثلاث طبقات تتدرّج بالسماكة والشفافية فتعطي توهجًا دون أي تمويه مكلف. */
internal fun DrawScope.glowArc(f: CFrame, col: Color, sweep: Float, r: Float, w: Float) {
    arcRing(col.al(0.07f * f.glow), 0f, sweep, r, w * 2.6f)
    arcRing(col.al(0.16f * f.glow), 0f, sweep, r, w * 1.7f)
    arcRing(col, 0f, sweep, r, w)
}

internal fun DrawScope.star4(c: Offset, s: Float, col: Color) {
    val p = Path().apply {
        moveTo(c.x, c.y - s); lineTo(c.x + s * 0.22f, c.y - s * 0.22f); lineTo(c.x + s, c.y); lineTo(c.x + s * 0.22f, c.y + s * 0.22f)
        lineTo(c.x, c.y + s); lineTo(c.x - s * 0.22f, c.y + s * 0.22f); lineTo(c.x - s, c.y); lineTo(c.x - s * 0.22f, c.y - s * 0.22f); close()
    }
    drawPath(p, col)
}

internal fun starPath(c: Offset, rOut: Float, rIn: Float, points: Int, rotDeg: Float): Path {
    val p = Path()
    val n = points * 2
    for (k in 0 until n) {
        val rr = if (k % 2 == 0) rOut else rIn
        val a = (k * (360f / n) - 90f + rotDeg) * (PI.toFloat() / 180f)
        val x = c.x + rr * cos(a)
        val y = c.y + rr * sin(a)
        if (k == 0) p.moveTo(x, y) else p.lineTo(x, y)
    }
    p.close()
    return p
}

internal fun circlePath(c: Offset, r: Float): Path = Path().apply { addOval(Rect(c, r)) }

/** ورقة (عدسة) طولها [len] وعرضها [wid] مركزها [c] ومحورها باتجاه [deg] (من الأعلى مع عقارب الساعة). */
internal fun leafPath(c: Offset, len: Float, wid: Float, deg: Float): Path {
    val a = (deg - 90f) * (PI.toFloat() / 180f)
    val ca = cos(a); val sa = sin(a)
    fun pnt(lx: Float, ly: Float) = Offset(c.x + lx * ca - ly * sa, c.y + lx * sa + ly * ca)
    val tip = pnt(len / 2f, 0f); val base = pnt(-len / 2f, 0f)
    val c1 = pnt(0f, wid); val c2 = pnt(0f, -wid)
    return Path().apply {
        moveTo(base.x, base.y)
        quadraticBezierTo(c1.x * 2f - (base.x + tip.x) / 2f, c1.y * 2f - (base.y + tip.y) / 2f, tip.x, tip.y)
        quadraticBezierTo(c2.x * 2f - (base.x + tip.x) / 2f, c2.y * 2f - (base.y + tip.y) / 2f, base.x, base.y)
        close()
    }
}

internal fun DrawScope.waveFill(topY: Float, amp: Float, k: Float, phase: Float, bottom: Float, left: Float, right: Float): Path {
    val p = Path()
    p.moveTo(left, bottom)
    val steps = 20
    for (i in 0..steps) {
        val x = left + (right - left) * i / steps
        p.lineTo(x, topY + amp * sin(TAU_F * (i.toFloat() / steps * k + phase)))
    }
    p.lineTo(right, bottom)
    p.close()
    return p
}

// ------------------------------------------------------------------ حلّ الألوان
internal fun resolveFrame(
    st: CounterStyle, cfg: CounterCfg, count: Int, target: Int, name: String,
    t: Float, tap: Float, burst: Float, progress: Float,
): CFrame {
    // light = هل العدّاد فاتح؟ (حسب إعداد المستخدم أو حسب التصميم)
    val light = when (cfg.tone) { 1 -> false; 2 -> true; else -> !st.dark }
    val styleLight = !st.dark
    val c1 = Color(st.c1)
    // لو غيّر المستخدم النغمة عن الافتراضية نعدّل الوجه والحلقة كي يبقى التصميم مقروءًا
    val faceBase = Color(st.face)
    val face = when {
        cfg.bgColor != 0L -> Color(cfg.bgColor)
        light == styleLight -> faceBase
        light -> lerp(Color.White, c1, 0.12f)
        else -> lerp(Color.Black, c1, 0.22f)
    }
    val ringBase = if (cfg.ringColor != 0L) Color(cfg.ringColor) else c1
    val ring = if (light && cfg.ringColor == 0L && !styleLight) lerp(ringBase, Color.Black, 0.30f) else ringBase
    val ink = when {
        cfg.numColor != 0L -> Color(cfg.numColor)
        light -> if (st.engine == CounterEngine.CALLI && styleLight) Color(st.c3) else lerp(Color.Black, c1, 0.28f)
        else -> Color(0xFFFFF8E6)
    }
    return CFrame(
        st = st, ring = ring, hi = Color(st.c2), acc = Color(st.c3), face = face, ink = ink, light = light,
        p = progress.coerceIn(0f, 1f), t = t, tap = tap, burst = burst,
        glow = cfg.glow, bgA = cfg.bgAlpha, count = count, target = target, name = name, cfg = cfg,
    )
}

// ------------------------------------------------------------------ الرقم والنصوص
private fun typefaceFor(font: Int): android.graphics.Typeface = when (font) {
    1 -> android.graphics.Typeface.create(android.graphics.Typeface.SANS_SERIF, android.graphics.Typeface.BOLD)
    2 -> android.graphics.Typeface.create(android.graphics.Typeface.SERIF, android.graphics.Typeface.NORMAL)
    3 -> android.graphics.Typeface.create("sans-serif-light", android.graphics.Typeface.NORMAL)
    else -> android.graphics.Typeface.create(android.graphics.Typeface.SERIF, android.graphics.Typeface.BOLD)
}

private fun argb(c: Color): Int =
    android.graphics.Color.argb((c.alpha * 255f).toInt(), (c.red * 255f).toInt(), (c.green * 255f).toInt(), (c.blue * 255f).toInt())

private fun numberFactor(e: CounterEngine): Float = when (e) {
    CounterEngine.STAR8 -> 0.80f
    CounterEngine.PETALS -> 0.84f
    CounterEngine.ORB -> 0.90f
    CounterEngine.DIAL -> 0.92f
    CounterEngine.BEADS -> 0.94f
    else -> 1f
}

internal fun DrawScope.drawCounterText(f: CFrame) {
    val r = rad; val u = uu
    val shown = if (f.target > 0) f.count.coerceAtMost(f.target) else f.count
    val digits = Arabic.digits(shown)
    val lenK = if (digits.length <= 3) 1f else (3f / digits.length).coerceAtLeast(0.5f)
    val pop = 1f + 0.10f * f.tap
    val size = r * 0.50f * f.cfg.numScale * lenK * numberFactor(f.st.engine) * pop
    val cy = center.y
    drawIntoCanvas { cv ->
        val nc = cv.nativeCanvas
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = android.graphics.Paint.Align.CENTER
            typeface = typefaceFor(f.cfg.font)
            textSize = size
        }
        val baseY = cy + size * 0.34f
        // ظل خفيف يضمن وضوح الرقم فوق أي تأثير ضوئي خلفه
        if (f.st.engine == CounterEngine.DEPTH) {
            paint.color = argb(Color.Black.al(0.55f)); nc.drawText(digits, center.x, baseY + 2.2f * u, paint)
            paint.color = argb(Color.White.al(0.22f)); nc.drawText(digits, center.x, baseY - 1.2f * u, paint)
        } else {
            paint.setShadowLayer(5f * u, 0f, 1.5f * u, argb((if (f.light) Color.White else Color.Black).al(0.55f)))
        }
        paint.color = argb(f.ink)
        nc.drawText(digits, center.x, baseY, paint)
        paint.clearShadowLayer()

        if (f.cfg.showGoal && f.target > 0) {
            val gp = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                textAlign = android.graphics.Paint.Align.CENTER
                typeface = typefaceFor(1)
                textSize = r * 0.115f
                color = argb(f.ring.al(0.95f))
            }
            nc.drawText("الهدف " + Arabic.digits(f.target), center.x, baseY + size * 0.22f + gp.textSize * 1.3f, gp)
        }
        if (f.cfg.showName && f.name.isNotBlank()) {
            val np = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                textAlign = android.graphics.Paint.Align.CENTER
                typeface = typefaceFor(2)
                textSize = r * 0.125f
                color = argb(f.ink.al(0.85f))
            }
            var txt = f.name.trim()
            if (txt.length > 22) txt = txt.take(21) + "…"
            val maxW = r * 1.25f
            val wNow = np.measureText(txt)
            if (wNow > maxW) np.textSize = np.textSize * maxW / wNow
            nc.drawText(txt, center.x, baseY - size * 0.95f, np)
        }
    }
}

// ------------------------------------------------------------------ النقطة المركزية
internal fun DrawScope.drawCounter(f: CFrame) {
    val r = rad
    // وميض الضغط العام (بالإضافة إلى أثر كل محرّك)
    glowDisc(center, r * 0.95f, f.hi, 0.22f * f.tap * f.glow)
    when (f.st.engine) {
        CounterEngine.HALO -> engHalo(f)
        CounterEngine.GLASS_GEM -> engGlassGem(f)
        CounterEngine.CRESCENT -> engCrescent(f)
        CounterEngine.ORBIT -> engOrbit(f)
        CounterEngine.HUE_RING -> engHueRing(f)
        CounterEngine.WATER -> engWater(f)
        CounterEngine.GALAXY -> engGalaxy(f)
        CounterEngine.GEO -> engGeo(f)
        CounterEngine.PULSE -> engPulse(f)
        CounterEngine.DEPTH -> engDepth(f)
        CounterEngine.LEAF -> engLeaf(f)
        CounterEngine.FROST -> engFrost(f)
        CounterEngine.MOON -> engMoon(f)
        CounterEngine.CALLI -> engCalli(f)
        CounterEngine.EMBER -> engEmber(f)
        CounterEngine.BEADS -> engBeads(f)
        CounterEngine.STAR8 -> engStar8(f)
        CounterEngine.SUNRISE -> engSunrise(f)
        CounterEngine.LANTERN -> engLantern(f)
        CounterEngine.PETALS -> engPetals(f)
        CounterEngine.DIAL -> engDial(f)
        CounterEngine.ARC_GAUGE -> engArcGauge(f)
        CounterEngine.ORB -> engOrb(f)
    }
    // انفجار الإكمال: توهج وشرارات تتوسع
    val b = f.burst
    if (b > 0f && b < 1f) {
        glowDisc(center, r, f.hi, 0.35f * (1f - b))
        for (i in 0 until 18) {
            val p = cPt(i * 20f, r * (0.70f + 0.28f * b))
            drawCircle(f.hi.al(1f - b), (4f * (1f - b) + 1f) * uu, p)
        }
    }
    drawCounterText(f)
}

/** كل دوال المحركات تُرسم داخل مربع مركزه [DrawScope.center]. */
internal fun counterFrameFor(
    st: CounterStyle, cfg: CounterCfg, count: Int, target: Int, name: String,
    t: Float = 0.35f, tap: Float = 0f, burst: Float = 0f,
): CFrame {
    val p = if (target > 0) (count.toFloat() / target).coerceIn(0f, 1f) else 1f
    return resolveFrame(st, cfg, count, target, name, t, tap, burst, p)
}

/**
 * يرسم العدّاد على صورة Bitmap (لودجت الشاشة الرئيسية لا يدعم أنيميشن ولا Canvas مباشرًا، فنعرض لقطة من نفس الرسم).
 * [tap] = 1 يعطي لقطة «لحظة الضغط» المضيئة.
 */
fun renderCounterBitmap(sizePx: Int, cfg: CounterCfg, count: Int, target: Int, name: String, tap: Float = 0f): Bitmap {
    val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
    val st = CounterCatalog.byId(cfg.styleId)
    val canvas = Canvas(bmp.asImageBitmap())
    val scope = CanvasDrawScope()
    scope.draw(Density(1f), LayoutDirection.Ltr, canvas, Size(sizePx.toFloat(), sizePx.toFloat())) {
        if (st != null) {
            drawCounter(counterFrameFor(st, cfg, count, target, name, tap = tap))
        }
    }
    return bmp
}
