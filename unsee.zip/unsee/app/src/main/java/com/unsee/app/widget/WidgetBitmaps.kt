package com.unsee.app.widget

import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.TextPaint
import android.text.TextUtils
import com.unsee.app.core.Appearance
import com.unsee.app.core.Arabic
import com.unsee.app.core.LiveClock
import com.unsee.app.core.SunWindow
import com.unsee.app.data.Settings
import java.time.LocalTime
import kotlin.math.max
import kotlin.math.min

/**
 * رسم الودجت الدائرية كصورة بحجمها الفعلي بالبكسل (وليس صورة ثابتة تتمدّد): الحلقة والرقم والنص تُرسم بخطوط حادة
 * على لوحة معتمة تقريبًا بلون يناسب النهار/الليل، فتبقى واضحة فوق أي خلفية شاشة وعند أي تكبير أو تصغير.
 */
object WidgetBitmaps {
    /** حجم الودجت الحالي بالبكسل، مع سقف للذاكرة (RemoteViews يرفض الصور الكبيرة جدًا). */
    fun sizePx(ctx: Context, mgr: AppWidgetManager, id: Int, defaultDp: Int = 110): Pair<Int, Int> {
        val o = runCatching { mgr.getAppWidgetOptions(id) }.getOrNull()
        val portrait = ctx.resources.configuration.orientation != Configuration.ORIENTATION_LANDSCAPE
        val wDp = (if (portrait) o?.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0) else o?.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 0)) ?: 0
        val hDp = (if (portrait) o?.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0) else o?.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0)) ?: 0
        val d = ctx.resources.displayMetrics
        var w = ((if (wDp > 0) wDp else defaultDp) * d.density).toInt().coerceAtLeast(64)
        var h = ((if (hDp > 0) hDp else defaultDp) * d.density).toInt().coerceAtLeast(64)
        val budget = d.widthPixels.toLong() * d.heightPixels * 0.30
        val area = w.toLong() * h
        if (area > budget) {
            val k = Math.sqrt(budget / area.toDouble())
            w = (w * k).toInt(); h = (h * k).toInt()
        }
        return w to h
    }

    /** هل المشهد الآن ليلي؟ يحترم وضع المظهر المختار ثم وقت اليوم (أو وضع النظام). */
    fun isNight(ctx: Context, s: Settings): Boolean = when (s.appearance) {
        Appearance.LIGHT -> false
        Appearance.DARK -> true
        Appearance.SYSTEM -> (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        Appearance.AUTO_TIME -> {
            val t = LocalTime.now()
            LiveClock.dayBlend(t.hour * 60f + t.minute, SunWindow.DEFAULT) < 0.5f
        }
    }

    private class Ink(val plate: Int, val ink: Int, val dim: Int, val accent: Int, val edge: Int)

    private fun ink(night: Boolean) = if (night) {
        Ink(0xF2241236.toInt(), 0xFFFBEFF6.toInt(), 0xFFCDB6CC.toInt(), 0xFFFF8DB0.toInt(), 0x66FFFFFF)
    } else {
        Ink(0xF5FFFFFF.toInt(), 0xFF34182E.toInt(), 0xFF6E5468.toInt(), 0xFFB3153F.toInt(), 0x33B3153F)
    }

    private fun fit(p: TextPaint, text: String, maxW: Float, startSize: Float, minSize: Float) {
        var size = startSize
        p.textSize = size
        while (p.measureText(text) > maxW && size > minSize) { size -= 1f; p.textSize = size }
    }

    fun tasbih(w: Int, h: Int, count: Int, target: Int, phrase: String, flash: Boolean, night: Boolean): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val k = ink(night)
        val unit = min(w, h).toFloat()
        val aa = Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG

        // لوحة الودجت
        val plate = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = k.plate }
        val r = unit * 0.16f
        c.drawRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), r, r, plate)
        c.drawRoundRect(RectF(1f, 1f, w - 1f, h - 1f), r, r, Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = max(1f, unit * 0.012f); color = k.edge })

        val padX = w * 0.06f
        val tp = TextPaint(aa).apply { typeface = Typeface.SERIF; color = k.accent; isFakeBoldText = true }
        val phraseTop = h * 0.05f
        fit(tp, phrase, w - 2 * padX, unit * 0.11f, unit * 0.06f)
        val shown = TextUtils.ellipsize(phrase, tp, w - 2 * padX, TextUtils.TruncateAt.END).toString()
        val phraseBase = phraseTop - tp.ascent()
        tp.textAlign = Paint.Align.CENTER
        c.drawText(shown, w / 2f, phraseBase, tp)

        val bottomBand = unit * 0.15f
        val ringTop = phraseBase + tp.descent() + unit * 0.03f
        val ringBottom = h - bottomBand - unit * 0.02f
        val d = max(unit * 0.3f, min(ringBottom - ringTop, w - 2 * padX))
        val cx = w / 2f
        val cy = (ringTop + ringBottom) / 2f
        val stroke = d * 0.085f
        val rect = RectF(cx - d / 2 + stroke / 2, cy - d / 2 + stroke / 2, cx + d / 2 - stroke / 2, cy + d / 2 - stroke / 2)

        // وجه العدّاد
        c.drawOval(rect, Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = if (flash) (k.accent and 0x00FFFFFF) or 0x40000000 else (k.ink and 0x00FFFFFF) or 0x0D000000 })
        val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = stroke; color = (k.accent and 0x00FFFFFF) or 0x40000000 }
        c.drawArc(rect, 0f, 360f, false, track)
        val frac = if (target > 0) (count.toFloat() / target).coerceIn(0f, 1f) else 0f
        val prog = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = if (flash) stroke * 1.2f else stroke; strokeCap = Paint.Cap.ROUND; color = k.accent }
        if (frac > 0f) c.drawArc(rect, -90f, 360f * frac, false, prog)

        // الرقم: أكبر ما يمكن داخل الحلقة وبلون كامل الكثافة
        val num = Arabic.digits(count)
        val np = TextPaint(aa).apply { typeface = Typeface.DEFAULT_BOLD; color = k.ink; textAlign = Paint.Align.CENTER }
        fit(np, num, d * 0.62f, d * 0.42f, d * 0.14f)
        c.drawText(num, cx, cy - (np.ascent() + np.descent()) / 2f, np)

        // الهدف
        val goal = if (target > 0 && count >= target) "اكتمل ✓" else if (target > 0) "الهدف ${Arabic.digits(target)}" else ""
        if (goal.isNotEmpty()) {
            val gp = TextPaint(aa).apply { color = k.dim; textAlign = Paint.Align.CENTER; isFakeBoldText = true }
            fit(gp, goal, w - 2 * padX, unit * 0.10f, unit * 0.055f)
            c.drawText(goal, cx, h - unit * 0.05f - gp.descent(), gp)
        }
        return bmp
    }
}
