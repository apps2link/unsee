package com.unsee.app.data

import com.unsee.app.core.ArabicText

/**
 * مكتبة الأذكار — المرجع الوحيد للنصوص: كتاب «حصن المسلم من أذكار الكتاب والسنة» (د. سعيد بن علي بن وهف القحطاني).
 *
 * - البيانات في HisnBookData.kt مولَّدة آليًا من ملف الكتاب (tools/hisn/extract_hisn.py) وقورنت به بمسار استخراج مستقل
 *   (tools/hisn/verify_hisn.py)؛ لا يُكتب فيها ولا يُعدَّل ذكر يدويًا.
 * - لا اختصار ولا دمج ولا إضافة: كل ذكر مرقَّم في الكتاب (1–267) يظهر بنصه، مع عدده كما ورد، وحواشيه (التخريج/الفضل) حرفيًا.
 * - الباب 27 (الصباح والمساء) واحد في الكتاب؛ يظهر في القسمين، وما قيّده الكتاب بوقت («إذا أصبح»/«إذا أمسى») يظهر في وقته فقط.
 *   معرّفات الصباح تبدأ بـ m_ ومعرّفات المساء بـ e_ ليكون لكل منهما تقدّمه اليومي المستقل.
 */
/** قسم مستقل = باب واحد من أبواب الكتاب (الباب 27 يُفرَّع إلى «الصباح» و«المساء»). لا يُدمج بابان في قسم. */
data class Section(val key: String, val title: String, val category: Category, val items: List<Zikr>) {
    val countableItems: List<Zikr> get() = items.filter { it.countable && it.count > 0 }
}

object AdhkarData {
    val BOOK_TITLE: String get() = HisnMeta.TITLE
    val BOOK_AUTHOR: String get() = HisnMeta.AUTHOR

    internal val chapters: List<HisnChapter> get() = HisnChapters.all
    private val chapterByNo: Map<Int, HisnChapter> by lazy { HisnChapters.all.associateBy { it.no } }

    /** مقدمة المؤلف كما وردت. */
    val preface: List<String> get() = HisnMeta.preface
    val prefaceFootnotes: List<Footnote> get() = HisnMeta.prefaceFootnotes

    private fun makeZikr(row: HisnRow, category: Category, idPrefix: String): Zikr {
        val ch = chapterByNo.getValue(row.chapterNo)
        val source = if (row.bookNo > 0) "حصن المسلم · ذكر رقم ${row.bookNo}" else "حصن المسلم"
        return Zikr(
            id = idPrefix + row.id,
            category = category,
            title = ch.title,
            text = if (idPrefix == "e_" && row.chapterNo == 27) EveningForms.text(row.id, row.text) else row.text,
            // قرار المستخدم: الذكر بلا عدد محدد في الكتاب يُقرأ مرة واحدة (الكتاب نفسه لا يذكر عددًا؛ countText يبقى فارغًا)
            count = if (row.count == 0 && (row.kind == ZikrKind.DHIKR || row.kind == ZikrKind.ADDITION)) 1 else row.count,
            source = source,
            note = row.afterNote,
            bookNo = row.bookNo,
            chapterNo = row.chapterNo,
            kind = row.kind,
            countText = row.countText,
            footnotes = if (idPrefix == "e_" && row.chapterNo == 27) EveningForms.footnotes(row.footnotes) else row.footnotes,
            fromBook = true,
        )
    }

    /** كل ما يُقرأ في القسم بترتيب الكتاب (يشمل التنبيهات NOTE). */
    private val reader: Map<Category, List<Zikr>> by lazy {
        val out = LinkedHashMap<Category, MutableList<Zikr>>()
        for (c in Category.values()) out[c] = ArrayList()
        for (row in HisnRows.all) {
            val ch = chapterByNo.getValue(row.chapterNo)
            if (ch.category == "MORNING_EVENING") {
                // التقييد بالوقت يأتي من عبارة العدد في الكتاب نفسها («إذا أصبح» / «إذا أمسى»)
                if (row.countWhen != "EVENING") out.getValue(Category.MORNING).add(makeZikr(row, Category.MORNING, "m_"))
                if (row.countWhen != "MORNING") out.getValue(Category.EVENING).add(makeZikr(row, Category.EVENING, "e_"))
            } else {
                val cat = runCatching { Category.valueOf(ch.category) }.getOrNull() ?: continue
                out.getValue(cat).add(makeZikr(row, cat, ""))
            }
        }
        out
    }

    private val byCategory: Map<Category, List<Zikr>> by lazy {
        Category.values().associateWith { c -> reader.getValue(c).filter { it.kind != ZikrKind.NOTE } }
    }

    /** أذكار القسم الصالحة للعدّ والودجت (بلا التنبيهات). */
    fun forCategory(c: Category): List<Zikr> = byCategory.getValue(c)

    /** كل باب من الكتاب قسمٌ منفرد بترتيب الكتاب. */
    val sections: List<Section> by lazy {
        val out = ArrayList<Section>()
        for (ch in HisnChapters.all) {
            if (ch.category == "MORNING_EVENING") {
                val m = reader.getValue(Category.MORNING).filter { it.chapterNo == ch.no }
                val e = reader.getValue(Category.EVENING).filter { it.chapterNo == ch.no }
                if (m.isNotEmpty()) out.add(Section("ch${ch.no}m", "أذكار الصباح", Category.MORNING, m))
                if (e.isNotEmpty()) out.add(Section("ch${ch.no}e", "أذكار المساء", Category.EVENING, e))
            } else {
                val cat = runCatching { Category.valueOf(ch.category) }.getOrNull() ?: continue
                val items = reader.getValue(cat).filter { it.chapterNo == ch.no }
                if (items.isNotEmpty()) out.add(Section("ch${ch.no}", ch.title, cat, items))
            }
        }
        // الترتيب: فضل الذكر ثم أذكار الصباح ثم المساء، ثم بقية الأبواب بترتيب الكتاب
        val head = listOf("ch0", "ch27m", "ch27e")
        out.sortedBy { sec -> head.indexOf(sec.key).let { if (it >= 0) it else head.size } }
    }
    private val sectionIndex: Map<String, Section> by lazy { sections.associateBy { it.key } }
    fun section(key: String): Section? = sectionIndex[key]

    /** مفتاح القسم المنفرد الذي ينتمي إليه الذكر (للأذكار القديمة خارج الكتاب: null). */
    fun sectionKeyOf(z: Zikr): String? = when {
        !z.fromBook -> null
        z.chapterNo == 27 && z.id.startsWith("m_") -> "ch27m"
        z.chapterNo == 27 && z.id.startsWith("e_") -> "ch27e"
        else -> "ch${z.chapterNo}"
    }

    /** قائمة شاشة القراءة: كل نص في القسم بترتيب الكتاب، ومعه التنبيهات. */
    fun readerList(c: Category): List<Zikr> = reader.getValue(c)

    val all: List<Zikr> by lazy { Category.values().flatMap { forCategory(it) } }

    private val index: Map<String, Zikr> by lazy { reader.values.flatten().associateBy { it.id } }

    /** يعيد الذكر بمعرّفه؛ والمعرّف القديم يُحوَّل إلى مقابله في الكتاب إن وُجد. */
    fun byId(id: String): Zikr? = index[id] ?: LegacyIdMap.map[id]?.let { index[it] }

    /** هل هذا المعرّف من المكتبة السابقة (خارج الكتاب)؟ */
    fun isLegacyId(id: String): Boolean = id !in index && id !in LegacyIdMap.map && LegacyAdhkar.byId(id) != null

    /**
     * المفضلة: أذكار الكتاب أولًا، ثم ما بقي من المكتبة السابقة ولا مقابل حرفيًا له في الكتاب
     * (تُعرض بوسم «من المكتبة السابقة» حتى لا تُنسب إلى الكتاب).
     */
    fun favoriteList(favs: Set<String>): List<Zikr> {
        val book = all.filter { it.id in favs }
        val legacy = favs.filter { isLegacyId(it) }.mapNotNull { LegacyAdhkar.byId(it) }
        return book + legacy
    }

    private val searchBlobs: Map<String, String> by lazy {
        val m = HashMap<String, String>()
        for (z in all) {
            val sb = StringBuilder()
            sb.append(z.title).append(' ').append(z.text)
            z.countText?.let { sb.append(' ').append(it) }
            z.note?.let { sb.append(' ').append(it) }
            for (f in z.footnotes) sb.append(' ').append(f.text)
            m[z.id] = ArabicText.normalize(sb.toString())
        }
        m
    }

    /**
     * بحث في النص والعنوان والعدد والحواشي (يتجاهل التشكيل). كل كلمات الاستعلام يجب أن تتحقق.
     * رقم صرف (مثل 75) يبحث عن رقم الذكر في الكتاب. category = null يعني كل الأقسام.
     */
    fun search(query: String, category: Category? = null, limit: Int = 60): List<Zikr> {
        val raw = query.trim()
        if (raw.isEmpty()) return emptyList()
        val pool = if (category == null) all else forCategory(category)
        val num = raw.toIntOrNull()
        if (num != null) return pool.filter { it.bookNo == num }.take(limit)
        val words = ArabicText.normalize(raw).split(' ').filter { it.isNotEmpty() }
        if (words.isEmpty() || ArabicText.normalize(raw).length < 2) return emptyList()
        return pool.filter { z ->
            val blob = searchBlobs[z.id] ?: return@filter false
            words.all { blob.contains(it) }
        }.take(limit)
    }

    /** إحصاءات للاختبارات والتقارير. */
    internal fun rows(): List<HisnRow> = HisnRows.all
}
