package com.unsee.app.overlay

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.unsee.app.MainActivity
import com.unsee.app.R
import com.unsee.app.core.CompanionPicker
import com.unsee.app.core.LogKind
import com.unsee.app.core.PendingItem
import com.unsee.app.core.PlanLogic
import com.unsee.app.core.Voice
import com.unsee.app.data.CompanionMessages
import com.unsee.app.data.CompanionStore
import com.unsee.app.data.Store
import com.unsee.app.notify.CompanionAct
import com.unsee.app.notify.CompanionActionReceiver
import com.unsee.app.notify.CompanionActions
import com.unsee.app.notify.CompanionNotifier
import com.unsee.app.notify.Sfx
import java.time.LocalDate
import java.time.LocalTime
import kotlin.math.hypot
import kotlin.random.Random

/**
 * فقاعة «رفيق أُنسي» العائمة: أيقونة التطبيق فوق الشاشة الرئيسية وكل التطبيقات، ونقطة حمراء عند وجود رسالة.
 * الضغط عليها يفتح بطاقة بالذكر/الدعاء/النصيحة (أو بعنصر معلّق: عادة حلوة، تذكير صلاة، خطة إقلاع).
 * تُسحب لأي مكان وتلتصق بالحافة، وتُرمى على علامة ✕ في الأسفل لإيقافها (إلا والفيه عنصر «أولوية»).
 * تختفي وأنت داخل أُنسي نفسه. كل العمل على الخيط الرئيسي.
 */
class BubbleService : Service() {
    companion object {
        const val ACTION_SYNC = "com.unsee.app.BUBBLE_SYNC"
        const val EXTRA_NEW = "new"
        private const val CHANNEL_ID = "bubble_service"
        private const val NOTIF_ID = 2001

        @Volatile var appVisible = false
        @Volatile private var instance: BubbleService? = null

        /** يُستدعى من MainActivity: الفقاعة تختفي أثناء وجودك داخل التطبيق. */
        fun onAppVisibility(visible: Boolean) {
            appVisible = visible
            val s = instance ?: return
            s.handler.post { s.applyVisibility() }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var bubble: BubbleView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var card: View? = null
    private var target: TextView? = null
    private var targetHover = false
    private var peeking = false
    private var idleHidden = false
    private var autoClose: Runnable? = null

    private val cs get() = CompanionStore.get(this)
    private fun voice(): Voice = cs.voice()
    private fun dp(v: Float): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun dp(v: Int): Int = dp(v.toFloat())
    private val screenW get() = resources.displayMetrics.widthPixels
    private val screenH get() = resources.displayMetrics.heightPixels

    // ============================================================ دورة حياة الخدمة
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createChannel()
        if (!goForeground()) { stopSelf(); return }
        Sfx.warm(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // يجب استدعاء startForeground عقب كل startForegroundService حتى لو سنتوقف بعدها
        if (!goForeground()) { stopSelf(); return START_NOT_STICKY }
        if (!BubbleController.wanted(this)) {
            removeAllViews()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        ensureBubble()
        refresh(isNew = intent?.getBooleanExtra(EXTRA_NEW, false) == true)
        return START_STICKY
    }

    override fun onDestroy() {
        removeAllViews()
        handler.removeCallbacksAndMessages(null)
        if (instance === this) instance = null
        super.onDestroy()
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "الفقاعة العائمة", NotificationManager.IMPORTANCE_MIN).apply {
                description = "إشعار صغير صامت يُبقي فقاعة رفيق أُنسي ظاهرة. يمكنك إيقافها من زر فيه."
                setShowBadge(false)
            },
        )
    }

    private fun goForeground(): Boolean = runCatching {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(NOTIF_ID, n)
        true
    }.getOrDefault(false)

    private fun buildNotification(): Notification {
        val v = voice()
        val open = PendingIntent.getActivity(
            this, 7001,
            Intent(this, MainActivity::class.java).putExtra("route", "companion").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val off = PendingIntent.getBroadcast(
            this, 7002,
            Intent(this, CompanionActionReceiver::class.java).setAction(CompanionNotifier.ACTION_BUBBLE_OFF),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(com.unsee.app.notify.NotifyStyle.ACCENT)
            .setLargeIcon(com.unsee.app.notify.NotifyStyle.largeIcon(this))
            .setContentTitle(v.bubbleTitle)
            .setContentText(v.t("الفقاعة شغّالة. اضغط لفتح الإعدادات.", "الفقاعة شغّالة. اضغط لفتح الإعدادات."))
            .setContentIntent(open)
            .addAction(R.drawable.ic_notification, v.t("إيقاف الفقاعة", "إيقاف الفقاعة"), off)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    // ============================================================ الفقاعة نفسها
    private fun edgeX(side: Int): Int {
        val size = dp(BubbleView.WINDOW_DP)
        val pad = dp(BubbleView.PAD_DP)
        return if (side == 0) -pad + dp(2) else screenW - size + pad - dp(2)
    }

    private fun ensureBubble() {
        if (bubble != null) return
        val size = dp(BubbleView.WINDOW_DP)
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = edgeX(cs.bubbleSide())
            val savedY = cs.bubbleY()
            y = (if (savedY >= 0) savedY else (screenH * 0.35f).toInt()).coerceIn(0, (screenH - size).coerceAtLeast(0))
        }
        val view = BubbleView(this).apply {
            setIcon(runCatching { packageManager.getApplicationIcon(packageName) }.getOrNull())
            contentDescription = voice().bubbleTitle
        }
        installTouch(view, lp)
        val ok = runCatching { wm.addView(view, lp) }.isSuccess
        if (!ok) { stopSelf(); return }
        bubble = view
        bubbleLp = lp
        view.alpha = 0f
        view.scaleX = 0.3f; view.scaleY = 0.3f
        view.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(420).setInterpolator(OvershootInterpolator(1.6f)).start()
    }

    private fun installTouch(view: BubbleView, lp: WindowManager.LayoutParams) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var dragging = false
        view.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX; downY = ev.rawY; startX = lp.x; startY = lp.y; dragging = false
                    view.setPressedLook(true)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downX
                    val dy = ev.rawY - downY
                    if (!dragging && hypot(dx, dy) > slop) { dragging = true; closeCard(); showTarget() }
                    if (dragging) {
                        val size = dp(BubbleView.WINDOW_DP)
                        val pad = dp(BubbleView.PAD_DP)
                        lp.x = (startX + dx).toInt().coerceIn(-pad, screenW - size + pad)
                        lp.y = (startY + dy).toInt().coerceIn(0, (screenH - size).coerceAtLeast(0))
                        runCatching { wm.updateViewLayout(view, lp) }
                        updateHover(lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.setPressedLook(false)
                    if (dragging) endDrag(lp, ev.actionMasked == MotionEvent.ACTION_UP)
                    else if (ev.actionMasked == MotionEvent.ACTION_UP) onTap()
                    true
                }
                else -> false
            }
        }
    }

    private fun showTarget() {
        // لا يمكن إسقاط فقاعة فيها عنصر أولوية: لا نعرض علامة الإغلاق أصلًا
        if (cs.pending().any { it.priority } || target != null) return
        val size = dp(64)
        val t = TextView(this).apply {
            text = "✕"; textSize = 24f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#CC1F2937")); setStroke(dp(2), Color.parseColor("#55FFFFFF")) }
            alpha = 0f
        }
        val lp = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = dp(56) }
        if (runCatching { wm.addView(t, lp) }.isSuccess) {
            target = t
            t.animate().alpha(1f).setDuration(160).start()
        }
    }

    private fun updateHover(lp: WindowManager.LayoutParams) {
        val t = target ?: return
        val size = dp(BubbleView.WINDOW_DP)
        val cx = lp.x + size / 2f
        val cy = lp.y + size / 2f
        val tx = screenW / 2f
        val ty = screenH - dp(56) - dp(32).toFloat()
        val near = hypot(cx - tx, cy - ty) < dp(76)
        if (near != targetHover) {
            targetHover = near
            (t.background as? GradientDrawable)?.setColor(if (near) Color.parseColor("#EEEF4444") else Color.parseColor("#CC1F2937"))
            t.animate().scaleX(if (near) 1.3f else 1f).scaleY(if (near) 1.3f else 1f).setDuration(120).start()
        }
    }

    private fun hideTarget() {
        val t = target ?: return
        target = null
        targetHover = false
        runCatching { wm.removeViewImmediate(t) }
    }

    private fun endDrag(lp: WindowManager.LayoutParams, released: Boolean) {
        val dropOnTarget = released && targetHover
        hideTarget()
        if (dropOnTarget) {
            // ✕ = تأجيل فقط. لا نكتب cmp_bubble ولا cmp_enabled، ولا نستدعي stopService مباشرة هنا:
            // snooze() يحفظ الموعد ويجدول العودة ثم يوقف عرض الفقاعة وحدها (الرفيق يبقى مفعّلًا).
            val minutes = cs.bubbleSnoozeMin()
            val app = applicationContext
            Toast.makeText(this, voice().t("الفقاعة هترجع بعد $minutes دقيقة 🕊️", "الفقاعة ترجع بعد $minutes دقيقة 🕊️"), Toast.LENGTH_LONG).show()
            val v = bubble
            if (v == null) { BubbleController.snooze(app); return }
            v.animate().alpha(0f).scaleX(0.2f).scaleY(0.2f).setDuration(180)
                .withEndAction { BubbleController.snooze(app) }.start()
            return
        }
        val size = dp(BubbleView.WINDOW_DP)
        val side = if (lp.x + size / 2 < screenW / 2) 0 else 1
        cs.setBubbleSide(side)
        cs.setBubbleY(lp.y)
        val view = bubble ?: return
        val from = lp.x
        val to = edgeX(side)
        ValueAnimator.ofInt(from, to).apply {
            duration = 320
            interpolator = OvershootInterpolator(1.2f)
            addUpdateListener { lp.x = it.animatedValue as Int; runCatching { wm.updateViewLayout(view, lp) } }
            start()
        }
    }

    // ============================================================ الحالة والنقطة الحمراء
    private fun refresh(isNew: Boolean) {
        val view = bubble ?: return
        val s = cs.settings()
        val list = cs.pending()
        view.setBadge(list.size, list.any { it.priority })
        view.setMood(GlassMood.forPending(list.map { it.kind }, list.any { it.priority }))
        view.setFx(motionOn())
        idleHidden = !s.bubbleAlways && list.isEmpty()
        applyVisibility()
        if (isNew && list.isNotEmpty()) {
            view.pop()
            Sfx.play(this, Sfx.Sound.CHIRP, companionOnly = true)
        }
    }

    private fun applyVisibility() {
        val view = bubble ?: return
        val hide = appVisible || idleHidden
        view.visibility = if (hide) View.GONE else View.VISIBLE
        if (hide) closeCard()
    }

    // ============================================================ التصميم الزجاجي: أدوات مشتركة
    private fun isDark(): Boolean =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    /** الحركة مسموحة؟ «بلا حركة» في إعدادات أُنسي أو «إزالة الرسوم المتحركة» في النظام تعطّلانها. */
    private fun motionOn(): Boolean {
        if (Store.get(this).settings().motion == 0) return false
        val scale = runCatching { Settings.Global.getFloat(contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) }.getOrDefault(1f)
        return scale > 0f
    }

    /** نصوص النتيجة قد تحوي رموزًا تعبيرية من مكتبة الرسائل؛ البطاقة الفاخرة تستعمل أيقونات مرسومة بدلها. */
    private val emojiRegex = Regex("[\\x{1F300}-\\x{1FAFF}\\x{2600}-\\x{27BF}\\x{FE0F}\\x{200D}]")
    private fun cleanResult(t: String): String = t.replace(emojiRegex, "").replace("  ", " ").trim()

    private fun glassFill(fillColor: Int, strokeColor: Int, radius: Float) = GradientDrawable().apply {
        setColor(fillColor); cornerRadius = radius; setStroke(dp(1.2f), strokeColor)
    }

    /** يطابق حالة الفقاعة مع ما هو معلّق الآن (لون وسرعة نبض). */
    private fun syncMood() {
        val list = cs.pending()
        bubble?.setMood(GlassMood.forPending(list.map { it.kind }, list.any { it.priority }))
    }

    /** زر زجاجي كبير (لا يقل عن ٤٨dp) مع حركة ضغط نابضية. style: 0 ممتلئ بلون الحالة، 1 أخضر ممتلئ، 2 زجاجي بحدّ، 3 وردي بحدّ. */
    private fun glassButton(label: String, style: Int, skin: GlassSkin, motion: Boolean, onClick: () -> Unit) = TextView(this).apply {
        text = label; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; maxLines = 2
        minHeight = dp(48)
        val r = dp(24).toFloat()
        when (style) {
            0, 1 -> {
                val c1 = if (style == 1) 0xFF34D399.toInt() else skin.accentA
                val c2 = if (style == 1) 0xFFA7F3D0.toInt() else skin.accentB
                setTextColor(skin.onAccent)
                background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(c1, c2)).apply {
                    cornerRadius = r; setStroke(dp(1), GlassSkin.withAlpha(0xFFFFFFFF.toInt(), 130))
                }
            }
            3 -> {
                setTextColor(if (skin.dark) 0xFFFDA4AF.toInt() else 0xFFBE123C.toInt())
                background = glassFill(GlassSkin.withAlpha(0xFFFB7185.toInt(), 34), GlassSkin.withAlpha(0xFFFB7185.toInt(), 170), r)
            }
            else -> {
                setTextColor(skin.titleColor)
                background = glassFill(GlassSkin.withAlpha(skin.accentA, if (skin.dark) 34 else 28), GlassSkin.withAlpha(skin.accentA, 160), r)
            }
        }
        setPadding(dp(8), dp(11), dp(8), dp(11))
        isClickable = true
        contentDescription = label
        // حركة الضغط لا تستهلك اللمسة (نُرجع false) فيبقى النقر يعمل كما هو
        setOnTouchListener { v, ev ->
            if (motion) when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(90).setInterpolator(DecelerateInterpolator()).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(320).setInterpolator(SpringInterpolator()).start()
            }
            false
        }
        setOnClickListener { onClick() }
    }

    /** توهج محيطي خلف النص: Blur حقيقي بـ RenderEffect على Android 12+، وتدرّج شعاعي ناعم على الأقدم. لا يمس النص. */
    private fun ambientBlob(skin: GlassSkin): View = View(this).apply {
        alpha = if (skin.dark) 0.55f else 0.40f
        if (Build.VERSION.SDK_INT >= 31) {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(skin.accentA) }
            setRenderEffect(RenderEffect.createBlurEffect(dp(34).toFloat(), dp(34).toFloat(), Shader.TileMode.DECAL))
        } else {
            background = GradientDrawable().apply {
                gradientType = GradientDrawable.RADIAL_GRADIENT
                gradientRadius = dp(75).toFloat()
                colors = intArrayOf(GlassSkin.withAlpha(skin.accentA, 200), GlassSkin.withAlpha(skin.accentA, 0))
            }
        }
    }

    /** جذر البطاقة: سطح زجاجي مقصوص بزوايا مستديرة + توهج محيطي خلف المحتوى. */
    private fun glassRoot(skin: GlassSkin, content: View): FrameLayout {
        val radius = dp(28).toFloat()
        return FrameLayout(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = GlassCardDrawable(skin, radius, dp(1.2f).toFloat())
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) { outline.setRoundRect(0, 0, view.width, view.height, radius) }
            }
            addView(ambientBlob(skin), FrameLayout.LayoutParams(dp(150), dp(150), Gravity.TOP or Gravity.START).apply {
                topMargin = -dp(62); marginStart = -dp(48)
            })
            addView(content, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT))
        }
    }

    /** ظهور متدرّج: عناصر البطاقة ترتفع بلطف واحدًا بعد الآخر (بارالاكس خفيف). */
    private fun rise(content: ViewGroup, motion: Boolean) {
        if (!motion) return
        for (i in 0 until content.childCount) {
            val child = content.getChildAt(i)
            child.alpha = 0f
            child.translationY = dp(10 + 4 * i).toFloat()
            child.animate().alpha(1f).translationY(0f).setStartDelay(60L + 45L * i).setDuration(320).setInterpolator(DecelerateInterpolator()).start()
        }
    }

    // ============================================================ البطاقة
    private fun onTap() {
        if (card != null) { closeCard(animated = true); return }
        val list = cs.pending()
        if (list.isNotEmpty()) { peeking = false; showCard(list.first(), list.size) }
        else { peeking = true; showCard(peekItem(), 0) }
    }

    private fun peekItem(): PendingItem {
        val v = voice()
        val s = cs.settings()
        val msg = CompanionPicker.pick(CompanionMessages.all, s, LocalTime.now().hour, cs.recentIds(), Random(System.nanoTime()))
            ?: CompanionMessages.all.first()
        cs.pushRecent(msg.id)
        return PendingItem(
            LogKind.DHIKR, msg.id, v.bubbleTitle, msg.textFor(v.dialect), msg.source?.let { "— $it" },
            v.bubbleDone, v.bubbleAnother, v.bubbleOpen, "adhkar", 3001, false, System.currentTimeMillis(),
        )
    }

    private fun showCard(item: PendingItem, total: Int) {
        closeCard()
        val v = voice()
        val dark = isDark()
        val motion = motionOn()
        val skin = GlassSkin.of(GlassMood.forItem(item.kind, item.priority), dark)
        val w = minOf((screenW * 0.92f).toInt(), dp(350))
        val padH = dp(18)
        val wrap = LinearLayout.LayoutParams.WRAP_CONTENT

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(padH, dp(12), padH, dp(16))
        }

        // ١) الشريط العلوي: أيقونة صغيرة متحركة + نوع التذكير + العدد + إخفاء
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(GlyphView(this, skin.glyph, skin.titleColor, motion))
        top.addView(TextView(this).apply {
            text = if (item.priority) "${v.bubblePriority} · ${item.kind.label}" else item.kind.label
            textSize = 11.5f; typeface = Typeface.DEFAULT_BOLD; setTextColor(skin.titleColor)
            background = glassFill(GlassSkin.withAlpha(skin.accentA, if (dark) 40 else 34), GlassSkin.withAlpha(skin.accentA, 130), dp(12).toFloat())
            setPadding(dp(10), dp(3), dp(10), dp(3))
            layoutParams = LinearLayout.LayoutParams(wrap, wrap).apply { marginStart = dp(8) }
        })
        top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        if (total > 1) top.addView(TextView(this).apply {
            text = "$total"; textSize = 12f; setTextColor(skin.textSecondary); setPadding(dp(6), 0, dp(6), 0)
        })
        if (!item.priority) {
            top.addView(TextView(this).apply {
                text = "✕"; textSize = 16f; setTextColor(skin.textSecondary); gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))   // مساحة لمس مريحة
                contentDescription = "إخفاء"; isClickable = true
                setOnClickListener { act(item, CompanionAct.DISMISS) }
            })
        }
        content.addView(top)

        // ٢) العنوان
        content.addView(TextView(this).apply {
            text = item.title; textSize = 15.5f; typeface = Typeface.DEFAULT_BOLD; setTextColor(skin.titleColor)
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START; setPadding(0, dp(2), 0, 0)
        })

        // ٣) النص (العنصر الأساسي) + ٤) المصدر. النص الطويل يُمرَّر داخل البطاقة بدل أن يدفع الأزرار خارج الشاشة.
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.addView(TextView(this).apply {
            text = item.text; textSize = 18f; setTextColor(skin.textPrimary); setLineSpacing(0f, 1.3f)
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START; setPadding(0, dp(8), 0, 0)
        })
        if (!item.sub.isNullOrBlank()) body.addView(TextView(this).apply {
            text = item.sub; textSize = 12.5f; setTextColor(skin.textSecondary)
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START; setPadding(0, dp(6), 0, 0)
        })
        body.measure(View.MeasureSpec.makeMeasureSpec(w - 2 * padH, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        val maxBody = (screenH * 0.34f).toInt()
        if (body.measuredHeight > maxBody) {
            content.addView(ScrollView(this).apply {
                isVerticalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER
                addView(body)
            }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, maxBody))
        } else content.addView(body)

        // ٥) أزرار التفاعل
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(14), 0, 0) }
        fun cell(b: TextView, first: Boolean) {
            b.layoutParams = LinearLayout.LayoutParams(0, wrap, 1f).apply { if (!first) marginStart = dp(8) }
            row.addView(b)
        }
        val isPlan = item.kind == LogKind.PLAN
        cell(glassButton(item.primary, if (isPlan || item.kind == LogKind.HABIT) 1 else 0, skin, motion) { act(item, CompanionAct.PRIMARY) }, true)
        if (item.secondary.isNotBlank()) {
            cell(glassButton(item.secondary, if (isPlan) 3 else 2, skin, motion) { act(item, if (isPlan) CompanionAct.SLIP else CompanionAct.SNOOZE) }, false)
        }
        if (item.open.isNotBlank()) cell(glassButton(item.open, 2, skin, motion) { act(item, CompanionAct.OPEN) }, false)
        content.addView(row)
        if (item.priority) content.addView(TextView(this).apply {
            text = v.t("الفقاعة دي هتفضل معاك لحد ما تردّ عليها.", "هالفقاعة تبقى معك لين ترد عليها.")
            textSize = 11.5f; setTextColor(skin.textSecondary); textAlignment = View.TEXT_ALIGNMENT_VIEW_START; setPadding(0, dp(8), 0, 0)
        })
        placeCard(glassRoot(skin, content), w, motion)
        rise(content, motion)
    }

    /** بطاقة صغيرة بنتيجة الفعل: احتفال بعد حسنة أو مواساة بعد زلّة، ثم تُغلق وننتقل للعنصر التالي إن وُجد. */
    private fun showResult(text: String, good: Boolean) {
        closeCard()
        val dark = isDark()
        val motion = motionOn()
        val skin = GlassSkin.of(if (good) BubbleMood.CELEBRATE else BubbleMood.COMFORT, dark)
        val w = minOf((screenW * 0.86f).toInt(), dp(320))
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
        }
        content.addView(GlyphView(this, skin.glyph, skin.titleColor, motion, 38f))
        content.addView(TextView(this).apply {
            this.text = cleanResult(text); textSize = 16.5f; setTextColor(skin.textPrimary); gravity = Gravity.CENTER
            setLineSpacing(0f, 1.3f); setPadding(0, dp(8), 0, 0)
        })
        placeCard(glassRoot(skin, content), w, motion)
        rise(content, motion)
        val next = Runnable {
            closeCard()
            refresh(false)
            val list = cs.pending()
            if (list.isNotEmpty()) { peeking = false; showCard(list.first(), list.size) }
        }
        autoClose = next
        handler.postDelayed(next, if (good) 1800L else 2600L)
    }

    private fun placeCard(root: View, w: Int, motion: Boolean) {
        val bub = bubbleLp ?: return
        root.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        val h = root.measuredHeight
        val size = dp(BubbleView.WINDOW_DP)
        val cx = bub.x + size / 2
        val cy = bub.y + size / 2
        val circleR = dp(BubbleView.CIRCLE_DP) / 2
        val below = cy < screenH / 2
        val x = (cx - w / 2).coerceIn(dp(8), (screenW - w - dp(8)).coerceAtLeast(dp(8)))
        val y = (if (below) cy + circleR + dp(10) else cy - circleR - dp(10) - h).coerceIn(dp(24), (screenH - h - dp(24)).coerceAtLeast(dp(24)))
        val lp = WindowManager.LayoutParams(
            w, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }
        // Blur خلف البطاقة: فقط على Android 12+ وحين يسمح النظام به (وضع توفير الطاقة/إعدادات المطوّر قد تعطّله).
        // البطاقة نفسها شبه معتمة فيبقى النص واضحًا بوجود الـ Blur أو بدونه.
        if (Build.VERSION.SDK_INT >= 31 && runCatching { wm.isCrossWindowBlurEnabled }.getOrDefault(false)) {
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            lp.blurBehindRadius = dp(14)
        }
        root.setOnTouchListener { _, ev -> if (ev.action == MotionEvent.ACTION_OUTSIDE) { closeCard(animated = true); true } else false }
        if (!runCatching { wm.addView(root, lp) }.isSuccess) return
        card = root
        if (!motion) return
        root.pivotX = (cx - x).toFloat()
        root.pivotY = if (below) 0f else h.toFloat()
        root.alpha = 0f; root.scaleX = 0.7f; root.scaleY = 0.7f
        root.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(380).setInterpolator(SpringInterpolator()).start()
    }

    private fun cancelAnims(v: View) {
        v.animate().cancel()
        if (v is ViewGroup) for (i in 0 until v.childCount) cancelAnims(v.getChildAt(i))
    }

    /** إغلاق البطاقة. animated = تلاشٍ سريع مع تصغير خفيف (للإغلاق بإرادة المستخدم)، وإلا إزالة فورية. */
    private fun closeCard(animated: Boolean = false) {
        autoClose?.let { handler.removeCallbacks(it) }
        autoClose = null
        val c = card ?: return
        card = null
        if (animated && motionOn()) {
            c.animate().cancel()
            c.animate().alpha(0f).scaleX(0.94f).scaleY(0.94f).setDuration(140)
                .withEndAction { runCatching { wm.removeViewImmediate(c) } }.start()
        } else {
            cancelAnims(c)
            runCatching { wm.removeViewImmediate(c) }
        }
    }

    // ============================================================ الأفعال
    private fun act(item: PendingItem, a: CompanionAct) {
        val v = voice()
        if (peeking && a == CompanionAct.SNOOZE) { showCard(peekItem(), 0); return }   // «رسالة تانية»
        val ctx = applicationContext
        CompanionActions.handle(ctx, a, item.kind, item.ref, item.openRoute)
        val keep = item.priority && a == CompanionAct.OPEN   // الأولوية لا تُمسح إلا بالرد عليها
        if (!keep) cs.removePending(item.kind, item.ref)
        val list = cs.pending()
        bubble?.setBadge(list.size, list.any { it.priority })
        syncMood()
        when (a) {
            CompanionAct.PRIMARY -> {
                val msg = when (item.kind) {
                    LogKind.PLAN -> v.planKeptReply(cs.plan(item.ref.removePrefix("plan:"))?.let { PlanLogic.cleanDays(it, LocalDate.now()) } ?: 1)
                    LogKind.HABIT -> v.cheer(System.nanoTime().toInt())
                    LogKind.PRAYER -> v.t("تقبّل الله صلاتك، +١ حسنة", "تقبّل الله صلاتك، +١ حسنة")
                    else -> v.bubbleThanks
                }
                bubble?.burst(true)
                showResult(msg, true)
            }
            CompanionAct.SLIP -> {
                bubble?.burst(false)
                showResult(v.planSlipReply, false)
            }
            else -> {
                closeCard(animated = a == CompanionAct.DISMISS)
                if (a != CompanionAct.OPEN) refresh(false)
            }
        }
    }

    private fun removeAllViews() {
        closeCard()
        hideTarget()
        bubble?.let { it.animate().cancel(); runCatching { wm.removeViewImmediate(it) } }
        bubble = null
        bubbleLp = null
    }
}
