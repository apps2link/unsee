package com.unsee.app.overlay

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.unsee.app.MainActivity
import com.unsee.app.R
import com.unsee.app.core.CompanionPicker
import com.unsee.app.core.LogKind
import com.unsee.app.core.PendingItem
import com.unsee.app.core.PlanLogic
import com.unsee.app.core.Voice
import com.unsee.app.data.CompanionMessages
import com.unsee.app.data.CompanionStore
import com.unsee.app.data.Store
import com.unsee.app.notify.CompanionAct
import com.unsee.app.notify.CompanionActionReceiver
import com.unsee.app.notify.CompanionActions
import com.unsee.app.notify.CompanionNotifier
import com.unsee.app.notify.Sfx
import java.time.LocalDate
import java.time.LocalTime
import kotlin.math.hypot
import kotlin.random.Random

/**
 * فقاعة «رفيق أُنسي» العائمة: أيقونة التطبيق فوق الشاشة الرئيسية وكل التطبيقات، ونقطة حمراء عند وجود رسالة.
 * الضغط عليها يفتح بطاقة بالذكر/الدعاء/النصيحة (أو بعنصر معلّق: عادة حلوة، تذكير صلاة، خطة إقلاع).
 * تُسحب لأي مكان وتلتصق بالحافة، وتُرمى على علامة ✕ في الأسفل لإيقافها (إلا والفيه عنصر «أولوية»).
 * تختفي وأنت داخل أُنسي نفسه. كل العمل على الخيط الرئيسي.
 */
class BubbleService : Service() {
    companion object {
        const val ACTION_SYNC = "com.unsee.app.BUBBLE_SYNC"
        const val EXTRA_NEW = "new"
        private const val CHANNEL_ID = "bubble_service"
        private const val NOTIF_ID = 2001

        @Volatile var appVisible = false
        @Volatile private var instance: BubbleService? = null

        /** يُستدعى من MainActivity: الفقاعة تختفي أثناء وجودك داخل التطبيق. */
        fun onAppVisibility(visible: Boolean) {
            appVisible = visible
            val s = instance ?: return
            s.handler.post { s.applyVisibility() }
        }

        private val NAVY = Color.parseColor("#FF0B1B3A")
        private val NAVY2 = Color.parseColor("#FF14315F")
        private val GOLD = Color.parseColor("#FFE2B857")
        private val CREAM = Color.parseColor("#FFFFF4D6")
        private val CREAM_DIM = Color.parseColor("#FFC9C1A5")
        private val GREEN = Color.parseColor("#FF22C55E")
        private val RED = Color.parseColor("#FFEF4444")
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var bubble: BubbleView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var card: View? = null
    private var target: TextView? = null
    private var targetHover = false
    private var peeking = false
    private var idleHidden = false
    private var autoClose: Runnable? = null

    private val cs get() = CompanionStore.get(this)
    private fun voice(): Voice = cs.voice()
    private fun dp(v: Float): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun dp(v: Int): Int = dp(v.toFloat())
    private val screenW get() = resources.displayMetrics.widthPixels
    private val screenH get() = resources.displayMetrics.heightPixels

    // ============================================================ دورة حياة الخدمة
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createChannel()
        if (!goForeground()) { stopSelf(); return }
        Sfx.warm(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // يجب استدعاء startForeground عقب كل startForegroundService حتى لو سنتوقف بعدها
        if (!goForeground()) { stopSelf(); return START_NOT_STICKY }
        if (!BubbleController.wanted(this)) {
            removeAllViews()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        ensureBubble()
        refresh(isNew = intent?.getBooleanExtra(EXTRA_NEW, false) == true)
        return START_STICKY
    }

    override fun onDestroy() {
        removeAllViews()
        handler.removeCallbacksAndMessages(null)
        if (instance === this) instance = null
        super.onDestroy()
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "الفقاعة العائمة", NotificationManager.IMPORTANCE_MIN).apply {
                description = "إشعار صغير صامت يُبقي فقاعة رفيق أُنسي ظاهرة. يمكنك إيقافها من زر فيه."
                setShowBadge(false)
            },
        )
    }

    private fun goForeground(): Boolean = runCatching {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(NOTIF_ID, n)
        true
    }.getOrDefault(false)

    private fun buildNotification(): Notification {
        val v = voice()
        val open = PendingIntent.getActivity(
            this, 7001,
            Intent(this, MainActivity::class.java).putExtra("route", "companion").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val off = PendingIntent.getBroadcast(
            this, 7002,
            Intent(this, CompanionActionReceiver::class.java).setAction(CompanionNotifier.ACTION_BUBBLE_OFF),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(com.unsee.app.notify.NotifyStyle.ACCENT)
            .setLargeIcon(com.unsee.app.notify.NotifyStyle.largeIcon(this))
            .setContentTitle(v.bubbleTitle)
            .setContentText(v.t("الفقاعة شغّالة. اضغط لفتح الإعدادات.", "الفقاعة شغّالة. اضغط لفتح الإعدادات."))
            .setContentIntent(open)
            .addAction(R.drawable.ic_notification, v.t("إيقاف الفقاعة", "إيقاف الفقاعة"), off)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    // ============================================================ الفقاعة نفسها
    private fun edgeX(side: Int): Int {
        val size = dp(BubbleView.WINDOW_DP)
        val pad = dp(BubbleView.PAD_DP)
        return if (side == 0) -pad + dp(2) else screenW - size + pad - dp(2)
    }

    private fun ensureBubble() {
        if (bubble != null) return
        val size = dp(BubbleView.WINDOW_DP)
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = edgeX(cs.bubbleSide())
            val savedY = cs.bubbleY()
            y = (if (savedY >= 0) savedY else (screenH * 0.35f).toInt()).coerceIn(0, (screenH - size).coerceAtLeast(0))
        }
        val view = BubbleView(this).apply {
            setIcon(runCatching { packageManager.getApplicationIcon(packageName) }.getOrNull())
            contentDescription = voice().bubbleTitle
        }
        installTouch(view, lp)
        val ok = runCatching { wm.addView(view, lp) }.isSuccess
        if (!ok) { stopSelf(); return }
        bubble = view
        bubbleLp = lp
        view.alpha = 0f
        view.scaleX = 0.3f; view.scaleY = 0.3f
        view.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(420).setInterpolator(OvershootInterpolator(1.6f)).start()
    }

    private fun installTouch(view: BubbleView, lp: WindowManager.LayoutParams) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var dragging = false
        view.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX; downY = ev.rawY; startX = lp.x; startY = lp.y; dragging = false
                    view.setPressedLook(true)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downX
                    val dy = ev.rawY - downY
                    if (!dragging && hypot(dx, dy) > slop) { dragging = true; closeCard(); showTarget() }
                    if (dragging) {
                        val size = dp(BubbleView.WINDOW_DP)
                        val pad = dp(BubbleView.PAD_DP)
                        lp.x = (startX + dx).toInt().coerceIn(-pad, screenW - size + pad)
                        lp.y = (startY + dy).toInt().coerceIn(0, (screenH - size).coerceAtLeast(0))
                        runCatching { wm.updateViewLayout(view, lp) }
                        updateHover(lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.setPressedLook(false)
                    if (dragging) endDrag(lp, ev.actionMasked == MotionEvent.ACTION_UP)
                    else if (ev.actionMasked == MotionEvent.ACTION_UP) onTap()
                    true
                }
                else -> false
            }
        }
    }

    private fun showTarget() {
        // لا يمكن إسقاط فقاعة فيها عنصر أولوية: لا نعرض علامة الإغلاق أصلًا
        if (cs.pending().any { it.priority } || target != null) return
        val size = dp(64)
        val t = TextView(this).apply {
            text = "✕"; textSize = 24f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#CC0B1B3A")); setStroke(dp(2), Color.parseColor("#88E2B857")) }
            alpha = 0f
        }
        val lp = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = dp(56) }
        if (runCatching { wm.addView(t, lp) }.isSuccess) {
            target = t
            t.animate().alpha(1f).setDuration(160).start()
        }
    }

    private fun updateHover(lp: WindowManager.LayoutParams) {
        val t = target ?: return
        val size = dp(BubbleView.WINDOW_DP)
        val cx = lp.x + size / 2f
        val cy = lp.y + size / 2f
        val tx = screenW / 2f
        val ty = screenH - dp(56) - dp(32).toFloat()
        val near = hypot(cx - tx, cy - ty) < dp(76)
        if (near != targetHover) {
            targetHover = near
            (t.background as? GradientDrawable)?.setColor(if (near) Color.parseColor("#EE9F2A4A") else Color.parseColor("#CC0B1B3A"))
            t.animate().scaleX(if (near) 1.3f else 1f).scaleY(if (near) 1.3f else 1f).setDuration(120).start()
        }
    }

    private fun hideTarget() {
        val t = target ?: return
        target = null
        targetHover = false
        runCatching { wm.removeViewImmediate(t) }
    }

    private fun endDrag(lp: WindowManager.LayoutParams, released: Boolean) {
        val dropOnTarget = released && targetHover
        hideTarget()
        if (dropOnTarget) {
            // ✕ = إخفاء التذكير الحالي فقط (وليس إيقاف الرفيق): نسجّل الإخفاء ونزيل المعلّق الآن، ثم تختفي الفقاعة،
            // ويعود كل شيء تلقائيًا عند وصول التذكير التالي في موعده. لا نكتب cmp_bubble ولا cmp_enabled ولا نمسّ الجداول.
            val app = applicationContext
            cs.pending().forEach { item ->
                CompanionActions.handle(app, CompanionAct.DISMISS, item.kind, item.ref, item.openRoute)
                cs.removePending(item.kind, item.ref)
            }
            Toast.makeText(this, voice().t("اتخفّى التذكير الحالي. التذكير الجاي هيظهر في ميعاده", "انخفى التذكير الحالي. التذكير الجاي يظهر في موعده"), Toast.LENGTH_LONG).show()
            val v = bubble
            if (v == null) { BubbleController.dismissCurrent(app); return }
            v.animate().alpha(0f).scaleX(0.2f).scaleY(0.2f).setDuration(180)
                .withEndAction { BubbleController.dismissCurrent(app) }.start()
            return
        }
        val size = dp(BubbleView.WINDOW_DP)
        val side = if (lp.x + size / 2 < screenW / 2) 0 else 1
        cs.setBubbleSide(side)
        cs.setBubbleY(lp.y)
        val view = bubble ?: return
        val from = lp.x
        val to = edgeX(side)
        ValueAnimator.ofInt(from, to).apply {
            duration = 320
            interpolator = OvershootInterpolator(1.2f)
            addUpdateListener { lp.x = it.animatedValue as Int; runCatching { wm.updateViewLayout(view, lp) } }
            start()
        }
    }

    // ============================================================ الحالة والنقطة الحمراء
    private fun refresh(isNew: Boolean) {
        val view = bubble ?: return
        val s = cs.settings()
        val list = cs.pending()
        view.setState(list.size, list.any { it.priority }, list.firstOrNull()?.kind)
        view.setFx(!reducedMotion())
        idleHidden = !s.bubbleAlways && list.isEmpty()
        applyVisibility()
        if (isNew && list.isNotEmpty()) {
            view.pop()
            Sfx.play(this, Sfx.Sound.CHIRP, companionOnly = true)
        }
    }

    private fun applyVisibility() {
        val view = bubble ?: return
        val hide = appVisible || idleHidden
        view.visibility = if (hide) View.GONE else View.VISIBLE
        if (hide) closeCard()
    }

    // ============================================================ البطاقة
    private fun onTap() {
        if (card != null) { closeCard(); return }
        val list = cs.pending()
        if (list.isNotEmpty()) { peeking = false; showCard(list.first(), list.size) }
        else { peeking = true; showCard(peekItem(), 0) }
    }

    private fun peekItem(): PendingItem {
        val v = voice()
        val s = cs.settings()
        val msg = CompanionPicker.pick(CompanionMessages.all, s, LocalTime.now().hour, cs.recentIds(), Random(System.nanoTime()))
            ?: CompanionMessages.all.first()
        cs.pushRecent(msg.id)
        return PendingItem(
            LogKind.DHIKR, msg.id, v.bubbleTitle, msg.textFor(v.dialect), msg.source?.let { "— $it" },
            v.bubbleDone, v.bubbleAnother, v.bubbleOpen, "adhkar", 3001, false, System.currentTimeMillis(),
        )
    }

    /** هل المستخدم يطلب تقليل الحركة (نظام الهاتف أو إعداد أُنسي)؟ */
    private fun reducedMotion(): Boolean =
        Store.get(this).settings().motion <= 0 ||
            runCatching { android.provider.Settings.Global.getFloat(contentResolver, android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f }.getOrDefault(false)

    /** طمس الخلفية خلف البطاقة: Android 12+ وعند دعم الجهاز فقط؛ وبدونه تبقى البطاقة بكثافة أعلى تحفظ التباين. */
    private fun blurSupported(): Boolean =
        Build.VERSION.SDK_INT >= 31 && runCatching { wm.isCrossWindowBlurEnabled }.getOrDefault(false)

    private fun showCard(item: PendingItem, total: Int) {
        closeCard(false)
        val v = voice()
        val d = resources.displayMetrics.density
        val w = minOf((screenW * 0.92f).toInt(), dp(360))
        val root = GlassUi.reminderCard(this, d, item, total, v, blurSupported(), !reducedMotion()) { a -> act(item, a) }
        placeCard(root, w)
    }

    /** بطاقة نتيجة (تشجيع/مواساة) ثم تُغلق وتنتقل للعنصر التالي إن وُجد. */
    private fun showResult(text: String, good: Boolean) {
        closeCard(false)
        val d = resources.displayMetrics.density
        val w = minOf((screenW * 0.86f).toInt(), dp(330))
        placeCard(GlassUi.resultCard(this, d, text, good, blurSupported(), !reducedMotion()), w)
        val next = Runnable {
            closeCard()
            refresh(false)
            val list = cs.pending()
            if (list.isNotEmpty()) { peeking = false; showCard(list.first(), list.size) }
        }
        autoClose = next
        handler.postDelayed(next, if (good) 1800L else 2600L)
    }

    private fun placeCard(root: View, w: Int) {
        val bub = bubbleLp ?: return
        root.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        val h = root.measuredHeight
        val size = dp(BubbleView.WINDOW_DP)
        val cx = bub.x + size / 2
        val cy = bub.y + size / 2
        val circleR = dp(BubbleView.CIRCLE_DP) / 2
        val below = cy < screenH / 2
        val x = (cx - w / 2).coerceIn(dp(8), (screenW - w - dp(8)).coerceAtLeast(dp(8)))
        val y = (if (below) cy + circleR + dp(12) else cy - circleR - dp(12) - h).coerceIn(dp(24), (screenH - h - dp(24)).coerceAtLeast(dp(24)))
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        val blur = blurSupported()
        if (blur) flags = flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
        val lp = WindowManager.LayoutParams(
            w, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y
            if (blur && Build.VERSION.SDK_INT >= 31) runCatching { blurBehindRadius = dp(18) }
        }
        root.setOnTouchListener { _, ev -> if (ev.action == MotionEvent.ACTION_OUTSIDE) { closeCard(); true } else false }
        if (!runCatching { wm.addView(root, lp) }.isSuccess) return
        card = root
        val reduce = reducedMotion()
        root.pivotX = (cx - x).toFloat()
        root.pivotY = if (below) 0f else h.toFloat()
        if (reduce) return
        // دخول: نمو مرتد خفيف من الفقاعة، ثم ظهور متتابع لعناصر البطاقة (حركة لغة واحدة مع الفقاعة)
        root.alpha = 0f; root.scaleX = 0.7f; root.scaleY = 0.7f
        root.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(320).setInterpolator(OvershootInterpolator(1.1f)).start()
        if (root is ViewGroup) for (i in 0 until root.childCount) {
            val c = root.getChildAt(i)
            c.alpha = 0f; c.translationY = dp(8).toFloat()
            c.animate().alpha(1f).translationY(0f).setStartDelay(60L + i * 40L).setDuration(260).start()
        }
    }

    private fun closeCard(animated: Boolean = true) {
        autoClose?.let { handler.removeCallbacks(it) }
        autoClose = null
        val c = card ?: return
        card = null
        c.animate().cancel()
        if (!animated || reducedMotion()) { runCatching { wm.removeViewImmediate(c) }; return }
        c.animate().alpha(0f).scaleX(0.9f).scaleY(0.9f).setDuration(150)
            .withEndAction { runCatching { wm.removeViewImmediate(c) } }.start()
    }

    // ============================================================ الأفعال
    private fun act(item: PendingItem, a: CompanionAct) {
        val v = voice()
        if (peeking && a == CompanionAct.SNOOZE) { showCard(peekItem(), 0); return }   // «رسالة تانية»
        val ctx = applicationContext
        CompanionActions.handle(ctx, a, item.kind, item.ref, item.openRoute)
        val keep = item.priority && a == CompanionAct.OPEN   // الأولوية لا تُمسح إلا بالرد عليها
        if (!keep) cs.removePending(item.kind, item.ref)
        val list = cs.pending()
        bubble?.setState(list.size, list.any { it.priority }, list.firstOrNull()?.kind)
        when (a) {
            CompanionAct.PRIMARY -> {
                val msg = when (item.kind) {
                    LogKind.PLAN -> v.planKeptReply(cs.plan(item.ref.removePrefix("plan:"))?.let { PlanLogic.cleanDays(it, LocalDate.now()) } ?: 1)
                    LogKind.HABIT -> v.cheer(System.nanoTime().toInt())
                    LogKind.PRAYER -> v.t("تقبّل الله صلاتك 🤲 +١ حسنة", "تقبّل الله صلاتك 🤲 +١ حسنة")
                    else -> v.bubbleThanks
                }
                bubble?.burst(true)
                showResult(msg, true)
            }
            CompanionAct.SLIP -> {
                bubble?.burst(false)
                showResult(v.planSlipReply, false)
            }
            else -> {
                closeCard()
                if (a != CompanionAct.OPEN) refresh(false)
            }
        }
    }

    private fun removeAllViews() {
        closeCard(false)
        hideTarget()
        bubble?.let { runCatching { wm.removeViewImmediate(it) } }
        bubble = null
        bubbleLp = null
    }
}
