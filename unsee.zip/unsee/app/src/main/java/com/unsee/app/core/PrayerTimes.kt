package com.unsee.app.core

import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.ZonedDateTime
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.tan

enum class Prayer(val label: String, val key: String) {
    FAJR("الفجر", "fajr"),
    DHUHR("الظهر", "dhuhr"),
    ASR("العصر", "asr"),
    MAGHRIB("المغرب", "maghrib"),
    ISHA("العشاء", "isha"),
    ;

    /** البت الذي يمثل هذه الصلاة في قناع الصلوات المفعّلة. */
    val bit: Int get() = 1 shl ordinal

    companion object {
        const val ALL_MASK = 31
        fun fromKey(key: String): Prayer? = values().firstOrNull { it.key == key }
    }
}

/** طرق حساب شائعة. الزوايا بالدرجات تحت الأفق. تختلف الهيئات بدقائق قليلة، فتأكد من مسجد منطقتك. */
enum class CalcMethod(val label: String, val fajrAngle: Double, val ishaAngle: Double, val ishaMinutesAfterMaghrib: Int = 0) {
    EGYPT("الهيئة المصرية العامة للمساحة", 19.5, 17.5),
    MWL("رابطة العالم الإسلامي", 18.0, 17.0),
    UMM_AL_QURA("أم القرى (مكة المكرمة)", 18.5, 0.0, 90),
    KARACHI("جامعة العلوم الإسلامية بكراتشي", 18.0, 18.0),
    ISNA("أمريكا الشمالية (ISNA)", 15.0, 15.0),
}

enum class AsrMethod(val label: String, val factor: Double) {
    STANDARD("ظل المثل (جمهور الفقهاء)", 1.0),
    HANAFI("ظل المثلين (حنفي)", 2.0),
}

data class GeoPoint(val name: String, val lat: Double, val lng: Double)

data class DayTimes(
    val date: LocalDate,
    val fajr: ZonedDateTime?,
    val sunrise: ZonedDateTime?,
    val dhuhr: ZonedDateTime?,
    val asr: ZonedDateTime?,
    val maghrib: ZonedDateTime?,
    val isha: ZonedDateTime?,
) {
    fun of(p: Prayer): ZonedDateTime? = when (p) {
        Prayer.FAJR -> fajr
        Prayer.DHUHR -> dhuhr
        Prayer.ASR -> asr
        Prayer.MAGHRIB -> maghrib
        Prayer.ISHA -> isha
    }
}

/**
 * حساب فلكي محلي لمواقيت الصلاة بلا إنترنت. الخوارزمية هي الصيغة المعروفة لحساب موضع الشمس (المستخدمة في مكتبات
 * مواقيت مفتوحة المصدر): معادلة الزمن + ميل الشمس، ثم زاوية الفجر والعشاء، وظل العصر.
 *
 * النتائج تُحسب بتوقيت UTC ثم تُحوَّل إلى المنطقة الزمنية [zone]، فيتعامل التحويل مع التوقيت الصيفي تلقائيًا.
 * لا نفترض أي مواقيت ثابتة. وفي العروض العالية جدًا قد يستحيل حساب الفجر/العشاء فنُرجع null بدل رقم مخترع.
 */
object PrayerTimes {
    private const val RISE_SET_ANGLE = 0.833 // انكسار الضوء + نصف قطر الشمس

    private fun rad(d: Double) = Math.toRadians(d)
    private fun dsin(d: Double) = sin(rad(d))
    private fun dcos(d: Double) = cos(rad(d))
    private fun dtan(d: Double) = tan(rad(d))
    private fun darcsin(x: Double) = Math.toDegrees(asin(x))
    private fun darccos(x: Double) = Math.toDegrees(acos(x))
    private fun darctan2(y: Double, x: Double) = Math.toDegrees(atan2(y, x))
    private fun darccot(x: Double) = Math.toDegrees(atan(1.0 / x))
    private fun fixAngle(a: Double): Double = a - 360.0 * floor(a / 360.0)
    private fun fixHour(h: Double): Double = h - 24.0 * floor(h / 24.0)

    /** اليوم الجولياني عند منتصف ليل UTC لتاريخ ميلادي. */
    internal fun julian(year: Int, month: Int, day: Int): Double {
        var y = year
        var m = month
        if (m <= 2) { y -= 1; m += 12 }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + day + b - 1524.5
    }

    private class Sun(val declination: Double, val equation: Double)

    private fun sunPosition(jd: Double): Sun {
        val d = jd - 2451545.0
        val g = fixAngle(357.529 + 0.98560028 * d)
        val q = fixAngle(280.459 + 0.98564736 * d)
        val l = fixAngle(q + 1.915 * dsin(g) + 0.020 * dsin(2 * g))
        val e = 23.439 - 0.00000036 * d
        var ra = darctan2(dcos(e) * dsin(l), dcos(l)) / 15.0
        ra = fixHour(ra)
        return Sun(darcsin(dsin(e) * dsin(l)), q / 15.0 - ra)
    }

    private class Calc(val jd: Double, val lat: Double, val lng: Double) {
        fun midDay(t: Double): Double = fixHour(12.0 - sunPosition(jd + t).equation)

        /** وقت بلوغ الشمس زاوية [angle] تحت الأفق. NaN إن لم تبلغها في هذا اليوم. */
        fun angleTime(angle: Double, t: Double, ccw: Boolean): Double {
            val decl = sunPosition(jd + t).declination
            val noon = midDay(t)
            val x = (-dsin(angle) - dsin(decl) * dsin(lat)) / (dcos(decl) * dcos(lat))
            if (x < -1.0 || x > 1.0) return Double.NaN
            val v = darccos(x) / 15.0
            return noon + if (ccw) -v else v
        }

        fun asrTime(factor: Double, t: Double): Double {
            val decl = sunPosition(jd + t).declination
            val angle = -darccot(factor + dtan(abs(lat - decl)))
            return angleTime(angle, t, false)
        }
    }

    private class Hours(
        val fajr: Double, val sunrise: Double, val dhuhr: Double,
        val asr: Double, val sunset: Double, val maghrib: Double, val isha: Double,
    )

    /**
     * يحسب مواقيت يوم [date] (التاريخ المحلي عند المستخدم).
     * [adjustMinutes]: تعديل يدوي بالدقائق لكل صلاة بترتيب (الفجر، الظهر، العصر، المغرب، العشاء)؛ يُهمل إن كان قصيرًا.
     */
    fun forDate(
        date: LocalDate,
        point: GeoPoint,
        method: CalcMethod,
        asr: AsrMethod,
        zone: ZoneId,
        adjustMinutes: List<Int> = emptyList(),
    ): DayTimes {
        val jd = julian(date.year, date.monthValue, date.dayOfMonth) - point.lng / (15.0 * 24.0)
        val c = Calc(jd, point.lat, point.lng)

        var f = 5.0 / 24; var sr = 6.0 / 24; var dh = 12.0 / 24; var a = 13.0 / 24; var ss = 18.0 / 24; var m = 18.0 / 24; var i = 18.0 / 24
        var h = Hours(5.0, 6.0, 12.0, 13.0, 18.0, 18.0, 18.0)
        repeat(2) {
            h = Hours(
                fajr = c.angleTime(method.fajrAngle, f, true),
                sunrise = c.angleTime(RISE_SET_ANGLE, sr, true),
                dhuhr = c.midDay(dh),
                asr = c.asrTime(asr.factor, a),
                sunset = c.angleTime(RISE_SET_ANGLE, ss, false),
                maghrib = c.angleTime(RISE_SET_ANGLE, m, false),
                isha = if (method.ishaMinutesAfterMaghrib > 0) Double.NaN else c.angleTime(method.ishaAngle, i, false),
            )
            // لا نغذّي التكرار التالي بقيمة NaN (تحدث في العروض العالية): نُبقي التقدير السابق ونُرجع null للوقت المستحيل.
            if (!h.fajr.isNaN()) f = h.fajr / 24
            if (!h.sunrise.isNaN()) sr = h.sunrise / 24
            dh = h.dhuhr / 24
            if (!h.asr.isNaN()) a = h.asr / 24
            if (!h.sunset.isNaN()) ss = h.sunset / 24
            if (!h.maghrib.isNaN()) m = h.maghrib / 24
            if (!h.isha.isNaN()) i = h.isha / 24
        }

        val shift = -point.lng / 15.0 // التحويل من التوقيت الشمسي المحلي إلى UTC
        val ishaHours = if (method.ishaMinutesAfterMaghrib > 0) h.maghrib + method.ishaMinutesAfterMaghrib / 60.0 else h.isha
        fun adj(idx: Int) = adjustMinutes.getOrElse(idx) { 0 }

        return DayTimes(
            date = date,
            fajr = toZoned(date, h.fajr + shift, zone, adj(0)),
            sunrise = toZoned(date, h.sunrise + shift, zone, 0),
            dhuhr = toZoned(date, h.dhuhr + shift, zone, adj(1)),
            asr = toZoned(date, h.asr + shift, zone, adj(2)),
            maghrib = toZoned(date, h.maghrib + shift, zone, adj(3)),
            isha = toZoned(date, ishaHours + shift, zone, adj(4)),
        )
    }

    /** ساعات UTC منذ منتصف ليل [date] (UTC) → لحظة في [zone] مقرّبة لأقرب دقيقة. */
    private fun toZoned(date: LocalDate, utcHours: Double, zone: ZoneId, adjustMin: Int): ZonedDateTime? {
        if (utcHours.isNaN() || utcHours.isInfinite()) return null
        val secs = Math.round(utcHours * 60.0) * 60L + adjustMin * 60L
        return date.atStartOfDay(ZoneOffset.UTC).plusSeconds(secs).withZoneSameInstant(zone)
    }
}

/** مدن جاهزة (إحداثيات تقريبية لمراكز المدن). يمكن للمستخدم إدخال إحداثيات يدويًا. */
object Cities {
    val ALL: List<GeoPoint> = listOf(
        GeoPoint("القاهرة", 30.0444, 31.2357),
        GeoPoint("الجيزة", 30.0131, 31.2089),
        GeoPoint("الإسكندرية", 31.2001, 29.9187),
        GeoPoint("المنيا", 28.1099, 30.7503),
        GeoPoint("أسيوط", 27.1809, 31.1837),
        GeoPoint("سوهاج", 26.5591, 31.6948),
        GeoPoint("قنا", 26.1551, 32.7160),
        GeoPoint("الأقصر", 25.6872, 32.6396),
        GeoPoint("أسوان", 24.0889, 32.8998),
        GeoPoint("بني سويف", 29.0661, 31.0994),
        GeoPoint("الفيوم", 29.3084, 30.8428),
        GeoPoint("المنصورة", 31.0409, 31.3785),
        GeoPoint("طنطا", 30.7865, 31.0004),
        GeoPoint("الزقازيق", 30.5877, 31.5020),
        GeoPoint("دمنهور", 31.0341, 30.4682),
        GeoPoint("بورسعيد", 31.2653, 32.3019),
        GeoPoint("الإسماعيلية", 30.5965, 32.2715),
        GeoPoint("السويس", 29.9668, 32.5498),
        GeoPoint("الغردقة", 27.2579, 33.8116),
        GeoPoint("شرم الشيخ", 27.9158, 34.3300),
        GeoPoint("مكة المكرمة", 21.3891, 39.8579),
        GeoPoint("المدينة المنورة", 24.5247, 39.5692),
        GeoPoint("الرياض", 24.7136, 46.6753),
        GeoPoint("دبي", 25.2048, 55.2708),
        GeoPoint("عمّان", 31.9454, 35.9284),
        GeoPoint("القدس", 31.7683, 35.2137),
    )
    val DEFAULT: GeoPoint = ALL.first()
}
