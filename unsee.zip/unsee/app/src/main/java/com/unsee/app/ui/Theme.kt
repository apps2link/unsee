package com.unsee.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection

object UColors {
    val NightDeep = Color(0xFF0B1B3A)
    val NightMid = Color(0xFF14295A)
    val Emerald = Color(0xFF0F7B5F)
    val Gold = Color(0xFFE2B857)
    val GoldSoft = Color(0xFFF3D98B)
    val Cream = Color(0xFFFFF4D6)
    val CreamDim = Color(0xCCFFF4D6)
    val Card = Color(0x990A1530)
}

/**
 * يستخدم خط Amiri إن أضفتَه إلى app/src/main/res/font/amiri_regular.ttf (انظر README)،
 * وإلا يعود إلى خط النسخ العربي المدمج في Android (Noto Naskh عبر عائلة serif).
 */
@Composable
fun rememberArabicFamily(): FontFamily {
    val ctx = LocalContext.current
    return remember {
        val id = ctx.resources.getIdentifier("amiri_regular", "font", ctx.packageName)
        if (id != 0) FontFamily(Font(id)) else FontFamily.Serif
    }
}

private fun Typography.withFont(f: FontFamily) = copy(
    displayLarge = displayLarge.copy(fontFamily = f),
    displayMedium = displayMedium.copy(fontFamily = f),
    displaySmall = displaySmall.copy(fontFamily = f),
    headlineLarge = headlineLarge.copy(fontFamily = f),
    headlineMedium = headlineMedium.copy(fontFamily = f),
    headlineSmall = headlineSmall.copy(fontFamily = f),
    titleLarge = titleLarge.copy(fontFamily = f),
    titleMedium = titleMedium.copy(fontFamily = f),
    titleSmall = titleSmall.copy(fontFamily = f),
    bodyLarge = bodyLarge.copy(fontFamily = f),
    bodyMedium = bodyMedium.copy(fontFamily = f),
    bodySmall = bodySmall.copy(fontFamily = f),
    labelLarge = labelLarge.copy(fontFamily = f),
    labelMedium = labelMedium.copy(fontFamily = f),
    labelSmall = labelSmall.copy(fontFamily = f),
)

@Composable
fun UnseeTheme(fontScale: Float, content: @Composable () -> Unit) {
    val d = LocalDensity.current
    val family = rememberArabicFamily()
    val scheme = darkColorScheme(
        primary = UColors.Gold,
        onPrimary = UColors.NightDeep,
        secondary = UColors.Emerald,
        onSecondary = UColors.Cream,
        background = UColors.NightDeep,
        onBackground = UColors.Cream,
        surface = Color(0xFF0E2147),
        onSurface = UColors.Cream,
        surfaceVariant = Color(0xFF16305F),
        onSurfaceVariant = UColors.CreamDim,
        primaryContainer = Color(0xFF17407A),
        onPrimaryContainer = UColors.Cream,
        secondaryContainer = Color(0xFF1B3A6B),
        onSecondaryContainer = UColors.Cream,
        outline = Color(0x66E2B857),
    )
    CompositionLocalProvider(
        LocalLayoutDirection provides LayoutDirection.Rtl, // واجهة عربية RTL دائمًا
        LocalDensity provides Density(d.density, d.fontScale * fontScale),
    ) {
        MaterialTheme(colorScheme = scheme, typography = Typography().withFont(family), content = content)
    }
}
