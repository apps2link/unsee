package com.unsee.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import com.unsee.app.core.PaletteSpec
import com.unsee.app.core.Palettes
import com.unsee.app.core.ThemeId
import com.unsee.app.core.ThemeMode
import com.unsee.app.data.Settings

/**
 * ألوان التطبيق الحالية. تُضبط مرة واحدة في [UnseeTheme] من الثيم المختار، وتُقرأ في كل الشاشات،
 * لذلك يتغير كل التطبيق (وليس الرئيسية فقط) عند تبديل الثيم أو الوضع.
 * الأسماء (Gold/Cream/…) موروثة من الإصدار الأول وتعني الآن: اللون الرئيسي / لون النص.
 */
object UColors {
    var spec by mutableStateOf(Palettes.EMERALD_DARK)
    var accentOverride by mutableLongStateOf(0L)
    var cardAlpha by mutableFloatStateOf(1f)
    var radiusDp by mutableIntStateOf(28)
    var pattern by mutableStateOf(false)

    val Gold: Color get() = Color(if (accentOverride != 0L) accentOverride else spec.accent)
    val GoldSoft: Color get() = if (accentOverride != 0L) Color(accentOverride).copy(alpha = 0.75f) else Color(spec.accentSoft)
    val Cream: Color get() = Color(spec.text)
    val CreamDim: Color get() = Color(spec.textDim)
    val Card: Color get() = Color(spec.card).copy(alpha = cardAlpha)
    val CardSolid: Color get() = Color(spec.card)
    val BgTop: Color get() = Color(spec.bgTop)
    val BgBottom: Color get() = Color(spec.bgBottom)
    val OnAccent: Color get() = Color(spec.onAccent)
    val isDark: Boolean get() = spec.dark

    /** لون هادئ (باستيل) مشتق من لون أساسي فوق لون البطاقة؛ يعمل في الفاتح والداكن. */
    fun tint(base: Color, a: Float = 0.16f): Color = base.copy(alpha = a).compositeOver(CardSolid)
}

val LocalAppFont = staticCompositionLocalOf<FontFamily> { FontFamily.Serif }

@Composable
fun rememberArabicFamily(): FontFamily = LocalAppFont.current

/**
 * الثيم الفعلي: وضع القراءة الليلي يجبر الشاشة على الداكن، فإن كان الثيم المختار فاتحًا ثابتًا
 * (مثل اللؤلؤ والثلج) نستبدله بالأزرق الليلي حتى لا يختلط نص فاتح بخلفية فاتحة.
 */
fun effectiveTheme(settings: Settings, forceDark: Boolean): ThemeId =
    if (forceDark && settings.themeId.fixedDark == false) ThemeId.NIGHT else settings.themeId

@Composable
fun UnseeTheme(settings: Settings, forceDark: Boolean = false, content: @Composable () -> Unit) {
    val d = LocalDensity.current
    val ctx = LocalContext.current
    val systemDark = isSystemInDarkTheme()
    val themeId = effectiveTheme(settings, forceDark)
    val dark = forceDark || themeId.fixedDark ?: when (settings.mode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> systemDark
    }
    val spec: PaletteSpec = Palettes.spec(themeId, dark)
    val accent = if (settings.accent != 0L) {
        Palettes.ACCENTS.firstOrNull { it.second.first == settings.accent }?.second?.let { if (spec.dark) it.first else it.second } ?: settings.accent
    } else 0L

    // نكتب الألوان قبل رسم المحتوى ليقرأها كل الأبناء
    if (UColors.spec != spec) UColors.spec = spec
    if (UColors.accentOverride != accent) UColors.accentOverride = accent
    // الثيمات المتحركة: بطاقات شبه شفافة قليلًا لتظهر الخلفية دون أن يضعف وضوح النص
    val alpha = if (themeId == ThemeId.NATURE) 0.62f else if (themeId.animated) 0.82f else if (settings.cardStyle == 1) 0.82f else 1f
    if (UColors.cardAlpha != alpha) UColors.cardAlpha = alpha
    val radius = when (settings.cardRadius) { 0 -> 20; 2 -> 36; else -> 28 }
    if (UColors.radiusDp != radius) UColors.radiusDp = radius
    val pattern = themeId == ThemeId.PATTERN
    if (UColors.pattern != pattern) UColors.pattern = pattern

    val font = remember(settings.font) {
        when (settings.font) {
            1 -> FontFamily.SansSerif
            2 -> {
                val id = ctx.resources.getIdentifier("amiri_regular", "font", ctx.packageName)
                if (id != 0) FontFamily(Font(id)) else FontFamily.Serif
            }
            else -> FontFamily.Serif
        }
    }

    val gold = UColors.Gold
    val card = UColors.CardSolid
    val scheme = if (spec.dark) darkColorScheme(
        primary = gold, onPrimary = UColors.OnAccent, secondary = gold, onSecondary = UColors.OnAccent,
        background = UColors.BgTop, onBackground = UColors.Cream, surface = card, onSurface = UColors.Cream,
        surfaceVariant = card, onSurfaceVariant = UColors.CreamDim,
        secondaryContainer = gold.copy(alpha = 0.22f).compositeOver(card), onSecondaryContainer = UColors.Cream,
        primaryContainer = gold.copy(alpha = 0.22f).compositeOver(card), onPrimaryContainer = UColors.Cream,
        outline = gold.copy(alpha = 0.45f),
    ) else lightColorScheme(
        primary = gold, onPrimary = UColors.OnAccent, secondary = gold, onSecondary = UColors.OnAccent,
        background = UColors.BgTop, onBackground = UColors.Cream, surface = card, onSurface = UColors.Cream,
        surfaceVariant = card, onSurfaceVariant = UColors.CreamDim,
        secondaryContainer = gold.copy(alpha = 0.18f).compositeOver(card), onSecondaryContainer = UColors.Cream,
        primaryContainer = gold.copy(alpha = 0.18f).compositeOver(card), onPrimaryContainer = UColors.Cream,
        outline = gold.copy(alpha = 0.45f),
    )

    CompositionLocalProvider(
        LocalLayoutDirection provides LayoutDirection.Rtl, // واجهة عربية RTL دائمًا
        LocalDensity provides Density(d.density, d.fontScale * settings.fontScale),
        LocalAppFont provides font,
    ) {
        MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
    }
}
