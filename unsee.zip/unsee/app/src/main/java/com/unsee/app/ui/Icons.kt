package com.unsee.app.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AddAlarm
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.AutoStories
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Flight
import androidx.compose.material.icons.rounded.FormatSize
import androidx.compose.material.icons.rounded.Help
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.MeetingRoom
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.Mosque
import androidx.compose.material.icons.rounded.NightsStay
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Restaurant
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SelfImprovement
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material.icons.rounded.Widgets
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.unsee.app.data.Category

/** نقطة واحدة لكل الأيقونات: لو تغيّر اسم أيقونة في إصدار مكتبة مختلف يكفي تعديلها هنا. */
object Ico {
    val Home = Icons.Rounded.Home
    val Book = Icons.Rounded.MenuBook
    val Stories = Icons.Rounded.AutoStories
    val Beads = Icons.Rounded.TouchApp
    val Widgets = Icons.Rounded.Widgets
    val More = Icons.Rounded.MoreHoriz
    val Heart = Icons.Rounded.Favorite
    val HeartOutline = Icons.Rounded.FavoriteBorder
    val Chart = Icons.Rounded.BarChart
    val Bell = Icons.Rounded.Notifications
    val Alarm = Icons.Rounded.Alarm
    val AddAlarm = Icons.Rounded.AddAlarm
    val Settings = Icons.Rounded.Settings
    val Share = Icons.Rounded.Share
    val Copy = Icons.Rounded.ContentCopy
    val Palette = Icons.Rounded.Palette
    val FontSize = Icons.Rounded.FormatSize
    val Tune = Icons.Rounded.Tune
    val Info = Icons.Rounded.Info
    val Help = Icons.Rounded.Help
    val Person = Icons.Rounded.Person
    val Search = Icons.Rounded.Search
    val Add = Icons.Rounded.Add
    val Delete = Icons.Rounded.Delete
    val Edit = Icons.Rounded.Edit
    val Check = Icons.Rounded.Check
    val CheckCircle = Icons.Rounded.CheckCircle
    val Close = Icons.Rounded.Close
    val Refresh = Icons.Rounded.Refresh
    val Star = Icons.Rounded.Star
    val Back = Icons.AutoMirrored.Rounded.ArrowBack
    val Forward = Icons.AutoMirrored.Rounded.ArrowForward
    val Sun = Icons.Rounded.WbSunny
    val Night = Icons.Rounded.NightsStay
    val Mosque = Icons.Rounded.Mosque
    val Sleep = Icons.Rounded.Bedtime
    val Door = Icons.Rounded.MeetingRoom
    val Food = Icons.Rounded.Restaurant
    val Travel = Icons.Rounded.Flight
    val Calm = Icons.Rounded.SelfImprovement
    val Calendar = Icons.Rounded.CalendarMonth
    val Chevron = Icons.Rounded.ChevronLeft
    val Expand = Icons.Rounded.ExpandMore
    val History = Icons.Rounded.History
}

fun Category.icon(): ImageVector = when (this) {
    Category.MORNING -> Ico.Sun
    Category.EVENING -> Ico.Night
    Category.SLEEP_WAKE -> Ico.Sleep
    Category.PRAYER -> Ico.Mosque
    Category.AFTER_PRAYER -> Ico.Mosque
    Category.CLEAN -> Ico.Calm
    Category.ENTER_EXIT -> Ico.Door
    Category.HOME -> Ico.Home
    Category.FOOD -> Ico.Food
    Category.TRAVEL -> Ico.Travel
    Category.HEALTH -> Ico.Heart
    Category.NATURE -> Ico.Sun
    Category.FAMILY -> Ico.Person
    Category.SOCIAL -> Ico.Person
    Category.HAJJ -> Ico.Travel
    Category.DUAS -> Ico.Stories
    Category.MISC -> Ico.Calm
    Category.FADL -> Ico.Book
}

/** لون مميّز لكل قسم (يُستخدم بدرجة باهتة في البلاطات). */
fun Category.tint(): Color = when (this) {
    Category.MORNING -> Color(0xFFF59E0B)
    Category.EVENING -> Color(0xFF6366F1)
    Category.SLEEP_WAKE -> Color(0xFF8B5CF6)
    Category.PRAYER -> Color(0xFF059669)
    Category.AFTER_PRAYER -> Color(0xFF10B981)
    Category.CLEAN -> Color(0xFF06B6D4)
    Category.ENTER_EXIT -> Color(0xFF0EA5E9)
    Category.HOME -> Color(0xFFD97706)
    Category.FOOD -> Color(0xFFF97316)
    Category.TRAVEL -> Color(0xFF14B8A6)
    Category.HEALTH -> Color(0xFFEF4444)
    Category.NATURE -> Color(0xFF38BDF8)
    Category.FAMILY -> Color(0xFFF472B6)
    Category.SOCIAL -> Color(0xFFA78BFA)
    Category.HAJJ -> Color(0xFFCA8A04)
    Category.DUAS -> Color(0xFFEC4899)
    Category.MISC -> Color(0xFF84CC16)
    Category.FADL -> Color(0xFFFBBF24)
}
