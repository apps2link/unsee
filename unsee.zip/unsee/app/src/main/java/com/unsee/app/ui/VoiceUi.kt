package com.unsee.app.ui

import android.content.Intent
import android.provider.Settings as AndroidSettings
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.navigation.NavController
import com.unsee.app.core.Arabic
import com.unsee.app.core.QuranGuard
import com.unsee.app.core.SkipReason
import com.unsee.app.core.VoiceSection
import com.unsee.app.voice.DeviceVoice
import com.unsee.app.voice.EngineState
import com.unsee.app.voice.VoiceEngine
import com.unsee.app.voice.VoiceHooks
import com.unsee.app.voice.VoiceStatus
import com.unsee.app.voice.VoiceStore
import kotlin.math.PI
import kotlin.math.sin

private fun skipText(r: SkipReason?): String = when (r) {
    SkipReason.MASTER_OFF -> "الصوت متوقف من «استوديو الصوت»"
    SkipReason.SECTION_OFF -> "الصوت متوقف لهذا القسم"
    SkipReason.SILENT_MODE -> "الهاتف على الصامت أو الاهتزاز"
    SkipReason.DND -> "وضع عدم الإزعاج مفعّل"
    SkipReason.QUIET_HOURS -> "الآن ضمن ساعات الهدوء"
    SkipReason.QURAN -> "الآيات القرآنية لا تُقرأ بصوت آلي"
    else -> "تعذّر تشغيل الصوت (راجع استوديو الصوت)"
}

private fun hhmm(min: Int): String {
    val h = min / 60; val m = min % 60
    return (if (h < 10) "٠" else "") + Arabic.digits(h) + ":" + (if (m < 10) "٠" else "") + Arabic.digits(m)
}

/** زر «استمع/إيقاف» جاهز لأي نص. لا يظهر إن كان الصوت متوقفًا، ويستبدل بملاحظة إن كان النص آيات قرآنية. */
@Composable
fun SpeakPill(text: String, section: VoiceSection, title: String = "", modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val vs by remember { VoiceStore.get(ctx).state }.collectAsState()
    val speaking by VoiceEngine.speaking.collectAsState()
    var mine by remember { mutableStateOf(false) }
    LaunchedEffect(speaking) { if (!speaking) mine = false }
    if (QuranGuard.isQuranic(title, text)) {
        Text(
            "فيه آيات قرآنية: استمع لها بتلاوة قارئ، فالصوت الآلي لا يُستعمل للتلاوة.",
            color = UColors.CreamDim, fontSize = 12.sp, modifier = modifier.padding(top = 6.dp),
        )
        return
    }
    if (!vs.master || !vs.section(section).enabled) return
    val playing = speaking && mine
    PillButton(
        if (playing) "إيقاف" else "استمع",
        {
            if (playing) VoiceEngine.stop()
            else {
                mine = VoiceHooks.speakNow(ctx, text, section, title)
                if (!mine) Toast.makeText(ctx, skipText(VoiceEngine.lastSkip), Toast.LENGTH_SHORT).show()
            }
        },
        modifier, icon = if (playing) Ico.Stop else Ico.Speaker, filled = false,
    )
}

/** موجات صوتية تتحرك أثناء النطق وتهدأ بعده (وتتجمّد مع «تقليل الحركة»). */
@Composable
private fun VoiceWave(active: Boolean, modifier: Modifier = Modifier) {
    val reduce = LocalReduceMotion.current
    val t = if (active && !reduce) {
        rememberInfiniteTransition(label = "wave").animateFloat(0f, 1f, infiniteRepeatable(tween(1600, easing = LinearEasing)), label = "w")
    } else remember { mutableStateOf(0.3f) }
    val amp by animateFloatAsState(if (active) 1f else 0.10f, tween(if (reduce) 0 else 450), label = "amp")
    val a = UColors.Gold
    val soft = UColors.GoldSoft
    Canvas(modifier) {
        val n = 33
        val gap = size.width / n
        val bw = gap * 0.50f
        for (i in 0 until n) {
            val ph = i / n.toFloat()
            val env = 0.30f + 0.70f * sin(PI.toFloat() * ph)
            val wv = 0.5f + 0.5f * sin(2f * PI.toFloat() * (t.value * 2f + ph * 3f))
            val h = (size.height * (0.08f + 0.92f * amp * env * wv)).coerceIn(bw, size.height)
            drawRoundRect(
                Brush.verticalGradient(listOf(soft, a), startY = (size.height - h) / 2f, endY = (size.height + h) / 2f),
                topLeft = Offset(i * gap + (gap - bw) / 2f, (size.height - h) / 2f), size = Size(bw, h), cornerRadius = CornerRadius(bw / 2f, bw / 2f),
            )
        }
    }
}

private fun sampleFor(s: VoiceSection): String = when (s) {
    VoiceSection.ADHKAR_DAY -> "سبحان الله وبحمده، سبحان الله العظيم"
    VoiceSection.ADHKAR_SLEEP -> "باسمك ربي وضعت جنبي، وبك أرفعه"
    VoiceSection.TASBIH -> "ما شاء الله، أتممت هدفك في التسبيح"
    VoiceSection.COMPANION -> "السلام عليكم، عامل إيه النهارده؟ متنساش أذكار الصباح"
    VoiceSection.ENCOURAGE -> "أحسنت، ربنا يتقبل منك، استمر على طاعتك"
    VoiceSection.NOTIFY -> "يلا بينا، جه وقت أذكار المساء"
    VoiceSection.MUHASABA -> "خد دقيقة تحاسب فيها نفسك على يومك"
}

@Composable
fun VoiceStudioScreen(nav: NavController) {
    val ctx = LocalContext.current
    val store = remember { VoiceStore.get(ctx) }
    val vs by store.state.collectAsState()
    val engine by VoiceEngine.state.collectAsState()
    val speaking by VoiceEngine.speaking.collectAsState()
    val voices by VoiceEngine.voices.collectAsState()
    var sample by remember { mutableStateOf("السلام عليكم، أهلًا بك في أُنسي. جعل الله يومك مباركًا") }

    LaunchedEffect(Unit) { VoiceEngine.init(ctx) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { VoiceEngine.refreshVoices() }
    DisposableEffect(Unit) { onDispose { VoiceEngine.stop() } }

    fun preview(text: String, voice: String?, section: VoiceSection = VoiceSection.NOTIFY) {
        val id = VoiceEngine.speak(ctx, text, section, com.unsee.app.core.SpeechPriority.HIGH, ignoreGate = true, voiceName = voice)
        if (id == null) Toast.makeText(ctx, if (engine == EngineState.FAILED) "تعذّر تشغيل محرك النطق على هذا الجهاز" else skipText(VoiceEngine.lastSkip), Toast.LENGTH_SHORT).show()
    }
    fun openInstall() {
        val i = Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (runCatching { ctx.startActivity(i) }.isFailure) openTtsSettings(ctx)
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ScreenHeader("استوديو الصوت", { nav.popBackStack() })

        // ---- المعاينة الحية
        GlassCard(Modifier.fillMaxWidth(), glow = speaking) {
            VoiceWave(speaking, Modifier.fillMaxWidth().height(64.dp))
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = sample, onValueChange = { sample = it.take(400) }, modifier = Modifier.fillMaxWidth(),
                label = { Text("نص للتجربة") }, colors = fieldColors(), shape = RoundedCornerShape(18.dp),
                keyboardOptions = KeyboardOptions.Default,
            )
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (speaking) PillButton("إيقاف", { VoiceEngine.stop() }, icon = Ico.Stop)
                else PillButton("تشغيل", { preview(sample, null) }, icon = Ico.Play)
                PillButton("الصوت الافتراضي", { preview(sample, vs.voice.ifBlank { null }) }, icon = Ico.Voice, filled = false)
            }
        }

        // ---- حالة المحرك
        StatusCard(engine, voices.size, ::openInstall) { openTtsSettings(ctx) }

        // ---- الأصوات الفعلية
        SectionLabel("أصوات الجهاز العربية")
        Text("تظهر هنا الأصوات الموجودة فعلًا في محرك النطق على جهازك فقط.", color = UColors.CreamDim, fontSize = 12.sp)
        DefaultVoiceCard(selected = vs.voice.isBlank(), onPick = { store.update { it.copy(voice = "") } }, onTry = { preview(sample, null) })
        voices.forEachIndexed { i, v ->
            VoiceCard(
                v, i + 1, selected = vs.voice == v.name,
                onPick = { store.update { it.copy(voice = v.name) } },
                onTry = { preview(sample, v.name) },
                onDownload = ::openInstall,
            )
        }

        // ---- التحكم
        SectionLabel("النطق")
        GlassCard(Modifier.fillMaxWidth()) {
            LabeledSlider("السرعة: ${Arabic.digits((vs.rate * 100).toInt())}٪", vs.rate, 0.5f..1.6f) { v -> store.update { it.copy(rate = v) } }
            GlowProgressBar({ (vs.rate - 0.5f) / 1.1f }, Modifier.fillMaxWidth().height(5.dp))
            Spacer(Modifier.height(8.dp))
            LabeledSlider("درجة الصوت: ${Arabic.digits((vs.pitch * 100).toInt())}٪", vs.pitch, 0.7f..1.4f) { v -> store.update { it.copy(pitch = v) } }
            GlowProgressBar({ (vs.pitch - 0.7f) / 0.7f }, Modifier.fillMaxWidth().height(5.dp))
            Spacer(Modifier.height(8.dp))
            LabeledSlider("مستوى الصوت: ${Arabic.digits((vs.volume * 100).toInt())}٪", vs.volume, 0.2f..1f) { v -> store.update { it.copy(volume = v) } }
            GlowProgressBar({ (vs.volume - 0.2f) / 0.8f }, Modifier.fillMaxWidth().height(5.dp))
            Text("مستوى الصوت نسبي لصوت الجهاز؛ استخدم أزرار الصوت في الهاتف للرفع أكثر.", color = UColors.CreamDim, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
        }

        // ---- السلوك العام
        SectionLabel("متى يتكلم أُنسي")
        GlassCard(Modifier.fillMaxWidth()) {
            SwitchRow("تفعيل الصوت", "مفتاح عام لكل ما يُنطق في التطبيق", vs.master) { v -> store.update { it.copy(master = v) } }
            SwitchRow("نطق الإشعارات والتذكيرات", "الإشعار النصي يبقى دائمًا، والصوت إضافة إليه", vs.speakNotifications) { v -> store.update { it.copy(speakNotifications = v) } }
            SwitchRow("نطق العنوان قبل المحتوى", null, vs.speakTitle) { v -> store.update { it.copy(speakTitle = v) } }
            SwitchRow("احترام الصامت والاهتزاز", "لا نطق إن كان الهاتف صامتًا", vs.respectSilent) { v -> store.update { it.copy(respectSilent = v) } }
            SwitchRow("احترام «عدم الإزعاج»", "لا نطق للإشعارات أثناء عدم الإزعاج", vs.respectDnd) { v -> store.update { it.copy(respectDnd = v) } }
            SwitchRow("ساعات الهدوء والنوم", "لا تُنطق الإشعارات في هذه الفترة", vs.quietEnabled) { v -> store.update { it.copy(quietEnabled = v) } }
            if (vs.quietEnabled) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                    Text("من ${hhmm(vs.quietStartMin)} إلى ${hhmm(vs.quietEndMin)}", color = UColors.Cream, modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                    PillButton("البداية −", { store.update { it.copy(quietStartMin = it.quietStartMin - 30) } }, filled = false)
                    PillButton("البداية +", { store.update { it.copy(quietStartMin = it.quietStartMin + 30) } }, filled = false)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                    PillButton("النهاية −", { store.update { it.copy(quietEndMin = it.quietEndMin - 30) } }, filled = false)
                    PillButton("النهاية +", { store.update { it.copy(quietEndMin = it.quietEndMin + 30) } }, filled = false)
                }
            }
        }

        // ---- تخصيص كل قسم
        SectionLabel("تخصيص كل قسم")
        VoiceSection.values().forEach { sec ->
            val sv = vs.section(sec)
            val manualOnly = sec == VoiceSection.ADHKAR_DAY || sec == VoiceSection.ADHKAR_SLEEP
            GlassCard(Modifier.fillMaxWidth()) {
                Text(sec.label, color = UColors.Gold, fontWeight = FontWeight.Bold)
                Text(sec.blurb, color = UColors.CreamDim, fontSize = 12.sp)
                SwitchRow("تفعيل الصوت لهذا القسم", null, sv.enabled) { v -> store.updateSection(sec) { it.copy(enabled = v) } }
                if (!manualOnly) SwitchRow("تشغيل تلقائي", "ينطق دون ضغط عند وصول الرسالة أو حدوث الحدث", sv.auto) { v -> store.updateSection(sec) { it.copy(auto = v) } }
                if (voices.isNotEmpty()) {
                    val names = listOf("") + voices.filter { it.status == VoiceStatus.AVAILABLE }.map { it.name }
                    ChipRow(names, { it == sv.voice }, { if (it.isBlank()) "الصوت العام" else "صوت ${voices.indexOfFirst { v -> v.name == it } + 1}" }) { n -> store.updateSection(sec) { it.copy(voice = n) } }
                }
                PillButton("جرّب هذا القسم", { preview(sampleFor(sec), vs.voiceFor(sec).ifBlank { null }, sec) }, Modifier.padding(top = 6.dp), icon = Ico.Play, filled = false)
            }
        }

        GlassCard(Modifier.fillMaxWidth()) {
            Text("القرآن الكريم", color = UColors.Gold, fontWeight = FontWeight.Bold)
            Text(
                "الصوت الآلي لا يُستعمل أبدًا بديلًا عن التلاوة. الأذكار التي فيها آيات تُعرض نصًّا فقط، ولا يقرؤها المحرك.",
                color = UColors.CreamDim, fontSize = 12.sp,
            )
        }
        Spacer(Modifier.height(90.dp))
    }
}

@Composable
private fun StatusCard(state: EngineState, count: Int, onInstall: () -> Unit, onSettings: () -> Unit) {
    GlassCard(Modifier.fillMaxWidth()) {
        val (title, body) = when (state) {
            EngineState.READY -> if (count > 0) "المحرك جاهز" to "وُجد ${Arabic.digits(count)} صوتًا عربيًا على جهازك." else
                "المحرك جاهز لكن لا توجد أصوات عربية مفصّلة" to "قد يستعمل المحرك صوته العربي الافتراضي إن وُجد. للمزيد ثبّت بيانات صوت عربية."
            EngineState.INITIALIZING, EngineState.IDLE -> "جارٍ تجهيز المحرك…" to "لحظات ويظهر ما هو متاح على جهازك."
            EngineState.NO_ARABIC -> "اللغة العربية غير مثبّتة في محرك النطق" to "لن يُنطق العربي بصوت صحيح قبل تثبيت بيانات الصوت."
            EngineState.FAILED -> "تعذّرت تهيئة محرك النطق" to (VoiceEngine.lastError() ?: "تأكد أن لديك محرك نطق (مثل Google Text-to-speech) مفعّلًا.")
        }
        Text(title, color = UColors.Cream, fontWeight = FontWeight.Bold)
        Text(body, color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
        if (state == EngineState.NO_ARABIC || state == EngineState.FAILED || (state == EngineState.READY && count == 0)) {
            Spacer(Modifier.height(8.dp))
            Text("طريقة تثبيت صوت عربي:", color = UColors.Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(
                "١) اضغط «تثبيت بيانات الصوت» أو افتح إعدادات النطق في هاتفك.\n٢) اختر محرك Google للنطق ثم «تثبيت بيانات الصوت».\n٣) اختر اللغة العربية ونزّل الصوت ليعمل دون إنترنت.\n٤) ارجع إلى هنا وستظهر الأصوات تلقائيًا.",
                color = UColors.Cream, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp),
            )
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PillButton("تثبيت بيانات الصوت", onInstall, icon = Ico.Add)
                PillButton("إعدادات النطق", onSettings, icon = Ico.Settings, filled = false)
            }
        }
    }
}

@Composable
private fun DefaultVoiceCard(selected: Boolean, onPick: () -> Unit, onTry: () -> Unit) {
    GlassCard(Modifier.fillMaxWidth(), glow = selected) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBadge(Ico.Voice, 40.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("الافتراضي للغة العربية", color = UColors.Cream, fontWeight = FontWeight.Bold)
                Text("يترك اختيار الصوت لمحرك النطق", color = UColors.CreamDim, fontSize = 12.sp)
            }
        }
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PillButton("تجربة", onTry, icon = Ico.Play, filled = false)
            PillButton(if (selected) "المعتمد" else "اعتماد", onPick, icon = if (selected) Ico.Check else null, filled = !selected)
        }
    }
}

@Composable
private fun VoiceCard(v: DeviceVoice, index: Int, selected: Boolean, onPick: () -> Unit, onTry: () -> Unit, onDownload: () -> Unit) {
    GlassCard(Modifier.fillMaxWidth(), glow = selected) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBadge(Ico.Voice, 40.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("صوت ${Arabic.digits(index)} · ${v.locale}", color = UColors.Cream, fontWeight = FontWeight.Bold)
                Text(
                    "${v.status.label} · ${v.qualityLabel} · " + (if (v.needsNetwork) "يحتاج إنترنت" else "يعمل دون إنترنت"),
                    color = UColors.CreamDim, fontSize = 12.sp,
                )
                Text(v.name, color = UColors.CreamDim.copy(alpha = 0.7f), fontSize = 10.sp, textAlign = TextAlign.Start)
            }
        }
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            when (v.status) {
                VoiceStatus.NEEDS_DOWNLOAD -> PillButton("تنزيل الصوت", onDownload, icon = Ico.Add)
                VoiceStatus.UNSUPPORTED -> Text("غير مدعوم على هذا الجهاز", color = UColors.CreamDim, fontSize = 12.sp)
                VoiceStatus.AVAILABLE -> {
                    PillButton("تجربة", onTry, icon = Ico.Play, filled = false)
                    PillButton(if (selected) "المعتمد" else "اعتماد", onPick, icon = if (selected) Ico.Check else null, filled = !selected)
                }
            }
        }
    }
}

private fun openTtsSettings(ctx: android.content.Context) {
    val i = Intent("com.android.settings.TTS_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    if (runCatching { ctx.startActivity(i) }.isFailure) {
        runCatching { ctx.startActivity(Intent(AndroidSettings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }
}
