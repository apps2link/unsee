package com.unsee.app.data

import android.content.Context
import android.content.SharedPreferences
import com.unsee.app.core.Codec
import com.unsee.app.core.CounterCfg
import com.unsee.app.core.CounterCodec
import com.unsee.app.core.NamedCounter
import com.unsee.app.core.Reminder
import com.unsee.app.core.ReminderKind
import com.unsee.app.core.TasbihSession
import com.unsee.app.core.ThemeId
import com.unsee.app.core.ThemeMode
import com.unsee.app.core.WidgetSource
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import java.time.LocalDate

data class Settings(
    val themeId: ThemeId = ThemeId.NATURE,   // «الطبيعة الحية» هو الثيم الرئيسي
    val mode: ThemeMode = ThemeMode.DARK,    // موروث؛ كل ثيم يحدد داكنًا/فاتحًا بنفسه
    val accent: Long = 0L,            // 0 = لون الثيم الافتراضي
    val cardStyle: Int = 0,           // 0 صلبة، 1 ناعمة (شبه شفافة)
    val cardRadius: Int = 1,          // 0 صغيرة، 1 متوسطة، 2 كبيرة
    val font: Int = 0,                // 0 نسخ، 1 نظيف (Sans)، 2 أميري إن وُجد
    val fontScale: Float = 1f,
    val readerScale: Float = 1f,
    val lineSpacing: Float = 1.9f,
    val readerNight: Boolean = false,
    val motion: Int = 2,              // 0 بلا حركة، 1 خفيفة، 2 كاملة
    val sound: Boolean = true,
    val haptics: Boolean = true,
    val statsEnabled: Boolean = true,
    val dailyGoal: Int = 100,
    val userName: String = "",
    val widgetSource: WidgetSource = WidgetSource.AUTO,
    val widgetTextColor: Int = 0xFFFFF4D6.toInt(),
    val widgetBgAlpha: Int = 35,
    val widgetAutoRotate: Boolean = true,
) {
    val reduceMotion: Boolean get() = motion == 0
    val particles: Boolean get() = motion >= 2
}

data class WidgetCfg(
    val bg: Int = 0,                  // 0 زمردي، 1 ليلي، 2 فجر، 3 أسود، 4 بنفسجي
    val color: Long = 0xFFFFF4D6,
    val source: WidgetSource? = null, // null = اتبع الإعداد العام
    val alpha: Int = 100,
)

data class TapResult(val count: Int, val completed: Boolean, val counted: Boolean)
data class TasbihState(val sessionId: String, val text: String, val count: Int, val target: Int, val rounds: Int, val todayTotal: Int, val lifetime: Int)
data class TasbihTap(val count: Int, val completedRound: Boolean)
data class DayStat(val date: LocalDate, val taps: Int, val completed: Int)
data class Achievement(val date: String, val text: String, val target: Int)

/**
 * مخزن محلي واحد (SharedPreferences). اخترناه بدل Room/DataStore لأن مستقبِلات الودجت (BroadcastReceiver)
 * تحتاج قراءة/كتابة متزامنة وسريعة، وحجم البيانات صغير (عدادات وقوائم قصيرة).
 */
class Store private constructor(context: Context) {
    private val sp: SharedPreferences = context.getSharedPreferences("unsee_prefs", Context.MODE_PRIVATE)
    // الأجهزة الضعيفة تبدأ بحركة خفيفة تلقائيًا (يستطيع المستخدم رفعها من الإعدادات)
    private val lowRam: Boolean = runCatching {
        (context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager).isLowRamDevice
    }.getOrDefault(false)

    init { migrateAdhkarIdsOnce() }

    /**
     * ترحيل لمرة واحدة عند التحديث إلى مكتبة «حصن المسلم»: تُحوَّل معرّفات المفضلة وتقدّم اليوم القديمة
     * إلى مقابلاتها في الكتاب (حيث يطابق النص)، ويبقى ما لا مقابل له كما هو (يُعرض في المفضلة بوسم المكتبة السابقة).
     */
    private fun migrateAdhkarIdsOnce() {
        if (sp.getBoolean("hisn_ids_v1", false)) return
        val map = LegacyIdMap.map
        val e = sp.edit()
        val favs = HashSet(sp.getStringSet("favorites", emptySet()) ?: emptySet())
        val newFavs = HashSet<String>()
        for (id in favs) newFavs.add(map[id] ?: id)
        if (newFavs != favs) e.putStringSet("favorites", newFavs)
        val prefix = "p_${LocalDate.now()}_"
        val merged = HashMap<String, Int>()
        val oldKeys = ArrayList<String>()
        for ((k, v) in sp.all) {
            if (k.startsWith(prefix) && v is Int) {
                val n = map[k.removePrefix(prefix)] ?: continue
                oldKeys.add(k)
                merged[n] = maxOf(merged[n] ?: 0, v)
            }
        }
        for (k in oldKeys) e.remove(k)
        for ((n, v) in merged) e.putInt(prefix + n, v)
        sp.getString("last_id", null)?.let { id -> map[id]?.let { n -> e.putString("last_id", n) } }
        e.putBoolean("hisn_ids_v1", true)
        e.apply()
    }

    companion object {
        @Volatile private var instance: Store? = null
        fun get(context: Context): Store =
            instance ?: synchronized(this) {
                instance ?: Store(context.applicationContext).also { instance = it }
            }
    }

    fun today(): String = LocalDate.now().toString()

    fun <T> observe(read: () -> T): Flow<T> = callbackFlow {
        val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> trySend(read()) }
        sp.registerOnSharedPreferenceChangeListener(listener)
        trySend(read())
        awaitClose { sp.unregisterOnSharedPreferenceChangeListener(listener) }
    }.distinctUntilChanged()

    fun edit(block: SharedPreferences.Editor.() -> Unit) = sp.edit().apply(block).apply()

    // ============================================================ الإعدادات
    private inline fun <reified T : Enum<T>> enumOr(key: String, def: T): T =
        runCatching { enumValueOf<T>(sp.getString(key, def.name) ?: def.name) }.getOrDefault(def)

    fun settings(): Settings = Settings(
        themeId = enumOr("theme_id", ThemeId.NATURE), // ثيم محذوف أو غير معروف => الطبيعة الحية
        mode = enumOr("theme_mode", ThemeMode.DARK),
        accent = sp.getLong("accent", 0L),
        cardStyle = sp.getInt("card_style", 0),
        cardRadius = sp.getInt("card_radius", 1).coerceIn(0, 2),
        font = sp.getInt("font", 0).coerceIn(0, 2),
        fontScale = sp.getFloat("font_scale", 1f).coerceIn(0.8f, 1.5f),
        readerScale = sp.getFloat("reader_scale", 1f).coerceIn(0.7f, 1.8f),
        lineSpacing = sp.getFloat("line_spacing", 1.9f).coerceIn(1.4f, 2.6f),
        readerNight = sp.getBoolean("reader_night", false),
        motion = if (sp.contains("motion")) sp.getInt("motion", 2).coerceIn(0, 2) else if (sp.getBoolean("reduce_motion", false)) 0 else if (lowRam) 1 else 2,
        sound = sp.getBoolean("sound", true),
        haptics = sp.getBoolean("haptics", true),
        statsEnabled = sp.getBoolean("stats_enabled", true),
        dailyGoal = sp.getInt("daily_goal", 100).coerceIn(1, 100_000),
        userName = sp.getString("user_name", "") ?: "",
        widgetSource = enumOr("w_source", WidgetSource.AUTO),
        widgetTextColor = sp.getInt("w_text_color", 0xFFFFF4D6.toInt()),
        widgetBgAlpha = sp.getInt("w_bg_alpha", 35).coerceIn(0, 100),
        widgetAutoRotate = sp.getBoolean("w_auto_rotate", true),
    )

    // ============================================================ تقدّم الأذكار اليومي
    fun progress(id: String): Int = sp.getInt("p_${today()}_$id", 0)

    fun todayProgress(): Map<String, Int> {
        val prefix = "p_${today()}_"
        val out = HashMap<String, Int>()
        for ((k, v) in sp.all) if (k.startsWith(prefix) && v is Int) out[k.removePrefix(prefix)] = v
        return out
    }

    fun tapZikr(z: Zikr): TapResult {
        val key = "p_${today()}_${z.id}"
        val cur = sp.getInt(key, 0)
        if (z.count > 0 && cur >= z.count) return TapResult(cur, completed = true, counted = false)
        val n = cur + 1
        val done = z.count > 0 && n >= z.count
        sp.edit().apply {
            putInt(key, n)
            putString("last_id", z.id)
            recordStats(this, taps = 1, completed = if (done) 1 else 0)
        }.apply()
        return TapResult(n, completed = done, counted = true)
    }

    fun resetZikr(z: Zikr) = edit { putInt("p_${today()}_${z.id}", 0) }
    fun lastZikrId(): String? = sp.getString("last_id", null)

    private fun recordStats(e: SharedPreferences.Editor, taps: Int, completed: Int) {
        if (!sp.getBoolean("stats_enabled", true)) return
        val d = today()
        if (taps > 0) e.putInt("s_$d", sp.getInt("s_$d", 0) + taps)
        if (completed > 0) e.putInt("c_$d", sp.getInt("c_$d", 0) + completed)
    }

    fun todayTaps(): Int = sp.getInt("s_${today()}", 0)

    fun dayStats(days: Int): List<DayStat> {
        val now = LocalDate.now()
        return (days - 1 downTo 0).map { i ->
            val d = now.minusDays(i.toLong())
            DayStat(d, sp.getInt("s_$d", 0), sp.getInt("c_$d", 0))
        }
    }

    /** تسبيحات المسبحة اليومية لآخر [days] يومًا (الأقدم أولًا). */
    fun tasbihDays(days: Int): List<Pair<LocalDate, Int>> {
        val now = LocalDate.now()
        return (days - 1 downTo 0).map { i ->
            val d = now.minusDays(i.toLong())
            d to sp.getInt("td_$d", 0)
        }
    }

    /** يحذف سجل يوم واحد فقط (إحصاءاته وإنجازاته)، دون المساس بالجلسات أو الأيام الأخرى. */
    fun deleteDay(date: LocalDate) = edit {
        remove("s_$date"); remove("c_$date"); remove("td_$date")
        val kept = readAchievementLines().filterNot { it.startsWith("$date|") }
        putString("t_log", kept.joinToString("\n"))
    }

    /** يمسح السجلات اليومية والإنجازات فقط؛ تبقى الجلسات والمفضلة والإعدادات. */
    fun clearStats() = edit {
        for (k in sp.all.keys) if (k.startsWith("s_") || k.startsWith("c_") || k.startsWith("td_") || k == "t_log") remove(k)
    }

    fun pruneOld() {
        val cutoff = LocalDate.now().minusDays(14).toString()
        edit {
            for (k in sp.all.keys) if (k.startsWith("p_") && k.length > 12 && k.substring(2, 12) < cutoff) remove(k)
        }
    }

    // ============================================================ المفضلة
    fun favorites(): Set<String> = HashSet(sp.getStringSet("favorites", emptySet()) ?: emptySet())

    fun toggleFavorite(id: String) {
        val set = favorites().toMutableSet()
        if (!set.add(id)) set.remove(id)
        edit { putStringSet("favorites", set) }
    }

    // ============================================================ موضع القراءة
    fun lastPage(cat: Category): Int = sp.getInt("pos_${cat.name}", 0)
    fun setLastPage(cat: Category, page: Int) = edit { putInt("pos_${cat.name}", page) }
    fun lastPageKey(key: String): Int = sp.getInt("pos_$key", 0)
    fun setLastPageKey(key: String, page: Int) = edit { putInt("pos_$key", page) }

    // ============================================================ المسبحة (جلسات متعددة)
    fun sessions(): List<TasbihSession> {
        val raw = sp.getString("sessions", null)
        val list = if (raw != null) Codec.decodeSessions(raw) else emptyList()
        if (list.isNotEmpty()) return list
        // أول تشغيل أو ترحيل من الإصدار 1.0
        return listOf(
            TasbihSession(
                id = "main", text = TasbihPhrases.get(sp.getInt("t_phrase", 0)),
                target = sp.getInt("t_target", 33).coerceAtLeast(1),
                count = sp.getInt("t_count", 0), total = sp.getInt("t_total", 0),
            ),
        )
    }

    private fun writeSessions(e: SharedPreferences.Editor, list: List<TasbihSession>) {
        e.putString("sessions", Codec.encodeSessions(list))
    }

    fun activeSessionId(): String {
        val list = sessions()
        val id = sp.getString("t_active", null)
        return if (id != null && list.any { it.id == id }) id else list.first().id
    }

    fun tasbih(): TasbihState {
        val list = sessions()
        val s = list.firstOrNull { it.id == activeSessionId() } ?: list.first()
        return TasbihState(s.id, s.text, s.count, s.target, s.rounds, sp.getInt("td_${today()}", 0), list.sumOf { it.total })
    }

    fun tasbihTap(): TasbihTap {
        val list = sessions().toMutableList()
        val activeId = activeSessionId()
        val idx = list.indexOfFirst { it.id == activeId }.coerceAtLeast(0)
        val s = list[idx]
        val base = if (s.count >= s.target) 0 else s.count
        val n = base + 1
        val done = n == s.target
        list[idx] = s.copy(count = n, total = s.total + 1, updated = System.currentTimeMillis(), rounds = s.rounds + if (done) 1 else 0)
        val d = today()
        edit {
            writeSessions(this, list)
            putString("t_active", activeId)
            putInt("td_$d", sp.getInt("td_$d", 0) + 1)
            if (sp.getBoolean("stats_enabled", true)) putInt("s_$d", sp.getInt("s_$d", 0) + 1)
            if (done) {
                val line = "$d|${s.text.replace('|', ' ')}|${s.target}"
                putString("t_log", (readAchievementLines() + line).takeLast(200).joinToString("\n"))
            }
        }
        return TasbihTap(n, done)
    }

    fun tasbihReset() = updateActive { it.copy(count = 0) }
    fun setTasbihTarget(target: Int) = updateActive { it.copy(target = target.coerceIn(1, 100_000), count = 0) }

    private fun updateActive(f: (TasbihSession) -> TasbihSession) {
        val list = sessions().toMutableList()
        val id = activeSessionId()
        val idx = list.indexOfFirst { it.id == id }.coerceAtLeast(0)
        list[idx] = f(list[idx])
        edit { writeSessions(this, list) }
    }

    /** يختار الجلسة التي تحمل هذا الذكر إن وُجدت، وإلا ينشئ جلسة جديدة. */
    fun useText(text: String, target: Int): String {
        val clean = text.replace('|', ' ').replace('\n', ' ').trim().ifEmpty { return activeSessionId() }
        val list = sessions()
        val existing = list.firstOrNull { it.text == clean }
        if (existing != null) { selectSession(existing.id); return existing.id }
        return newSession(clean, target)
    }

    fun newSession(text: String, target: Int): String {
        val id = "s${System.currentTimeMillis()}"
        val clean = text.replace('|', ' ').replace('\n', ' ').trim().ifEmpty { "ذكر" }
        val list = sessions() + TasbihSession(id, clean, target.coerceIn(1, 100_000), updated = System.currentTimeMillis())
        edit { writeSessions(this, list); putString("t_active", id) }
        return id
    }

    fun selectSession(id: String) = edit { putString("t_active", id) }

    /** يحذف جلسة واحدة فقط. إن كانت الأخيرة تُنشأ جلسة فارغة بدلها. */
    fun deleteSession(id: String) {
        var list = sessions().filterNot { it.id == id }
        if (list.isEmpty()) list = listOf(TasbihSession("main", TasbihPhrases.get(0), 33))
        val active = if (activeSessionId() == id) list.first().id else activeSessionId()
        edit { writeSessions(this, list); putString("t_active", active) }
    }

    private fun readAchievementLines(): List<String> = (sp.getString("t_log", "") ?: "").split('\n').filter { it.isNotBlank() }

    /** سجل الإنجازات (الأحدث أولًا). يدعم الصيغة القديمة التي كانت تخزّن رقم العبارة. */
    fun achievements(): List<Achievement> = readAchievementLines().mapNotNull {
        val p = it.split('|')
        if (p.size != 3) return@mapNotNull null
        val text = p[1].toIntOrNull()?.let { i -> TasbihPhrases.get(i) } ?: p[1]
        Achievement(p[0], text, p[2].toIntOrNull() ?: 0)
    }.reversed()

    // ============================================================ التذكيرات
    fun reminders(): List<Reminder> {
        val raw = sp.getString("reminders", null)
        if (raw != null) return Codec.decodeReminders(raw)
        return listOf(
            Reminder("morning", ReminderKind.MORNING, "أذكار الصباح", sp.getInt("rem_morning_min", 5 * 60 + 30), Reminder.ALL_DAYS, sp.getBoolean("rem_morning", false), Category.MORNING.name),
            Reminder("evening", ReminderKind.EVENING, "أذكار المساء", sp.getInt("rem_evening_min", 17 * 60), Reminder.ALL_DAYS, sp.getBoolean("rem_evening", false), Category.EVENING.name),
        )
    }

    fun saveReminders(list: List<Reminder>) = edit { putString("reminders", Codec.encodeReminders(list)) }

    // ============================================================ عدّادات التسبيح (التصميم والتخصيص)
    fun counterCfg(): CounterCfg = CounterCodec.decode(sp.getString("cnt_cfg", null))
    fun setCounterCfg(c: CounterCfg) = edit { putString("cnt_cfg", CounterCodec.encode(c.clamped())) }
    fun savedCounters(): List<NamedCounter> = CounterCodec.decodeSaved(sp.getString("cnt_saved", null))

    /** يحفظ التصميم باسم يختاره المستخدم (نفس الاسم يستبدل القديم). */
    fun saveCounterDesign(name: String, cfg: CounterCfg) {
        val clean = name.replace('|', ' ').replace('\n', ' ').trim().take(24).ifEmpty { return }
        val list = savedCounters().filterNot { it.name == clean } + NamedCounter(clean, cfg.clamped())
        edit { putString("cnt_saved", CounterCodec.encodeSaved(list)) }
    }

    fun deleteCounterDesign(name: String) {
        edit { putString("cnt_saved", CounterCodec.encodeSaved(savedCounters().filterNot { it.name == name })) }
    }

    // ============================================================ الودجت
    fun widgetOffset(id: Int): Int = sp.getInt("w_off_$id", 0)
    fun setWidgetOffset(id: Int, v: Int) = edit { putInt("w_off_$id", v) }

    fun widgetCfg(id: Int): WidgetCfg = WidgetCfg(
        bg = sp.getInt("wc_${id}_bg", 0),
        color = sp.getLong("wc_${id}_color", 0xFFFFF4D6),
        source = sp.getString("wc_${id}_src", null)?.let { runCatching { WidgetSource.valueOf(it) }.getOrNull() },
        alpha = sp.getInt("wc_${id}_alpha", 100).coerceIn(0, 100),
    )

    fun setWidgetCfg(id: Int, c: WidgetCfg) = edit {
        putInt("wc_${id}_bg", c.bg); putLong("wc_${id}_color", c.color); putInt("wc_${id}_alpha", c.alpha)
        if (c.source == null) remove("wc_${id}_src") else putString("wc_${id}_src", c.source.name)
    }

    fun removeWidget(id: Int) = edit {
        remove("w_off_$id")
        for (k in sp.all.keys) if (k.startsWith("wc_${id}_")) remove(k)
    }
}
