package com.unsee.app.data

import android.content.Context
import android.content.SharedPreferences
import com.unsee.app.core.WidgetSource
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import java.time.LocalDate

enum class ThemeMode(val label: String) {
    AUTO("تلقائي"), DAWN("فجر"), DAY("حديقة"), SUNSET("غروب"), NIGHT("ليل")
}

data class Settings(
    val theme: ThemeMode = ThemeMode.AUTO,
    val fontScale: Float = 1f,
    val reduceMotion: Boolean = false,
    val particles: Boolean = true,
    val sound: Boolean = false,
    val haptics: Boolean = true,
    val statsEnabled: Boolean = true,
    val morningReminder: Boolean = false,
    val morningMinute: Int = 5 * 60 + 30,
    val eveningReminder: Boolean = false,
    val eveningMinute: Int = 17 * 60,
    val widgetSource: WidgetSource = WidgetSource.AUTO,
    val widgetTextColor: Int = 0xFFFFF4D6.toInt(),
    val widgetBgAlpha: Int = 35,          // 0..100 (للودجت الشفافة)
    val widgetAutoRotate: Boolean = true,
)

data class TapResult(val count: Int, val completed: Boolean, val counted: Boolean)
data class TasbihState(val phrase: Int, val count: Int, val target: Int, val todayTotal: Int, val lifetime: Int)
data class TasbihTap(val count: Int, val completedRound: Boolean)
data class DayStat(val date: LocalDate, val taps: Int, val completed: Int)

/**
 * مخزن محلي واحد (SharedPreferences). اخترناه بدل DataStore لأن مستقبِلات الودجت (BroadcastReceiver)
 * تحتاج قراءة/كتابة متزامنة وسريعة، وكل الحالة صغيرة. التطبيق والودجت في نفس العملية فتتطابق القيم دائمًا.
 */
class Store private constructor(context: Context) {
    private val sp: SharedPreferences = context.getSharedPreferences("unsee_prefs", Context.MODE_PRIVATE)

    companion object {
        @Volatile private var instance: Store? = null
        fun get(context: Context): Store =
            instance ?: synchronized(this) {
                instance ?: Store(context.applicationContext).also { instance = it }
            }
    }

    fun today(): String = LocalDate.now().toString()

    /** يتتبع أي تغيير في المخزن ويعيد قراءة القيمة. */
    fun <T> observe(read: () -> T): Flow<T> = callbackFlow {
        val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> trySend(read()) }
        sp.registerOnSharedPreferenceChangeListener(listener)
        trySend(read())
        awaitClose { sp.unregisterOnSharedPreferenceChangeListener(listener) }
    }.distinctUntilChanged()

    fun edit(block: SharedPreferences.Editor.() -> Unit) = sp.edit().apply(block).apply()

    // ---------- الإعدادات ----------
    fun settings(): Settings = Settings(
        theme = runCatching { ThemeMode.valueOf(sp.getString("theme", "AUTO") ?: "AUTO") }.getOrDefault(ThemeMode.AUTO),
        fontScale = sp.getFloat("font_scale", 1f),
        reduceMotion = sp.getBoolean("reduce_motion", false),
        particles = sp.getBoolean("particles", true),
        sound = sp.getBoolean("sound", false),
        haptics = sp.getBoolean("haptics", true),
        statsEnabled = sp.getBoolean("stats_enabled", true),
        morningReminder = sp.getBoolean("rem_morning", false),
        morningMinute = sp.getInt("rem_morning_min", 5 * 60 + 30),
        eveningReminder = sp.getBoolean("rem_evening", false),
        eveningMinute = sp.getInt("rem_evening_min", 17 * 60),
        widgetSource = runCatching { WidgetSource.valueOf(sp.getString("w_source", "AUTO") ?: "AUTO") }.getOrDefault(WidgetSource.AUTO),
        widgetTextColor = sp.getInt("w_text_color", 0xFFFFF4D6.toInt()),
        widgetBgAlpha = sp.getInt("w_bg_alpha", 35).coerceIn(0, 100),
        widgetAutoRotate = sp.getBoolean("w_auto_rotate", true),
    )

    // ---------- تقدّم الأذكار اليومي ----------
    fun progress(id: String): Int = sp.getInt("p_${today()}_$id", 0)

    fun todayProgress(): Map<String, Int> {
        val prefix = "p_${today()}_"
        val out = HashMap<String, Int>()
        for ((k, v) in sp.all) if (k.startsWith(prefix) && v is Int) out[k.removePrefix(prefix)] = v
        return out
    }

    fun tapZikr(z: Zikr): TapResult {
        val key = "p_${today()}_${z.id}"
        val cur = sp.getInt(key, 0)
        if (z.count > 0 && cur >= z.count) return TapResult(cur, completed = true, counted = false)
        val n = cur + 1
        val done = z.count > 0 && n >= z.count
        sp.edit().apply {
            putInt(key, n)
            putString("last_id", z.id)
            recordStats(this, taps = 1, completed = if (done) 1 else 0)
        }.apply()
        return TapResult(n, completed = done, counted = true)
    }

    fun resetZikr(z: Zikr) = edit { putInt("p_${today()}_${z.id}", 0) }

    fun lastZikrId(): String? = sp.getString("last_id", null)

    private fun recordStats(e: SharedPreferences.Editor, taps: Int, completed: Int) {
        if (!sp.getBoolean("stats_enabled", true)) return
        val d = today()
        if (taps > 0) e.putInt("s_$d", sp.getInt("s_$d", 0) + taps)
        if (completed > 0) e.putInt("c_$d", sp.getInt("c_$d", 0) + completed)
    }

    fun todayTaps(): Int = sp.getInt("s_${today()}", 0)

    fun dayStats(days: Int): List<DayStat> {
        val now = LocalDate.now()
        return (days - 1 downTo 0).map { i ->
            val d = now.minusDays(i.toLong())
            DayStat(d, sp.getInt("s_$d", 0), sp.getInt("c_$d", 0))
        }
    }

    fun clearStats() = edit {
        for (k in sp.all.keys) if (k.startsWith("s_") || k.startsWith("c_") || k.startsWith("td_") || k == "t_log") remove(k)
    }

    /** يحذف تقدم الأيام القديمة (أكثر من 14 يومًا) لإبقاء المخزن صغيرًا. */
    fun pruneOld() {
        val cutoff = LocalDate.now().minusDays(14).toString()
        edit {
            for (k in sp.all.keys) {
                if (k.startsWith("p_") && k.length > 12 && k.substring(2, 12) < cutoff) remove(k)
            }
        }
    }

    // ---------- المفضلة ----------
    fun favorites(): Set<String> = HashSet(sp.getStringSet("favorites", emptySet()) ?: emptySet())

    fun toggleFavorite(id: String) {
        val set = favorites().toMutableSet()
        if (!set.add(id)) set.remove(id)
        edit { putStringSet("favorites", set) }
    }

    // ---------- السبحة ----------
    fun tasbih(): TasbihState = TasbihState(
        phrase = sp.getInt("t_phrase", 0),
        count = sp.getInt("t_count", 0),
        target = sp.getInt("t_target", 33).coerceAtLeast(1),
        todayTotal = sp.getInt("td_${today()}", 0),
        lifetime = sp.getInt("t_total", 0),
    )

    fun tasbihTap(): TasbihTap {
        val t = tasbih()
        val base = if (t.count >= t.target) 0 else t.count
        val n = base + 1
        val done = n == t.target
        edit {
            putInt("t_count", n)
            putInt("t_total", t.lifetime + 1)
            putInt("td_${today()}", t.todayTotal + 1)
            if (sp.getBoolean("stats_enabled", true)) {
                val d = today()
                putInt("s_$d", sp.getInt("s_$d", 0) + 1)
            }
            if (done) {
                val line = "${today()}|${t.phrase}|${t.target}"
                val old = (sp.getString("t_log", "") ?: "").split('\n').filter { it.isNotBlank() }
                putString("t_log", (old + line).takeLast(60).joinToString("\n"))
            }
        }
        return TasbihTap(n, done)
    }

    fun tasbihReset() = edit { putInt("t_count", 0) }
    fun setTasbihTarget(target: Int) = edit { putInt("t_target", target.coerceIn(1, 100_000)); putInt("t_count", 0) }
    fun setTasbihPhrase(i: Int) = edit { putInt("t_phrase", i); putInt("t_count", 0) }

    /** سجل الإنجازات: (التاريخ، رقم العبارة، الهدف) الأحدث أولًا. */
    fun achievements(): List<Triple<String, Int, Int>> =
        (sp.getString("t_log", "") ?: "").split('\n').filter { it.isNotBlank() }.mapNotNull {
            val p = it.split('|')
            if (p.size == 3) Triple(p[0], p[1].toIntOrNull() ?: 0, p[2].toIntOrNull() ?: 0) else null
        }.reversed()

    // ---------- حالة الودجت ----------
    fun widgetOffset(id: Int): Int = sp.getInt("w_off_$id", 0)
    fun setWidgetOffset(id: Int, v: Int) = edit { putInt("w_off_$id", v) }
    fun removeWidget(id: Int) = edit { remove("w_off_$id") }
}
