package com.unsee.app.ui

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.unsee.app.data.Category
import com.unsee.app.data.Store
import java.time.LocalTime

private data class Tab(val route: String, val label: String, val glyph: String)

private val TABS = listOf(
    Tab("home", "الرئيسية", "🏠"),
    Tab("adhkar", "الأذكار", "📖"),
    Tab("tasbih", "السبحة", "📿"),
    Tab("favorites", "المفضلة", "♥"),
    Tab("settings", "التخصيص", "⚙"),
)

@Composable
fun UnseeApp(store: Store, startRoute: String?, onRouteConsumed: () -> Unit) {
    val flow = remember { store.observe { store.settings() } }
    val settings by flow.collectAsStateWithLifecycle(initialValue = remember { store.settings() })
    val hour = remember { LocalTime.now().hour }
    val scene = Scenes.forTheme(settings.theme, hour)

    UnseeTheme(settings.fontScale) {
        Box(Modifier.fillMaxSize()) {
            Backdrop(scene, settings.reduceMotion, settings.particles)
            val nav = rememberNavController()
            val backStack by nav.currentBackStackEntryAsState()
            val route = backStack?.destination?.route

            LaunchedEffect(startRoute) {
                if (startRoute != null) {
                    runCatching { nav.navigate(startRoute) }
                    onRouteConsumed()
                }
            }

            Scaffold(
                containerColor = Color.Transparent,
                contentWindowInsets = WindowInsets.safeDrawing,
                bottomBar = {
                    if (route == null || TABS.any { it.route == route }) {
                        NavigationBar(containerColor = Color(0xCC081330)) {
                            TABS.forEach { tab ->
                                NavigationBarItem(
                                    selected = route == tab.route,
                                    onClick = {
                                        nav.navigate(tab.route) {
                                            popUpTo("home") { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                    icon = { Text(tab.glyph, fontSize = 20.sp) },
                                    label = { Text(tab.label, fontSize = 11.sp) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedTextColor = UColors.Gold,
                                        unselectedTextColor = UColors.CreamDim,
                                        indicatorColor = UColors.Gold.copy(alpha = 0.18f),
                                    ),
                                )
                            }
                        }
                    }
                },
            ) { pad ->
                NavHost(
                    navController = nav,
                    startDestination = "home",
                    modifier = Modifier.padding(pad),
                    enterTransition = { fadeIn(tween(350)) + slideInVertically(tween(350)) { it / 24 } },
                    exitTransition = { fadeOut(tween(200)) },
                    popEnterTransition = { fadeIn(tween(300)) },
                    popExitTransition = { fadeOut(tween(200)) },
                ) {
                    composable("home") { HomeScreen(store, settings, nav) }
                    composable("adhkar") { AdhkarScreen(store, nav) }
                    composable(
                        "list/{cat}?start={start}",
                        arguments = listOf(
                            navArgument("cat") { type = NavType.StringType },
                            navArgument("start") { type = NavType.StringType; defaultValue = "" },
                        ),
                    ) { e ->
                        val cat = runCatching { Category.valueOf(e.arguments?.getString("cat") ?: "") }.getOrDefault(Category.MORNING)
                        AdhkarPagerScreen(cat, e.arguments?.getString("start") ?: "", store, settings, nav)
                    }
                    composable("tasbih") { TasbihScreen(store, settings) }
                    composable("favorites") { FavoritesScreen(store, nav) }
                    composable("stats") { StatsScreen(store, settings, nav) }
                    composable("settings") { SettingsScreen(store, settings) }
                }
            }
        }
    }
}
