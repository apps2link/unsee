package com.unsee.app.ui

import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.unsee.app.core.ThemeId
import com.unsee.app.data.Category
import com.unsee.app.data.Store
import java.time.LocalTime

private data class Tab(val route: String, val label: String, val icon: ImageVector)

// «رفيق أُنسي» حلّ محل تبويب «الأذكار» في الشريط السفلي. الأذكار ما زالت متاحة من الرئيسية (أقسام الأذكار والبحث) ومن «المزيد».
private val TABS = listOf(
    Tab("home", "الرئيسية", Ico.Home),
    Tab("companion", "رفيق أُنسي", Ico.Mosque),
    Tab("tasbih", "المسبحة", Ico.Beads),
    Tab("widgets", "الويدجت", Ico.Widgets),
    Tab("more", "المزيد", Ico.More),
)
private val MORE_ROUTES = setOf(
    "favorites", "stats", "reminders", "themes", "reading", "appsettings", "help", "about",
)
private val COMPANION_ROUTES = setOf(
    "companion", "companion_settings", "companion_perms", "companion_log", "prayer", "muhasaba", "muhasaba_notes", "comeback",
)

@Composable
fun UnseeApp(store: Store, startRoute: String?, onRouteConsumed: () -> Unit) {
    val ctx = LocalContext.current
    val flow = remember { store.observe { store.settings() } }
    val raw by flow.collectAsStateWithLifecycle(initialValue = remember { store.settings() })
    // نحترم إعداد النظام «إزالة الرسوم المتحركة»
    val systemReduce = remember {
        runCatching { android.provider.Settings.Global.getFloat(ctx.contentResolver, android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f }.getOrDefault(false)
    }
    val settings = if (systemReduce && raw.motion != 0) raw.copy(motion = 0) else raw
    val hour = remember { LocalTime.now().hour }

    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val forceDark = settings.readerNight && route?.startsWith("list/") == true

    UnseeTheme(settings, forceDark) {
      ProvideVoice {
        Box(Modifier.fillMaxSize()) {
            if (settings.themeId == ThemeId.NATURE) {
                // الثيم الرئيسي: الخلفية الأصلية كما هي دون أي تغيير
                NatureBackdrop(Scenes.forHour(hour), settings.reduceMotion, settings.particles)
            } else {
                // كل ثيم له محرّك رسم وحركة خاصة به؛ «حركة خفيفة» تنصّف عدد العناصر، و«بلا حركة» تجمّد المشهد (توفير للبطارية)
                ThemeBackdrop(settings.themeId, UColors.spec, settings.reduceMotion, if (settings.particles) 1f else 0.5f)
            }

            // أيقونات شريط الحالة والتنقل تتبع الثيم: داكنة فوق الثيمات الفاتحة وفاتحة فوق الداكنة
            val darkBars = UColors.isDark
            val activity = remember(ctx) { ctx.findComponentActivity() }
            LaunchedEffect(darkBars) {
                activity?.enableEdgeToEdge(
                    statusBarStyle = if (darkBars) SystemBarStyle.dark(android.graphics.Color.TRANSPARENT) else SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT),
                    navigationBarStyle = if (darkBars) SystemBarStyle.dark(android.graphics.Color.TRANSPARENT) else SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT),
                )
            }

            LaunchedEffect(startRoute) {
                if (startRoute != null) {
                    runCatching { nav.navigate(startRoute) }
                    onRouteConsumed()
                }
            }

            Scaffold(
                containerColor = Color.Transparent,
                contentWindowInsets = WindowInsets.safeDrawing,
                bottomBar = {
                    if (route?.startsWith("list/") != true) {
                        FloatingNav(route) { target ->
                            nav.navigate(target) {
                                popUpTo("home") { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    }
                },
            ) { pad ->
                NavHost(
                    navController = nav,
                    startDestination = "home",
                    modifier = Modifier.padding(pad),
                    enterTransition = { if (settings.reduceMotion) fadeIn(tween(0)) else fadeIn(tween(320)) + slideInVertically(tween(320)) { it / 24 } },
                    exitTransition = { fadeOut(tween(if (settings.reduceMotion) 0 else 180)) },
                    popEnterTransition = { fadeIn(tween(if (settings.reduceMotion) 0 else 260)) },
                    popExitTransition = { fadeOut(tween(if (settings.reduceMotion) 0 else 180)) },
                ) {
                    composable("home") { HomeScreen(store, settings, nav) }
                    composable("adhkar") { AdhkarScreen(store, nav) }
                    composable(
                        "list/{cat}?start={start}",
                        arguments = listOf(
                            navArgument("cat") { type = NavType.StringType },
                            navArgument("start") { type = NavType.StringType; defaultValue = "" },
                        ),
                    ) { e ->
                        val cat = runCatching { Category.valueOf(e.arguments?.getString("cat") ?: "") }.getOrDefault(Category.MORNING)
                        AdhkarPagerScreen(cat, e.arguments?.getString("start") ?: "", store, settings, nav)
                    }
                    composable("tasbih") { TasbihScreen(store, settings, nav) }
                    composable("widgets") { WidgetsScreen(store, settings, nav) }
                    composable("counters") { CounterStudioScreen(store, settings, nav) }
                    composable("more") { MoreScreen(nav) }
                    composable("favorites") { FavoritesScreen(store, nav) }
                    composable("stats") { StatsScreen(store, nav) }
                    composable("reminders") { RemindersScreen(store, nav) }
                    composable("themes") { ThemesScreen(store, settings, nav) }
                    composable("reading") { ReadingSettingsScreen(store, settings, nav) }
                    composable("appsettings") { AppSettingsScreen(store, settings, nav) }
                    composable("help") { HelpScreen(nav) }
                    composable("about") { AboutScreen(nav) }
                    composable("companion") { CompanionScreen(nav) }
                    composable("companion_settings") { CompanionSettingsScreen(nav) }
                    composable("companion_perms") { CompanionPermsScreen(nav) }
                    composable("companion_log") { CompanionLogScreen(nav) }
                    composable("prayer") { PrayerScreen(nav) }
                    composable("muhasaba") { MuhasabaScreen(nav) }
                    composable("muhasaba_notes") { MuhasabaNotesScreen(nav) }
                    composable("comeback") { ComebackScreen(nav) }
                }
            }
        }
      }
    }
}

/** شريط تنقل عائم مستدير، والعنصر المحدد داخل حبّة بحدّ رفيع (على طراز التطبيقات الحديثة). */
@Composable
private fun FloatingNav(route: String?, onSelect: (String) -> Unit) {
    val shape = RoundedCornerShape(36.dp)
    Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 14.dp, vertical = 8.dp)) {
        Row(
            Modifier.fillMaxWidth().softSurface(shape, 14.dp).padding(horizontal = 6.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TABS.forEach { tab ->
                val selected = when (tab.route) {
                    "home" -> route == "home" || route == "adhkar"
                    "companion" -> route in COMPANION_ROUTES
                    "widgets" -> route == "widgets" || route == "counters"
                    "more" -> route == "more" || route in MORE_ROUTES
                    else -> route == tab.route
                }
                val tint = if (selected) UColors.Gold else UColors.CreamDim
                val itemShape = RoundedCornerShape(28.dp)
                var m = Modifier.weight(1f).clip(itemShape)
                if (selected) m = m.background(UColors.Gold.copy(alpha = 0.12f)).border(1.dp, UColors.Gold.copy(alpha = 0.55f), itemShape)
                Column(m.clickable { onSelect(tab.route) }.padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(tab.icon, tab.label, tint = tint, modifier = Modifier.size(26.dp))
                    Text(tab.label, color = tint, fontSize = 11.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }
    }
}

private tailrec fun android.content.Context.findComponentActivity(): ComponentActivity? = when (this) {
    is ComponentActivity -> this
    is android.content.ContextWrapper -> baseContext.findComponentActivity()
    else -> null
}
