package com.unsee.app.ui

import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.unsee.app.core.ThemeId
import com.unsee.app.data.AdhkarData
import com.unsee.app.data.Category
import com.unsee.app.data.Store
import java.time.LocalTime

private data class Tab(val route: String, val label: String, val icon: ImageVector)

// تبويب «محاسبة النفس» في الشريط السفلي؛ «رفيق أُنسي» انتقل إلى «المزيد». الأذكار متاحة من الرئيسية و«المزيد».
private val TABS = listOf(
    Tab("home", "الرئيسية", Ico.Home),
    Tab("muhasaba", "محاسبة النفس", Ico.CheckCircle),
    Tab("tasbih", "المسبحة", Ico.Beads),
    Tab("widgets", "الويدجت", Ico.Widgets),
    Tab("more", "المزيد", Ico.More),
)
private val MORE_ROUTES = setOf(
    "favorites", "stats", "reminders", "themes", "reading", "appsettings", "help", "about",
    "voice", "companion", "companion_settings", "companion_perms", "companion_log", "prayer", "comeback",
)
private val MUHASABA_ROUTES = setOf("muhasaba", "muhasaba_notes")

/** هل هذا التبويب هو المحدد حاليًا (الشاشة الحالية تنتمي إليه)؟ */
private fun tabSelected(tabRoute: String, route: String?): Boolean = when (tabRoute) {
    "home" -> route == "home" || route == "adhkar"
    "muhasaba" -> route in MUHASABA_ROUTES
    "widgets" -> route == "widgets" || route == "counters"
    "more" -> route == "more" || route in MORE_ROUTES
    else -> route == tabRoute
}

@Composable
fun UnseeApp(store: Store, startRoute: String?, onRouteConsumed: () -> Unit) {
    val ctx = LocalContext.current
    val flow = remember { store.observe { store.settings() } }
    val raw by flow.collectAsStateWithLifecycle(initialValue = remember { store.settings() })
    // نحترم إعداد النظام «إزالة الرسوم المتحركة»
    val systemReduce = remember {
        runCatching { android.provider.Settings.Global.getFloat(ctx.contentResolver, android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f }.getOrDefault(false)
    }
    val settings = if (systemReduce && raw.motion != 0) raw.copy(motion = 0) else raw
    val hour = remember { LocalTime.now().hour }
    val sky = rememberLiveSky(settings)

    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val inReader = route?.startsWith("list/") == true || route?.startsWith("section/") == true
    val forceDark = settings.readerNight && inReader

    UnseeTheme(settings, forceDark, sky) {
      ProvideVoice {
        Box(Modifier.fillMaxSize()) {
            if (settings.themeId == ThemeId.SILK) {
                // الثيم الرئيسي الجديد: حرير حي (نهار لؤلؤي ↔ ليل بنفسجي) يتبع الوقت الحقيقي ووضع المظهر
                SilkBackdrop(sky, settings.reduceMotion, if (settings.particles) 1f else 0.5f)
            } else if (settings.themeId == ThemeId.NATURE) {
                // الثيم الرئيسي: الخلفية الأصلية كما هي دون أي تغيير
                NatureBackdrop(Scenes.forHour(hour), settings.reduceMotion, settings.particles)
            } else {
                // كل ثيم له محرّك رسم وحركة خاصة به؛ «حركة خفيفة» تنصّف عدد العناصر، و«بلا حركة» تجمّد المشهد (توفير للبطارية)
                ThemeBackdrop(settings.themeId, UColors.spec, settings.reduceMotion, if (settings.particles) 1f else 0.5f)
            }
            // كل الثيمات غير الحرير تأخذ طبقة الزجاج المحيط نفسها فتتوحّد لغة التصميم
            if (settings.themeId != ThemeId.SILK) AmbientGlassOverlay(settings.reduceMotion, if (settings.particles) 1f else 0.5f)

            // أيقونات شريط الحالة والتنقل تتبع الثيم: داكنة فوق الثيمات الفاتحة وفاتحة فوق الداكنة
            val darkBars = UColors.isDark
            val activity = remember(ctx) { ctx.findComponentActivity() }
            LaunchedEffect(darkBars) {
                activity?.enableEdgeToEdge(
                    statusBarStyle = if (darkBars) SystemBarStyle.dark(android.graphics.Color.TRANSPARENT) else SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT),
                    navigationBarStyle = if (darkBars) SystemBarStyle.dark(android.graphics.Color.TRANSPARENT) else SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT),
                )
            }

            LaunchedEffect(startRoute) {
                if (startRoute != null) {
                    runCatching { nav.navigate(startRoute) }
                    onRouteConsumed()
                }
            }

            Scaffold(
                containerColor = Color.Transparent,
                contentWindowInsets = WindowInsets.safeDrawing,
                bottomBar = {
                    if (!inReader) {
                        FloatingNav(route, settings.reduceMotion) { target ->
                            // الضغط على تبويب أنت داخل إحدى شاشاته: نعود لجذره مباشرة (بلا restoreState وإلا أعاد النظام
                            // نفس الشاشة الفرعية المحفوظة فتبدو الضغطة بلا استجابة). تبويب آخر: ننتقل إليه ونستعيد حالته.
                            val reselect = tabSelected(target, route)
                            nav.navigate(target) {
                                popUpTo("home") { saveState = !reselect }
                                launchSingleTop = true
                                restoreState = !reselect
                            }
                        }
                    }
                },
            ) { pad ->
                androidx.compose.runtime.CompositionLocalProvider(LocalContentBottomPad provides pad.calculateBottomPadding()) {
                NavHost(
                    navController = nav,
                    startDestination = "home",
                    modifier = Modifier.padding(pad).aboveKeyboard(),
                    enterTransition = {
                        if (settings.reduceMotion) fadeIn(tween(0))
                        else fadeIn(tween(420, easing = FastOutSlowInEasing)) +
                            scaleIn(tween(420, easing = FastOutSlowInEasing), initialScale = 0.97f) +
                            slideInVertically(spring(dampingRatio = 0.9f, stiffness = Spring.StiffnessLow)) { it / 28 }
                    },
                    exitTransition = { fadeOut(tween(if (settings.reduceMotion) 0 else 200)) },
                    popEnterTransition = { fadeIn(tween(if (settings.reduceMotion) 0 else 320, easing = FastOutSlowInEasing)) },
                    popExitTransition = { fadeOut(tween(if (settings.reduceMotion) 0 else 200)) },
                ) {
                    composable("home") { HomeScreen(store, settings, nav) }
                    composable("adhkar") { AdhkarScreen(store, nav) }
                    composable(
                        "list/{cat}?start={start}",
                        arguments = listOf(
                            navArgument("cat") { type = NavType.StringType },
                            navArgument("start") { type = NavType.StringType; defaultValue = "" },
                        ),
                    ) { e ->
                        val cat = runCatching { Category.valueOf(e.arguments?.getString("cat") ?: "") }.getOrDefault(Category.MORNING)
                        AdhkarPagerScreen(cat.title, cat, AdhkarData.readerList(cat), cat.name, e.arguments?.getString("start") ?: "", store, settings, nav)
                    }
                    composable(
                        "section/{key}?start={start}",
                        arguments = listOf(
                            navArgument("key") { type = NavType.StringType },
                            navArgument("start") { type = NavType.StringType; defaultValue = "" },
                        ),
                    ) { e ->
                        val sec = AdhkarData.section(e.arguments?.getString("key") ?: "") ?: AdhkarData.sections.first()
                        AdhkarPagerScreen(sec.title, sec.category, sec.items, sec.key, e.arguments?.getString("start") ?: "", store, settings, nav)
                    }
                    composable("tasbih") { TasbihScreen(store, settings, nav) }
                    composable("widgets") { WidgetsScreen(store, settings, nav) }
                    composable("counters") { CounterStudioScreen(store, settings, nav) }
                    composable("more") { MoreScreen(nav) }
                    composable("favorites") { FavoritesScreen(store, nav) }
                    composable("stats") { StatsScreen(store, nav) }
                    composable("reminders") { RemindersScreen(store, nav) }
                    composable("voice") { VoiceStudioScreen(nav) }
                    composable("themes") { ThemesScreen(store, settings, nav) }
                    composable("reading") { ReadingSettingsScreen(store, settings, nav) }
                    composable("appsettings") { AppSettingsScreen(store, settings, nav) }
                    composable("help") { HelpScreen(nav) }
                    composable("about") { AboutScreen(nav) }
                    composable("companion") { CompanionScreen(nav) }
                    composable("companion_settings") { CompanionSettingsScreen(nav) }
                    composable("companion_perms") { CompanionPermsScreen(nav) }
                    composable("companion_log") { CompanionLogScreen(nav) }
                    composable("prayer") { PrayerScreen(nav) }
                    composable("muhasaba") { MuhasabaScreen(nav) }
                    composable("muhasaba_notes") { MuhasabaNotesScreen(nav) }
                    composable("comeback") { ComebackScreen(nav) }
                }
                }
            }
        }
      }
    }
}

/** شريط سفلي بفتحة نصف دائرية في الوسط يستقر فيها زر المسبحة العائم (على طراز التطبيقات الحديثة). */
private class NotchedBarShape(private val corner: Dp, private val notchRadius: Dp) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val c = with(density) { corner.toPx() }
        val r = with(density) { notchRadius.toPx() }
        val base = Path().apply { addRoundRect(RoundRect(0f, 0f, size.width, size.height, CornerRadius(c, c))) }
        val cut = Path().apply { addOval(Rect(Offset(size.width / 2f, 0f), r)) }
        return Outline.Generic(Path().apply { op(base, cut, PathOperation.Difference) })
    }
}

/**
 * شريط تنقل عائم زجاجي: أربعة تبويبات حول زر مسبحة مرتفع في الوسط. مؤشّر التحديد حبّة تنزلق بنابض بين التبويبات،
 * والأيقونة المحددة تكبر بنعومة، وزر المسبحة يتنفس ببطء حين يكون مفتوحًا (وتتوقف الحركة عند «تقليل الحركة»).
 */
@Composable
private fun FloatingNav(route: String?, reduceMotion: Boolean, onSelect: (String) -> Unit) {
    val barH = 70.dp
    val fab = 64.dp
    val gap = 86.dp
    val dark = UColors.isDark
    val accent = UColors.Gold
    val selIndex = TABS.indexOfFirst { tabSelected(it.route, route) }
    val centerSelected = selIndex == 2
    // موضع التحديد بين التبويبات الأربعة (يُتخطّى المنتصف)
    val slot = when { selIndex < 0 -> 0; selIndex < 2 -> selIndex; selIndex == 2 -> -1; else -> selIndex - 1 }

    Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 14.dp).padding(bottom = 8.dp)) {
        Box(Modifier.fillMaxWidth().padding(top = fab / 2)) {
            val shape = NotchedBarShape(36.dp, fab / 2 + 8.dp)
            BoxWithConstraints(
                Modifier.fillMaxWidth().height(barH).softSurface(shape, 16.dp).padding(horizontal = 8.dp),
            ) {
                val tabW = (maxWidth - gap) / 4
                val targetX = if (slot < 0) 0.dp else tabW * slot + (if (slot >= 2) gap else 0.dp)
                val x by animateDpAsState(targetX, spring(dampingRatio = 0.62f, stiffness = Spring.StiffnessLow), label = "navX")
                val alpha by animateFloatAsState(if (slot < 0) 0f else 1f, spring(stiffness = Spring.StiffnessLow), label = "navA")
                // الحبّة المنزلقة خلف التبويب المحدد
                Box(
                    Modifier.offset(x = x, y = 7.dp).width(tabW).height(barH - 14.dp)
                        .graphicsLayer { this.alpha = alpha }
                        .clip(RoundedCornerShape(26.dp))
                        .background(Brush.verticalGradient(listOf(accent.copy(alpha = 0.20f), accent.copy(alpha = 0.07f))))
                        .border(1.dp, Brush.verticalGradient(listOf(accent.copy(alpha = 0.55f), accent.copy(alpha = 0.12f))), RoundedCornerShape(26.dp)),
                )
                Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                    TABS.forEachIndexed { i, tab ->
                        if (i == 2) {
                            Spacer(Modifier.width(gap))
                        } else {
                            NavTab(tab, tabSelected(tab.route, route), Modifier.weight(1f)) { onSelect(tab.route) }
                        }
                    }
                }
            }
        }

        // زر المسبحة العائم
        val center = TABS[2]
        val breathe = if (reduceMotion || !centerSelected) null else rememberInfiniteTransition(label = "fab").animateFloat(
            1f, 1.05f, infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), androidx.compose.animation.core.RepeatMode.Reverse), label = "fabS",
        )
        val glowA by animateFloatAsState(if (centerSelected) 0.55f else 0.32f, tween(if (reduceMotion) 0 else 500), label = "fabGlow")
        val far = if (dark) lerp(accent, Color.White, 0.28f) else lerp(accent, Color(0xFFB69BFF), 0.60f)
        Box(
            Modifier.align(Alignment.TopCenter).size(fab)
                .graphicsLayer { val sc = breathe?.value ?: 1f; scaleX = sc; scaleY = sc }
                .springClick(pressedScale = 0.9f) { onSelect(center.route) }
                .shadow(18.dp, CircleShape, ambientColor = accent.copy(alpha = glowA), spotColor = accent.copy(alpha = glowA + 0.1f))
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(accent, far)))
                .border(1.5.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.65f), Color.White.copy(alpha = 0.05f))), CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(center.icon, center.label, tint = UColors.OnAccent, modifier = Modifier.size(30.dp))
        }
    }
}

@Composable
private fun NavTab(tab: Tab, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val tint by animateColorAsState(if (selected) UColors.Gold else UColors.CreamDim, tween(260), label = "navTint")
    val scale by animateFloatAsState(if (selected) 1.14f else 1f, spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMediumLow), label = "navScale")
    Column(
        modifier.fillMaxSize().springClick(pressedScale = 0.92f, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(tab.icon, tab.label, tint = tint, modifier = Modifier.size(24.dp).graphicsLayer { scaleX = scale; scaleY = scale })
        Text(
            tab.label, color = tint, fontSize = 10.sp, maxLines = 1, softWrap = false, textAlign = TextAlign.Center,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal, modifier = Modifier.padding(top = 3.dp),
        )
    }
}

private tailrec fun android.content.Context.findComponentActivity(): ComponentActivity? = when (this) {
    is ComponentActivity -> this
    is android.content.ContextWrapper -> baseContext.findComponentActivity()
    else -> null
}
