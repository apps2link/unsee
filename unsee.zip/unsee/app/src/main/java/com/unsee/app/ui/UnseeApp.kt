package com.unsee.app.ui

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.unsee.app.core.ThemeId
import com.unsee.app.data.Category
import com.unsee.app.data.Store
import java.time.LocalTime

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val TABS = listOf(
    Tab("home", "الرئيسية", Ico.Home),
    Tab("companion", "رفيق أُنسي", Ico.Mosque),
    Tab("tasbih", "المسبحة", Ico.Beads),
    Tab("widgets", "الويدجت", Ico.Widgets),
    Tab("more", "المزيد", Ico.More),
)
private val MORE_ROUTES = setOf("favorites", "stats", "reminders", "themes", "reading", "appsettings", "help", "about")
// شاشات «رفيق أُنسي» (تبويب مستقل في الشريط السفلي)
private val COMPANION_ROUTES = setOf("companion", "companion_settings", "companion_perms", "companion_log", "prayer", "muhasaba", "comeback")
// الأذكار لم تعد تبويبًا: مكتبتها تُفتح من الرئيسية (البحث والأقسام) ومن «المزيد»، فتبقى الرئيسية هي المحدّدة
private val HOME_ROUTES = setOf("home", "adhkar")
private val TASBIH_ROUTES = setOf("tasbih", "ringstudio")

@Composable
fun UnseeApp(store: Store, startRoute: String?, onRouteConsumed: () -> Unit) {
    val ctx = LocalContext.current
    val flow = remember { store.observe { store.settings() } }
    val raw by flow.collectAsStateWithLifecycle(initialValue = remember { store.settings() })
    // نحترم إعداد النظام «إزالة الرسوم المتحركة»
    val systemReduce = remember {
        runCatching { android.provider.Settings.Global.getFloat(ctx.contentResolver, android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f }.getOrDefault(false)
    }
    // توفير الطاقة: نوقف الحركة تلقائيًا (إن لم يعطّل المستخدم ذلك)، ونخفّفها على الأجهزة ضعيفة الذاكرة
    val pm = remember { ctx.getSystemService(android.content.Context.POWER_SERVICE) as? android.os.PowerManager }
    var powerSave by remember { mutableStateOf(pm?.isPowerSaveMode == true) }
    DisposableEffect(Unit) {
        val rec = object : android.content.BroadcastReceiver() {
            override fun onReceive(c: android.content.Context?, i: android.content.Intent?) { powerSave = pm?.isPowerSaveMode == true }
        }
        runCatching { ctx.registerReceiver(rec, android.content.IntentFilter(android.os.PowerManager.ACTION_POWER_SAVE_MODE_CHANGED)) }
        onDispose { runCatching { ctx.unregisterReceiver(rec) } }
    }
    val lowRam = remember { (ctx.getSystemService(android.content.Context.ACTIVITY_SERVICE) as? android.app.ActivityManager)?.isLowRamDevice == true }
    val settings = when {
        (systemReduce || (raw.autoSaver && powerSave)) && raw.motion != 0 -> raw.copy(motion = 0)
        lowRam && raw.motion == 2 -> raw.copy(motion = 1)
        else -> raw
    }
    val hour = remember { LocalTime.now().hour }

    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val forceDark = settings.readerNight && route?.startsWith("list/") == true

    UnseeTheme(settings, forceDark) {
        Box(Modifier.fillMaxSize()) {
            ThemeBackdrop(effectiveTheme(settings, forceDark), settings.motion, hour)

            LaunchedEffect(startRoute) {
                if (startRoute != null) {
                    runCatching { nav.navigate(startRoute) }
                    onRouteConsumed()
                }
            }

            Scaffold(
                containerColor = Color.Transparent,
                contentWindowInsets = WindowInsets.safeDrawing,
                bottomBar = {
                    if (route?.startsWith("list/") != true) {
                        FloatingNav(route) { target ->
                            nav.navigate(target) {
                                popUpTo("home") { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    }
                },
            ) { pad ->
                NavHost(
                    navController = nav,
                    startDestination = "home",
                    modifier = Modifier.padding(pad),
                    enterTransition = { if (settings.reduceMotion) fadeIn(tween(0)) else fadeIn(tween(320)) + slideInVertically(tween(320)) { it / 24 } },
                    exitTransition = { fadeOut(tween(if (settings.reduceMotion) 0 else 180)) },
                    popEnterTransition = { fadeIn(tween(if (settings.reduceMotion) 0 else 260)) },
                    popExitTransition = { fadeOut(tween(if (settings.reduceMotion) 0 else 180)) },
                ) {
                    composable("home") { HomeScreen(store, settings, nav) }
                    composable("adhkar") { AdhkarScreen(store, nav) }
                    composable("ringstudio") { RingStudioScreen(store, settings, nav) }
                    composable(
                        "list/{cat}?start={start}",
                        arguments = listOf(
                            navArgument("cat") { type = NavType.StringType },
                            navArgument("start") { type = NavType.StringType; defaultValue = "" },
                        ),
                    ) { e ->
                        val cat = runCatching { Category.valueOf(e.arguments?.getString("cat") ?: "") }.getOrDefault(Category.MORNING)
                        AdhkarPagerScreen(cat, e.arguments?.getString("start") ?: "", store, settings, nav)
                    }
                    composable("tasbih") { TasbihScreen(store, settings, nav) }
                    composable("widgets") { WidgetsScreen(store, settings, nav) }
                    composable("more") { MoreScreen(nav) }
                    composable("favorites") { FavoritesScreen(store, nav) }
                    composable("stats") { StatsScreen(store, nav) }
                    composable("reminders") { RemindersScreen(store, nav) }
                    composable("themes") { ThemesScreen(store, settings, nav) }
                    composable("reading") { ReadingSettingsScreen(store, settings, nav) }
                    composable("appsettings") { AppSettingsScreen(store, settings, nav) }
                    composable("help") { HelpScreen(nav) }
                    composable("about") { AboutScreen(nav) }
                    composable("companion") { CompanionScreen(nav) }
                    composable("companion_settings") { CompanionSettingsScreen(nav) }
                    composable("companion_perms") { CompanionPermsScreen(nav) }
                    composable("companion_log") { CompanionLogScreen(nav) }
                    composable("prayer") { PrayerScreen(nav) }
                    composable("muhasaba") { MuhasabaScreen(nav) }
                    composable("comeback") { ComebackScreen(nav) }
                }
            }
        }
    }
}

/** شريط تنقل عائم مستدير، والعنصر المحدد داخل حبّة بحدّ رفيع (على طراز التطبيقات الحديثة). */
@Composable
private fun FloatingNav(route: String?, onSelect: (String) -> Unit) {
    val shape = RoundedCornerShape(36.dp)
    Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 14.dp, vertical = 8.dp)) {
        Row(
            Modifier.fillMaxWidth().softSurface(shape, 14.dp).padding(horizontal = 6.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TABS.forEach { tab ->
                val selected = when (tab.route) {
                    "home" -> route in HOME_ROUTES
                    "companion" -> route in COMPANION_ROUTES
                    "tasbih" -> route in TASBIH_ROUTES
                    "more" -> route == "more" || route in MORE_ROUTES
                    else -> route == tab.route
                }
                val tint = if (selected) UColors.Gold else UColors.CreamDim
                val itemShape = RoundedCornerShape(28.dp)
                var m = Modifier.weight(1f).clip(itemShape)
                if (selected) m = m.background(UColors.Gold.copy(alpha = 0.12f)).border(1.dp, UColors.Gold.copy(alpha = 0.55f), itemShape)
                Column(m.clickable { onSelect(tab.route) }.padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(tab.icon, tab.label, tint = tint, modifier = Modifier.size(26.dp))
                    Text(tab.label, color = tint, fontSize = if (tab.label.length > 8) 10.sp else 11.sp, maxLines = 1, softWrap = false, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }
    }
}
