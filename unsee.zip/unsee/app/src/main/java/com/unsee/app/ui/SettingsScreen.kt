package com.unsee.app.ui

import android.Manifest
import android.app.TimePickerDialog
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.unsee.app.core.Arabic
import com.unsee.app.core.TimeLogic
import com.unsee.app.core.WidgetSource
import com.unsee.app.data.Settings
import com.unsee.app.data.Store
import com.unsee.app.data.ThemeMode
import com.unsee.app.notify.Reminders
import com.unsee.app.widget.WidgetRenderer
import com.unsee.app.widget.WidgetStyle

private fun requestPin(ctx: Context, style: WidgetStyle) {
    val mgr = AppWidgetManager.getInstance(ctx)
    if (mgr.isRequestPinAppWidgetSupported) {
        val ok = mgr.requestPinAppWidget(ComponentName(ctx, WidgetRenderer.providerClass(style)), null, null)
        if (!ok) Toast.makeText(ctx, "تعذّر الطلب. أضِفها يدويًا: اضغط مطولًا على الشاشة الرئيسية ← الودجت ← أُنسي", Toast.LENGTH_LONG).show()
    } else {
        Toast.makeText(ctx, "الشاشة الرئيسية لا تدعم الإضافة المباشرة. اضغط مطولًا على الشاشة ← الودجت ← أُنسي", Toast.LENGTH_LONG).show()
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Text(title, color = UColors.Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.padding(top = 8.dp))
    GlassCard(Modifier.fillMaxWidth()) { content() }
}

@Composable
private fun SwitchRow(title: String, sub: String? = null, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = UColors.Cream)
            if (sub != null) Text(sub, color = UColors.CreamDim, fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun SettingsScreen(store: Store, s: Settings) {
    val ctx = LocalContext.current
    fun save(block: SharedPreferences.Editor.() -> Unit) { store.edit(block); WidgetRenderer.updateAll(ctx) }
    fun saveAndReschedule(block: SharedPreferences.Editor.() -> Unit) { store.edit(block); Reminders.rescheduleAll(ctx) }

    var pendingKind by remember { mutableStateOf<String?>(null) }
    var confirmClear by remember { mutableStateOf(false) }
    var fontDraft by remember(s.fontScale) { mutableFloatStateOf(s.fontScale) }
    var alphaDraft by remember(s.widgetBgAlpha) { mutableFloatStateOf(s.widgetBgAlpha.toFloat()) }

    fun enableReminder(kind: String) {
        saveAndReschedule { putBoolean(if (kind == Reminders.MORNING) "rem_morning" else "rem_evening", true) }
    }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val k = pendingKind
        pendingKind = null
        if (granted && k != null) enableReminder(k)
        else Toast.makeText(ctx, "لم يُمنح إذن الإشعارات، فلن تصل التذكيرات", Toast.LENGTH_LONG).show()
    }
    fun toggleReminder(kind: String, on: Boolean) {
        if (!on) {
            saveAndReschedule { putBoolean(if (kind == Reminders.MORNING) "rem_morning" else "rem_evening", false) }
        } else if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingKind = kind
            permission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else enableReminder(kind)
    }
    fun pickTime(kind: String, current: Int) {
        TimePickerDialog(ctx, { _, h, m ->
            saveAndReschedule { putInt(if (kind == Reminders.MORNING) "rem_morning_min" else "rem_evening_min", h * 60 + m) }
        }, current / 60, current % 60, false).show()
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("التخصيص", color = UColors.Gold, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

        Section("المظهر") {
            Text("الخلفية والثيم", color = UColors.CreamDim, fontSize = 12.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemeMode.values().forEach { m ->
                    FilterChip(selected = s.theme == m, onClick = { save { putString("theme", m.name) } }, label = { Text(m.label) })
                }
            }
            Spacer(Modifier.height(10.dp))
            Text("حجم الخط: ${Arabic.digits((fontDraft * 100).toInt())}٪", color = UColors.CreamDim, fontSize = 12.sp)
            Slider(
                value = fontDraft, onValueChange = { fontDraft = it },
                onValueChangeFinished = { save { putFloat("font_scale", fontDraft) } },
                valueRange = 0.85f..1.4f,
                colors = SliderDefaults.colors(thumbColor = UColors.Gold, activeTrackColor = UColors.Gold),
            )
            Text("بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ", color = UColors.Cream, fontSize = 22.sp, fontFamily = rememberArabicFamily(), modifier = Modifier.fillMaxWidth())
        }

        Section("الحركة والأداء") {
            SwitchRow("تقليل الحركة", "يوقف الأنيميشن الخلفي لتوفير البطارية", s.reduceMotion) { save { putBoolean("reduce_motion", it) } }
            SwitchRow("الجزيئات الذهبية", "إيقافها يخفف الرسم قليلًا", s.particles) { save { putBoolean("particles", it) } }
        }

        Section("الصوت والاهتزاز") {
            SwitchRow("صوت النقر", null, s.sound) { save { putBoolean("sound", it) } }
            SwitchRow("اهتزاز خفيف", "عند التسبيح وإكمال الذكر (يحترم إعدادات النظام)", s.haptics) { save { putBoolean("haptics", it) } }
        }

        Section("التذكيرات (اختيارية)") {
            SwitchRow("تذكير أذكار الصباح", TimeLogic.formatMinute(s.morningMinute), s.morningReminder) { toggleReminder(Reminders.MORNING, it) }
            if (s.morningReminder) TextButton(onClick = { pickTime(Reminders.MORNING, s.morningMinute) }) { Text("تغيير الوقت", color = UColors.Gold) }
            SwitchRow("تذكير أذكار المساء", TimeLogic.formatMinute(s.eveningMinute), s.eveningReminder) { toggleReminder(Reminders.EVENING, it) }
            if (s.eveningReminder) TextButton(onClick = { pickTime(Reminders.EVENING, s.eveningMinute) }) { Text("تغيير الوقت", color = UColors.Gold) }
            Text("إشعار صامت واحد لكل تذكير، وقد يتأخر دقائق بسبب توفير البطارية. لا يعتمد على مواقيت الصلاة؛ اختر الوقت المناسب لك.", color = UColors.CreamDim, fontSize = 12.sp)
        }

        Section("إعدادات الودجت") {
            Text("مصدر الأذكار", color = UColors.CreamDim, fontSize = 12.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                WidgetSource.values().forEach { src ->
                    FilterChip(selected = s.widgetSource == src, onClick = { save { putString("w_source", src.name) } }, label = { Text(src.label) })
                }
            }
            SwitchRow("تدوير تلقائي كل نصف ساعة", "للودجت السينمائية والشفافة والزجاجية والمصغرة", s.widgetAutoRotate) { save { putBoolean("w_auto_rotate", it) } }
            Text("لون النص (الشفافة والزجاجية)", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf(0xFFFFF4D6, 0xFFE2B857, 0xFFFFFFFF, 0xFFB8F0D2, 0xFFBFD8FF).forEach { c ->
                    val col = c.toInt()
                    Box1(col, selected = s.widgetTextColor == col) { save { putInt("w_text_color", col) } }
                }
            }
            Text("درجة خلفية الودجت الشفافة: ${Arabic.digits(alphaDraft.toInt())}٪", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            Slider(
                value = alphaDraft, onValueChange = { alphaDraft = it },
                onValueChangeFinished = { save { putInt("w_bg_alpha", alphaDraft.toInt()) } },
                valueRange = 0f..100f,
                colors = SliderDefaults.colors(thumbColor = UColors.Gold, activeTrackColor = UColors.Gold),
            )
        }

        Section("أشكال الودجت — أضِف إلى الشاشة الرئيسية") {
            WidgetStyle.values().forEach { st ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(st.label, color = UColors.Cream, fontWeight = FontWeight.Bold)
                        Text(st.description, color = UColors.CreamDim, fontSize = 12.sp)
                    }
                    Button(onClick = { requestPin(ctx, st) }) { Text("أضِف") }
                }
            }
            Text("إن لم يظهر طلب الإضافة (شائع في أجهزة Xiaomi): فعّل إذن «اختصارات الشاشة الرئيسية» للتطبيق، أو أضِفها يدويًا من قائمة الودجت.", color = UColors.CreamDim, fontSize = 12.sp)
        }

        Section("البيانات والخصوصية") {
            SwitchRow("تسجيل الإحصائيات محليًا", "لا يُرسل شيء خارج جهازك", s.statsEnabled) { save { putBoolean("stats_enabled", it) } }
            OutlinedButton(onClick = { confirmClear = true }) { Text("مسح سجل الإحصائيات", color = UColors.Gold) }
            Text("التطبيق بلا إنترنت وبلا حسابات ولا إعلانات ولا تتبّع.", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
        }
        Text("أُنسي | UNSEE — الإصدار ١٫٠٫٠", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp))
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("مسح السجل؟") },
            text = { Text("سيُحذف سجل الإحصائيات وإنجازات السبحة. تبقى المفضلة والإعدادات.") },
            confirmButton = { TextButton(onClick = { store.clearStats(); confirmClear = false }) { Text("مسح") } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("إلغاء") } },
        )
    }
}

@Composable
private fun Box1(color: Int, selected: Boolean, onClick: () -> Unit) {
    androidx.compose.foundation.layout.Box(
        Modifier.size(34.dp).clip(CircleShape).background(Color(color))
            .border(if (selected) 3.dp else 1.dp, if (selected) UColors.Gold else Color.White.copy(alpha = 0.4f), CircleShape)
            .clickable(onClick = onClick),
    )
}
