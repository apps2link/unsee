package com.unsee.app.core

/**
 * حالات الفقاعة العائمة (الهوية البصرية) — منطق نقي قابل للاختبار.
 * NORMAL هادئة، REMINDER تذكير جديد، URGENT عاجل (أولوية)، PRAYER تذكير صلاة، DHIKR تذكير ذكر،
 * REFLECT محاسبة/خطة، CELEBRATE احتفال بحسنة، COMFORT مواساة بعد سيئة.
 */
enum class BubbleMood { NORMAL, REMINDER, URGENT, PRAYER, DHIKR, REFLECT, CELEBRATE, COMFORT }

/** أنواع البطاقة المنبثقة: لكلٍّ لون وزخرفة وأيقونة، مع بقاء الهوية واحدة. */
enum class CardKind { DHIKR, PRAYER, REFLECT, ENCOURAGE, COMFORT, URGENT }

object BubbleLook {
    /** المزاج الظاهر: الاحتفال/المواساة المؤقتان أولًا، ثم العاجل، ثم نوع أول تذكير معلّق، وإلا الهادئ. */
    fun mood(pendingCount: Int, priority: Boolean, firstKind: LogKind?, override: BubbleMood?): BubbleMood = when {
        override != null -> override
        pendingCount <= 0 -> BubbleMood.NORMAL
        priority -> BubbleMood.URGENT
        firstKind == LogKind.PRAYER -> BubbleMood.PRAYER
        firstKind == LogKind.DHIKR || firstKind == LogKind.HABIT -> BubbleMood.DHIKR
        firstKind == LogKind.PLAN || firstKind == LogKind.MUHASABA -> BubbleMood.REFLECT
        else -> BubbleMood.REMINDER
    }

    /** نوع بطاقة التذكير: العاجل يغلب نوع الرسالة. */
    fun cardKind(kind: LogKind, priority: Boolean): CardKind = when {
        priority -> CardKind.URGENT
        kind == LogKind.PRAYER -> CardKind.PRAYER
        kind == LogKind.PLAN || kind == LogKind.MUHASABA -> CardKind.REFLECT
        else -> CardKind.DHIKR
    }
}
