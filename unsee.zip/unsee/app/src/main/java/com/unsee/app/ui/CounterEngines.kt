package com.unsee.app.ui

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/*
 * المحركات 1–10. كل محرّك له شخصية بصرية مستقلة؛ و f.st.variant (0..2) يغيّر هندسة الرسم داخل المحرّك نفسه.
 * القاعدة: لا تعديل على حالة، ولا حلقات أثقل من ~60 عنصرًا، وكل الحركة دوال في f.t (مضاعفات صحيحة) و f.tap و f.p.
 */

// ------------------------------------------------------------------ 1) حلقة مضيئة
internal fun DrawScope.engHalo(f: CFrame) {
    val u = uu; val r = rad * 0.86f; val w = 11f * u
    val pulse = 0.5f + 0.5f * cWave(f.t, 3f)
    glowDisc(center, rad, f.ring, (0.14f + 0.10f * pulse + 0.35f * f.tap) * f.glow)
    faceDisc(f, rad * 0.74f)
    val sweep = 360f * f.p
    when (f.st.variant) {
        2 -> { // حلقة نقطية: 60 حبة مضيئة
            val n = 60
            for (i in 0 until n) {
                val lit = (i + 1f) / n <= f.p + 0.001f
                val pos = cPt(i * 360f / n, r)
                if (lit) {
                    glowDisc(pos, 9f * u, f.ring, 0.35f * f.glow)
                    drawCircle(f.ring, 3.6f * u, pos)
                } else {
                    drawCircle(f.ring.al(0.22f), 2.4f * u, pos)
                }
            }
        }
        else -> {
            trackRing(f, r, w)
            glowArc(f, f.ring, sweep, r, w)
            if (f.st.variant == 1) { // حلقة داخلية مقطّعة تدور + نجمة لامعة عند رأس القوس
                rotate(360f * f.t, center) {
                    drawCircle(f.hi.al(0.35f), rad * 0.66f, center, style = Stroke(1.6f * u, pathEffect = PathEffect.dashPathEffect(floatArrayOf(7f * u, 9f * u), 0f)))
                }
            }
        }
    }
    if (f.st.variant != 2 && f.p > 0.01f) {
        val head = cPt(sweep, r)
        glowDisc(head, 20f * u, f.hi, 0.85f * f.glow)
        drawCircle(f.hi, 4.8f * u, head)
        if (f.st.variant == 1) star4(head, (9f + 5f * pulse) * u, f.hi.al(0.9f))
    }
}

// ------------------------------------------------------------------ 2) زجاج الأحجار الكريمة
internal fun DrawScope.engGlassGem(f: CFrame) {
    val u = uu; val r = rad * 0.84f
    val w = (if (f.st.variant == 2) 18f else 24f) * u
    glowDisc(center, rad, f.ring, 0.14f * f.glow + 0.25f * f.tap)
    faceDisc(f, rad * 0.68f)
    // سطح زجاجي خفيف داخل الوجه
    drawCircle(Brush.verticalGradient(listOf(f.hi.al(0.16f), Color.Transparent), startY = center.y - rad * 0.68f, endY = center.y), rad * 0.68f, center)
    // نطاق زجاجي شفاف + حافتان لامعتان
    drawCircle(f.ring.al(0.22f), r, center, style = Stroke(w))
    drawCircle(f.hi.al(0.50f), r + w / 2f, center, style = Stroke(1.6f * u))
    drawCircle(f.hi.al(0.28f), r - w / 2f, center, style = Stroke(1.2f * u))
    val sweep = 360f * f.p
    arcRing(f.ring.al(0.92f), 0f, sweep, r, w * 0.58f)
    arcRing(f.acc.al(0.75f), 0f, sweep, r - w * 0.12f, w * 0.14f)
    // لمعة زجاجية تتحرك ببطء
    val a0 = -140f + 45f * cWave(f.t, 1f)
    arcRing(Color.White.al(0.55f), a0, 48f, r + w * 0.22f, 2.4f * u)
    arcRing(Color.White.al(0.25f), a0 + 160f, 22f, r - w * 0.22f, 1.8f * u)
    if (f.st.variant == 2) { // فقاعات داخل الجمشت
        for (i in 0 until 6) {
            val y = 1f - cFrac(cRnd(i) + f.t * (1 + i % 3))
            val x = (cRnd(i, 3) - 0.5f) * rad * 0.9f
            val pos = Offset(center.x + x, center.y + (y - 0.5f) * rad * 1.2f)
            drawCircle(f.hi.al(0.35f), (2f + 2.5f * cRnd(i, 5)) * u, pos, style = Stroke(1.1f * u))
        }
    }
    if (f.p > 0.01f) glowDisc(cPt(sweep, r), 16f * u, f.acc, 0.6f * f.glow)
}

// ------------------------------------------------------------------ 3) هلال ونجوم
internal fun crescentPath(c: Offset, r: Float): Path = Path.combine(
    PathOperation.Difference,
    Path().apply { addOval(Rect(c, r)) },
    Path().apply { addOval(Rect(c + Offset(r * 0.52f, -r * 0.14f), r * 0.82f)) },
)

internal fun DrawScope.engCrescent(f: CFrame) {
    val u = uu; val r = rad * 0.86f
    faceDisc(f, rad * 0.74f)
    trackRing(f, r, 4f * u, 0.22f)
    glowArc(f, f.ring, 360f * f.p, r, 4.5f * u)
    val nStars = if (f.st.variant == 1) 7 else 4
    for (i in 0 until nStars) {
        val ang = i * 360f / nStars + 360f * f.t
        val tw = 0.5f + 0.5f * cWave(f.t, 6f, i * 0.17f)
        val pos = cPt(ang, r + (if (i % 2 == 0) 11f else -11f) * u)
        star4(pos, (4f + 3f * tw) * u, f.acc.al(0.55f + 0.45f * tw))
    }
    // الهلال: يدور عكس النجوم، أو ثابت أعلى الحلقة وكبير في التصميم الثالث
    val cc: Offset; val cr: Float; val tilt: Float
    if (f.st.variant == 2) { cc = cPt(0f, r); cr = 16f * u; tilt = 0f }
    else { val ang = -360f * f.t; cc = cPt(ang, r); cr = 12f * u; tilt = ang }
    glowDisc(cc, cr * 3.2f, f.hi, 0.35f * f.glow)
    rotate(tilt, cc) { drawPath(crescentPath(cc, cr), f.hi) }
    if (f.st.variant == 2) { // نجمة صغيرة داخل فتحة الهلال
        star4(cPt(0f, r + 14f * u), 5f * u, f.acc.al(0.9f))
    }
}

// ------------------------------------------------------------------ 4) جزيئات مدارية
internal fun DrawScope.engOrbit(f: CFrame) {
    val u = uu; val r = rad * 0.84f
    faceDisc(f, rad * 0.72f)
    trackRing(f, r, 3f * u, 0.16f)
    arcRing(f.ring.al(0.85f), 0f, 360f * f.p, r, 5f * u)
    val n = 24
    for (i in 0 until n) {
        val dir = if (i % 2 == 0) 1f else -1f
        val ang = i * 360f / n + dir * 360f * f.t
        val rr = r + ((i % 3) - 1) * 10f * u + 3f * u * cWave(f.t, 2f, i * 0.1f) + 12f * u * f.tap
        val pos = cPt(ang, rr)
        val sz = (1.6f + (i % 4) * 0.7f) * u * (1f + 0.5f * f.tap)
        when (f.st.variant) {
            0 -> { // شرارات
                drawCircle(f.ring.al(0.9f), sz, pos)
                if (i % 4 == 0) star4(pos, sz * 2.6f, f.hi.al(0.85f))
            }
            1 -> { // لآلئ
                drawCircle(Brush.radialGradient(listOf(Color.White, f.ring, f.acc.al(0.6f)), center = pos - Offset(sz * 0.3f, sz * 0.3f), radius = sz * 1.6f), sz * 1.5f, pos)
            }
            else -> { // شهب لها ذيل
                val tail = cPt(ang - dir * 14f, rr)
                drawLine(Brush.linearGradient(listOf(Color.Transparent, f.ring.al(0.7f)), start = tail, end = pos), tail, pos, strokeWidth = sz * 1.1f)
                drawCircle(f.hi, sz, pos)
            }
        }
    }
    glowDisc(cPt(360f * f.p, r), 18f * u, f.hi, 0.7f * f.glow)
}

// ------------------------------------------------------------------ 5) حلقة تتغير ألوانها حسب الإنجاز
private fun hueAt(f: CFrame, x: Float): Color {
    val c1 = Color(f.st.c1); val c2 = Color(f.st.c2); val c3 = Color(f.st.c3)
    val v = x.coerceIn(0f, 1f)
    return if (v < 0.5f) lerp(c1, c2, v * 2f) else lerp(c2, c3, (v - 0.5f) * 2f)
}

internal fun DrawScope.engHueRing(f: CFrame) {
    val u = uu; val r = rad * 0.85f
    faceDisc(f, rad * 0.72f)
    val now = hueAt(f, f.p)
    glowDisc(center, rad, now, (0.10f + 0.25f * f.tap) * f.glow)
    val n = 60
    if (f.st.variant == 2) { // نبضات (ticks)
        for (i in 0 until n) {
            val lit = (i + 1f) / n <= f.p + 0.001f
            val col = hueAt(f, i / (n - 1f))
            val a = cPt(i * 360f / n, r - 9f * u)
            val b = cPt(i * 360f / n, r + 9f * u)
            drawLine(if (lit) col else col.al(0.18f), a, b, strokeWidth = if (lit) 4f * u else 2.4f * u)
        }
    } else {
        val seg = 360f / n
        for (i in 0 until n) {
            val start = i * seg
            val col = hueAt(f, i / (n - 1f))
            arcRing(col.al(0.16f), start, seg + 0.6f, r, 11f * u, round = false)
            val endFrac = (i + 1f) / n
            if (endFrac <= f.p + 0.0001f) {
                arcRing(col, start, seg + 0.6f, r, 11f * u, round = false)
            } else if (i.toFloat() / n < f.p) {
                arcRing(col, start, (f.p - i.toFloat() / n) * 360f, r, 11f * u, round = false)
            }
        }
    }
    drawCircle(now.al(0.55f), rad * 0.71f, center, style = Stroke(2f * u))
    if (f.p > 0.01f) {
        val head = cPt(360f * f.p, r)
        glowDisc(head, 20f * u, now, 0.8f * f.glow)
        drawCircle(Color.White.al(0.9f), 3.6f * u, head)
    }
}

// ------------------------------------------------------------------ 6) ماء وتموجات (مستوى الماء = التقدّم)
internal fun DrawScope.engWater(f: CFrame) {
    val u = uu; val fr = rad * 0.80f
    val clip = circlePath(center, fr)
    clipPath(clip) {
        drawCircle(f.face.al(f.bgA), fr, center)
        val level = 0.10f + 0.80f * f.p
        val topY = center.y + fr - 2f * fr * level
        val amp = (if (f.st.variant == 1) 8f else 5.5f) * u * (1f + 0.9f * f.tap)
        val bottom = center.y + fr
        drawPath(waveFill(topY, amp, 1.4f, f.t * 2f, bottom, center.x - fr, center.x + fr), f.ring.al(0.40f))
        drawPath(
            waveFill(topY + 3f * u, amp * 0.9f, 1.1f, -f.t * 3f + 0.3f, bottom, center.x - fr, center.x + fr),
            Brush.verticalGradient(listOf(f.hi.al(0.55f), f.ring.al(0.85f)), startY = topY, endY = bottom),
        )
        for (i in 0 until 7) { // فقاعات صاعدة داخل الماء
            val rise = 1f - cFrac(cRnd(i) + f.t * (1 + i % 3))
            val by = topY + (bottom - topY) * rise
            if (by > topY + 4f * u) drawCircle(f.acc.al(0.45f), (1.6f + 2.2f * cRnd(i, 2)) * u, Offset(center.x + (cRnd(i, 4) - 0.5f) * fr * 1.5f, by), style = Stroke(1.1f * u))
        }
        if (f.st.variant == 1) { // لمعات على سطح البحيرة
            for (i in 0 until 5) {
                val x = center.x - fr + (cFrac(cRnd(i, 6) + f.t) * 2f * fr)
                drawLine(f.acc.al(0.5f), Offset(x, topY - 1f * u), Offset(x + 12f * u, topY - 1f * u), strokeWidth = 1.6f * u)
            }
        }
        if (f.st.variant == 2) { // دوائر موجية مستمرة من المركز (ينبوع)
            for (i in 0 until 3) {
                val q = cFrac(f.t * 2f + i / 3f)
                drawCircle(f.acc.al(0.35f * (1f - q)), fr * q, center, style = Stroke(1.6f * u))
            }
        }
        if (f.tap > 0.01f) drawCircle(f.acc.al(0.6f * f.tap), fr * (1.05f - 0.8f * f.tap), center, style = Stroke(2.4f * u)) // تموّج الضغط
    }
    drawCircle(f.ring, fr + 3f * u, center, style = Stroke(4f * u))
    arcRing(f.hi.al(0.9f), 0f, 360f * f.p, rad * 0.90f, 3.5f * u)
    trackRing(f, rad * 0.90f, 3.5f * u, 0.14f)
}

// ------------------------------------------------------------------ 7) مجرة ونجوم
internal fun DrawScope.engGalaxy(f: CFrame) {
    val u = uu; val fr = rad * 0.80f
    clipPath(circlePath(center, fr)) {
        drawCircle(f.face.al(f.bgA), fr, center)
        val blobs = listOf(f.hi, f.acc, f.ring)
        for (i in 0 until 3) {
            val c = cPt(360f * f.t + i * 120f, fr * 0.40f)
            glowDisc(c, fr * 0.85f, blobs[i], 0.34f * f.glow)
        }
        rotate(360f * f.t, center) { // ذراعان حلزونيان
            for (arm in 0 until 2) for (i in 0 until 26) {
                val q = i / 26f
                val ang = arm * 180f + q * 300f
                val pos = cPt(ang, fr * (0.10f + 0.85f * q))
                drawCircle(f.ring.al(0.55f * (1f - q * 0.6f)), (1.0f + 1.8f * (1f - q)) * u, pos)
            }
        }
        for (i in 0 until 26) { // نجوم تتلألأ
            val tw = 0.5f + 0.5f * cWave(f.t, 8f, cRnd(i, 9))
            val pos = Offset(center.x + (cRnd(i, 1) - 0.5f) * fr * 2f, center.y + (cRnd(i, 2) - 0.5f) * fr * 2f)
            drawCircle(Color.White.al(0.2f + 0.6f * tw), (0.6f + cRnd(i, 3) * 1.1f) * u, pos)
        }
    }
    val r = rad * 0.89f
    trackRing(f, r, 4f * u, 0.22f)
    glowArc(f, f.ring, 360f * f.p, r, 5f * u)
    if (f.p > 0.02f) { // ذيل لامع خلف رأس القوس
        for (k in 1..5) drawCircle(f.acc.al(0.6f - k * 0.1f), (3.2f - k * 0.4f) * u, cPt(360f * f.p - k * 5f, r))
        glowDisc(cPt(360f * f.p, r), 18f * u, f.acc, 0.8f * f.glow)
    }
}

// ------------------------------------------------------------------ 8) زخارف هندسية إسلامية متحركة
internal fun DrawScope.engGeo(f: CFrame) {
    val u = uu; val r = rad * 0.85f
    faceDisc(f, rad * 0.72f)
    val s12 = starPath(center, rad * 0.70f, rad * 0.56f, 12, 0f)
    val s8 = starPath(center, rad * 0.60f, rad * 0.43f, 8, 0f)
    rotate(360f * f.t, center) { drawPath(s12, f.acc.al(0.55f), style = Stroke(1.6f * u)) }
    rotate(-360f * f.t, center) { drawPath(s8, f.ring.al(0.55f), style = Stroke(1.6f * u)) }
    if (f.st.variant == 1) drawCircle(f.hi.al(0.35f), rad * 0.76f, center, style = Stroke(1.2f * u))
    // حلقة المعينات: كل معين يضيء عند بلوغ نسبته
    val n = 48
    for (i in 0 until n) {
        val lit = (i + 1f) / n <= f.p + 0.001f
        val pos = cPt(i * 360f / n, r)
        val s = if (lit) 6.2f * u else 4.2f * u
        val d = Path().apply {
            moveTo(pos.x, pos.y - s); lineTo(pos.x + s * 0.62f, pos.y); lineTo(pos.x, pos.y + s); lineTo(pos.x - s * 0.62f, pos.y); close()
        }
        rotate(i * 360f / n, pos) {
            if (lit) { glowDisc(pos, 10f * u, f.ring, 0.3f * f.glow); drawPath(d, f.ring) }
            else drawPath(d, f.ring.al(0.28f), style = Stroke(1.2f * u))
        }
    }
    glowDisc(center, rad * 0.5f, f.hi, 0.12f * f.tap * f.glow + 0.04f)
}

// ------------------------------------------------------------------ 9) نبض ضوئي مع كل ضغطة
internal fun DrawScope.engPulse(f: CFrame) {
    val u = uu; val r = rad * 0.78f
    val beat = 0.5f + 0.5f * cWave(f.t, 4f)
    faceDisc(f, rad * 0.70f)
    glowDisc(center, rad * 0.75f, f.ring, (0.10f + 0.12f * beat + 0.30f * f.tap) * f.glow)
    trackRing(f, r, 8f * u, 0.18f)
    glowArc(f, f.ring, 360f * f.p, r, 8f * u)
    if (f.st.variant == 1) drawCircle(f.hi.al(0.9f), r + 12f * u, center, style = Stroke(1.2f * u)) // نيون: حلقة خارجية رفيعة
    if (f.st.variant == 2) { // قرمزي: خط نبض قلب خلف الرقم
        val y = center.y + rad * 0.40f
        val p = Path().apply {
            moveTo(center.x - rad * 0.5f, y)
            lineTo(center.x - rad * 0.18f, y); lineTo(center.x - rad * 0.10f, y - 14f * u); lineTo(center.x, y + 16f * u)
            lineTo(center.x + rad * 0.10f, y - 8f * u); lineTo(center.x + rad * 0.18f, y); lineTo(center.x + rad * 0.5f, y)
        }
        drawPath(p, f.hi.al(0.6f), style = Stroke(2.2f * u))
    }
    // موجات الضغط المتتابعة
    if (f.tap > 0.01f) {
        for (j in 0 until 2) {
            val grow = (1f - f.tap) * (1f + j * 0.6f)
            drawCircle(f.hi.al(f.tap * (0.75f - 0.3f * j)), r + rad * 0.22f * grow, center, style = Stroke((3.2f - j) * u))
        }
    }
    if (f.p > 0.01f) glowDisc(cPt(360f * f.p, r), 16f * u, f.hi, 0.8f * f.glow)
}

// ------------------------------------------------------------------ 10) ثلاثي الأبعاد (زر معدني بارز يغوص عند الضغط)
internal fun DrawScope.engDepth(f: CFrame) {
    val u = uu
    val press = 1f - 0.04f * f.tap
    // ظل ناعم أسفل الزر
    for (k in 1..6) drawCircle(Color.Black.al(0.09f), rad * 0.88f + k * 1.8f * u, center + Offset(0f, (9f - 5f * f.tap) * u))
    // الإطار المعدني
    val bz = rad * 0.86f
    drawCircle(
        Brush.sweepGradient(listOf(f.hi, f.ring, f.acc, f.ring, f.hi, f.ring, f.acc, f.hi), center),
        bz, center, style = Stroke(rad * 0.13f),
    )
    drawCircle(Color.Black.al(0.35f), bz - rad * 0.065f, center, style = Stroke(1.6f * u))
    drawCircle(Color.White.al(0.35f), bz + rad * 0.065f, center, style = Stroke(1.4f * u))
    // مصابيح التقدّم على الإطار
    val n = 40
    for (i in 0 until n) {
        val pos = cPt(i * 360f / n, bz)
        if ((i + 1f) / n <= f.p + 0.001f) {
            glowDisc(pos, 8f * u, f.hi, 0.6f * f.glow)
            drawCircle(Color.White.al(0.95f), 2.2f * u, pos)
        } else drawCircle(Color.Black.al(0.38f), 2f * u, pos)
    }
    // القبة البارزة بإضاءة من أعلى اليسار
    val rd = rad * 0.70f * press
    val fc = f.face
    val hiPt = center + Offset(-rd * 0.30f, -rd * 0.36f)
    drawCircle(
        Brush.radialGradient(listOf(lerp(fc, Color.White, 0.38f), fc, lerp(fc, Color.Black, 0.55f)), center = hiPt, radius = rd * 1.6f),
        rd, center,
    )
    arcRing(Color.White.al(0.40f), -150f, 100f, rd - 1.6f * u, 2.4f * u)
    arcRing(Color.Black.al(0.45f), 30f, 100f, rd - 1.6f * u, 2.4f * u)
}
