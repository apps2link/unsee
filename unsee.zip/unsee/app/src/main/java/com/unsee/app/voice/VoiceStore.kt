package com.unsee.app.voice

import android.content.Context
import android.content.SharedPreferences
import com.unsee.app.core.SectionVoice
import com.unsee.app.core.VoiceCodec
import com.unsee.app.core.VoiceSection
import com.unsee.app.core.VoiceSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** حفظ إعدادات الصوت محليًا (SharedPreferences). الحالة تُبثّ كـ StateFlow لتتحدّث الواجهة فورًا. */
class VoiceStore private constructor(ctx: Context) {
    private val sp: SharedPreferences = ctx.applicationContext.getSharedPreferences("unsee_voice", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(read())
    val state: StateFlow<VoiceSettings> = _state.asStateFlow()

    fun current(): VoiceSettings = _state.value

    private fun read(): VoiceSettings {
        val d = VoiceSettings()
        return VoiceSettings(
            master = sp.getBoolean("master", d.master),
            voice = sp.getString("voice", "") ?: "",
            rate = sp.getFloat("rate", d.rate),
            pitch = sp.getFloat("pitch", d.pitch),
            volume = sp.getFloat("volume", d.volume),
            speakNotifications = sp.getBoolean("notif", d.speakNotifications),
            speakTitle = sp.getBoolean("title", d.speakTitle),
            pronunciation = sp.getBoolean("pron", d.pronunciation),
            respectSilent = sp.getBoolean("silent", d.respectSilent),
            respectDnd = sp.getBoolean("dnd", d.respectDnd),
            quietEnabled = sp.getBoolean("quiet", d.quietEnabled),
            quietStartMin = sp.getInt("q_start", d.quietStartMin),
            quietEndMin = sp.getInt("q_end", d.quietEndMin),
            sections = VoiceCodec.decodeSections(sp.getString("sections", null)),
        ).clamped()
    }

    /** يحدّث الإعدادات ويحفظها فورًا (apply غير متزامن لكنه يُرى فورًا داخل العملية). */
    fun update(block: (VoiceSettings) -> VoiceSettings) {
        val n = block(_state.value).clamped()
        sp.edit()
            .putBoolean("master", n.master).putString("voice", n.voice)
            .putFloat("rate", n.rate).putFloat("pitch", n.pitch).putFloat("volume", n.volume)
            .putBoolean("notif", n.speakNotifications).putBoolean("title", n.speakTitle)
            .putBoolean("pron", n.pronunciation).putBoolean("silent", n.respectSilent).putBoolean("dnd", n.respectDnd)
            .putBoolean("quiet", n.quietEnabled).putInt("q_start", n.quietStartMin).putInt("q_end", n.quietEndMin)
            .putString("sections", VoiceCodec.encodeSections(n.sections))
            .apply()
        _state.value = n
    }

    fun updateSection(s: VoiceSection, block: (SectionVoice) -> SectionVoice) =
        update { cur -> cur.copy(sections = cur.sections + (s to block(cur.section(s)))) }

    companion object {
        @Volatile private var inst: VoiceStore? = null
        fun get(ctx: Context): VoiceStore = inst ?: synchronized(this) { inst ?: VoiceStore(ctx).also { inst = it } }
    }
}
