package com.unsee.app.ui

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp

/*
 * محرّكات «الزجاج الفاخر» الثلاثة (على طراز قرص التحكم الزجاجي): قرص مدرّج، قوس عدّاد، كرة زجاجية.
 * كلها نسبية لنصف القطر (rad/uu) كبقية المحركات، فتظهر بنفس الشكل في التطبيق والمعرض والودجت.
 */

/** قرص زجاجي بقوس خارجي (270°) وزرّ منزلق، وقرص داخلي مدرّج بالعلامات تضيء مع التقدّم. */
internal fun DrawScope.engDial(f: CFrame) {
    val u = uu; val r = rad
    val pulse = 0.5f + 0.5f * cWave(f.t, 2f)
    glowDisc(center, r, f.ring, (0.10f + 0.06f * pulse + 0.30f * f.tap) * f.glow)

    val ro = r * 0.88f; val w = 7f * u
    val start = -135f; val span = 270f
    arcRing(f.ring.al(0.20f), start, span, ro, w)
    if (f.p > 0.004f) {
        arcRing(f.ring.al(0.14f * f.glow), start, span * f.p, ro, w * 2.3f)
        arcRing(f.ring, start, span * f.p, ro, w)
    }
    val knob = cPt(start + span * f.p, ro)
    glowDisc(knob, 24f * u, f.ring, 0.55f * f.glow)
    drawCircle(Color.White, (10f + 2f * f.tap) * u, knob)
    drawCircle(f.ring.al(0.60f), (10f + 2f * f.tap) * u, knob, style = Stroke(2.2f * u))

    // القرص الزجاجي: وجه + لمعة علوية + حدّ مضيء
    val rd = r * 0.76f
    drawCircle(f.face.al(f.bgA), rd, center)
    drawCircle(
        Brush.radialGradient(listOf(Color.White.al(if (f.light) 0.80f else 0.10f), Color.Transparent), center = Offset(center.x, center.y - r * 0.22f), radius = rd),
        rd, center,
    )
    drawCircle(f.ring.al(0.18f), rd, center, style = Stroke(1.2f * u))
    val inner = if (f.light) Color.White.al(0.78f * f.bgA) else lerp(f.face, Color.White, 0.09f).al(f.bgA)
    drawCircle(inner, r * 0.60f, center)

    // علامات التدرّج حول القرص الداخلي (الكثافة تختلف بين التصاميم)
    val n = when (f.st.variant) { 1 -> 90; 2 -> 48; else -> 60 }
    val major = n / 12
    for (i in 0 until n) {
        val ang = i * 360f / n
        val lit = (i + 1f) / n <= f.p + 0.001f
        val isMajor = i % major == 0
        val a = cPt(ang, r * 0.655f)
        val b = cPt(ang, r * (if (isMajor) 0.725f else 0.700f))
        val col = if (lit) f.ring else f.ring.al(if (f.light) 0.30f else 0.34f)
        if (f.st.variant == 2) {
            drawCircle(col, (if (isMajor) 2.6f else 1.9f) * u, cPt(ang, r * 0.69f))
        } else {
            drawLine(col, a, b, strokeWidth = (if (isMajor) 2.4f else 1.4f) * u, cap = StrokeCap.Round)
        }
    }
}

/** قوس عدّاد عريض (240°) كمؤشر ضبط: شريط ناعم متراكب، نقاط قياس خارجية، وزرّ بحلقتين. */
internal fun DrawScope.engArcGauge(f: CFrame) {
    val u = uu; val r = rad
    val pulse = 0.5f + 0.5f * cWave(f.t, 2f)
    glowDisc(center, r, f.ring, (0.09f + 0.06f * pulse + 0.26f * f.tap) * f.glow)

    val rd = r * 0.93f
    drawCircle(f.face.al(f.bgA), rd, center)
    drawCircle(
        Brush.verticalGradient(listOf(Color.White.al(if (f.light) 0.70f else 0.10f), Color.Transparent), startY = center.y - rd, endY = center.y + rd * 0.2f),
        rd, center,
    )
    drawCircle(f.ring.al(0.16f), rd, center, style = Stroke(1.2f * u))

    val ro = r * 0.74f; val w = 20f * u
    val start = -120f; val span = 240f
    arcRing(f.ring.al(0.15f), start, span, ro, w)
    if (f.p > 0.004f) {
        arcRing(f.hi.al(0.55f), start, span * f.p, ro, w)
        arcRing(f.ring, start, span * f.p, ro, w * 0.58f)
    }
    for (i in 0..10) {
        val frac = i / 10f
        val pos = cPt(start + span * frac, ro + w * 1.15f)
        val lit = frac <= f.p + 0.001f
        drawCircle(if (lit) f.ring else f.ring.al(0.28f), (if (i % 5 == 0) 2.8f else 1.8f) * u, pos)
    }
    val knob = cPt(start + span * f.p, ro)
    glowDisc(knob, 30f * u, f.ring, 0.6f * f.glow)
    drawCircle(Color.White, w * 0.66f, knob)
    drawCircle(f.ring, w * 0.40f * (1f + 0.2f * f.tap), knob)
}

/** كرة زجاجية متدرجة بلمعة وحلقتين من الزجاج حولها، وقوس تقدّم رفيع، وتتنفس ببطء. */
internal fun DrawScope.engOrb(f: CFrame) {
    val u = uu; val r = rad
    val pulse = 0.5f + 0.5f * cWave(f.t, 2f)
    val breathe = 1f + 0.015f * cWave(f.t, 1f) + 0.04f * f.tap
    glowDisc(center, r, f.ring, (0.16f + 0.08f * pulse + 0.30f * f.tap) * f.glow)

    val rh = r * 0.92f
    drawCircle(Color.White.al(if (f.light) 0.18f else 0.07f), rh, center)
    drawCircle(Color.White.al(0.30f), rh, center, style = Stroke(1.5f * u))
    drawCircle(Color.White.al(0.16f), r * 0.82f, center, style = Stroke(1.2f * u))
    arcRing(Color.White.al(0.18f), 0f, 360f, rh, 4f * u)
    if (f.p > 0.004f) {
        arcRing(f.hi, 0f, 360f * f.p, rh, 4f * u)
        val head = cPt(360f * f.p, rh)
        glowDisc(head, 16f * u, f.hi, 0.8f * f.glow)
        drawCircle(Color.White, 4.2f * u, head)
    }

    val rs = r * 0.64f * breathe
    val c0 = Offset(center.x - rs * 0.30f, center.y - rs * 0.35f)
    drawCircle(
        Brush.radialGradient(listOf(lerp(f.ring, Color.White, 0.22f), f.ring, f.acc), center = c0, radius = rs * 1.6f),
        rs, center,
    )
    drawCircle(Color.White.al(0.35f), rs, center, style = Stroke(1.6f * u))
    val sp = Offset(center.x - rs * 0.36f, center.y - rs * 0.46f)
    drawCircle(Brush.radialGradient(listOf(Color.White.al(0.55f), Color.Transparent), center = sp, radius = rs * 0.46f), rs * 0.46f, sp)
}
