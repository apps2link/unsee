package com.unsee.app.notify

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.unsee.app.MainActivity
import com.unsee.app.R
import com.unsee.app.core.TimeLogic
import com.unsee.app.data.Category
import com.unsee.app.data.Store
import java.time.ZonedDateTime
import java.util.concurrent.TimeUnit

/**
 * تذكيرات هادئة عبر WorkManager (بلا إذن «منبّه دقيق»). قد يتأخر التنفيذ دقائق بسبب توفير البطارية؛
 * وهذا مقصود لتجنّب استنزاف البطارية. القناة بلا صوت ولا اهتزاز ويمكن للمستخدم تعديلها من إعدادات النظام.
 */
object Reminders {
    const val CHANNEL_ID = "adhkar_reminders"
    const val MORNING = "morning"
    const val EVENING = "evening"

    fun createChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val ch = NotificationChannel(CHANNEL_ID, "تذكيرات الأذكار", NotificationManager.IMPORTANCE_LOW).apply {
            description = "تذكير هادئ بأذكار الصباح والمساء"
            setSound(null, null)
            enableVibration(false)
            setShowBadge(false)
        }
        ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun workName(kind: String, slot: Int) = "unsee_reminder_${kind}_$slot"

    fun schedule(ctx: Context, kind: String, minuteOfDay: Int, slot: Int = 0) {
        val delay = TimeLogic.delayUntilNext(ZonedDateTime.now(), minuteOfDay)
        val req = OneTimeWorkRequestBuilder<ReminderWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setInputData(workDataOf("kind" to kind, "slot" to slot))
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork(workName(kind, slot), ExistingWorkPolicy.REPLACE, req)
    }

    fun cancel(ctx: Context, kind: String) {
        val wm = WorkManager.getInstance(ctx)
        wm.cancelUniqueWork(workName(kind, 0))
        wm.cancelUniqueWork(workName(kind, 1))
    }

    /** يُستدعى عند فتح التطبيق وعند تغيير الإعدادات. */
    fun rescheduleAll(ctx: Context) {
        val s = Store.get(ctx).settings()
        cancel(ctx, MORNING); cancel(ctx, EVENING)
        if (s.morningReminder) schedule(ctx, MORNING, s.morningMinute)
        if (s.eveningReminder) schedule(ctx, EVENING, s.eveningMinute)
    }

    fun canNotify(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return false
        return NotificationManagerCompat.from(ctx).areNotificationsEnabled()
    }

    fun show(ctx: Context, kind: String) {
        if (!canNotify(ctx)) return
        val cat = if (kind == MORNING) Category.MORNING else Category.EVENING
        val open = Intent(ctx, MainActivity::class.java)
            .putExtra("route", "list/${cat.name}")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(ctx, kind.hashCode(), open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val text = if (kind == MORNING) "حان وقت أذكار الصباح — دقائق تهدّئ القلب" else "حان وقت أذكار المساء — ختامٌ هادئ ليومك"
        val n = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(cat.title)
            .setContentText(text)
            .setSubText("أُنسي — أذكارك أقرب، وقلبك أهدأ")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .build()
        runCatching { NotificationManagerCompat.from(ctx).notify(kind.hashCode(), n) }
    }
}

class ReminderWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val kind = inputData.getString("kind") ?: return Result.success()
        val slot = inputData.getInt("slot", 0)
        val s = Store.get(applicationContext).settings()
        val (enabled, minute) = if (kind == Reminders.MORNING) s.morningReminder to s.morningMinute else s.eveningReminder to s.eveningMinute
        if (!enabled) return Result.success()
        Reminders.show(applicationContext, kind)
        // نجدول اليوم التالي تحت اسم بديل (0/1) كي لا نُلغي هذا العمل أثناء تنفيذه.
        Reminders.schedule(applicationContext, kind, minute, 1 - slot)
        return Result.success()
    }
}
