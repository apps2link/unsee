package com.unsee.app.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import com.unsee.app.core.PaletteSpec
import com.unsee.app.core.ThemeId
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * محرّك الخلفيات المتحركة للثيمات (29 ثيمًا؛ «الطبيعة الحية» لها NatureBackdrop الأصلي في Backdrop.kt دون أي تغيير).
 *
 * المبادئ:
 * - مؤقّت واحد لكل خلفية (60 ثانية) والرسم كله في مرحلة الرسم دون إعادة تركيب. كل الحركات مضاعفات صحيحة للمؤقّت فلا تظهر قفزة عند التكرار.
 * - كل ثيم له دالة رسم مستقلة بشخصية مختلفة (مطر، ثلج، يراعات، شفق، رخام، فوانيس…) وليس مجرد تغيير ألوان.
 * - [level] (0.5 للحركة الخفيفة، 1 للكاملة) يقلل عدد العناصر على الأجهزة الضعيفة، و[reduceMotion] يجمّد المشهد على لقطة واحدة.
 * - الألوان من [PaletteSpec] المُمرَّر وليس من UColors، فيمكن عرض معاينة ثيم آخر قبل اختياره.
 */
private const val TAU = (2.0 * PI).toFloat()

private class Seed(val x: Float, val y: Float, val s: Float, val p: Float, val k: Int)

private val rng = Random(2024)
private fun seeds(n: Int, kMax: Int = 3) = List(n) { Seed(rng.nextFloat(), rng.nextFloat(), 0.4f + rng.nextFloat() * 1.2f, rng.nextFloat(), 1 + rng.nextInt(kMax)) }
private val S80 = seeds(80)
private val S40 = seeds(40)
private val S24 = seeds(24)
private val S14 = seeds(14)
private val S8 = seeds(8)

private fun c(v: Long): Color = Color(v)
private fun Color.a(x: Float): Color = this.copy(alpha = x.coerceIn(0f, 1f))
private fun wave(t: Float, k: Float, ph: Float = 0f): Float = sin(TAU * (t * k + ph))
private fun frac(v: Float): Float = v - kotlin.math.floor(v)
private fun count(n: Int, d: Float): Int = (n * d).toInt().coerceAtLeast(1)

@Composable
fun ThemeBackdrop(id: ThemeId, spec: PaletteSpec, reduceMotion: Boolean, level: Float, modifier: Modifier = Modifier) {
    val t: State<Float> = if (reduceMotion) {
        remember { mutableStateOf(0.31f) }
    } else {
        rememberInfiniteTransition(label = "theme_backdrop").animateFloat(
            initialValue = 0f, targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(60_000, easing = LinearEasing)),
            label = "tt",
        )
    }
    Box(
        modifier.fillMaxSize().drawBehind {
            drawRect(Brush.verticalGradient(listOf(c(spec.bgTop), c(spec.bgBottom))))
            drawTheme(id, spec, t.value, level)
            // طبقة قراءة خفيفة جدًا فوق التأثيرات لتبقى النصوص المباشرة على الخلفية واضحة
            drawRect(c(spec.bgTop).a(0.10f))
        },
    )
}

private fun DrawScope.drawTheme(id: ThemeId, sp: PaletteSpec, t: Float, d: Float) {
    when (id) {
        ThemeId.NATURE -> Unit // يُرسم بـ NatureBackdrop الأصلي
        ThemeId.SILK -> Unit   // يُرسم بـ SilkBackdrop (ui/SilkBackdrop.kt)
        ThemeId.PARADISE -> paradise(sp, t, d)
        ThemeId.FAITH_NIGHT -> faithNight(sp, t, d)
        ThemeId.ROYAL_GOLD -> royalGold(sp, t, d)
        ThemeId.ISLAMIC_EMERALD -> emeraldRise(sp, t, d)
        ThemeId.PACIFIC -> pacific(sp, t, d)
        ThemeId.VIOLET_SKY -> violetSky(sp, t, d)
        ThemeId.GALAXY -> galaxy(sp, t, d)
        ThemeId.DAWN -> dawn(sp, t, d)
        ThemeId.SUNSET -> sunset(sp, t, d)
        ThemeId.QUIET_RAIN -> quietRain(sp, t, d)
        ThemeId.WATERFALL -> waterfall(sp, t, d)
        ThemeId.GOLD_DESERT -> desert(sp, t, d)
        ThemeId.MOON_CLOUDS -> moonClouds(sp, t, d)
        ThemeId.CRYSTAL -> crystal(sp, t, d)
        ThemeId.PEARL -> pearl(sp, t, d)
        ThemeId.CALLIGRAPHY -> calligraphy(sp, t, d)
        ThemeId.GEOMETRIC -> geometric(sp, t, d)
        ThemeId.ROYAL_TURQUOISE -> turquoise(sp, t, d)
        ThemeId.NAVY_NIGHT -> navyNight(sp, t, d)
        ThemeId.LIT_GARDEN -> fireflies(sp, t, d)
        ThemeId.QUIET_SNOW -> snow(sp, t, d)
        ThemeId.DEEP_SPACE -> deepSpace(sp, t, d)
        ThemeId.LANTERNS -> lanterns(sp, t, d)
        ThemeId.SPIRITUAL_DAWN -> spiritualDawn(sp, t, d)
        ThemeId.AURORA -> aurora(sp, t, d)
        ThemeId.ROYAL_MARBLE -> marble(sp, t, d)
        ThemeId.RAINY_SKY -> rainySky(sp, t, d)
        ThemeId.SOFT_ROSE -> petals(sp, t, d)
        ThemeId.UNSEE_SPECIAL -> unseeSpecial(sp, t, d)
    }
}

// ------------------------------------------------------------------ أدوات رسم مشتركة
private fun DrawScope.glow(center: Offset, r: Float, col: Color, a: Float) {
    drawCircle(Brush.radialGradient(listOf(col.a(a), Color.Transparent), center = center, radius = r), radius = r, center = center)
}

private fun DrawScope.starfield(col: Color, seeds: List<Seed>, t: Float, d: Float, yMax: Float, speed: Float = 12f, maxA: Float = 1f) {
    val n = count(seeds.size, d)
    for (i in 0 until n) {
        val s = seeds[i]
        val tw = 0.5f + 0.5f * wave(t, speed * s.k, s.p)
        drawCircle(col.a(maxA * (0.2f + 0.8f * tw)), s.s * 1.4f * density, Offset(s.x * size.width, s.y * size.height * yMax))
    }
}

private fun DrawScope.crescent(center: Offset, r: Float, col: Color, bite: Color) {
    drawCircle(col, r, center)
    drawCircle(bite, r * 0.82f, center + Offset(r * 0.42f, -r * 0.14f))
}

private fun DrawScope.star8(center: Offset, r: Float, col: Color, stroke: Float, rot: Float = 0f) {
    val p = Path()
    for (k in 0 until 16) {
        val rad = if (k % 2 == 0) r else r * 0.62f
        val ang = (k * 22.5f - 90f + rot) * (PI.toFloat() / 180f)
        val x = center.x + rad * cos(ang)
        val y = center.y + rad * sin(ang)
        if (k == 0) p.moveTo(x, y) else p.lineTo(x, y)
    }
    p.close()
    drawPath(p, col, style = Stroke(stroke))
}

private fun DrawScope.cloud(x: Float, y: Float, w: Float, h: Float, col: Color) {
    drawOval(col, Offset(x, y), Size(w, h))
    drawOval(col, Offset(x + w * 0.2f, y - h * 0.45f), Size(w * 0.5f, h * 0.9f))
    drawOval(col, Offset(x + w * 0.5f, y - h * 0.3f), Size(w * 0.4f, h * 0.8f))
}

private fun DrawScope.waveBand(t: Float, y: Float, amp: Float, k: Float, ph: Float, col: Color, bottom: Float = size.height) {
    val p = Path()
    p.moveTo(0f, bottom)
    var x = 0f
    val step = size.width / 24f
    while (x <= size.width + step) {
        p.lineTo(x, y + amp * sin(TAU * (x / size.width * k + t * 2f + ph)))
        x += step
    }
    p.lineTo(size.width, bottom)
    p.close()
    drawPath(p, col)
}

// ------------------------------------------------------------------ 2 الجنة الخضراء: أشعة شمس دوّارة + أوراق متساقطة
private fun DrawScope.paradise(sp: PaletteSpec, t: Float, d: Float) {
    val w = size.width; val h = size.height
    val sun = Offset(w * 0.85f, h * 0.06f)
    glow(sun, w * 0.7f, c(sp.accentSoft), 0.35f)
    rotate(degrees = 360f * t * 2f, pivot = sun) {
        for (i in 0 until 9) {
            val ang = i * 40f
            rotate(ang, sun) {
                drawLine(c(sp.accentSoft).a(0.07f), sun, Offset(sun.x, sun.y + h * 0.9f), strokeWidth = w * 0.09f)
            }
        }
    }
    val n = count(18, d)
    for (i in 0 until n) {
        val s = S24[i]
        val y = frac(s.y + t * s.k)
        val x = s.x + 0.06f * wave(t, 2f * s.k, s.p)
        val cc = Offset(x * w, y * h)
        rotate(360f * (t * s.k + s.p) * 2f, cc) {
            drawOval(c(0xFF8FE3B0).a(0.26f), Offset(cc.x - s.s * 9f * density, cc.y - s.s * 4f * density), Size(s.s * 18f * density, s.s * 8f * density))
        }
    }
}

// ------------------------------------------------------------------ 3 ليلة إيمانية: نجوم متلألئة + هلال نابض
private fun DrawScope.faithNight(sp: PaletteSpec, t: Float, d: Float) {
    val w = size.width; val h = size.height
    starfield(c(sp.text), S80, t, d, 0.7f, 12f, 0.9f)
    val m = Offset(w * 0.78f, h * 0.13f)
    val r = w * 0.085f
    glow(m, r * (4.5f + 0.5f * wave(t, 6f)), c(sp.accentSoft), 0.28f)
    crescent(m, r, c(sp.accentSoft), c(sp.bgTop).a(1f))
}

// ------------------------------------------------------------------ 4 الذهب الملكي: شبكة زخارف ذهبية + شريط انعكاس يمسح الشاشة
private fun DrawScope.royalGold(sp: PaletteSpec, t: Float, d: Float) {
    val w = size.width; val h = size.height
    val cell = w / 4.2f
    val col = c(sp.accent).a(0.10f)
    var row = 0
    var y = 0f
    while (y < h + cell) {
        var x = if (row % 2 == 0) 0f else cell / 2f
        while (x < w + cell) {
            star8(Offset(x, y), cell * 0.36f, col, 1.2f * density, 0f)
            x += cell
        }
        y += cell * 0.5f; row++
    }
    val sweep = frac(t * 3f) * (w + h * 0.6f) - h * 0.3f
    rotate(20f, Offset(w / 2, h / 2)) {
        drawRect(
            Brush.horizontalGradient(listOf(Color.Transparent, c(sp.accentSoft).a(0.20f), Color.Transparent), startX = sweep - w * 0.18f, endX = sweep + w * 0.18f),
            Offset(-w * 0.2f, -h * 0.2f), Size(w * 1.4f, h * 1.4f),
        )
    }
}

// ------------------------------------------------------------------ 5 الزمرد الإسلامي: جزيئات خضراء صاعدة + توهج
private fun DrawScope.emeraldRise(sp: PaletteSpec, t: Float, d: Float) {
    val w = size.width; val h = size.height
    glow(Offset(w * 0.2f, h * (0.3f + 0.05f * wave(t, 3f))), w * 0.6f, c(sp.accent), 0.14f)
    glow(Offset(w * 0.85f, h * (0.75f - 0.05f * wave(t, 3f))), w * 0.55f, c(sp.accentSoft), 0.12f)
    val n = count(40, d)
    for (i in 0 until n) {
        val s = S40[i]
        val y = 1f - frac(s.y + t * s.k)
        val x = s.x + 0.025f * wave(t, 2f * s.k, s.p)
        val a = 0.15f + 0.5f * (0.5f + 0.5f * wave(t, 6f * s.k, s.p))
        drawCircle(c(sp.accent).a(a), s.s * 2.2f * density, Offset(x * w, y * h))
    }
}

// ------------------------------------------------------------------ 6 المحيط الهادئ: أمواج متداخلة + بقع ضوء (كاوستكس)
private fun DrawScope.pacific(sp: PaletteSpec, t: Float, d: Float) {
    val w = size.width; val h = size.height
    for (i in 0 until count(12, d)) {
        val s = S14[i % S14.size]
        val cx = (s.x + 0.1f * wave(t, 2f, s.p)) * w
        val cy = (0.15f + 0.45f * s.y) * h
        glow(Offset(cx, cy), w * 0.16f * s.s, c(sp.accentSoft), 0.10f)
    }
    waveBand(t, h * 0.62f, h * 0.012f, 1.6f, 0f, c(sp.accent).a(0.10f))
    waveBand(t, h * 0.70f, h * 0.016f, 1.2f, 0.3f, c(sp.accent).a(0.13f))
    waveBand(t, h * 0.79f, h * 0.020f, 0.9f, 0.6f, c(sp.accentSoft).a(0.15f))
    waveBand(t, h * 0.89f, h * 0.024f, 0.7f, 0.9f, c(sp.bgTop).a(0.35f))
}

// ------------------------------------------------------------------ 7 السماء البنفسجية: سحب ضوئية بطيئة + نجوم ناعمة
private fun DrawScope.violetSky(sp: PaletteSpec, t: Float, d: Float) {
    val w = size.width; val h = size.height
    starfield(c(sp.text), S40, t, d, 0.55f, 10f, 0.7f)
    for (i in 0 until 4) {
        val cw = w * (0.55f + 0.12f * i)
        val x = frac(t * (1 + i % 2) * 1f + i * 0.31f) * (w + cw) - cw
        cloud(x, h * (0.16f + 0.17f * i), cw, h * 0.05f, c(sp.accentSoft).a(0.10f))
    }
    glow(Offset(w * 0.3f, h * 0.9f), w * 0.8f, c(sp.accent), 0.12f)
}

// ------------------------------------------------------------------ 8 المجرة: ثلاث طبقات نجوم بعمق (بارالاكس) + ذراع حلزوني
private fun DrawScope.galaxy(sp: PaletteSpec, t: Float, d: Float) {
    val w = size.width; val h = size.height
    val ctr = Offset(w * 0.5f, h * 0.38f)
    rotate(360f * t, ctr) {
        for (arm in 0 until 2) {
            for (i in 0 until count(30, d)) {
                val f = i / 30f
                val ang = arm * PI.toFloat() + f * 5.2f
                val r = w * (0.04f + 0.55f * f)
                val p = Offset(ctr.x + r * cos(ang), ctr.y + r * sin(ang) * 0.55f)
                drawCircle(c(sp.accent).a(0.35f * (1f - f)), (1.2f + 2f * (1f - f)) * density, p)
            }
        }
    }
    glow(ctr, w * 0.35f, c(sp.accentSoft), 0.22f)
    for (layer in 0 until 3) {
        val speed = 1 + layer
        for (i in 0 until count(24, d)) {
            val s = S80[(i + layer * 24) % S80.size]
            val x = frac(s.x - t * speed)
            drawCircle(c(sp.text).a(0.25f + 0.2f * layer), (0.6f + layer * 0.7f) * density, Offset(x * w, s.y * h))
        }
    }
}

// ------------------------------------------------------------------ 9 الفجر: شمس تصعد ببطء من الأفق بتدرج دافئ
private fun DrawScope.dawn(sp: PaletteSpec, t: Float, d: Float) {
    val w = size.width; val h = size.height
    val rise = 0.5f + 0.5f * wave(t, 1f)
    val sun = Offset(w * 0.5f, h * (0.80f - 0.22f * rise))
    glow(sun, w * 0.95f, c(sp.accent), 0.25f + 0.2f * rise)
    glow(sun, w * 0.35f, c(sp.accentSoft), 0.35f)
    drawCircle(c(sp.accentSoft).a(0.65f), w * 0.07f, sun)
    for (i in 0 until 4) {
        val y = h * (0.55f + 0.1f * i)
        drawRect(Brush.horizontalGradient(listOf(Color.Transparent, c(sp.accentSoft).a(0.08f), Color.Transparent)), Offset(0f, y), Size(w, h * 0.012f))
    }
    drawRect(c(sp.bgTop).a(0.5f), Offset(0f, h * 0.9f), Size(w, h * 0.1f))
}

// ------------------------------------------------------------------ 10 الغروب: قرص شمس ينزل بخطوط أفقية ودفء متغير
private fun DrawScope.sunset(sp: PaletteSpec, t: Float, d: Float) {
    val w = size.width; val h = size.height
    val sun = Offset(w * 0.5f, h * (0.58f + 0.08f * wave(t, 1f)))
    glow(sun, w * 0.9f, c(sp.accent), 0.28f)
    drawCircle(Brush.verticalGradient(listOf(c(sp.accentSoft).a(0.8f), c(sp.accent).a(0.7f)), startY = sun.y - w * 0.16f, endY = sun.y + w * 0.16f), w * 0.16f, sun)
    for (i in 0 until 7) {
        val y = sun.y + w * 0.02f + i * w * 0.028f
        drawRect(c(sp.bgBottom).a(0.20f + 0.07f * i), Offset(0f, y), Size(w, w * (0.005f + 0.004f * i)))
    }
    for (i in 0 until 3) {
        val x = frac(t * 2f + i * 0.4f) * (w * 1.6f) - w * 0.3f
        cloud(x, h * (0.25f + 0.08f * i), w * 0.5f, h * 0.03f, c(sp.accentSoft).a(0.10f))
    }
}

// ------------------------------------------------------------------ 11 المطر الهادئ: قطرات رأسية رقيقة + دوائر ارتداد
private fun DrawScope.quietRain(sp: PaletteSpec, t: Float, d: Float) {
    val w = size.width; val h = size.height
    for (i in 0 until count(40, d)) {
        val s = S40[i]
        val y = frac(s.y + t * (4 + s.k))
        val x = s.x * w
        val len = h * 0.03f * s.s
        drawLine(c(sp.accentSoft).a(0.25f), Offset(x, y * h), Offset(x, y * h + len), strokeWidth = 1.2f * density, cap = StrokeCap.Round)
    }
    for (i in 0 until count(8, d)) {
        val s = S8[i]
        val ph = frac(t * 5f + s.p)
        val cx = s.x * w
        val cy = h * (0.82f + 0.15f * s.y)
        drawOval(c(sp.accentSoft).a(0.28f * (1f - ph)), Offset(cx - ph * w * 0.06f, cy - ph * w * 0.018f), Size(ph * w * 0.12f, ph * w * 0.036f), style = Stroke(1.2f * density))
    }
}

// ------------------------------------------------------------------ 12 الشلال: خيوط ماء متدفقة + ضباب عند القاع
private fun DrawScope.waterfall(sp: PaletteSpec, t: Float, d: Float) {
    val w = size.width; val h = size.height
    val left = w * 0.18f; val right = w * 0.82f
    for (i in 0 until count(22, d)) {
        val s = S24[i]
        val x = left + (right - left) * s.x
        val y = frac(s.y + t * (3 + s.k))
        drawLine(
            Brush.verticalGradient(listOf(Color.Transparent, c(sp.accentSoft).a(0.32f), Color.Transparent), startY = y * h - h * 0.12f, endY = y * h + h * 0.12f),
            Offset(x, y * h - h * 0.12f), Offset(x, y * h + h * 0.12f), strokeWidth = (2f + 3f * s.s) * density,
        )
    }
    for (i in 0 until 4) {
        glow(Offset(w * (0.25f + 0.17f * i), h * (0.93f + 0.01f * wave(t, 3f, i * 0.2f))), w * 0.35f, c(sp.text), 0.10f)
    }
}

// ------------------------------------------------------------------ 13 الصحراء الذهبية: كثبان بطبقات + حبيبات رمل تهبّ + شمس
private fun DrawScope.desert(sp: PaletteSpec, t: Float, d: Float) {
    val w = size.width; val h = size.height
    val sun = Offset(w * 0.78f, h * 0.2f)
    glow(sun, w * 0.7f, c(sp.accent), 0.30f)
    drawCircle(c(sp.accentSoft).a(0.7f), w * 0.07f, sun)
    waveBand(0f, h * 0.70f, h * 0.03f, 0.8f, 0.1f, c(sp.accent).a(0.16f))
    waveBand(0f, h * 0.80f, h * 0.04f, 0.6f, 0.5f, c(sp.bgTop).a(0.30f))
    waveBand(0f, h * 0.90f, h * 0.035f, 0.9f, 0.8f, c(sp.bgTop).a(0.50f))
    for (i in 0 until count(40, d)) {
        val s = S40[i]
        val x = frac(s.x + t * (2 + s.k))
        val y = h * (0.55f + 0.4f * s.y) + h * 0.01f * wave(t, 6f, s.p)
        drawCircle(c(sp.accentSoft).a(0.35f), s.s * 1.2f * density, Offset(x * w, y))
    }
}

// ------------------------------------------------------------------ 14 القمر والسحاب: قمر كبير بتوهج وسحب تعبره
private fun DrawScope.moonClouds(sp: PaletteSpec, t: Float, d: Float) {
    val w = size.width; val h = size.height
    val m = Offset(w * 0.5f, h * 0.2f)
    glow(m, w * 0.6f, c(sp.accentSoft), 0.22f)
    drawCircle(Brush.radialGradient(listOf(c(sp.accentSoft), c(sp.accent).a(0.85f)), center = m, radius = w * 0.13f), w * 0.13f, m)
    starfield(c(sp.text), S40, t, d, 0.5f, 8f, 0.45f)
    for (i in 0 until 5) {
        val cw = w * (0.5f + 0.1f * (i % 3))
        val x = frac(t * (1 + i % 2) + i * 0.23f) * (w + cw) - cw
        cloud(x, h * (0.12f + 0.07f * i), cw, h * 0.04f, c(sp.bgBottom).a(0.55f))
    }
}

// ------------------------------------------------------------------ 15 الزجاج البلوري: ألواح زجاجية مائلة تنساب مع لمعة
private fun DrawScope.crystal(sp: PaletteSpec, t: Float, d: Float) {
    val w = size.width; val h = size.height
    for (i in 0 until 6) {
        val x = frac(t * (1 + i % 3) + i * 0.17f) * (w * 1.4f) - w * 0.2f
        val pw = w * (0.12f + 0.05f * (i % 3))
        val p = Path().apply {
            moveTo(x, 0f); lineTo(x + pw, 0f); lineTo(x + pw - w * 0.25f, h); lineTo(x - w * 0.25f, h); close()
        }
        drawPath(p, Brush.verticalGradient(listOf(c(sp.accentSoft).a(0.14f), c(sp.accent).a(0.03f))))
        drawLine(c(sp.text).a(0.18f), Offset(x, 0f), Offset(x - w * 0.25f, h), strokeWidth = 1.2f * density)
    }
    for (i in 0 until count(10, d)) {
        val s = S14[i]
        val a = 0.5f + 0.5f * wave(t, 8f, s.p)
        drawCircle(c(sp.text).a(0.5f * a), 1.6f * density, Offset(s.x * w, s.y * h))
    }
}

// ------------------------------------------------------------------ 16 اللؤلؤ: بقع ألوان لؤلؤية تتمازج ببطء (ثيم فاتح)
private fun DrawScope.pearl(sp: PaletteSpec, t: Float, d: Float) {
    val w = size.width; val h = size.height
    val cols = listOf(0xFFF8C8E8L, 0xFFC8E0F8L, 0xFFE0D0F8L, 0xFFD0F0E0L, 0xFFF8E8C8L)
    for (i in 0 until count(5, d)) {
        val ctr = Offset(w * (0.2f + 0.6f * frac(i * 0.37f) + 0.12f * wave(t, 1f, i * 0.2f)), h * (0.15f + 0.7f * frac(i * 0.61f) + 0.08f * wave(t, 2f, i * 0.13f)))
        glow(ctr, w * 0.55f, c(cols[i]), 0.55f)
    }
    for (i in 0 until count(14, d)) {
        val s = S14[i]
        val a = 0.5f + 0.5f * wave(t, 4f, s.p)
        drawCircle(Color.White.a(0.55f * a), 2.2f * density, Offset(s.x * w, s.y * h))
    }
}

// ------------------------------------------------------------------ 17 الخط العربي: حروف عربية كبيرة شفافة تطفو (ثيم فاتح كأنه ورق)
private fun DrawScope.calligraphy(sp: PaletteSpec, t: Float, d: Float) {
    val w = size.width; val h = size.height
    val letters = listOf("ا", "ل", "ه", "م", "ن", "ي", "و", "ب", "ر", "ح", "س", "ق")
    val paint = android.graphics.Paint().apply {
        isAntiAlias = true
        typeface = android.graphics.Typeface.SERIF
        textAlign = android.graphics.Paint.Align.CENTER
    }
    drawIntoCanvas { cv ->
        for (i in 0 until count(10, d)) {
            val s = S14[i]
            paint.textSize = w * (0.22f + 0.2f * s.s)
            paint.color = c(sp.accent).a(0.10f).let { android.graphics.Color.argb((it.alpha * 255).toInt(), (it.red * 255).toInt(), (it.green * 255).toInt(), (it.blue * 255).toInt()) }
            val x = s.x * w + w * 0.04f * wave(t, 1f, s.p)
            val y = frac(s.y + t * s.k) * (h + w * 0.4f) - w * 0.1f
            cv.nativeCanvas.save()
            cv.nativeCanvas.rotate(12f * wave(t, 1f, s.p), x, y)
            cv.nativeCanvas.drawText(letters[(i * 5) % letters.size], x, y, paint)
            cv.nativeCanvas.restore()
        }
    }
    drawLine(c(sp.accent).a(0.18f), Offset(w * 0.1f, h * 0.06f), Offset(w * 0.9f, h * 0.06f), strokeWidth = 1.5f * density)
}

// ------------------------------------------------------------------ 18 النقوش الهندسية: نجوم مضلّعة تدور وتنبض بموجة تنتشر من المركز
private fun DrawScope.geometric(sp: PaletteSpec, t: Float, d: Float) {
    val w = size.width; val h = size.height
    val cell = w / 3.4f
    var row = 0
    var y = 0f
    while (y < h + cell) {
        var x = if (row % 2 == 0) 0f else cell / 2f
        while (x < w + cell) {
            val dist = kotlin.math.hypot(x - w / 2f, y - h / 2f) / w
            val pulse = 0.5f + 0.5f * wave(t, 4f, -dist)
            star8(Offset(x, y), cell * (0.26f + 0.10f * pulse), c(sp.accent).a(0.07f + 0.13f * pulse), 1.3f * density, 360f * t * (if (row % 2 == 0) 1f else -1f))
            x += cell
        }
        y += cell * 0.5f; row++
    }
}

// ------------------------------------------------------------------ 19 الفيروز الملكي: كتل فيروزية انسيابية + شعاع ضوء مائل
private fun DrawScope.turquoise(sp: PaletteSpec, t: Float, d: Float) {
    val w = size.width; val h = size.height
    for (i in 0 until 4) {
        val ctr = Offset(w * (0.2f + 0.2f * i + 0.15f * wave(t, 1f, i * 0.25f)), h * (0.2f + 0.2f * i + 0.1f * wave(t, 2f, i * 0.3f)))
        glow(ctr, w * 0.5f, c(if (i % 2 == 0) sp.accent else sp.accentSoft), 0.14f)
    }
    val beam = frac(t * 2f)
    rotate(-25f, Offset(w / 2, h / 2)) {
        val x = beam * w * 1.6f - w * 0.3f
        drawRect(Brush.horizontalGradient(listOf(Color.Transparent, c(sp.text).a(0.10f), Color.Transparent), startX = x - w * 0.1f, endX = x + w * 0.1f), Offset(-w * 0.3f, -h * 0.3f), Size(w * 1.6f, h * 1.6f))
    }
}

// ------------------------------------------------------------------ 20 الليل الكحلي: نجوم دقيقة فضية + شهاب عابر
private fun DrawScope.navyNight(sp: PaletteSpec, t: Float, d: Float) {
    val w = size.width; val h = size.height
    for (i in 0 until count(80, d)) {
        val s = S80[i]
        val tw = 0.5f + 0.5f * wave(t, 15f * s.k, s.p)
        drawCircle(c(sp.accent).a(0.15f + 0.6f * tw), 0.5f * s.s * density + 0.4f, Offset(s.x * w, s.y * h * 0.9f))
    }
    val ph = frac(t * 4f)
    if (ph < 0.25f) {
        val q = ph / 0.25f
        val start = Offset(w * (0.9f - 0.5f * q), h * (0.05f + 0.3f * q))
        drawLine(Brush.linearGradient(listOf(c(sp.accentSoft).a(0.8f * (1f - q)), Color.Transparent), start = start, end = start + Offset(w * 0.22f, -h * 0.07f)), start, start + Offset(w * 0.22f, -h * 0.07f), strokeWidth = 2f * density, cap = StrokeCap.Round)
    }
}

// ------------------------------------------------------------------ 21 الحديقة المضيئة: يراعات تتجول وتتوهج بإيقاع مختلف
private fun DrawScope.fireflies(sp: PaletteSpec, t: Float, d: Float) {
    val w = size.width; val h = size.height
    for (i in 0 until count(24, d)) {
        val s = S24[i]
        val x = (s.x + 0.08f * wave(t, 2f * s.k, s.p) + 0.03f * wave(t, 5f, s.p * 2f)) * w
        val y = (s.y + 0.06f * wave(t, 3f * s.k, s.p + 0.3f)) * h
        val on = 0.5f + 0.5f * wave(t, 6f * s.k, s.p)
        glow(Offset(x, y), (10f + 14f * on) * density, c(sp.accent), 0.55f * on)
        drawCircle(c(sp.accentSoft).a(0.9f * on), 1.6f * density, Offset(x, y))
    }
    waveBand(0f, h * 0.93f, h * 0.012f, 1.5f, 0.2f, c(sp.bgTop).a(0.6f))
}

// ------------------------------------------------------------------ 22 الثلج الهادئ: رقاقات ثلج تتمايل (ثيم فاتح)
private fun DrawScope.snow(sp: PaletteSpec, t: Float, d: Float) {
    val w = size.width; val h = size.height
    glow(Offset(w * 0.5f, 0f), w * 0.9f, Color.White, 0.5f)
    for (i in 0 until count(50, d)) {
        val s = S40[i % S40.size]
        val layer = i % 3
        val y = frac(s.y + t * (1 + layer) + i * 0.013f)
        val x = frac(s.x + 0.05f * wave(t, 2f * s.k, s.p) + i * 0.0071f)
        drawCircle(c(sp.accent).a(0.28f + 0.1f * layer), (1.5f + layer * 1.3f) * density, Offset(x * w, y * h))
    }
}

// ------------------------------------------------------------------ 23 الفضاء العميق: سدم ملونة كبيرة تتحرك + نجوم
private fun DrawScope.deepSpace(sp: PaletteSpec, t: Float, d: Float) {
    val w = size.width; val h = size.height
    val cols = listOf(0xFF7B2FF7L, 0xFFFF4D9AL, 0xFF2F7BFFL)
    for (i in 0 until 3) {
        val ctr = Offset(w * (0.25f + 0.3f * i + 0.12f * wave(t, 1f, i * 0.33f)), h * (0.22f + 0.28f * i + 0.08f * wave(t, 2f, i * 0.5f)))
        glow(ctr, w * 0.75f, c(cols[i]), 0.22f)
    }
    starfield(c(sp.text), S80, t, d, 1f, 10f, 0.85f)
}

// ------------------------------------------------------------------ 24 الفوانيس الرمضانية: فوانيس تتأرجح وتتوهج بأحجام مختلفة
private fun DrawScope.lanterns(sp: PaletteSpec, t: Float, d: Float) {
    val w = size.width; val h = size.height
    val xs = listOf(0.12f, 0.34f, 0.58f, 0.8f, 0.94f)
    val ls = listOf(0.10f, 0.19f, 0.12f, 0.22f, 0.09f)
    for (i in xs.indices) {
        val sway = 3f * wave(t, 2f, i * 0.2f)
        val top = Offset(w * xs[i], 0f)
        val bodyC = Offset(w * xs[i] + sway, h * ls[i] + 14f * density)
        drawLine(c(sp.accent).a(0.6f), top, Offset(bodyC.x, bodyC.y - 14f * density), strokeWidth = 1.4f * density)
        val flick = 0.7f + 0.3f * wave(t, 9f, i * 0.37f)
        glow(bodyC, (54f + 10f * flick) * density, c(sp.accent), 0.35f * flick)
        val bw = (16f + 4f * (i % 2)) * density
        val bh = bw * 1.7f
        drawRoundRect(Brush.verticalGradient(listOf(c(sp.accentSoft), c(sp.accent)), startY = bodyC.y - bh / 2f, endY = bodyC.y + bh / 2f), Offset(bodyC.x - bw / 2f, bodyC.y - bh / 2f), Size(bw, bh), androidx.compose.ui.geometry.CornerRadius(bw * 0.35f))
        drawCircle(Color(0xFFFFF4C2).a(0.9f * flick), bw * 0.18f, bodyC)
    }
}

// ------------------------------------------------------------------ 25 الفجر الروحاني: أفق مضيء + طبقات غيوم هادئة (ثيم فاتح)
private fun DrawScope.spiritualDawn(sp: PaletteSpec, t: Float, d: Float) {
    val w = size.width; val h = size.height
    val hz = Offset(w * 0.5f, h * 0.96f)
    glow(hz, w * (1.0f + 0.05f * wave(t, 2f)), Color(0xFFFFD9A0), 0.7f)
    glow(hz, w * 0.45f, Color.White, 0.5f)
    for (i in 0 until 4) {
        val cw = w * (0.6f + 0.1f * i)
        val x = frac(t * (1 + i % 2) + i * 0.27f) * (w + cw) - cw
        cloud(x, h * (0.18f + 0.12f * i), cw, h * 0.035f, Color.White.a(0.55f))
    }
}

// ------------------------------------------------------------------ 26 الشفق القطبي: أشرطة ضوء متموجة بألوان خضراء/بنفسجية
private fun DrawScope.aurora(sp: PaletteSpec, t: Float, d: Float) {
    val w = size.width; val h = size.height
    starfield(c(sp.text), S40, t, d, 0.6f, 8f, 0.4f)
    val cols = listOf(c(0xFF3DFFA0), c(0xFF35D0FF), c(0xFFB36BFF))
    for (b in 0 until 3) {
        val p = Path()
        val steps = 18
        val topPts = ArrayList<Offset>()
        for (i in 0..steps) {
            val x = w * i / steps
            val y = h * (0.18f + 0.12f * b) + h * 0.06f * wave(t, 1f + b, i * 0.07f + b * 0.2f)
            topPts.add(Offset(x, y))
        }
        p.moveTo(topPts.first().x, topPts.first().y)
        for (pt in topPts) p.lineTo(pt.x, pt.y)
        for (i in steps downTo 0) {
            val pt = topPts[i]
            p.lineTo(pt.x, pt.y + h * (0.22f + 0.04f * wave(t, 2f, i * 0.1f)))
        }
        p.close()
        drawPath(p, Brush.verticalGradient(listOf(cols[b].a(0.30f), Color.Transparent), startY = h * (0.15f + 0.12f * b), endY = h * (0.5f + 0.12f * b)))
    }
}

// ------------------------------------------------------------------ 27 الرخام الملكي: عروق رخام ثابتة + بريق يمرّ فوقها (ثيم فاتح)
private fun DrawScope.marble(sp: PaletteSpec, t: Float, d: Float) {
    val w = size.width; val h = size.height
    val vr = Random(7)
    for (v in 0 until 7) {
        val p = Path()
        var x = vr.nextFloat() * w
        var y = 0f
        p.moveTo(x, y)
        while (y < h) {
            x += (vr.nextFloat() - 0.5f) * w * 0.25f
            y += h * 0.09f
            p.lineTo(x, y)
        }
        drawPath(p, c(sp.accent).a(if (v % 3 == 0) 0.22f else 0.10f), style = Stroke((if (v % 3 == 0) 1.8f else 1f) * density))
    }
    val sweep = frac(t * 2f) * (w * 1.8f) - w * 0.4f
    rotate(25f, Offset(w / 2, h / 2)) {
        drawRect(Brush.horizontalGradient(listOf(Color.Transparent, Color.White.a(0.45f), Color.Transparent), startX = sweep - w * 0.22f, endX = sweep + w * 0.22f), Offset(-w * 0.3f, -h * 0.3f), Size(w * 1.6f, h * 1.6f))
    }
}

// ------------------------------------------------------------------ 28 السماء الممطرة: سحب داكنة + مطر مائل كثيف + بريق انعكاس
private fun DrawScope.rainySky(sp: PaletteSpec, t: Float, d: Float) {
    val w = size.width; val h = size.height
    for (i in 0 until 5) {
        val cw = w * (0.6f + 0.1f * (i % 3))
        val x = frac(t * (1 + i % 2) + i * 0.21f) * (w + cw) - cw
        cloud(x, h * (0.02f + 0.05f * i), cw, h * 0.05f, c(sp.bgBottom).a(0.7f))
    }
    for (i in 0 until count(60, d)) {
        val s = S80[i]
        val y = frac(s.y + t * (6 + s.k))
        val x = frac(s.x - y * 0.12f)
        drawLine(c(sp.accentSoft).a(0.22f), Offset(x * w, y * h), Offset(x * w - w * 0.012f, y * h + h * 0.035f), strokeWidth = 1.1f * density)
    }
    val flash = frac(t * 3f)
    if (flash > 0.97f) drawRect(c(sp.text).a(0.05f))
    waveBand(0f, h * 0.95f, h * 0.008f, 2f, 0f, c(sp.accentSoft).a(0.10f))
}

// ------------------------------------------------------------------ 29 الورد الهادئ: بتلات تتساقط وتدور (ثيم فاتح)
private fun DrawScope.petals(sp: PaletteSpec, t: Float, d: Float) {
    val w = size.width; val h = size.height
    glow(Offset(w * 0.15f, h * 0.1f), w * 0.7f, Color(0xFFFFC2D6), 0.5f)
    for (i in 0 until count(20, d)) {
        val s = S24[i]
        val y = frac(s.y + t * s.k)
        val x = s.x + 0.07f * wave(t, 2f * s.k, s.p)
        val cc = Offset(x * w, y * h)
        rotate(360f * (t * s.k + s.p), cc) {
            val pw = (10f + 8f * s.s) * density
            val path = Path().apply {
                moveTo(cc.x, cc.y - pw)
                cubicTo(cc.x + pw * 0.9f, cc.y - pw * 0.4f, cc.x + pw * 0.6f, cc.y + pw * 0.8f, cc.x, cc.y + pw)
                cubicTo(cc.x - pw * 0.6f, cc.y + pw * 0.8f, cc.x - pw * 0.9f, cc.y - pw * 0.4f, cc.x, cc.y - pw)
                close()
            }
            drawPath(path, Color(if (i % 2 == 0) 0xFFF59AB8 else 0xFFFFC2D6).a(0.5f))
        }
    }
}

// ------------------------------------------------------------------ 30 أُنسي الخاص: أفق مسجد + هلال + فانوس + نجمة ثمانية دوّارة + جزيئات
private fun DrawScope.unseeSpecial(sp: PaletteSpec, t: Float, d: Float) {
    val w = size.width; val h = size.height
    starfield(c(sp.text), S40, t, d, 0.5f, 10f, 0.6f)
    star8(Offset(w * 0.5f, h * 0.3f), w * 0.34f, c(sp.accent).a(0.10f), 1.6f * density, 360f * t)
    star8(Offset(w * 0.5f, h * 0.3f), w * 0.22f, c(sp.accentSoft).a(0.12f), 1.2f * density, -360f * t)
    val m = Offset(w * 0.8f, h * 0.1f)
    glow(m, w * 0.3f, c(sp.accentSoft), 0.25f)
    crescent(m, w * 0.06f, c(sp.accentSoft), c(sp.bgTop))
    val lx = w * 0.14f
    val flick = 0.7f + 0.3f * wave(t, 8f)
    drawLine(c(sp.accent).a(0.7f), Offset(lx, 0f), Offset(lx, h * 0.07f), strokeWidth = 1.4f * density)
    glow(Offset(lx, h * 0.095f), 48f * density, c(sp.accent), 0.35f * flick)
    drawRoundRect(c(sp.accent), Offset(lx - 8f * density, h * 0.07f), Size(16f * density, 26f * density), androidx.compose.ui.geometry.CornerRadius(5f * density))
    for (i in 0 until count(24, d)) {
        val s = S24[i]
        val y = 1f - frac(s.y + t * s.k)
        drawCircle(c(sp.accentSoft).a(0.18f + 0.3f * (0.5f + 0.5f * wave(t, 5f, s.p))), s.s * 1.6f * density, Offset((s.x + 0.02f * wave(t, 2f, s.p)) * w, y * h))
    }
    // أفق مساجد
    val base = h
    val sky = Path().apply {
        moveTo(0f, base); lineTo(0f, h * 0.93f)
        lineTo(w * 0.1f, h * 0.93f); lineTo(w * 0.1f, h * 0.87f); lineTo(w * 0.115f, h * 0.84f); lineTo(w * 0.13f, h * 0.87f); lineTo(w * 0.13f, h * 0.93f)
        lineTo(w * 0.34f, h * 0.93f)
        cubicTo(w * 0.34f, h * 0.84f, w * 0.44f, h * 0.84f, w * 0.5f, h * 0.83f)
        cubicTo(w * 0.56f, h * 0.84f, w * 0.66f, h * 0.84f, w * 0.66f, h * 0.93f)
        lineTo(w * 0.87f, h * 0.93f); lineTo(w * 0.87f, h * 0.87f); lineTo(w * 0.885f, h * 0.84f); lineTo(w * 0.9f, h * 0.87f); lineTo(w * 0.9f, h * 0.93f)
        lineTo(w, h * 0.93f); lineTo(w, base); close()
    }
    drawPath(sky, c(sp.bgTop).a(0.75f))
}

/** تقدير مفيد للاختبارات: كل الثيمات (عدا الطبيعة) لها دالة رسم مستقلة. */
fun themeHasOwnEngine(id: ThemeId): Boolean = id != ThemeId.NATURE && id != ThemeId.SILK
