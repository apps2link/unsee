package com.unsee.app.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.DrawStyle
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.nativeCanvas
import com.unsee.app.core.PaletteSpec
import com.unsee.app.core.Palettes
import com.unsee.app.core.ThemeId
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin
import kotlin.random.Random

/*
 * محرك الخلفيات المتحركة لثيمات «المجموعة المتحركة».
 * - كل ثيم له دالة رسم خاصة به بعناصر وحركة مختلفة (وليس مجرد تغيير ألوان).
 * - الزمن t يدور من 0 إلى 1 كل 60 ثانية، وكل الحركات بترددات صحيحة فتتكرر بسلاسة دون «قفزة».
 * - الرسم كله في مرحلة الرسم (drawWithCache) دون إعادة تركيب، والمسارات الثقيلة تُبنى مرة واحدة لكل مقاس.
 * - motion = 0 يرسم لقطة ثابتة بلا أي مؤقّت (توفير بطارية)، و motion = 1 يقلّل عدد العناصر إلى النصف تقريبًا.
 */

private const val TAU = (2.0 * PI).toFloat()
private const val HALF_PI = (PI / 2.0).toFloat()

private class Seed(val x: Float, val y: Float, val s: Float, val ph: Float, val k: Int)

private val rng = Random(2026)
private val SEEDS = List(160) { Seed(rng.nextFloat(), rng.nextFloat(), rng.nextFloat(), rng.nextFloat(), 1 + rng.nextInt(3)) }

private fun col(v: Long): Color = Color(v)
private fun Color.a(x: Float): Color = copy(alpha = x.coerceIn(0f, 1f))
private fun wave(t: Float, k: Float, ph: Float = 0f): Float = sin(TAU * (t * k + ph))
private fun cnt(base: Int, q: Float): Int = max(1, (base * q).toInt()).coerceAtMost(SEEDS.size)
private fun fr(x: Float): Float = x - kotlin.math.floor(x)

/** مسارات وأدوات تُبنى مرة واحدة لكل مقاس رسم. */
private class Kit(val w: Float, val h: Float, val d: Float) {
    val crescent: Path = Path.combine(
        PathOperation.Difference,
        Path().apply { addOval(Rect(Offset.Zero, w * 0.07f)) },
        Path().apply { addOval(Rect(Offset(w * 0.07f * 0.55f, -w * 0.07f * 0.2f), w * 0.07f * 0.85f)) },
    )
    val star8: Path = starPath(8, 0.62f)
    val star16: Path = starPath(16, 0.8f)
    val leaf: Path = Path().apply {
        moveTo(-1f, 0f)
        cubicTo(-0.4f, -0.95f, 0.5f, -0.95f, 1f, 0f)
        cubicTo(0.5f, 0.95f, -0.4f, 0.95f, -1f, 0f)
        close()
    }
    val petal: Path = Path().apply {
        moveTo(0f, -1f)
        cubicTo(0.9f, -0.7f, 0.9f, 0.5f, 0f, 1f)
        cubicTo(-0.9f, 0.5f, -0.9f, -0.7f, 0f, -1f)
        close()
    }
    val skyline: Path = unseeSkyline(w, h)
    val mountA: Path = ridge(0.80f, 0.06f, 1.3f, 0.2f)
    val mountB: Path = ridge(0.88f, 0.05f, 2.1f, 0.6f)
    val cliffL: Path = Path().apply {
        moveTo(0f, 0f); lineTo(w * 0.30f, 0f); cubicTo(w * 0.22f, h * 0.2f, w * 0.34f, h * 0.45f, w * 0.26f, h * 0.7f)
        cubicTo(w * 0.22f, h * 0.85f, w * 0.30f, h * 0.95f, w * 0.28f, h); lineTo(0f, h); close()
    }
    val cliffR: Path = Path().apply {
        moveTo(w, 0f); lineTo(w * 0.72f, 0f); cubicTo(w * 0.80f, h * 0.18f, w * 0.68f, h * 0.42f, w * 0.76f, h * 0.68f)
        cubicTo(w * 0.80f, h * 0.84f, w * 0.72f, h * 0.95f, w * 0.74f, h); lineTo(w, h); close()
    }
    val veins: List<Path> = List(7) { i ->
        val r = Random(900 + i)
        Path().apply {
            moveTo(-w * 0.1f, h * r.nextFloat())
            cubicTo(w * 0.3f, h * r.nextFloat(), w * 0.6f, h * r.nextFloat(), w * 1.1f, h * r.nextFloat())
        }
    }
    val text = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        typeface = android.graphics.Typeface.SERIF
        textAlign = android.graphics.Paint.Align.CENTER
    }

    private fun starPath(points: Int, inner: Float): Path = Path().apply {
        for (k in 0 until points * 2) {
            val rad = if (k % 2 == 0) 1f else inner
            val ang = k * PI.toFloat() / points - HALF_PI
            val x = rad * cos(ang)
            val y = rad * sin(ang)
            if (k == 0) moveTo(x, y) else lineTo(x, y)
        }
        close()
    }

    private fun ridge(base: Float, amp: Float, freq: Float, ph: Float): Path = Path().apply {
        moveTo(0f, h)
        val steps = 24
        for (i in 0..steps) {
            val x = w * i / steps
            val y = h * (base + amp * sin(TAU * (freq * i / steps + ph)) * (0.6f + 0.4f * sin(TAU * (i / steps.toFloat() * 3.1f))))
            lineTo(x, y)
        }
        lineTo(w, h); close()
    }
}

private fun unseeSkyline(w: Float, h: Float): Path {
    val k = w / 360f
    val y0 = h - 60f * k
    fun px(x: Float) = x * k
    fun py(y: Float) = y0 + y * k
    val p = Path()
    p.moveTo(px(0f), py(50f)); p.lineTo(px(360f), py(50f)); p.lineTo(px(360f), py(60f)); p.lineTo(px(0f), py(60f)); p.close()
    for (x in listOf(40f, 312f)) {
        p.moveTo(px(x), py(60f)); p.lineTo(px(x), py(20f)); p.lineTo(px(x + 4f), py(8f))
        p.lineTo(px(x + 8f), py(20f)); p.lineTo(px(x + 8f), py(60f)); p.close()
    }
    fun dome(x0: Float, x1: Float, top: Float, base: Float) {
        val cx = (x0 + x1) / 2f
        val q = (x1 - x0) * 0.25f
        p.moveTo(px(x0), py(60f)); p.lineTo(px(x0), py(base))
        p.cubicTo(px(x0), py(top + (base - top) * 0.2f), px(cx - q), py(top), px(cx), py(top))
        p.cubicTo(px(cx + q), py(top), px(x1), py(top + (base - top) * 0.2f), px(x1), py(base))
        p.lineTo(px(x1), py(60f)); p.close()
    }
    dome(150f, 210f, 8f, 38f); dome(90f, 130f, 26f, 44f); dome(230f, 270f, 26f, 44f)
    return p
}

// ============================================================ الواجهة العامة

/**
 * خلفية ثيم متحرك (غير «الطبيعة الحية» التي لها NatureBackdrop الأصلي).
 * [quality] 1 = كامل؛ المعاينات الصغيرة تستخدم أقل لتخفيف الحمل.
 */
@Composable
fun SceneBackdrop(id: ThemeId, motion: Int, modifier: Modifier = Modifier, quality: Float = 1f) {
    val spec = remember(id) { Palettes.spec(id, true) }
    val t: State<Float> = if (motion == 0) {
        remember { mutableStateOf(0.27f) }
    } else {
        rememberInfiniteTransition(label = "scene").animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(60_000, easing = LinearEasing)),
            label = "t",
        )
    }
    val q = if (motion == 1) quality * 0.55f else quality
    Box(
        modifier
            .fillMaxSize()
            .drawWithCache {
                val kit = Kit(size.width, size.height, density)
                onDrawBehind { drawScene(id, spec, kit, t.value, q) }
            },
    )
}

/** يختار الخلفية المناسبة للثيم: الأصلية للطبيعة الحية، المشاهد الجديدة للبقية، وساكنة للكلاسيكية. */
@Composable
fun ThemeBackdrop(id: ThemeId, motion: Int, hour: Int, modifier: Modifier = Modifier, quality: Float = 1f) {
    when {
        id == ThemeId.NATURE -> NatureBackdrop(Scenes.forHour(hour), motion == 0, motion >= 2, modifier)
        id.animated -> SceneBackdrop(id, motion, modifier, quality)
        else -> StaticBackdrop(modifier)
    }
}

private fun DrawScope.drawScene(id: ThemeId, p: PaletteSpec, k: Kit, t: Float, q: Float) {
    drawRect(Brush.verticalGradient(listOf(col(p.bgTop), col(p.bgBottom))))
    when (id) {
        ThemeId.PARADISE -> paradise(k, t, q)
        ThemeId.FAITH_NIGHT -> faithNight(k, t, q)
        ThemeId.ROYAL_GOLD -> royalGold(k, t, q)
        ThemeId.EMERALD_GLOW -> emeraldGlow(k, t, q)
        ThemeId.PACIFIC -> pacific(k, t, q)
        ThemeId.VIOLET_SKY -> violetSky(k, t, q)
        ThemeId.GALAXY -> galaxy(k, t, q)
        ThemeId.FAJR -> fajr(k, t, q)
        ThemeId.SUNSET -> sunset(k, t, q)
        ThemeId.CALM_RAIN -> calmRain(k, t, q)
        ThemeId.WATERFALL -> waterfall(k, t, q)
        ThemeId.GOLDEN_DESERT -> goldenDesert(k, t, q)
        ThemeId.MOON_CLOUDS -> moonClouds(k, t, q)
        ThemeId.CRYSTAL -> crystal(k, t, q)
        ThemeId.PEARL -> pearl(k, t, q)
        ThemeId.CALLIGRAPHY -> calligraphy(k, t, q, p)
        ThemeId.GEOMETRIC -> geometric(k, t, q)
        ThemeId.ROYAL_TURQUOISE -> royalTurquoise(k, t, q)
        ThemeId.NAVY_NIGHT -> navyNight(k, t, q)
        ThemeId.GLOW_GARDEN -> glowGarden(k, t, q)
        ThemeId.QUIET_SNOW -> quietSnow(k, t, q)
        ThemeId.DEEP_SPACE -> deepSpace(k, t, q)
        ThemeId.RAMADAN_LANTERNS -> ramadanLanterns(k, t, q)
        ThemeId.SPIRITUAL_DAWN -> spiritualDawn(k, t, q)
        ThemeId.AURORA -> aurora(k, t, q)
        ThemeId.ROYAL_MARBLE -> royalMarble(k, t, q)
        ThemeId.RAINY_SKY -> rainySky(k, t, q)
        ThemeId.SOFT_ROSE -> softRose(k, t, q)
        ThemeId.UNSEE_SPECIAL -> unseeSpecial(k, t, q)
        else -> {}
    }
    // طبقة وضوح خفيفة تحفظ قراءة النص فوق أي تأثير لامع
    drawRect(Brush.verticalGradient(listOf(col(p.bgTop).a(0.06f), col(p.bgBottom).a(0.16f))))
}

// ============================================================ أدوات الرسم المشتركة

private fun DrawScope.glow(center: Offset, r: Float, c: Color, a: Float) {
    if (a <= 0.004f || r <= 0f) return
    drawCircle(Brush.radialGradient(listOf(c.a(a), Color.Transparent), center = center, radius = r), radius = r, center = center)
}

private fun DrawScope.twinkle(k: Kit, n: Int, t: Float, c: Color, base: Float, maxY: Float, speed: Int, sizeMul: Float = 1f, off: Int = 0) {
    for (i in 0 until n) {
        val s = SEEDS[(i + off) % SEEDS.size]
        val tw = 0.5f + 0.5f * wave(t, (speed * s.k).toFloat(), s.ph)
        drawCircle(c.a(base * (0.2f + 0.8f * tw)), radius = (0.5f + s.s * 1.1f) * k.d * sizeMul, center = Offset(s.x * k.w, s.y * k.h * maxY))
    }
}

private fun DrawScope.sparkle(c: Offset, r: Float, color: Color, a: Float, width: Float) {
    drawLine(color.a(a), Offset(c.x - r, c.y), Offset(c.x + r, c.y), strokeWidth = width)
    drawLine(color.a(a), Offset(c.x, c.y - r), Offset(c.x, c.y + r), strokeWidth = width)
}

private fun DrawScope.stamp(path: Path, x: Float, y: Float, sx: Float, sy: Float, deg: Float, brushColor: Color, style: DrawStyle = Fill) {
    withTransform({
        translate(x, y)
        rotate(deg, Offset.Zero)
        scale(sx, sy, Offset.Zero)
    }) { drawPath(path, brushColor, style = style) }
}

private fun DrawScope.cloud(cx: Float, cy: Float, w: Float, h: Float, c: Color) {
    drawOval(c, Offset(cx - w / 2, cy - h / 2), Size(w, h))
    drawOval(c, Offset(cx - w * 0.30f, cy - h * 0.85f), Size(w * 0.5f, h * 1.1f))
    drawOval(c, Offset(cx - w * 0.02f, cy - h * 0.65f), Size(w * 0.42f, h * 0.9f))
}

private fun DrawScope.wavePath(k: Kit, base: Float, amp: Float, freq: Float, t: Float, speed: Float, ph: Float): Path {
    val p = Path()
    p.moveTo(0f, k.h)
    val steps = 28
    for (i in 0..steps) {
        val x = k.w * i / steps
        p.lineTo(x, base + amp * sin(TAU * (freq * i / steps + t * speed + ph)))
    }
    p.lineTo(k.w, k.h); p.close()
    return p
}

private fun DrawScope.rays(origin: Offset, n: Int, len: Float, width: Float, c: Color, a: Float, rotDeg: Float) {
    for (i in 0 until n) {
        val ang = (rotDeg + i * 360f / n) * PI.toFloat() / 180f
        drawLine(c.a(a), origin, Offset(origin.x + len * cos(ang), origin.y + len * sin(ang)), strokeWidth = width)
    }
}

private fun DrawScope.rainLayer(k: Kit, n: Int, t: Float, c: Color, a: Float, slant: Float, minLen: Float, maxLen: Float, base: Int) {
    for (i in 0 until n) {
        val s = SEEDS[(i * 3) % SEEDS.size]
        val y = fr(s.y + t * (base + s.k * 5)) * (k.h + 40f * k.d) - 20f * k.d
        val len = (minLen + (maxLen - minLen) * s.s) * k.d
        val x = s.x * k.w + slant * y * 0.12f
        drawLine(c.a(a * (0.5f + 0.5f * s.s)), Offset(x, y), Offset(x + slant * len * 0.12f, y + len), strokeWidth = (0.8f + s.s) * k.d)
    }
}

private fun DrawScope.ripples(k: Kit, n: Int, t: Float, c: Color, a: Float, yMin: Float, yMax: Float) {
    for (i in 0 until n) {
        val s = SEEDS[(i * 7 + 11) % SEEDS.size]
        val ph = fr(t * 6f + i / n.toFloat() + s.ph)
        val rw = (8f + 40f * ph) * k.d
        val cx = s.x * k.w
        val cy = k.h * (yMin + (yMax - yMin) * s.y)
        drawOval(c.a(a * (1f - ph)), Offset(cx - rw, cy - rw * 0.3f), Size(rw * 2f, rw * 0.6f), style = Stroke(width = k.d))
    }
}

// ============================================================ المشاهد (29)

/** 2) الجنة الخضراء: شمس هادئة بأشعة تدور ببطء + أوراق شجر تتساقط وتتمايل. */
private fun DrawScope.paradise(k: Kit, t: Float, q: Float) {
    val sc = Offset(k.w * 0.86f, k.h * 0.09f)
    glow(sc, k.w * 0.75f, col(0xFFFFE9A8), 0.26f + 0.05f * wave(t, 2f))
    rays(sc, 9, k.w * 1.3f, k.w * 0.05f, col(0xFFFFF3C4), 0.06f, 360f * t)
    drawCircle(col(0xFFFFF1B8).a(0.55f), radius = k.w * 0.045f, center = sc)
    for (i in 0 until cnt(14, q)) {
        val s = SEEDS[i]
        val y = fr(s.y + t * (1 + s.k)) * (k.h + 40f * k.d) - 20f * k.d
        val x = (s.x + 0.06f * wave(t, 2f * s.k, s.ph)) * k.w
        val tint = if (i % 3 == 0) col(0xFFB6F59A) else col(0xFF7FE0A0)
        stamp(k.leaf, x, y, (6f + 9f * s.s) * k.d, (6f + 9f * s.s) * k.d * 0.8f, 360f * (t * s.k + s.ph), tint.a(0.34f))
    }
    for (i in 0 until cnt(16, q)) {
        val s = SEEDS[100 + i]
        val y = 1f - fr(s.y + t * s.k)
        drawCircle(col(0xFFE8FFC8).a(0.18f + 0.2f * (0.5f + 0.5f * wave(t, 6f * s.k, s.ph))), radius = (1f + s.s * 1.6f) * k.d, center = Offset((s.x + 0.02f * wave(t, 2f, s.ph)) * k.w, y * k.h))
    }
}

/** 3) ليلة إيمانية: نجوم متلألئة بشرارات + هلال مضيء + شهاب عابر. */
private fun DrawScope.faithNight(k: Kit, t: Float, q: Float) {
    twinkle(k, cnt(90, q), t, col(0xFFFFF6DC), 0.95f, 0.75f, 12)
    for (i in 0 until cnt(9, q)) {
        val s = SEEDS[120 + i]
        val a = 0.25f + 0.55f * (0.5f + 0.5f * wave(t, 6f * s.k, s.ph))
        sparkle(Offset(s.x * k.w, s.y * k.h * 0.6f), (3f + 5f * s.s) * k.d, col(0xFFFFE9B0), a, k.d)
    }
    val c = Offset(k.w * 0.2f, k.h * 0.12f)
    glow(c, k.w * 0.3f, col(0xFFFFD36B), 0.22f + 0.08f * wave(t, 3f))
    stamp(k.crescent, c.x, c.y, 1f, 1f, -15f, col(0xFFFFE6A3).a(0.95f))
    val ph = fr(t * 4f)
    if (ph < 0.14f) {
        val pr = ph / 0.14f
        val head = Offset(k.w * (0.95f - 0.5f * pr), k.h * (0.05f + 0.28f * pr))
        val tail = Offset(head.x + k.w * 0.14f, head.y - k.h * 0.06f)
        drawLine(Brush.linearGradient(listOf(Color.Transparent, col(0xFFFFFFFF).a(0.9f * (1f - pr))), tail, head), tail, head, strokeWidth = 2f * k.d)
    }
}

/** 4) الذهب الملكي: شبكة نجوم ذهبية خافتة، انعكاس ضوء يعبر قطريًا، وبريق ذهبي. */
private fun DrawScope.royalGold(k: Kit, t: Float, q: Float) {
    val cell = 92f * k.d
    var row = 0
    var y = cell / 2
    while (y < k.h + cell) {
        var x = if (row % 2 == 0) cell / 2 else cell
        while (x < k.w + cell) {
            stamp(k.star8, x, y, cell * 0.30f, cell * 0.30f, 22.5f, col(0xFFF2C14E).a(0.11f), Stroke(width = 1.2f * k.d / (cell * 0.30f)))
            x += cell
        }
        y += cell / 2
        row++
    }
    val pos = fr(t * 2f) * (k.w * 1.8f) - k.w * 0.5f
    drawRect(Brush.linearGradient(listOf(Color.Transparent, col(0xFFFFE08A).a(0.20f), Color.Transparent), Offset(pos, 0f), Offset(pos + k.w * 0.45f, k.h * 0.45f)))
    for (i in 0 until cnt(26, q)) {
        val s = SEEDS[i + 30]
        val a = max(0f, wave(t, 3f * s.k, s.ph))
        if (a > 0.05f) sparkle(Offset(s.x * k.w, s.y * k.h), (2f + 5f * s.s) * k.d * a, col(0xFFFFDB85), 0.8f * a, k.d)
    }
}

/** 5) الزمرد الإسلامي: جزيئات خضراء ناعمة (بوكيه) تصعد مع توهج زمردي نابض. */
private fun DrawScope.emeraldGlow(k: Kit, t: Float, q: Float) {
    glow(Offset(k.w * 0.5f, k.h * 1.02f), k.w * 1.0f, col(0xFF2EE6A8), 0.30f + 0.08f * wave(t, 3f))
    for (i in 0 until cnt(22, q)) {
        val s = SEEDS[i]
        val y = 1f - fr(s.y + t * s.k)
        val x = (s.x + 0.03f * wave(t, 2f, s.ph)) * k.w
        val r = (8f + 26f * s.s) * k.d
        val fade = sin(PI.toFloat() * (1f - y))
        glow(Offset(x, y * k.h), r, if (i % 2 == 0) col(0xFF7DFFD2) else col(0xFF3FE0A0), 0.22f * fade)
    }
}

/** 6) المحيط الهادئ: ثلاث طبقات أمواج تتحرك باتجاهات مختلفة، وخيوط ضوء مائية. */
private fun DrawScope.pacific(k: Kit, t: Float, q: Float) {
    glow(Offset(k.w * 0.2f, -k.h * 0.05f), k.w * 1.0f, col(0xFFBDEBFF), 0.22f)
    for (i in 0 until cnt(7, q)) {
        val s = SEEDS[i + 40]
        val x = (s.x + 0.08f * wave(t, 2f, s.ph)) * k.w
        drawLine(col(0xFFE6FAFF).a(0.05f + 0.04f * wave(t, 3f, s.ph)), Offset(x, 0f), Offset(x + k.w * 0.25f, k.h * 0.55f), strokeWidth = k.w * 0.03f)
    }
    drawPath(wavePath(k, k.h * 0.58f, k.h * 0.018f, 1.6f, t, 1f, 0.0f), col(0xFF5BC8F5).a(0.20f))
    drawPath(wavePath(k, k.h * 0.67f, k.h * 0.022f, 1.2f, t, -2f, 0.3f), col(0xFF2E9BD6).a(0.28f))
    drawPath(wavePath(k, k.h * 0.78f, k.h * 0.026f, 0.9f, t, 3f, 0.6f), col(0xFF0B4F7A).a(0.40f))
    for (i in 0 until cnt(10, q)) {
        val s = SEEDS[i + 60]
        val a = max(0f, wave(t, 4f * s.k, s.ph))
        if (a > 0.1f) drawCircle(col(0xFFFFFFFF).a(0.6f * a), radius = 1.6f * k.d, center = Offset(s.x * k.w, k.h * (0.58f + 0.05f * s.y)))
    }
}

/** 7) السماء البنفسجية: غيوم ضوئية ناعمة تعبر ببطء ونجوم خافتة. */
private fun DrawScope.violetSky(k: Kit, t: Float, q: Float) {
    twinkle(k, cnt(55, q), t, col(0xFFF5EDFF), 0.8f, 0.8f, 10, off = 20)
    for (i in 0 until 6) {
        val s = SEEDS[i + 90]
        val x = (fr(s.x + t * (1 + i % 2)) * 1.5f - 0.25f) * k.w
        val y = k.h * (0.10f + 0.65f * s.y)
        val r = k.w * (0.28f + 0.22f * s.s)
        glow(Offset(x, y), r, if (i % 2 == 0) col(0xFFE08AFF) else col(0xFF9C7BFF), 0.20f)
    }
}

/** 8) المجرة: ذراعان حلزونيان من النجوم تدور حول نواة مضيئة مع نجوم خلفية بعمق بصري. */
private fun DrawScope.galaxy(k: Kit, t: Float, q: Float) {
    twinkle(k, cnt(60, q), t, col(0xFFFFFFFF), 0.7f, 1f, 8, off = 50)
    val c = Offset(k.w * 0.5f, k.h * 0.36f)
    glow(c, k.w * 0.55f, col(0xFF8F6BFF), 0.28f)
    glow(c, k.w * 0.16f, col(0xFFFFE9C8), 0.40f)
    val n = cnt(90, q)
    for (arm in 0 until 2) {
        for (i in 0 until n) {
            val f = i / n.toFloat()
            val r = f.pow(0.7f) * k.w * 0.72f
            val ang = arm * PI.toFloat() + f * 5.2f + TAU * t
            val s = SEEDS[(i + arm * 37) % SEEDS.size]
            val x = c.x + r * cos(ang) + (s.x - 0.5f) * k.w * 0.06f
            val y = c.y + r * sin(ang) * 0.55f + (s.y - 0.5f) * k.w * 0.04f
            val tint = if (f < 0.35f) col(0xFFFFF0D0) else if (f < 0.7f) col(0xFFB9A6FF) else col(0xFF7FA8FF)
            drawCircle(tint.a(0.55f - 0.25f * f), radius = (0.6f + 1.4f * (1f - f) * s.s) * k.d, center = Offset(x, y))
        }
    }
}

/** 9) الفجر: شمس تتنفّس فوق الأفق، تدرّج شروق دافئ، أشعة تتمايل، وغيوم رقيقة. */
private fun DrawScope.fajr(k: Kit, t: Float, q: Float) {
    val horizon = k.h * 0.80f
    val sc = Offset(k.w * 0.5f, horizon - k.h * 0.08f + k.h * 0.012f * wave(t, 1f))
    drawRect(Brush.verticalGradient(listOf(Color.Transparent, col(0xFFFFB27A).a(0.30f + 0.06f * wave(t, 2f))), startY = k.h * 0.35f, endY = horizon))
    glow(sc, k.w * 0.9f, col(0xFFFFD08A), 0.40f)
    for (i in 0 until 9) {
        val ang = (-170f + i * 20f + 6f * wave(t, 2f, i * 0.1f)) * PI.toFloat() / 180f
        drawLine(col(0xFFFFE2B0).a(0.07f), sc, Offset(sc.x + k.w * 1.3f * cos(ang), sc.y + k.w * 1.3f * sin(ang)), strokeWidth = k.w * 0.045f)
    }
    drawCircle(col(0xFFFFE8B0).a(0.9f), radius = k.w * 0.075f, center = sc)
    twinkle(k, cnt(18, q), t, col(0xFFFFFFFF), 0.4f, 0.35f, 6, off = 10)
    for (i in 0 until 3) {
        val x = (fr(t * 1f + i * 0.37f) * 1.4f - 0.2f) * k.w
        cloud(x, k.h * (0.22f + 0.13f * i), k.w * (0.4f + 0.06f * i), k.h * 0.03f, col(0xFFFFC9D8).a(0.16f))
    }
}

/** 10) الغروب: شمس كبيرة تغوص في الأفق، شرائط لون دافئة، انعكاس متلألئ، وطيور تعبر. */
private fun DrawScope.sunset(k: Kit, t: Float, q: Float) {
    val horizon = k.h * 0.72f
    val sc = Offset(k.w * 0.5f, horizon)
    glow(sc, k.w * 1.0f, col(0xFFFF9A52), 0.40f + 0.06f * wave(t, 2f))
    for (i in 0 until 4) {
        val y = horizon - k.h * (0.05f + 0.07f * i) + k.h * 0.006f * wave(t, 2f, i * 0.2f)
        drawRect(col(0xFFFFB86B).a(0.07f), Offset(0f, y), Size(k.w, k.h * 0.035f))
    }
    drawArc(col(0xFFFFD39A).a(0.95f), 180f, 180f, true, Offset(sc.x - k.w * 0.2f, sc.y - k.w * 0.2f), Size(k.w * 0.4f, k.w * 0.4f))
    drawRect(col(0xFF1B0F2E).a(0.55f), Offset(0f, horizon), Size(k.w, k.h - horizon))
    for (i in 0 until 8) {
        val wdt = k.w * (0.34f - 0.03f * i) * (0.85f + 0.15f * wave(t, 6f, i * 0.13f))
        drawRect(col(0xFFFFC27A).a(0.30f - 0.03f * i), Offset(sc.x - wdt / 2, horizon + k.h * 0.012f * (i + 1)), Size(wdt, 2f * k.d))
    }
    for (i in 0 until cnt(5, q)) {
        val s = SEEDS[i + 20]
        val x = (1.1f - fr(t * 2f + s.x) * 1.3f) * k.w
        val y = k.h * (0.2f + 0.2f * s.y) + 5f * k.d * wave(t, 12f, s.ph)
        val flap = 5f * k.d * wave(t, 40f, s.ph)
        val c = col(0xFF2A1238).a(0.65f)
        drawLine(c, Offset(x - 8f * k.d, y - flap), Offset(x, y), strokeWidth = 1.5f * k.d)
        drawLine(c, Offset(x + 8f * k.d, y - flap), Offset(x, y), strokeWidth = 1.5f * k.d)
    }
}

/** 11) المطر الهادئ: قطرات مائلة خفيفة، دوائر انعكاس على الأرض، وضباب منخفض. */
private fun DrawScope.calmRain(k: Kit, t: Float, q: Float) {
    glow(Offset(k.w * 0.5f, 0f), k.w * 0.9f, col(0xFF9CC9E8), 0.12f)
    rainLayer(k, cnt(70, q), t, col(0xFFBFE3FF), 0.30f, 1.2f, 12f, 26f, 22)
    ripples(k, cnt(7, q), t, col(0xFFD6EEFF), 0.40f, 0.72f, 0.95f)
    drawRect(Brush.verticalGradient(listOf(Color.Transparent, col(0xFFBFD8EA).a(0.10f)), startY = k.h * 0.7f, endY = k.h))
}

/** 12) الشلال: خيوط ماء متساقطة بسرعات مختلفة، منحدرات صخرية على الجانبين، ورذاذ في الأسفل. */
private fun DrawScope.waterfall(k: Kit, t: Float, q: Float) {
    drawPath(k.cliffL, col(0xFF031A1C).a(0.55f))
    drawPath(k.cliffR, col(0xFF031A1C).a(0.55f))
    for (i in 0 until cnt(55, q)) {
        val s = SEEDS[i]
        val x = k.w * (0.34f + 0.32f * s.x)
        val y = fr(s.y + t * (18 + s.k * 6)) * k.h
        val len = (30f + 70f * s.s) * k.d
        drawLine(col(0xFFE6FFFC).a(0.10f + 0.22f * s.s), Offset(x, y), Offset(x, y + len), strokeWidth = (1f + 2f * s.s) * k.d)
    }
    for (i in 0 until 5) {
        val r = k.w * (0.16f + 0.05f * i) * (1f + 0.06f * wave(t, 4f, i * 0.2f))
        glow(Offset(k.w * (0.38f + 0.06f * i), k.h * 0.97f), r, col(0xFFD6FFFA), 0.16f)
    }
}

/** 13) الصحراء الذهبية: كثبان بطبقات تنساب ببطء، شمس منخفضة، ورمال تهبّ أفقيًا. */
private fun DrawScope.goldenDesert(k: Kit, t: Float, q: Float) {
    val sc = Offset(k.w * 0.72f, k.h * 0.40f)
    glow(sc, k.w * 0.9f, col(0xFFFFB45A), 0.38f)
    drawCircle(col(0xFFFFD99A).a(0.85f), radius = k.w * 0.09f, center = sc)
    drawPath(wavePath(k, k.h * 0.62f, k.h * 0.030f, 0.9f, t, 1f, 0.1f), col(0xFFB8742A).a(0.45f))
    drawPath(wavePath(k, k.h * 0.74f, k.h * 0.036f, 0.8f, t, -1f, 0.5f), col(0xFF8A4E18).a(0.60f))
    drawPath(wavePath(k, k.h * 0.88f, k.h * 0.030f, 1.1f, t, 2f, 0.8f), col(0xFF5A300E).a(0.70f))
    for (i in 0 until cnt(40, q)) {
        val s = SEEDS[i + 20]
        val x = (1.05f - fr(s.x + t * (3 + s.k))) * k.w
        val y = k.h * (0.55f + 0.4f * s.y) + 6f * k.d * wave(t, 6f * s.k, s.ph)
        drawCircle(col(0xFFFFE0A8).a(0.30f), radius = (0.8f + s.s * 1.4f) * k.d, center = Offset(x, y))
    }
}

/** 14) القمر والسحاب: قمر كبير بهالة وفوهات، وسحب تعبر أمامه ببطء. */
private fun DrawScope.moonClouds(k: Kit, t: Float, q: Float) {
    twinkle(k, cnt(45, q), t, col(0xFFF2F5FF), 0.8f, 0.7f, 10, off = 80)
    val mc = Offset(k.w * 0.68f, k.h * 0.20f)
    glow(mc, k.w * 0.55f, col(0xFFFFF2CC), 0.32f + 0.05f * wave(t, 2f))
    drawCircle(col(0xFFFFF1CC).a(0.96f), radius = k.w * 0.13f, center = mc)
    drawCircle(col(0xFFE6D6A8).a(0.35f), radius = k.w * 0.03f, center = Offset(mc.x - k.w * 0.04f, mc.y - k.w * 0.03f))
    drawCircle(col(0xFFE6D6A8).a(0.30f), radius = k.w * 0.02f, center = Offset(mc.x + k.w * 0.05f, mc.y + k.w * 0.02f))
    drawCircle(col(0xFFE6D6A8).a(0.25f), radius = k.w * 0.015f, center = Offset(mc.x - k.w * 0.01f, mc.y + k.w * 0.06f))
    for (i in 0 until 5) {
        val sp = 1 + i % 2
        val x = (fr(t * sp + i * 0.21f) * 1.6f - 0.3f) * k.w
        val y = k.h * (0.12f + 0.11f * i)
        cloud(x, y, k.w * (0.5f + 0.1f * (i % 3)), k.h * 0.035f, col(0xFFC9D6F2).a(0.20f))
    }
}

/** 15) الزجاج البلوري (فاتح): شظايا شفافة تتنفس، لمعة قطرية تعبر، وفقاعات صاعدة. */
private fun DrawScope.crystal(k: Kit, t: Float, q: Float) {
    for (i in 0 until 9) {
        val s = SEEDS[i + 5]
        val cx = s.x * k.w
        val cy = s.y * k.h
        val r = k.w * (0.18f + 0.22f * s.s)
        val a = 0.10f + 0.10f * (0.5f + 0.5f * wave(t, 2f, s.ph))
        val path = Path().apply {
            moveTo(cx, cy - r); lineTo(cx + r * 0.9f, cy + r * 0.5f); lineTo(cx - r * 0.7f, cy + r * 0.7f); close()
        }
        drawPath(path, col(0xFF7FB8E0).a(a))
        drawPath(path, col(0xFFFFFFFF).a(0.45f), style = Stroke(width = 1.2f * k.d))
    }
    val pos = fr(t * 2f) * (k.w * 1.8f) - k.w * 0.5f
    drawRect(Brush.linearGradient(listOf(Color.Transparent, col(0xFFFFFFFF).a(0.50f), Color.Transparent), Offset(pos, 0f), Offset(pos + k.w * 0.4f, k.h * 0.4f)))
    for (i in 0 until cnt(14, q)) {
        val s = SEEDS[i + 70]
        val y = 1f - fr(s.y + t * s.k)
        val x = (s.x + 0.02f * wave(t, 2f, s.ph)) * k.w
        val r = (3f + 7f * s.s) * k.d
        drawCircle(col(0xFFFFFFFF).a(0.45f), radius = r, center = Offset(x, y * k.h), style = Stroke(width = k.d))
        drawCircle(col(0xFFFFFFFF).a(0.7f), radius = r * 0.25f, center = Offset(x - r * 0.4f, y * k.h - r * 0.4f))
    }
}

/** 16) اللؤلؤ (فاتح): بقع قوس قزحية ناعمة تتحرك بمسارات ليساجو ولمعة تعبر وبريق دقيق. */
private fun DrawScope.pearl(k: Kit, t: Float, q: Float) {
    val tints = listOf(col(0xFFFFC9E3), col(0xFFB8F0FF), col(0xFFD9C8FF), col(0xFFFFE3C8))
    for (i in 0 until 4) {
        val cx = k.w * (0.5f + 0.28f * wave(t, 1f, i * 0.25f))
        val cy = k.h * (0.25f + 0.2f * i + 0.08f * wave(t, 2f, i * 0.3f))
        glow(Offset(cx, cy), k.w * 0.62f, tints[i], 0.55f)
    }
    val pos = fr(t * 1f) * (k.w * 1.8f) - k.w * 0.5f
    drawRect(Brush.linearGradient(listOf(Color.Transparent, col(0xFFFFFFFF).a(0.45f), Color.Transparent), Offset(pos, 0f), Offset(pos + k.w * 0.5f, k.h * 0.3f)))
    for (i in 0 until cnt(22, q)) {
        val s = SEEDS[i + 15]
        val a = max(0f, wave(t, 3f * s.k, s.ph))
        if (a > 0.1f) drawCircle(col(0xFFB98AB0).a(0.55f * a), radius = (1f + 1.6f * s.s) * k.d, center = Offset(s.x * k.w, s.y * k.h))
    }
}

/** 17) الخط العربي: عبارات ذكر كبيرة بالخط الأميري/النسخ تطفو للأعلى وتتلاشى، مع حلقة زخرفية متقطعة تدور. */
private fun DrawScope.calligraphy(k: Kit, t: Float, q: Float, p: PaletteSpec) {
    val gold = col(p.accent)
    val phrases = listOf("سبحان الله", "الحمد لله", "الله أكبر", "لا إله إلا الله", "أستغفر الله", "لا حول ولا قوة إلا بالله", "سبحان الله وبحمده")
    val c = Offset(k.w * 0.5f, k.h * 0.30f)
    drawCircle(gold.a(0.10f), radius = k.w * 0.42f, center = c, style = Stroke(width = 1.5f * k.d, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f * k.d, 14f * k.d), 360f * t)))
    drawCircle(gold.a(0.07f), radius = k.w * 0.34f, center = c, style = Stroke(width = k.d))
    val n = cnt(phrases.size, if (q < 0.7f) 0.6f else 1f)
    drawIntoCanvas { cv ->
        val nc = cv.nativeCanvas
        for (i in 0 until n) {
            val s = SEEDS[i * 9 + 4]
            val frac = fr(s.y + t * 1f)
            val y = k.h * (1.05f - 1.1f * frac)
            val x = k.w * (0.2f + 0.6f * s.x)
            val alpha = 0.05f + 0.10f * sin(PI.toFloat() * frac)
            k.text.color = android.graphics.Color.argb((alpha * 255).toInt(), (gold.red * 255).toInt(), (gold.green * 255).toInt(), (gold.blue * 255).toInt())
            k.text.textSize = k.w * (0.09f + 0.07f * s.s)
            nc.save()
            nc.rotate(-8f + 16f * s.ph, x, y)
            nc.drawText(phrases[i % phrases.size], x, y, k.text)
            nc.restore()
        }
    }
}

/** 18) النقوش الهندسية: شبكة نجوم ثمانية تدور بعكس بعضها وتنبض بسلاسة. */
private fun DrawScope.geometric(k: Kit, t: Float, q: Float) {
    val cell = k.w / 4f
    var row = 0
    var y = cell / 2
    while (y < k.h + cell) {
        for (cx in 0 until 4) {
            val x = cell / 2 + cx * cell
            val dir = if ((row + cx) % 2 == 0) 1f else -1f
            val pulse = 0.5f + 0.06f * wave(t, 3f, (row + cx) * 0.07f)
            stamp(k.star8, x, y, cell * pulse, cell * pulse, dir * 360f * t, col(0xFFFFC857).a(0.24f), Stroke(width = 1.4f * k.d / (cell * pulse)))
            if (q > 0.6f) stamp(k.star8, x, y, cell * pulse * 0.52f, cell * pulse * 0.52f, -dir * 720f * t, col(0xFF7FE8E0).a(0.20f), Stroke(width = 1.2f * k.d / (cell * pulse * 0.52f)))
        }
        y += cell
        row++
    }
}

/** 19) الفيروز الملكي: بقع فيروزية تتحرك كمصباح حمم ناعم مع حزم ضوء قطرية تتمايل. */
private fun DrawScope.royalTurquoise(k: Kit, t: Float, q: Float) {
    for (i in 0 until 5) {
        val cx = k.w * (0.5f + 0.34f * wave(t, 1f, i * 0.2f))
        val cy = k.h * (0.2f + 0.16f * i + 0.07f * wave(t, 2f, i * 0.17f))
        glow(Offset(cx, cy), k.w * 0.6f, if (i % 2 == 0) col(0xFF3DE8E0) else col(0xFF1FA7C9), 0.36f)
    }
    for (i in 0 until 3) {
        val x = k.w * (0.15f + 0.3f * i) + k.w * 0.06f * wave(t, 2f, i * 0.3f)
        drawLine(col(0xFFBFFFF8).a(0.06f), Offset(x, 0f), Offset(x + k.w * 0.4f, k.h * 0.7f), strokeWidth = k.w * 0.08f)
    }
    for (i in 0 until cnt(14, q)) {
        val s = SEEDS[i + 33]
        drawCircle(col(0xFFD6FFFA).a(0.25f), radius = (1f + 1.5f * s.s) * k.d, center = Offset(s.x * k.w, (1f - fr(s.y + t * s.k)) * k.h))
    }
}

/** 20) الليل الكحلي: نجوم دقيقة فضية كثيفة، نجوم لامعة بأربع شعاب، وشهب فضية خاطفة. */
private fun DrawScope.navyNight(k: Kit, t: Float, q: Float) {
    twinkle(k, cnt(150, q), t, col(0xFFDDE5F5), 0.9f, 0.95f, 6, sizeMul = 0.6f, off = 3)
    for (i in 0 until 4) {
        val s = SEEDS[i + 140]
        sparkle(Offset(s.x * k.w, s.y * k.h * 0.5f), (5f + 5f * s.s) * k.d, col(0xFFFFFFFF), 0.45f + 0.35f * (0.5f + 0.5f * wave(t, 3f, s.ph)), 1.2f * k.d)
    }
    glow(Offset(k.w * 0.5f, k.h * 1.05f), k.w * 1.0f, col(0xFFC9D6EE), 0.10f)
    for (j in 0 until 2) {
        val ph = fr(t * 6f + j * 0.5f)
        if (ph < 0.09f) {
            val pr = ph / 0.09f
            val head = Offset(k.w * (0.85f - 0.4f * pr - 0.2f * j), k.h * (0.08f + 0.25f * pr + 0.12f * j))
            val tail = Offset(head.x + k.w * 0.16f, head.y - k.h * 0.05f)
            drawLine(Brush.linearGradient(listOf(Color.Transparent, col(0xFFE6EEFF).a(0.9f * (1f - pr))), tail, head), tail, head, strokeWidth = 1.6f * k.d)
        }
    }
}

/** 21) الحديقة المضيئة: يراعات تتجول وتنبض بضوء أخضر مصفر، وأعشاب تتمايل في الأسفل. */
private fun DrawScope.glowGarden(k: Kit, t: Float, q: Float) {
    val grass = col(0xFF020D07).a(0.75f)
    for (i in 0 until cnt(46, q)) {
        val s = SEEDS[i + 10]
        val x = s.x * k.w
        val len = (22f + 40f * s.s) * k.d
        val sway = 7f * k.d * wave(t, 3f, s.ph)
        drawLine(grass, Offset(x, k.h + 2f), Offset(x + sway, k.h - len), strokeWidth = 2.2f * k.d)
    }
    for (i in 0 until cnt(22, q)) {
        val s = SEEDS[i]
        val x = (s.x + 0.07f * wave(t, s.k.toFloat(), s.ph)) * k.w
        val y = (0.25f + 0.65f * s.y + 0.04f * wave(t, (s.k + 1).toFloat(), s.ph * 2f)) * k.h
        val pulse = max(0f, wave(t, 6f * s.k, s.ph)).pow(2)
        glow(Offset(x, y), (12f + 14f * s.s) * k.d, col(0xFFE6F25A), 0.55f * pulse)
        drawCircle(col(0xFFFFFFC8).a(0.25f + 0.7f * pulse), radius = 1.6f * k.d, center = Offset(x, y))
    }
}

/** 22) الثلج الهادئ (فاتح): رقاقات تتساقط وتتمايل بأحجام متعددة فوق جبال زرقاء ناعمة. */
private fun DrawScope.quietSnow(k: Kit, t: Float, q: Float) {
    drawPath(k.mountA, col(0xFFBFD3E6).a(0.60f))
    drawPath(k.mountB, col(0xFFA9C4DC).a(0.55f))
    for (i in 0 until cnt(60, q)) {
        val s = SEEDS[i]
        val y = fr(s.y + t * (2 + s.k)) * (k.h + 20f * k.d) - 10f * k.d
        val x = (s.x + 0.04f * wave(t, 2f * s.k, s.ph)) * k.w
        val r = (1.2f + 3f * s.s) * k.d
        drawCircle(col(0xFFFFFFFF).a(0.95f), radius = r, center = Offset(x, y))
        drawCircle(col(0xFF8FB8D8).a(0.45f), radius = r, center = Offset(x, y), style = Stroke(width = 0.8f * k.d))
    }
}

/** 23) الفضاء العميق: نجوم تنطلق من المركز بإحساس عمق، وسدم ملوّنة تتحول ببطء. */
private fun DrawScope.deepSpace(k: Kit, t: Float, q: Float) {
    val tints = listOf(col(0xFFFF5FA2), col(0xFF5F7BFF), col(0xFF9B5FFF), col(0xFF3FD0FF))
    for (i in 0 until 4) {
        val cx = k.w * (0.5f + 0.3f * wave(t, 1f, i * 0.25f))
        val cy = k.h * (0.25f + 0.17f * i + 0.06f * wave(t, 2f, i * 0.2f))
        glow(Offset(cx, cy), k.w * 0.55f, tints[i], 0.24f)
    }
    val c = Offset(k.w * 0.5f, k.h * 0.45f)
    for (i in 0 until cnt(80, q)) {
        val s = SEEDS[i]
        val p = fr(s.x + t * (1 + s.k))
        val r = p * p * k.w * 1.0f
        val ang = s.ph * TAU
        val pos = Offset(c.x + r * cos(ang), c.y + r * 1.4f * sin(ang))
        drawCircle(col(0xFFFFFFFF).a(0.15f + 0.8f * p), radius = (0.5f + 1.8f * p) * k.d, center = pos)
    }
}

/** 24) الفوانيس الرمضانية: فوانيس معلّقة تتأرجح كالبندول بتوهج متذبذب ونجوم صغيرة. */
private fun DrawScope.ramadanLanterns(k: Kit, t: Float, q: Float) {
    twinkle(k, cnt(35, q), t, col(0xFFFFE9B0), 0.7f, 0.6f, 8, off = 100)
    val xs = floatArrayOf(0.12f, 0.31f, 0.54f, 0.77f, 0.92f)
    val ropes = floatArrayOf(0.07f, 0.15f, 0.05f, 0.12f, 0.09f)
    val sizes = floatArrayOf(0.9f, 1.15f, 1.0f, 1.2f, 0.85f)
    for (i in 0 until 5) {
        val top = Offset(k.w * xs[i], 0f)
        val swing = (4f + 2f * (i % 2)) * wave(t, (3 + i % 3).toFloat(), i * 0.2f)
        val ropeLen = k.h * ropes[i]
        val sz = sizes[i] * k.d
        withTransform({ rotate(swing, top) }) {
            drawLine(col(0xFFE2B857).a(0.7f), top, Offset(top.x, ropeLen), strokeWidth = 1.4f * k.d)
            val bodyW = 26f * sz
            val bodyH = 40f * sz
            val flick = 0.40f + 0.12f * wave(t, 11f, i * 0.31f) + 0.05f * wave(t, 23f, i * 0.17f)
            glow(Offset(top.x, ropeLen + bodyH * 0.6f), 58f * sz, col(0xFFFFB84D), flick)
            val cap = Path().apply {
                moveTo(top.x - bodyW * 0.35f, ropeLen + 5f * sz); lineTo(top.x, ropeLen - 4f * sz); lineTo(top.x + bodyW * 0.35f, ropeLen + 5f * sz); close()
            }
            drawPath(cap, col(0xFFE2B857))
            drawRoundRect(
                Brush.verticalGradient(listOf(col(0xFFFFE6A3), col(0xFFF2A93B), col(0xFFB8741B)), startY = ropeLen, endY = ropeLen + bodyH),
                topLeft = Offset(top.x - bodyW / 2, ropeLen + 5f * sz), size = Size(bodyW, bodyH), cornerRadius = CornerRadius(7f * sz),
            )
            drawRoundRect(col(0xFFFFF6D0).a(0.55f + 0.25f * wave(t, 11f, i * 0.31f)), Offset(top.x - bodyW * 0.28f, ropeLen + 11f * sz), Size(bodyW * 0.56f, bodyH * 0.6f), CornerRadius(5f * sz))
            drawCircle(col(0xFFE2B857), radius = 3.2f * sz, center = Offset(top.x, ropeLen + bodyH + 8f * sz))
        }
    }
}

/** 25) الفجر الروحاني (فاتح): أفق مضيء يتنفس، حزم نور تتمايل من الأسفل، وغيوم شاحبة. */
private fun DrawScope.spiritualDawn(k: Kit, t: Float, q: Float) {
    val c = Offset(k.w * 0.5f, k.h * 0.92f)
    drawRect(Brush.verticalGradient(listOf(Color.Transparent, col(0xFFFFC27A).a(0.45f + 0.08f * wave(t, 2f))), startY = k.h * 0.45f, endY = k.h))
    glow(c, k.w * 1.0f, col(0xFFFFD9A0), 0.55f)
    for (i in 0 until 7) {
        val ang = (-150f + i * 20f + 5f * wave(t, 2f, i * 0.12f)) * PI.toFloat() / 180f
        drawLine(col(0xFFFFF2D6).a(0.20f), c, Offset(c.x + k.h * 1.1f * cos(ang), c.y + k.h * 1.1f * sin(ang)), strokeWidth = k.w * 0.07f)
    }
    for (i in 0 until 4) {
        val x = (fr(t * (1 + i % 2) + i * 0.27f) * 1.5f - 0.25f) * k.w
        cloud(x, k.h * (0.14f + 0.12f * i), k.w * 0.45f, k.h * 0.03f, col(0xFFFFFFFF).a(0.65f))
    }
    twinkle(k, cnt(10, q), t, col(0xFFE08A4E), 0.5f, 0.3f, 6, off = 6)
}

/** 26) الشفق القطبي: ستائر ضوء خضراء وفيروزية تتموج، مع خطوط عمودية متلألئة ونجوم. */
private fun DrawScope.aurora(k: Kit, t: Float, q: Float) {
    twinkle(k, cnt(50, q), t, col(0xFFFFFFFF), 0.8f, 0.7f, 8, off = 60)
    val tints = listOf(col(0xFF6BFFB8), col(0xFF3FE0D0), col(0xFF8F7BFF))
    for (i in 0 until 3) {
        val base = k.h * (0.14f + 0.10f * i)
        val bandH = k.h * (0.34f - 0.04f * i)
        val path = Path()
        val steps = 24
        for (j in 0..steps) {
            val x = k.w * j / steps
            val y = base + k.h * 0.05f * sin(TAU * (1.4f * j / steps + t * (i + 1) + i * 0.3f))
            if (j == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        for (j in steps downTo 0) {
            val x = k.w * j / steps
            val y = base + bandH * (0.8f + 0.2f * sin(TAU * (2f * j / steps + t * 2f + i * 0.5f))) + k.h * 0.05f * sin(TAU * (1.4f * j / steps + t * (i + 1) + i * 0.3f))
            path.lineTo(x, y)
        }
        path.close()
        drawPath(path, Brush.verticalGradient(listOf(tints[i].a(0.50f), tints[i].a(0.18f), Color.Transparent), startY = base, endY = base + bandH))
        if (q > 0.6f) for (j in 0 until 26) {
            val x = k.w * (j + 0.5f) / 26f
            val y = base + k.h * 0.05f * sin(TAU * (1.4f * (j + 0.5f) / 26f + t * (i + 1) + i * 0.3f))
            val a = 0.04f + 0.05f * (0.5f + 0.5f * wave(t, 4f, j * 0.09f + i * 0.2f))
            drawLine(tints[i].a(a), Offset(x, y), Offset(x, y + bandH * 0.7f), strokeWidth = k.w * 0.012f)
        }
    }
}

/** 27) الرخام الملكي (فاتح): عروق رخامية رمادية وذهبية تنساب ببطء ولمعة فاخرة تعبر. */
private fun DrawScope.royalMarble(k: Kit, t: Float, q: Float) {
    for (i in k.veins.indices) {
        val dx = k.w * 0.015f * wave(t, 1f, i * 0.14f)
        val gold = i % 3 == 0
        withTransform({ translate(dx, 0f) }) {
            drawPath(
                k.veins[i],
                if (gold) col(0xFFC4A24D).a(0.34f) else col(0xFF8C8680).a(0.20f + 0.05f * wave(t, 2f, i * 0.1f)),
                style = Stroke(width = (if (gold) 1.6f else 1.1f + (i % 2)) * k.d),
            )
        }
    }
    val pos = fr(t * 1f) * (k.w * 1.8f) - k.w * 0.5f
    drawRect(Brush.linearGradient(listOf(Color.Transparent, col(0xFFFFFFFF).a(0.60f), Color.Transparent), Offset(pos, 0f), Offset(pos + k.w * 0.5f, k.h * 0.35f)))
    for (i in 0 until cnt(18, q)) {
        val s = SEEDS[i + 44]
        val a = max(0f, wave(t, 3f * s.k, s.ph))
        if (a > 0.1f) drawCircle(col(0xFFC4A24D).a(0.7f * a), radius = (1f + 1.5f * s.s) * k.d, center = Offset(s.x * k.w, s.y * k.h))
    }
}

/** 28) السماء الممطرة: طبقات سحب داكنة تتحرك بسرعات مختلفة، مطر مائل أكثف، وتوهج خلف الغيوم. */
private fun DrawScope.rainySky(k: Kit, t: Float, q: Float) {
    glow(Offset(k.w * 0.5f, k.h * 0.05f), k.w * 0.8f, col(0xFF9DB5CC), 0.14f + 0.04f * wave(t, 3f))
    for (row in 0 until 3) {
        for (i in 0 until 3) {
            val x = (fr(t * (row + 1) + i * 0.33f + row * 0.1f) * 1.5f - 0.25f) * k.w
            val y = k.h * (0.06f + 0.09f * row)
            cloud(x, y, k.w * (0.55f + 0.1f * row), k.h * 0.05f, (if (row == 1) col(0xFF6E8396) else col(0xFF0F1822)).a(if (row == 1) 0.30f else 0.42f))
        }
    }
    rainLayer(k, cnt(65, q), t, col(0xFFCFE3F5), 0.28f, 2.4f, 16f, 30f, 28)
    ripples(k, cnt(5, q), t, col(0xFFCFE3F5), 0.35f, 0.82f, 0.97f)
}

/** 29) الورد الهادئ (فاتح): بتلات وردية تتساقط وتتقلّب بأبعاد ثلاثية وبوكيه وردي ناعم. */
private fun DrawScope.softRose(k: Kit, t: Float, q: Float) {
    for (i in 0 until 6) {
        val s = SEEDS[i + 120]
        glow(Offset(s.x * k.w, s.y * k.h), k.w * (0.2f + 0.15f * s.s), col(0xFFF4A6BB), 0.18f + 0.05f * wave(t, 2f, s.ph))
    }
    val tints = listOf(col(0xFFF4A6BB), col(0xFFE87A9B), col(0xFFFFC4D2))
    for (i in 0 until cnt(18, q)) {
        val s = SEEDS[i]
        val y = fr(s.y + t * (1 + s.k)) * (k.h + 40f * k.d) - 20f * k.d
        val x = (s.x + 0.07f * wave(t, 2f * s.k, s.ph)) * k.w
        val flip = 0.35f + 0.65f * abs(cos(TAU * (t * 3f * s.k + s.ph)))
        val size = (7f + 8f * s.s) * k.d
        stamp(k.petal, x, y, size * 0.6f * flip, size, 360f * (t * s.k + s.ph), tints[i % 3].a(0.78f))
    }
}

/** 30) أُنسي الخاص: نجمة هندسية ضخمة تدور خلف الشاشة، هلال ونجمة تتمايلان، مدار منقّط، غبار ذهبي وأفق مساجد. */
private fun DrawScope.unseeSpecial(k: Kit, t: Float, q: Float) {
    val c = Offset(k.w * 0.5f, k.h * 0.24f)
    glow(c, k.w * 0.8f, col(0xFF7F6BFF), 0.20f)
    val gold = col(0xFFE2B857)
    stamp(k.star16, c.x, c.y, k.w * 0.52f, k.w * 0.52f, 360f * t, gold.a(0.16f), Stroke(width = 1.4f * k.d / (k.w * 0.52f)))
    stamp(k.star8, c.x, c.y, k.w * 0.34f, k.w * 0.34f, -360f * t, col(0xFF6BFFD0).a(0.16f), Stroke(width = 1.4f * k.d / (k.w * 0.34f)))
    drawCircle(gold.a(0.14f), radius = k.w * 0.40f, center = c, style = Stroke(width = 1.6f * k.d, pathEffect = PathEffect.dashPathEffect(floatArrayOf(2f * k.d, 12f * k.d), -720f * t)))
    val bob = 6f * k.d * wave(t, 3f)
    val mc = Offset(k.w * 0.80f, k.h * 0.09f + bob)
    glow(mc, k.w * 0.22f, col(0xFFFFE6A3), 0.28f)
    stamp(k.crescent, mc.x, mc.y, 0.9f, 0.9f, -20f, col(0xFFFFE6A3).a(0.95f))
    sparkle(Offset(mc.x + k.w * 0.07f, mc.y - k.w * 0.01f), 6f * k.d, col(0xFFFFF6D0), 0.7f + 0.3f * wave(t, 6f), 1.4f * k.d)
    for (i in 0 until cnt(24, q)) {
        val s = SEEDS[i + 70]
        val y = 1f - fr(s.y + t * s.k)
        drawCircle(col(0xFFF3D98B).a(0.20f + 0.30f * (0.5f + 0.5f * wave(t, 6f * s.k, s.ph))), radius = (1f + 1.7f * s.s) * k.d, center = Offset((s.x + 0.02f * wave(t, 2f, s.ph)) * k.w, y * k.h))
    }
    drawPath(k.skyline, col(0xFF02140F).a(0.55f))
}
