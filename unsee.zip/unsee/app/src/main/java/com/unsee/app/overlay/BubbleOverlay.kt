package com.unsee.app.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.unsee.app.notify.CompanionAct
import com.unsee.app.notify.Presentation
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull

/**
 * فقاعة التذكير العائمة فوق التطبيقات الأخرى (TYPE_APPLICATION_OVERLAY).
 *
 * قرارات تصميم مقصودة:
 *  - لا خدمة دائمة في الخلفية: النافذة تُضاف من عامل WorkManager لحظة موعد التذكير وتبقى مدة العرض فقط، فلا استهلاك
 *    للبطارية بين التذكيرات، ولا خدمة أمامية دائمة ولا إشعار ثابت.
 *  - تتطلب إذن «العرض فوق التطبيقات الأخرى» الذي يمنحه المستخدم بنفسه. إن لم يتوفر أو رفضته الشركة المصنّعة فنعيد false
 *    ويتحول الاستدعاء إلى إشعار بديل.
 *  - فقاعة واحدة فقط في كل وقت: عرض فقاعة جديدة يزيل السابقة.
 * كل الدوال تُستدعى على الخيط الرئيسي ما عدا [awaitClosed].
 */
object BubbleOverlay {
    private val handler = Handler(Looper.getMainLooper())
    private var windowManager: WindowManager? = null
    private var root: View? = null
    private var hideTask: Runnable? = null
    @Volatile private var closed: CompletableDeferred<Unit>? = null

    private val NAVY = Color.parseColor("#FF0B1B3A")
    private val GOLD = Color.parseColor("#FFE2B857")
    private val CREAM = Color.parseColor("#FFFFF4D6")
    private val CREAM_DIM = Color.parseColor("#FFC9C1A5")

    fun canDraw(ctx: Context): Boolean = runCatching { Settings.canDrawOverlays(ctx) }.getOrDefault(false)

    private fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    private fun pill(color: Int, stroke: Int?, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
        if (stroke != null) setStroke(2, stroke)
    }

    private fun glyph(style: Int): String = when (style) {
        1 -> "☾"
        2 -> "❖"
        else -> "✦"
    }

    private fun button(ctx: Context, label: String, filled: Boolean, onClick: () -> Unit): TextView = TextView(ctx).apply {
        text = label
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        maxLines = 2
        setTextColor(if (filled) NAVY else GOLD)
        background = if (filled) pill(GOLD, null, dp(ctx, 20)) else pill(Color.TRANSPARENT, GOLD, dp(ctx, 20))
        setPadding(dp(ctx, 6), dp(ctx, 10), dp(ctx, 6), dp(ctx, 10))
        isClickable = true
        contentDescription = label
        setOnClickListener { onClick() }
    }

    /**
     * يعرض الفقاعة. يعيد false إن تعذّر ذلك (لا إذن، أو رفض النظام) ليُستعمل الإشعار البديل.
     * [onAct] يُستدعى عند ضغط المستخدم أحد الأزرار، ثم تُغلق الفقاعة.
     * [onMoved] يُستدعى بالموضع الرأسي الجديد بعد سحب الفقاعة (لتذكّر موضعها).
     */
    fun show(
        ctx: Context,
        p: Presentation,
        style: Int,
        seconds: Int,
        animate: Boolean,
        startY: Int,
        onMoved: (Int) -> Unit,
        onAct: (CompanionAct) -> Unit,
    ): Boolean {
        val app = ctx.applicationContext
        if (!canDraw(app)) return false
        dismiss()

        val wm = app.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return false
        val dm = app.resources.displayMetrics
        val width = minOf((dm.widthPixels * 0.92f).toInt(), dp(app, 380))
        val maxY = (dm.heightPixels - dp(app, 180)).coerceAtLeast(0)

        val lp = WindowManager.LayoutParams(
            width,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = ((dm.widthPixels - width) / 2).coerceAtLeast(0)
            y = if (startY >= 0) startY.coerceIn(0, maxY) else dp(app, 96)
        }

        fun act(a: CompanionAct) {
            dismiss()
            onAct(a)
        }

        val card = LinearLayout(app).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(app, 16), dp(app, 10), dp(app, 16), dp(app, 14))
            background = GradientDrawable().apply {
                setColor(NAVY)
                cornerRadius = dp(app, 24).toFloat()
                setStroke(dp(app, 1), GOLD)
            }
            elevation = dp(app, 10).toFloat()
        }

        val header = LinearLayout(app).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val icon = TextView(app).apply {
            text = glyph(style)
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(NAVY)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(GOLD) }
            layoutParams = LinearLayout.LayoutParams(dp(app, 32), dp(app, 32))
        }
        val title = TextView(app).apply {
            text = p.title
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(GOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(app, 10) }
        }
        val close = TextView(app).apply {
            text = "✕"
            textSize = 16f
            setTextColor(CREAM_DIM)
            setPadding(dp(app, 10), dp(app, 6), dp(app, 4), dp(app, 6))
            contentDescription = "إخفاء"
            isClickable = true
            setOnClickListener { act(CompanionAct.DISMISS) }
        }
        header.addView(icon)
        header.addView(title)
        header.addView(close)

        val body = TextView(app).apply {
            text = p.text
            textSize = 16f
            setTextColor(CREAM)
            setLineSpacing(0f, 1.25f)
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START
            setPadding(0, dp(app, 8), 0, 0)
        }
        card.addView(header)
        card.addView(body)

        if (!p.sub.isNullOrBlank()) {
            card.addView(
                TextView(app).apply {
                    text = p.sub
                    textSize = 12f
                    setTextColor(GOLD)
                    textAlignment = View.TEXT_ALIGNMENT_VIEW_START
                    setPadding(0, dp(app, 4), 0, 0)
                },
            )
        }

        val row = LinearLayout(app).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(app, 12), 0, 0)
        }
        fun cell(v: TextView, first: Boolean) {
            v.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (!first) marginStart = dp(app, 6)
            }
            row.addView(v)
        }
        cell(button(app, p.primary, true) { act(CompanionAct.PRIMARY) }, true)
        cell(button(app, p.secondary, false) { act(CompanionAct.SNOOZE) }, false)
        cell(button(app, p.open, false) { act(CompanionAct.OPEN) }, false)
        card.addView(row)

        // سحب الفقاعة من الرأس لتحريكها بعيدًا عن أي أزرار مهمة تحتها
        var downX = 0f
        var downY = 0f
        var startXPos = 0
        var startYPos = 0
        header.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX; downY = ev.rawY
                    startXPos = lp.x; startYPos = lp.y
                    hideTask?.let { handler.removeCallbacks(it) }
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = (startXPos + (ev.rawX - downX)).toInt().coerceIn(0, (dm.widthPixels - width).coerceAtLeast(0))
                    lp.y = (startYPos + (ev.rawY - downY)).toInt().coerceIn(0, maxY)
                    runCatching { wm.updateViewLayout(card, lp) }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    onMoved(lp.y)
                    hideTask?.let { handler.postDelayed(it, seconds.coerceIn(4, 60) * 1000L) }
                    true
                }
                else -> false
            }
        }

        val added = runCatching { wm.addView(card, lp) }.isSuccess
        if (!added) return false

        windowManager = wm
        root = card
        closed = CompletableDeferred()
        if (animate) {
            card.alpha = 0f
            card.translationY = -dp(app, 12).toFloat()
            card.animate().alpha(1f).translationY(0f).setDuration(260).start()
        }
        val task = Runnable { dismiss() }
        hideTask = task
        handler.postDelayed(task, seconds.coerceIn(4, 60) * 1000L)
        return true
    }

    /** يزيل الفقاعة فورًا إن وُجدت. آمن للاستدعاء أكثر من مرة. */
    fun dismiss() {
        hideTask?.let { handler.removeCallbacks(it) }
        hideTask = null
        val v = root
        val wm = windowManager
        root = null
        windowManager = null
        if (v != null && wm != null) runCatching { wm.removeViewImmediate(v) }
        closed?.complete(Unit)
        closed = null
    }

    fun isShowing(): Boolean = root != null

    /** ينتظر حتى تُغلق الفقاعة (أو تنتهي [timeoutMs])، لإبقاء عملية التطبيق حيّة طوال العرض. */
    suspend fun awaitClosed(timeoutMs: Long) {
        val d = closed ?: return
        withTimeoutOrNull(timeoutMs) { d.await() }
    }
}
