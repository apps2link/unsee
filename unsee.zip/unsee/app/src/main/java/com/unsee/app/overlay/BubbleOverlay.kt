package com.unsee.app.overlay

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.unsee.app.data.CompanionStore

/** فحص إذن «العرض فوق التطبيقات الأخرى». */
object BubbleOverlay {
    fun canDraw(ctx: Context): Boolean = runCatching { Settings.canDrawOverlays(ctx) }.getOrDefault(false)
}

/**
 * يقرّر متى تعمل خدمة الفقاعة. الفقاعة صارت أيقونة دائمة (مثل فقاعة ماسنجر) فتحتاج خدمة أمامية بإشعار صامت صغير
 * (يمكن إيقافها من زر فيه). الإذن الخاص بالعرض فوق التطبيقات يعفي التطبيق من قيود بدء الخدمة من الخلفية.
 */
object BubbleController {
    fun wanted(ctx: Context): Boolean {
        val cs = CompanionStore.get(ctx)
        val s = cs.settings()
        return s.bubble && BubbleOverlay.canDraw(ctx) && (s.bubbleAlways || cs.pending().isNotEmpty())
    }

    /** يوفّق حالة الخدمة مع الإعدادات: يشغّلها أو يوقفها. */
    fun sync(ctx: Context) {
        val app = ctx.applicationContext
        if (wanted(app)) start(app, false) else stop(app)
    }

    /** رسالة جديدة وصلت: تشغيل الخدمة (أو تنبيهها) لتقفز الفقاعة وتظهر النقطة. يعيد false إن تعذّر ذلك. */
    fun notifyNew(ctx: Context): Boolean {
        val app = ctx.applicationContext
        val s = CompanionStore.get(app).settings()
        if (!s.bubble || !BubbleOverlay.canDraw(app)) return false
        return start(app, true)
    }

    private fun start(app: Context, isNew: Boolean): Boolean = runCatching {
        val i = Intent(app, BubbleService::class.java).setAction(BubbleService.ACTION_SYNC).putExtra(BubbleService.EXTRA_NEW, isNew)
        ContextCompat.startForegroundService(app, i)
        true
    }.getOrDefault(false)

    private fun stop(app: Context) {
        runCatching { app.stopService(Intent(app, BubbleService::class.java)) }
    }
}
