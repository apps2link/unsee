package com.unsee.app.overlay

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.unsee.app.data.CompanionStore
import com.unsee.app.notify.CompanionEngine
import com.unsee.app.notify.CompanionScheduler

/** فحص إذن «العرض فوق التطبيقات الأخرى». */
object BubbleOverlay {
    fun canDraw(ctx: Context): Boolean = runCatching { Settings.canDrawOverlays(ctx) }.getOrDefault(false)
}

/**
 * يقرّر متى تعمل خدمة الفقاعة. الفقاعة صارت أيقونة دائمة (مثل فقاعة ماسنجر) فتحتاج خدمة أمامية بإشعار صامت صغير
 * (يمكن إيقافها من زر فيه). الإذن الخاص بالعرض فوق التطبيقات يعفي التطبيق من قيود بدء الخدمة من الخلفية.
 */
object BubbleController {
    fun wanted(ctx: Context): Boolean {
        val cs = CompanionStore.get(ctx)
        val s = cs.settings()
        return s.bubble && BubbleOverlay.canDraw(ctx) && !cs.bubbleSnoozed() && !cs.bubbleDismissed() && (s.bubbleAlways || cs.pending().isNotEmpty())
    }

    /** يوفّق حالة الخدمة مع الإعدادات: يشغّلها أو يوقفها. */
    fun sync(ctx: Context) {
        val app = ctx.applicationContext
        if (wanted(app)) start(app, false) else stop(app)
    }

    /** رسالة جديدة وصلت: تشغيل الخدمة (أو تنبيهها) لتقفز الفقاعة وتظهر النقطة. يعيد false إن تعذّر ذلك. */
    fun notifyNew(ctx: Context): Boolean {
        val app = ctx.applicationContext
        val s = CompanionStore.get(app).settings()
        if (!s.bubble || !BubbleOverlay.canDraw(app)) return false
        // أثناء التأجيل تبقى الرسالة معلّقة بصمت وتظهر مع الفقاعة عند عودتها (لا نحوّلها إلى إشعار)
        if (CompanionStore.get(app).bubbleSnoozed()) return true
        // تذكير جديد وصل في موعده: يلغي أثر «إخفاء الحالي» فتعود الفقاعة
        CompanionStore.get(app).setBubbleDismissed(false)
        return start(app, true)
    }

    /**
     * علامة ✕ = تأجيل فقط: تختفي الفقاعة وتبقى كل إعدادات الرفيق كما هي (cmp_enabled / cmp_bubble لا يُمسّان).
     * يُحفظ موعد العودة ويُجدول عمل WorkManager واحد باسم ثابت (REPLACE) فلا تتكرر المهام.
     */
    fun snooze(ctx: Context) {
        val app = ctx.applicationContext
        val cs = CompanionStore.get(app)
        val delay = cs.bubbleSnoozeMin() * 60_000L
        cs.setBubbleSnoozeUntil(System.currentTimeMillis() + delay)
        CompanionScheduler.scheduleBubbleSnooze(app, delay, replace = true)
        stop(app)
    }

    /**
     * علامة ✕: إخفاء التذكير الحالي فقط. تُزال العناصر المعلّقة الآن وتختفي الفقاعة، بلا أي تغيير في إعدادات الرفيق
     * (cmp_enabled/cmp_bubble) ولا في الجداول؛ فيظهر التذكير التالي في موعده كالمعتاد وتعود معه الفقاعة تلقائيًا.
     */
    fun dismissCurrent(ctx: Context) {
        val app = ctx.applicationContext
        CompanionStore.get(app).setBubbleDismissed(true)
        stop(app)
    }

    /** إنهاء التأجيل وإظهار الفقاعة (عند انتهاء المدة، أو فورًا من داخل التطبيق). fresh = تذكير جديد مع عودتها. */
    fun resumeNow(ctx: Context, fresh: Boolean) {
        val app = ctx.applicationContext
        val cs = CompanionStore.get(app)
        cs.setBubbleSnoozeUntil(0L)
        cs.setBubbleDismissed(false)
        CompanionScheduler.cancelBubbleSnooze(app)
        sync(app)
        if (fresh) CompanionEngine.deliverDhikr(app, 0L, ignoreDailyLimit = true)
    }

    /** بعد الإقلاع/التحديث/فتح التطبيق: يعيد جدولة التأجيل المحفوظ (KEEP: لا مهمة مكررة) أو يُنهيه إن انقضى. */
    fun restoreSnooze(ctx: Context) {
        val app = ctx.applicationContext
        val until = CompanionStore.get(app).bubbleSnoozeUntil()
        if (until <= 0L) return
        val remaining = until - System.currentTimeMillis()
        if (remaining <= 0L) resumeNow(app, true) else CompanionScheduler.scheduleBubbleSnooze(app, remaining, replace = false)
    }

    /** «إيقاف الرفيق نهائيًا»: الوحيد الذي يوقف الخدمة. يمسح التأجيل ولا شيء يعيد تشغيله تلقائيًا. */
    fun stopForever(ctx: Context) {
        val app = ctx.applicationContext
        val cs = CompanionStore.get(app)
        cs.edit { putBoolean("cmp_enabled", false); putBoolean("cmp_bubble", false) }
        cs.setBubbleSnoozeUntil(0L)
        CompanionScheduler.cancelBubbleSnooze(app)
        CompanionScheduler.rescheduleAll(app)
        stop(app)
    }

    private fun start(app: Context, isNew: Boolean): Boolean = runCatching {
        val i = Intent(app, BubbleService::class.java).setAction(BubbleService.ACTION_SYNC).putExtra(BubbleService.EXTRA_NEW, isNew)
        ContextCompat.startForegroundService(app, i)
        true
    }.getOrDefault(false)

    private fun stop(app: Context) {
        runCatching { app.stopService(Intent(app, BubbleService::class.java)) }
    }
}
