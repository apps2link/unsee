package com.unsee.app.overlay

import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable

/**
 * خلفية بطاقة زجاجية مصنوعة من طبقات: سطح شبه شفاف متدرّج، غمر لوني ناعم من لوني الحالة، توهج داخلي علوي،
 * وحافة زجاجية رفيعة (إضاءة حافة). كل الـ Shaders تُبنى مرة واحدة في onBoundsChange، ولا يوجد أي تخصيص ذاكرة أثناء الرسم.
 * لا تعتمد على أي API حديث: تعمل على Android 8+ كما هي، والـ Blur (إن وُجد) طبقة إضافية خارجها.
 */
class GlassCardDrawable(
    private val skin: GlassSkin,
    private val radiusPx: Float,
    private val strokePx: Float,
) : Drawable() {
    private val surface = Paint(Paint.ANTI_ALIAS_FLAG)
    private val wash = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = strokePx }
    private val inner = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = strokePx }
    private val rect = RectF()
    private val innerRect = RectF()

    override fun onBoundsChange(b: Rect) {
        super.onBoundsChange(b)
        if (b.isEmpty) return
        val w = b.width().toFloat()
        val h = b.height().toFloat()
        val bx = b.left.toFloat()
        val by = b.top.toFloat()
        rect.set(bx + strokePx / 2f, by + strokePx / 2f, bx + w - strokePx / 2f, by + h - strokePx / 2f)
        innerRect.set(rect.left + strokePx * 1.6f, rect.top + strokePx * 1.6f, rect.right - strokePx * 1.6f, rect.bottom - strokePx * 1.6f)

        surface.shader = LinearGradient(0f, by, 0f, by + h, skin.surfaceTop, skin.surfaceBottom, Shader.TileMode.CLAMP)
        // غمر لوني قطري: accentA من الأعلى-يمين (RTL) إلى accentB في الأسفل-يسار، بشفافية منخفضة كي لا يطغى على النص
        val a1 = if (skin.dark) 58 else 44
        val a2 = if (skin.dark) 40 else 34
        wash.shader = LinearGradient(
            bx + w, by, bx, by + h,
            intArrayOf(GlassSkin.withAlpha(skin.accentA, a1), 0x00FFFFFF, GlassSkin.withAlpha(skin.accentB, a2)),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP,
        )
        // إضاءة داخلية ناعمة قرب الحافة العلوية (إحساس ضوء سينمائي هادئ)
        glow.shader = RadialGradient(
            bx + w * 0.5f, by, w * 0.85f,
            intArrayOf(GlassSkin.withAlpha(0xFFFFFFFF.toInt(), if (skin.dark) 46 else 120), 0x00FFFFFF),
            floatArrayOf(0f, 1f), Shader.TileMode.CLAMP,
        )
        // حافة زجاجية: لمعة بيضاء في الأعلى، لون الحالة في الوسط، ثم خفوت
        rim.shader = LinearGradient(
            0f, by, 0f, by + h,
            intArrayOf(
                GlassSkin.withAlpha(0xFFFFFFFF.toInt(), if (skin.dark) 150 else 235),
                GlassSkin.withAlpha(skin.accentA, if (skin.dark) 120 else 150),
                GlassSkin.withAlpha(skin.accentB, if (skin.dark) 70 else 110),
            ),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP,
        )
        inner.shader = LinearGradient(
            0f, by, 0f, by + h,
            intArrayOf(GlassSkin.withAlpha(0xFFFFFFFF.toInt(), if (skin.dark) 34 else 70), 0x00FFFFFF),
            null, Shader.TileMode.CLAMP,
        )
    }

    override fun draw(c: Canvas) {
        if (bounds.isEmpty) return
        c.drawRoundRect(rect, radiusPx, radiusPx, surface)
        c.drawRoundRect(rect, radiusPx, radiusPx, wash)
        c.drawRoundRect(rect, radiusPx, radiusPx, glow)
        c.drawRoundRect(innerRect, (radiusPx - strokePx * 1.6f).coerceAtLeast(0f), (radiusPx - strokePx * 1.6f).coerceAtLeast(0f), inner)
        c.drawRoundRect(rect, radiusPx, radiusPx, rim)
    }

    override fun setAlpha(alpha: Int) {
        surface.alpha = alpha; wash.alpha = alpha; glow.alpha = alpha; rim.alpha = alpha; inner.alpha = alpha
        invalidateSelf()
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        surface.colorFilter = colorFilter; wash.colorFilter = colorFilter; glow.colorFilter = colorFilter
        rim.colorFilter = colorFilter; inner.colorFilter = colorFilter
        invalidateSelf()
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
