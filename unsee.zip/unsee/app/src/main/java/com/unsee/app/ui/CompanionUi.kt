package com.unsee.app.ui

import android.Manifest
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.unsee.app.core.Arabic
import com.unsee.app.core.CompanionPersona
import com.unsee.app.core.CompanionSchedule
import com.unsee.app.core.DateText
import com.unsee.app.core.LogKind
import com.unsee.app.core.LogStats
import com.unsee.app.core.TimeLogic
import com.unsee.app.data.CompanionMessages
import com.unsee.app.data.CompanionStore
import com.unsee.app.data.MsgCategory
import com.unsee.app.notify.CompanionActions
import com.unsee.app.notify.CompanionEngine
import com.unsee.app.notify.CompanionScheduler
import com.unsee.app.notify.Presentation
import com.unsee.app.notify.Reminders
import com.unsee.app.overlay.BubbleController
import com.unsee.app.overlay.BubbleOverlay
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

// ============================================================ أدوات مشتركة
@Composable
internal fun <T> CompanionStore.observeAsState(read: () -> T): State<T> {
    val store = this
    val flow = remember(store) { store.observe(read) }
    val initial = remember(store) { read() }
    return flow.collectAsStateWithLifecycle(initialValue = initial)
}

/** يحفظ الإعداد ثم يعيد الجدولة (المواعيد حتمية فلا تتكرر التذكيرات). */
internal fun commitCompanion(ctx: Context, cs: CompanionStore, block: SharedPreferences.Editor.() -> Unit) {
    cs.edit(block)
    CompanionScheduler.rescheduleAll(ctx)
}

internal fun pickTime(ctx: Context, minute: Int, onPick: (Int) -> Unit) {
    TimePickerDialog(ctx, { _, h, m -> onPick(h * 60 + m) }, minute / 60, minute % 60, false).show()
}

internal fun fmtZoned(z: ZonedDateTime): String = TimeLogic.formatMinute(z.hour * 60 + z.minute)

internal fun intervalLabel(m: Int): String = when {
    m == 60 -> "ساعة"
    m == 90 -> "ساعة ونصف"
    m == 120 -> "ساعتين"
    m % 60 == 0 -> "${Arabic.digits(m / 60)} ساعات"
    else -> "${Arabic.digits(m)} دقيقة"
}

internal data class PermState(val notifications: Boolean, val overlay: Boolean, val dnd: Boolean)

internal fun readPerms(ctx: Context) = PermState(Reminders.canNotify(ctx), BubbleOverlay.canDraw(ctx), CompanionEngine.dndActive(ctx))

/** حالة الأذونات، تُحدَّث كلما عاد المستخدم إلى التطبيق (بعد زيارة إعدادات النظام). */
@Composable
internal fun rememberPerms(): State<PermState> {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val state = remember { mutableStateOf(readPerms(ctx)) }
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) state.value = readPerms(ctx) }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    return state
}

internal fun openOverlaySettings(ctx: Context) {
    val pkg = Uri.parse("package:${ctx.packageName}")
    val i = Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    if (runCatching { ctx.startActivity(i) }.isFailure) openAppSettings(ctx)
}

internal fun openAppSettings(ctx: Context) {
    val i = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    runCatching { ctx.startActivity(i) }
}

internal fun openNotificationSettings(ctx: Context) {
    val i = Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
        .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, ctx.packageName)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    if (runCatching { ctx.startActivity(i) }.isFailure) openAppSettings(ctx)
}

/**
 * بوابة إذن الإشعارات: تشرح السبب أولًا ثم تطلب الإذن (Android 13+)، وتنفّذ [onGranted] فقط إن كان متاحًا.
 * تُستدعى هكذا: val gate = rememberNotifGate(); gate { ...تفعيل... }
 */
@Composable
internal fun rememberNotifGate(): (() -> Unit) -> Unit {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<(() -> Unit)?>(null) }
    var ask by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val action = pending
        pending = null
        if (granted) action?.invoke()
        else Toast.makeText(ctx, "لم يُمنح إذن الإشعارات، لن تصلك التذكيرات كإشعارات", Toast.LENGTH_LONG).show()
    }
    if (ask) GlassAlertDialog(
        onDismissRequest = { ask = false; pending = null },
        containerColor = UColors.CardSolid,
        title = { Text("السماح بالإشعارات", color = UColors.Cream) },
        text = { Text("نحتاج إذن الإشعارات لنُذكّرك في الأوقات التي تختارها فقط، ولتكون بديلًا إن لم تتوفر الفقاعة. لا إعلانات ولا إشعارات أخرى، ويمكنك الإيقاف في أي وقت.", color = UColors.CreamDim) },
        confirmButton = { TextButton(onClick = { ask = false; launcher.launch(Manifest.permission.POST_NOTIFICATIONS) }) { Text("متابعة", color = UColors.Gold) } },
        dismissButton = { TextButton(onClick = { ask = false; pending = null }) { Text("ليس الآن", color = UColors.CreamDim) } },
    )
    return { onGranted ->
        val needs = Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        if (needs) { pending = onGranted; ask = true } else onGranted()
    }
}

@Composable
internal fun OverlayRationaleDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    GlassAlertDialog(
        onDismissRequest = onDismiss,
        containerColor = UColors.CardSolid,
        title = { Text("السماح بالعرض فوق التطبيقات", color = UColors.Cream) },
        text = {
            Text(
                "الفقاعة تظهر لثوانٍ فوق التطبيقات الأخرى لتُذكّرك، وهذا يحتاج إذنًا خاصًا من إعدادات النظام تمنحه بنفسك. " +
                    "لا نستخدمه لأي غرض آخر، ولا نقرأ ما على شاشتك، ويمكنك سحبه في أي وقت. إن لم تمنحه فستصلك التذكيرات كإشعارات.",
                color = UColors.CreamDim,
            )
        },
        confirmButton = { TextButton(onClick = { onDismiss(); openOverlaySettings(ctx) }) { Text("فتح الإعدادات", color = UColors.Gold) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("ليس الآن", color = UColors.CreamDim) } },
    )
}

private fun styleGlyph(style: Int) = when (style) { 1 -> "☾"; 2 -> "❖"; else -> "✦" }

/** معاينة شكل الفقاعة (نفس ألوانها الفعلية الثابتة، لأنها تظهر خارج التطبيق). */
@Composable
internal fun BubblePreview(style: Int, text: String, sub: String?, primary: String, secondary: String, open: String) {
    val navy = Color(0xFF0B1B3A)
    val gold = Color(0xFFE2B857)
    val cream = Color(0xFFFFF4D6)
    val shape = RoundedCornerShape(24.dp)
    Column(Modifier.fillMaxWidth().clip(shape).background(navy).border(1.dp, gold, shape).padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(32.dp).clip(CircleShape).background(gold), contentAlignment = Alignment.Center) {
                Text(styleGlyph(style), color = navy, fontSize = 16.sp)
            }
            Spacer(Modifier.width(10.dp))
            Text("رفيق أُنسي", color = gold, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text("✕", color = Color(0xFFC9C1A5))
        }
        Text(text, color = cream, fontSize = 16.sp, modifier = Modifier.padding(top = 8.dp))
        if (sub != null) Text(sub, color = gold, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(primary to true, secondary to false, open to false).forEach { (label, filled) ->
                val pill = RoundedCornerShape(20.dp)
                Box(
                    Modifier.weight(1f).clip(pill).background(if (filled) gold else Color.Transparent).border(1.dp, gold, pill).padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center,
                ) { Text(label, color = if (filled) navy else gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 2, textAlign = TextAlign.Center) }
            }
        }
    }
}

private fun startOfDayMillis(date: LocalDate): Long = date.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()

// ============================================================ لوحة تحكم رفيق أُنسي
@Composable
fun CompanionScreen(nav: NavController) {
    val ctx = LocalContext.current
    val cs = remember { CompanionStore.get(ctx) }
    val s by cs.observeAsState { cs.settings() }
    val log by cs.observeAsState { cs.log() }
    val perms by rememberPerms()
    val gate = rememberNotifGate()
    var overlayDialog by remember { mutableStateOf(false) }
    var sample by remember { mutableStateOf(CompanionMessages.all.random()) }

    fun commit(block: SharedPreferences.Editor.() -> Unit) = commitCompanion(ctx, cs, block)

    fun tryBubble() {
        if (!BubbleOverlay.canDraw(ctx)) { overlayDialog = true; return }
        if (!s.bubble) {
            Toast.makeText(ctx, "فعّل «الفقاعة العائمة» الأول", Toast.LENGTH_SHORT).show()
            return
        }
        val v = cs.voice()
        val p = Presentation(
            LogKind.DHIKR, CompanionActions.PREVIEW_REF, v.bubbleTitle, sample.textFor(v.dialect), sample.source?.let { "— $it" },
            v.bubbleDone, v.bubbleLater, v.bubbleOpen, "adhkar", 3001,
        )
        cs.addPending(p.toPending())
        if (!BubbleController.notifyNew(ctx)) {
            cs.removePending(LogKind.DHIKR, CompanionActions.PREVIEW_REF)
            Toast.makeText(ctx, "تعذّر عرض الفقاعة على جهازك، ستصلك التذكيرات كإشعارات", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(ctx, "اخرج من التطبيق وشوف الفقاعة على الشاشة الرئيسية، وفوقها نقطة حمرا", Toast.LENGTH_LONG).show()
        }
    }

    val next = remember(s.lat, s.lng, s.method, s.asr, s.adjust) { CompanionSchedule.nextPrayerTime(ZonedDateTime.now(), s) }
    val today = LocalDate.now()
    val todayCounts = LogStats.count(log, startOfDayMillis(today))
    val weekCounts = LogStats.count(log, startOfDayMillis(today.minusDays(6)))

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader("رفيق أُنسي", { nav.popBackStack() })

        GlassCard(Modifier.fillMaxWidth(), glow = s.enabled) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconBadge(Ico.Mosque, 48.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("صاحبك اللي يفكّرك بربنا", color = UColors.Gold, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text("تذكيرات قصيرة بالذكر والصلاة ومحاسبة النفس، من غير مراقبة ومن غير لوم.", color = UColors.CreamDim, fontSize = 12.sp)
                }
            }
            SwitchRow("تشغيل رفيق أُنسي", "رسائل ذكر في الأوقات التي تحددها", s.enabled) { on ->
                if (on) gate { commit { putBoolean("cmp_enabled", true) } } else commit { putBoolean("cmp_enabled", false) }
            }
            SwitchRow("الفقاعة العائمة", "تظهر ثواني فوق التطبيقات الأخرى. بدونها تصلك إشعارات", s.bubble) { on ->
                commit { putBoolean("cmp_bubble", on) }
                if (on && !perms.overlay) overlayDialog = true
            }
            if (s.bubble && !perms.overlay) {
                Text("إذن العرض فوق التطبيقات غير مفعّل، فالتذكيرات تصلك كإشعارات حاليًا.", color = UColors.Gold, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                PillButton("منح الإذن", { overlayDialog = true }, Modifier.padding(top = 6.dp), filled = false)
            }
            Text("كل بياناتك محفوظة على جهازك فقط، ولا يوجد حساب ولا تتبّع.", color = UColors.CreamDim, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
        }

        GlassCard(Modifier.fillMaxWidth(), onClick = { nav.navigate("prayer") }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconBadge(Ico.Mosque)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        if (next != null) "الصلاة القادمة: ${next.first.label} ${fmtZoned(next.second)}" else "مواقيت الصلاة",
                        color = UColors.Cream, fontWeight = FontWeight.Bold,
                    )
                    Text("الموقع: ${s.placeName} · ${s.method.label}", color = UColors.CreamDim, fontSize = 12.sp)
                }
                androidx.compose.material3.Icon(Ico.Forward, null, tint = UColors.Gold)
            }
        }

        SectionLabel("الفقاعة")
        GlassCard(Modifier.fillMaxWidth()) {
            Text("أيقونة أُنسي تطفو على الشاشة الرئيسية، وفوقها نقطة حمرا لما فيه رسالة. اضغط عليها تظهرلك الذكر أو الدعاء أو النصيحة.", color = UColors.Cream, fontSize = 13.sp)
            Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PillButton("جرّبها الآن", { tryBubble() }, icon = Ico.Bell)
                PillButton("رسالة أخرى", { sample = CompanionMessages.all.random() }, icon = Ico.Refresh, filled = false)
            }
        }

        SectionLabel("نشاطك الفعلي")
        GlassCard(Modifier.fillMaxWidth()) {
            if (weekCounts.shown == 0 && weekCounts.done == 0 && weekCounts.prayed == 0) {
                Text("لسه مفيش تذكيرات اتعرضت. الأرقام هنا بتتحسب من تفاعلك الحقيقي فقط.", color = UColors.CreamDim, fontSize = 13.sp)
            } else {
                Text(
                    "اليوم: ظهر ${Arabic.digits(todayCounts.shown)} · ذكرت ${Arabic.digits(todayCounts.done)} · أجّلت ${Arabic.digits(todayCounts.snoozed)} · سجّلت صلاة ${Arabic.digits(todayCounts.prayed)}",
                    color = UColors.Cream, fontSize = 13.sp,
                )
                Text(
                    "آخر ٧ أيام: ظهر ${Arabic.digits(weekCounts.shown)} · ذكرت ${Arabic.digits(weekCounts.done)} · أجّلت ${Arabic.digits(weekCounts.snoozed)} · سجّلت صلاة ${Arabic.digits(weekCounts.prayed)}",
                    color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp),
                )
                if (weekCounts.undelivered > 0) {
                    Text("${Arabic.digits(weekCounts.undelivered)} تذكير لم يُعرض لأن الفقاعة والإشعارات غير متاحة. راجع الأذونات.", color = UColors.Gold, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                }
            }
        }

        data class Tile(val icon: androidx.compose.ui.graphics.vector.ImageVector, val title: String, val sub: String, val route: String)
        val tiles = listOf(
            Tile(Ico.Night, "محاسبة النفس", "شاشة الحسنات والسيئات والخطط والأساسيات", "muhasaba"),
            Tile(Ico.Tune, "إعدادات الرفيق", "الشخصية والأوقات والفقاعة والفئات", "companion_settings"),
            Tile(Ico.Settings, "الأذونات والبطارية", "حالة الإشعارات والفقاعة وقيود الجهاز", "companion_perms"),
            Tile(Ico.History, "سجل التذكيرات", "ما ظهر وما فعلته به", "companion_log"),
        )
        tiles.forEachIndexed { i, t ->
            Appear(i * 40) {
                GlassCard(Modifier.fillMaxWidth(), onClick = { nav.navigate(t.route) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconBadge(t.icon)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(t.title, color = UColors.Cream, fontWeight = FontWeight.Bold)
                            Text(t.sub, color = UColors.CreamDim, fontSize = 12.sp)
                        }
                        androidx.compose.material3.Icon(Ico.Forward, null, tint = UColors.Gold)
                    }
                }
            }
        }

        GlassCard(Modifier.fillMaxWidth(), glow = true, onClick = { nav.navigate("comeback") }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconBadge(Ico.Heart)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("أنا محتاج أرجع لربنا", color = UColors.Gold, fontWeight = FontWeight.Bold)
                    Text("صفحة هادية: استغفار ودعاء وخطوات بسيطة تبدأ بيها من جديد", color = UColors.CreamDim, fontSize = 12.sp)
                }
            }
        }
    }
    if (overlayDialog) OverlayRationaleDialog { overlayDialog = false }
}

// ============================================================ إعدادات الرفيق
@Composable
fun CompanionSettingsScreen(nav: NavController) {
    val ctx = LocalContext.current
    val cs = remember { CompanionStore.get(ctx) }
    val s by cs.observeAsState { cs.settings() }
    fun commit(block: SharedPreferences.Editor.() -> Unit) = commitCompanion(ctx, cs, block)

    fun toggleCat(c: MsgCategory, on: Boolean) {
        val all = MsgCategory.values().map { it.name }.toSet()
        val cur = if (s.categories.isEmpty()) all else s.categories
        val next = if (on) cur + c.name else cur - c.name
        if (next.isEmpty()) {
            Toast.makeText(ctx, "لازم تختار فئة واحدة على الأقل", Toast.LENGTH_SHORT).show()
            return
        }
        cs.saveCategories(if (next == all) emptySet() else next)
    }

    val slots = CompanionSchedule.dailySlots(s)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ScreenHeader("إعدادات الرفيق", { nav.popBackStack() })

        SectionLabel("شخصية الرفيق")
        GlassCard(Modifier.fillMaxWidth()) {
            ChipRow(CompanionPersona.values().toList(), { it == s.persona }, { it.label }) { cs.savePersona(it) }
            Text(s.persona.blurb, color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            Text("الشخصية تغيّر اختيار الرسائل وأسلوبها من مكتبة محلية، وليست ذكاءً اصطناعيًا.", color = UColors.CreamDim, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
        }

        SectionLabel("أوقات الرسائل")
        GlassCard(Modifier.fillMaxWidth()) {
            Text("الفترة المفضلة", color = UColors.CreamDim, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("من", color = UColors.Cream)
                PillButton(TimeLogic.formatMinute(s.startMin), {
                    pickTime(ctx, s.startMin) { m ->
                        if (m >= s.endMin) Toast.makeText(ctx, "بداية الفترة لازم تكون قبل نهايتها", Toast.LENGTH_SHORT).show()
                        else commit { putInt("cmp_start", m) }
                    }
                }, icon = Ico.Alarm, filled = false)
                Text("إلى", color = UColors.Cream)
                PillButton(TimeLogic.formatMinute(s.endMin), {
                    pickTime(ctx, s.endMin) { m ->
                        if (m <= s.startMin) Toast.makeText(ctx, "نهاية الفترة لازم تكون بعد بدايتها", Toast.LENGTH_SHORT).show()
                        else commit { putInt("cmp_end", m) }
                    }
                }, icon = Ico.Alarm, filled = false)
            }
            Text("الفاصل بين الرسائل", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
            ChipRow(listOf(30, 60, 90, 120, 180, 240, 360), { it == s.intervalMin }, { intervalLabel(it) }) { v -> commit { putInt("cmp_interval", v) } }
            Text("أقصى عدد رسائل يوميًا", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
            ChipRow(listOf(2, 3, 5, 8, 12, 20), { it == s.maxPerDay }, { Arabic.digits(it) }) { v -> commit { putInt("cmp_max", v) } }
            Text(
                if (slots.isEmpty()) "بهذه الإعدادات لن تصلك رسائل: وسّع الفترة أو عدّل فترة الهدوء."
                else "المواعيد المتوقعة: " + slots.joinToString("، ") { TimeLogic.formatMinute(it) } + ". قد يتأخر التنفيذ دقائق بسبب توفير الطاقة.",
                color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp),
            )
        }

        SectionLabel("فترة الهدوء")
        GlassCard(Modifier.fillMaxWidth()) {
            SwitchRow("لا رسائل ذكر في فترة الهدوء", "للنوم أو العمل أو الدراسة. لا تخص الصلاة (لها إعداداتها)", s.quietEnabled) { v -> commit { putBoolean("cmp_quiet", v) } }
            if (s.quietEnabled) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("من", color = UColors.Cream)
                    PillButton(TimeLogic.formatMinute(s.quietStartMin), { pickTime(ctx, s.quietStartMin) { m -> commit { putInt("cmp_qs", m) } } }, icon = Ico.Sleep, filled = false)
                    Text("إلى", color = UColors.Cream)
                    PillButton(TimeLogic.formatMinute(s.quietEndMin), { pickTime(ctx, s.quietEndMin) { m -> commit { putInt("cmp_qe", m) } } }, icon = Ico.Sleep, filled = false)
                }
            }
            Text("الفقاعة لا تظهر أيضًا أثناء وضع «عدم الإزعاج» في النظام ولا والشاشة مطفأة.", color = UColors.CreamDim, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
        }

        SectionLabel("الفئات")
        GlassCard(Modifier.fillMaxWidth()) {
            MsgCategory.values().forEach { c ->
                val on = s.categories.isEmpty() || c.name in s.categories
                SwitchRow(c.title, null, on) { v -> toggleCat(c, v) }
            }
        }

        SectionLabel("لهجة الرفيق")
        GlassCard(Modifier.fillMaxWidth()) {
            ChipRow(com.unsee.app.core.DialectPref.values().toList(), { it == s.dialectPref }, { it.label }) { cs.saveDialectPref(it) }
            Text("كل كلام الرفيق (الفقاعة، المحاسبة، التشجيع، التذكيرات) بالعامية المصرية أو الخليجية. الآيات والأحاديث والأذكار تبقى بنصها دائمًا.", color = UColors.CreamDim, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
        }

        SectionLabel("الصوت")
        GlassCard(Modifier.fillMaxWidth()) {
            SwitchRow("مؤثرات صوتية", "زقزقة عصفور مع إشعار الفقاعة، تصفيق عند الحسنة، وبكاء حزين عند السيئة. لا موسيقى ولا تلاوة.", s.sfx) { on ->
                cs.edit { putBoolean("cmp_sfx", on) }
                if (on) com.unsee.app.notify.Sfx.play(ctx, com.unsee.app.notify.Sfx.Sound.CLAP)
            }
            Text("تُكتم تلقائيًا لو الهاتف على الصامت أو الاهتزاز.", color = UColors.CreamDim, fontSize = 11.sp)
        }

        SectionLabel("الفقاعة")
        GlassCard(Modifier.fillMaxWidth()) {
            SwitchRow("تظهر دائمًا كأيقونة", "مثل فقاعة ماسنجر. اقفلها لتظهر فقط عند وصول رسالة", s.bubbleAlways) { on ->
                commit { putBoolean("cmp_balways", on) }
            }
            Text("اضغط عليها: ذكر أو دعاء أو نصيحة. النقطة الحمراء = رسالة جديدة. اسحبها لأي مكان، وارمها على ✕ في الأسفل لتأجيلها فقط (يبقى الرفيق شغّالًا وترجع تلقائيًا). تختفي وأنت داخل أُنسي.", color = UColors.CreamDim, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
            Text("خطط الإقلاع تظهر كفقاعة «أولوية»: لا ✕ ولا تأجيل، وتبقى حتى تردّ عليها.", color = UColors.CreamDim, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
        }

        SectionLabel("تأجيل الفقاعة (علامة ✕)")
        GlassCard(Modifier.fillMaxWidth()) {
            var snoozeMin by remember { mutableStateOf(cs.bubbleSnoozeMin()) }
            var snoozeUntil by remember { mutableStateOf(cs.bubbleSnoozeUntil()) }
            Text("مدة التأجيل عند رمي الفقاعة على ✕", color = UColors.Cream, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(Modifier.height(6.dp))
            ChipRow(cs.snoozeChoices, { it == snoozeMin }, { if (it == 60) "ساعة" else "$it دقيقة" }) { m ->
                snoozeMin = m
                cs.setBubbleSnoozeMin(m)
            }
            val left = ((snoozeUntil - System.currentTimeMillis()) / 60_000L).coerceAtLeast(0L)
            if (snoozeUntil > System.currentTimeMillis()) {
                Text("الفقاعة مؤجَّلة، ترجع بعد نحو $left دقيقة. الرفيق نفسه ما زال مفعّلًا.", color = UColors.Gold, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            }
            PillButton("أظهر الفقاعة الآن", {
                if (!com.unsee.app.overlay.BubbleOverlay.canDraw(ctx)) {
                    Toast.makeText(ctx, "فعّل إذن «العرض فوق التطبيقات الأخرى» أولًا من شاشة الأذونات", Toast.LENGTH_LONG).show()
                } else {
                    BubbleController.resumeNow(ctx, false)
                    snoozeUntil = 0L
                }
            }, Modifier.padding(top = 8.dp), icon = Ico.Bell, filled = false)
        }

        SectionLabel("إيقاف الرفيق")
        GlassCard(Modifier.fillMaxWidth()) {
            Text("«إيقاف الرفيق نهائيًا» هو الوحيد الذي يوقف الذكر التلقائي والفقاعة. علامة ✕ لا توقفه أبدًا. تعيد تشغيله من مفتاح التفعيل في أعلى الشاشة.", color = UColors.CreamDim, fontSize = 12.sp)
            PillButton("إيقاف الرفيق نهائيًا", { BubbleController.stopForever(ctx) }, Modifier.padding(top = 8.dp), icon = Ico.Close, filled = false)
        }

        SectionLabel("تذكير العادات الحلوة")
        GlassCard(Modifier.fillMaxWidth()) {
            SwitchRow("ذكّرني بأعمالي الصالحة", "لو عملت خير إمبارح ومعملتوش النهارده، أفكّرك بيه مرة واحدة يوميًا", s.habitEnabled) { on ->
                commit { putBoolean("cmp_habit", on) }
            }
            if (s.habitEnabled) PillButton(TimeLogic.formatMinute(s.habitMin), { pickTime(ctx, s.habitMin) { m -> commit { putInt("cmp_habitmin", m) } } }, Modifier.padding(top = 6.dp), icon = Ico.Alarm, filled = false)
        }
    }
}

// ============================================================ الأذونات والقيود
@Composable
fun CompanionPermsScreen(nav: NavController) {
    val ctx = LocalContext.current
    val perms by rememberPerms()
    val gate = rememberNotifGate()

    @Composable
    fun Row2(title: String, ok: Boolean, okText: String, noText: String, sub: String, actionLabel: String?, action: () -> Unit) {
        GlassCard(Modifier.fillMaxWidth(), glow = ok) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconBadge(if (ok) Ico.CheckCircle else Ico.Info, tint = if (ok) UColors.Gold else UColors.CreamDim)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, color = UColors.Cream, fontWeight = FontWeight.Bold)
                    Text(if (ok) okText else noText, color = if (ok) UColors.Gold else UColors.CreamDim, fontSize = 12.sp)
                }
            }
            Text(sub, color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            if (actionLabel != null) PillButton(actionLabel, action, Modifier.padding(top = 8.dp), filled = !ok)
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ScreenHeader("الأذونات والبطارية", { nav.popBackStack() })
        Row2(
            "الإشعارات", perms.notifications, "مفعّلة", "غير مفعّلة",
            "بديل الفقاعة وطريقة وصول تذكير الصلاة ومحاسبة النفس.",
            if (perms.notifications) "إعدادات إشعارات التطبيق" else "تفعيل الإشعارات",
        ) { if (perms.notifications) openNotificationSettings(ctx) else gate { openNotificationSettings(ctx) } }
        Row2(
            "العرض فوق التطبيقات", perms.overlay, "مفعّل", "غير مفعّل",
            "للفقاعة العائمة فقط. تظهر لثوانٍ ثم تختفي، ولا نقرأ شيئًا من شاشتك.",
            if (perms.overlay) "إعدادات الإذن" else "منح الإذن",
        ) { openOverlaySettings(ctx) }
        Row2(
            "وضع عدم الإزعاج", !perms.dnd, "غير مفعّل", "مفعّل الآن",
            "أثناء تفعيله لا تظهر الفقاعة احترامًا لاختيارك، وقد تصل الإشعارات بصمت حسب إعداداتك في النظام.",
            null,
        ) {}

        GlassCard(Modifier.fillMaxWidth()) {
            Text("قيود البطارية والخلفية", color = UColors.Gold, fontWeight = FontWeight.Bold)
            Text(
                "التذكيرات تعمل عبر WorkManager لتوفير الطاقة، فقد تتأخر دقائق، وقد تؤخرها أو توقفها بعض الأجهزة. " +
                    "ولا يشغّل التطبيق خدمة دائمة في الخلفية. لا نضمن أن الفقاعة أو الإشعارات تعمل دائمًا على كل الأجهزة. " +
                    "إن كان جهازك Xiaomi أو HyperOS: فعّل «بدء التشغيل التلقائي» وعطّل قيود البطارية للتطبيق، ثم تأكد أن العرض فوق التطبيقات مسموح.",
                color = UColors.CreamDim, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp),
            )
            PillButton("فتح إعدادات التطبيق", { openAppSettings(ctx) }, Modifier.padding(top = 8.dp), filled = false)
        }
    }
}

// ============================================================ سجل التذكيرات
@Composable
fun CompanionLogScreen(nav: NavController) {
    val ctx = LocalContext.current
    val cs = remember { CompanionStore.get(ctx) }
    val log by cs.observeAsState { cs.log() }
    var clear by remember { mutableStateOf(false) }
    val zone = remember { ZoneId.systemDefault() }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        ScreenHeader("سجل التذكيرات", { nav.popBackStack() }) {
            if (log.isNotEmpty()) IconBtn(Ico.Delete, "مسح السجل", { clear = true }, UColors.CreamDim)
        }
        if (log.isEmpty()) {
            EmptyState(Ico.History, "السجل فاضي", "هنا تظهر التذكيرات التي عُرضت وما فعلته بها، محليًا على جهازك فقط.")
        }
        log.asReversed().take(100).forEach { e ->
            val at = Instant.ofEpochMilli(e.ts).atZone(zone)
            val detail = when (e.kind) {
                LogKind.DHIKR -> CompanionMessages.byId(e.ref)?.text?.let { if (it.length > 40) it.take(40) + "…" else it } ?: ""
                LogKind.PRAYER -> e.ref.split('|').getOrNull(1)?.let { k -> com.unsee.app.core.Prayer.fromKey(k)?.label } ?: ""
                LogKind.MUHASABA -> ""
                LogKind.HABIT -> e.ref.removePrefix("habit:")
                LogKind.PLAN -> ""
            }
            GlassCard(Modifier.fillMaxWidth()) {
                Text("${e.kind.label} · ${e.action.label}", color = UColors.Cream, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                if (detail.isNotEmpty()) Text(detail, color = UColors.CreamDim, fontSize = 12.sp)
                Text("${DateText.gregorian(at.toLocalDate())} · ${fmtZoned(at)}", color = UColors.CreamDim, fontSize = 11.sp)
            }
        }
    }
    if (clear) ConfirmDialog("مسح السجل؟", "يُمسح سجل التذكيرات فقط. لا تتأثر سجلات الصلاة ولا المراجعات.", "مسح", { cs.clearLog() }) { clear = false }
}

// ============================================================ أنا محتاج أرجع لربنا
@Composable
fun ComebackScreen(nav: NavController) {
    val steps = listOf(
        "ابدأ بنية صادقة إنك عايز ترجع. ده أصعب جزء وإنت خلاص عملته.",
        "توضا وصلّي ركعتين لو تقدر، وادعي ربنا بكلامك إنت من غير تكلّف.",
        "قول: أستغفر الله وأتوب إليه، ولو مرات قليلة. التكرار الهادي أحسن من الضغط على نفسك.",
        "ابعد عن الحاجة اللي بتجرّك للغلط لو تقدر، وغيّر الظروف اللي بتساعد عليها.",
        "اختار صلاة واحدة تحافظ عليها الأول، وزوّد بالتدريج.",
        "لو الغلط كان في حق حد، ردّ الحق أو اعتذر لو ينفع.",
        "صاحب ناس طيبين تعينك، ومتقعدش لوحدك في الحاجات التقيلة.",
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader("أنا محتاج أرجع لربنا", { nav.popBackStack() })
        GlassCard(Modifier.fillMaxWidth(), glow = true) {
            Text("أهلًا بيك يا صاحبي", color = UColors.Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("الرجوع بيبدأ بخطوة صغيرة، ومفيش هنا حد بيحاسبك ولا بيخوّفك. ربنا رحيم، وباب التوبة مفتوح.", color = UColors.Cream, modifier = Modifier.padding(top = 4.dp))
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Text("قُلْ يَا عِبَادِيَ الَّذِينَ أَسْرَفُوا عَلَىٰ أَنفُسِهِمْ لَا تَقْنَطُوا مِن رَّحْمَةِ اللَّهِ", color = UColors.Cream, fontSize = 20.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Text("سورة الزمر: ٥٣", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        }
        SectionLabel("خطوات بسيطة")
        GlassCard(Modifier.fillMaxWidth()) {
            steps.forEachIndexed { i, t ->
                Text("${Arabic.digits(i + 1)}. $t", color = UColors.Cream, fontSize = 14.sp, modifier = Modifier.padding(vertical = 3.dp))
            }
        }
        SectionLabel("دعاء واستغفار")
        GlassCard(Modifier.fillMaxWidth()) {
            Text("رَبَّنَا ظَلَمْنَا أَنفُسَنَا وَإِن لَّمْ تَغْفِرْ لَنَا وَتَرْحَمْنَا لَنَكُونَنَّ مِنَ الْخَاسِرِينَ", color = UColors.Cream, fontSize = 19.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Text("سورة الأعراف: ٢٣", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Text(
                "اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَىٰ عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، " +
                    "أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ",
                color = UColors.Cream, fontSize = 18.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(),
            )
            Text("سيد الاستغفار — رواه البخاري", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PillButton("ابدأ باستغفار", { nav.navigate("tasbih") }, icon = Ico.Beads)
            PillButton("أذكار اليوم", { nav.navigate("list/${TimeLogic.suggestedCategory(java.time.LocalTime.now().hour).name}") }, icon = Ico.Book, filled = false)
        }
        Text("لو حاسس بضيق شديد أو تعب نفسي، كلّم حد قريب منك تثق فيه أو متخصص. مش لازم تشيل لوحدك.", color = UColors.CreamDim, fontSize = 12.sp)
    }
}
