package com.unsee.app.core

import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * ثيمات التطبيق (30). «الطبيعة الحية» هي الثيم الرئيسي والافتراضي، وبقية الثيمات لكل منها خلفية متحركة بشخصية مختلفة
 * (انظر ui/ThemeBackdrops.kt). كل ثيم يحدد بنفسه إن كان داكنًا أو فاتحًا، فلا حاجة لوضع نظام/فاتح/داكن منفصل.
 * الثيمات الكلاسيكية القديمة (ناعم/زمردي/أسود/أبيض/أزرق ليلي/بنفسجي/زخارف) حُذفت؛ من كان يستخدمها ينتقل تلقائيًا إلى الطبيعة الحية.
 */
enum class ThemeId(val label: String, val blurb: String) {
    SILK("الحرير الحي", "نهار لافندر لؤلؤي وليل بنفسجي عميق يتبدلان مع الوقت الحقيقي"),
    NATURE("الطبيعة الحية", "الثيم الرئيسي: فجر ونهار وغروب وليل متحرك"),
    PARADISE("الجنة الخضراء", "أوراق متحركة وإضاءة شمس هادئة"),
    FAITH_NIGHT("ليلة إيمانية", "نجوم متلألئة وهلال مضيء"),
    ROYAL_GOLD("الذهب الملكي", "زخارف ذهبية وانعكاسات ضوئية"),
    ISLAMIC_EMERALD("الزمرد الإسلامي", "جزيئات خضراء وإضاءة ناعمة"),
    PACIFIC("المحيط الهادئ", "تموجات مائية وضوء متحرك"),
    VIOLET_SKY("السماء البنفسجية", "سحب ضوئية ونجوم"),
    GALAXY("المجرة", "نجوم متحركة وعمق بصري"),
    DAWN("الفجر", "تدرج ضوئي يحاكي الشروق"),
    SUNSET("الغروب", "ألوان دافئة وإضاءة متغيرة"),
    QUIET_RAIN("المطر الهادئ", "قطرات مطر وانعكاسات"),
    WATERFALL("الشلال", "حركة مياه وانسيابية بصرية"),
    GOLD_DESERT("الصحراء الذهبية", "رمال وإضاءة غروب"),
    MOON_CLOUDS("القمر والسحاب", "سحب تتحرك ببطء حول القمر"),
    CRYSTAL("الزجاج البلوري", "طبقات شفافة وانعكاسات"),
    PEARL("اللؤلؤ", "لمعان ناعم وتدرجات لؤلؤية"),
    CALLIGRAPHY("الخط العربي", "زخارف مستوحاة من الحروف العربية"),
    GEOMETRIC("النقوش الهندسية", "أشكال هندسية متحركة بانسيابية"),
    ROYAL_TURQUOISE("الفيروز الملكي", "تدرجات فيروزية وإضاءة متحركة"),
    NAVY_NIGHT("الليل الكحلي", "نجوم دقيقة ولمسات فضية"),
    LIT_GARDEN("الحديقة المضيئة", "أضواء تشبه اليراعات"),
    QUIET_SNOW("الثلج الهادئ", "رقاقات ثلج تتحرك ببطء"),
    DEEP_SPACE("الفضاء العميق", "سدم كونية وتأثيرات عمق"),
    LANTERNS("الفوانيس الرمضانية", "فوانيس متوهجة وحركة ضوئية"),
    SPIRITUAL_DAWN("الفجر الروحاني", "أفق مضيء وغيوم هادئة"),
    AURORA("الشفق القطبي", "أشرطة ضوئية متحركة"),
    ROYAL_MARBLE("الرخام الملكي", "خامات رخامية وإضاءة فاخرة"),
    RAINY_SKY("السماء الممطرة", "سحب ومطر وانعكاسات"),
    SOFT_ROSE("الورد الهادئ", "بتلات متحركة وألوان طبيعية"),
    UNSEE_SPECIAL("أُنسي الخاص", "مسجد وفانوس وهلال بتقنيات حديثة"),
}

/** يبقى للتوافق مع الإعدادات المخزّنة سابقًا؛ الثيمات الجديدة لا تستخدمه (كل ثيم داكن أو فاتح بطبيعته). */
enum class ThemeMode(val label: String) { SYSTEM("حسب النظام"), LIGHT("فاتح"), DARK("داكن") }

/** ألوان بصيغة ARGB (Long) كي يبقى الملف نقيًّا وقابلًا للاختبار على JVM. */
data class PaletteSpec(
    val bgTop: Long, val bgBottom: Long, val card: Long,
    val text: Long, val textDim: Long,
    val accent: Long, val accentSoft: Long, val onAccent: Long,
    val dark: Boolean,
)

object Palettes {
    private fun p(top: Long, bottom: Long, card: Long, text: Long, dim: Long, accent: Long, soft: Long, on: Long, dark: Boolean) =
        PaletteSpec(top, bottom, card, text, dim, accent, soft, on, dark)

    /** «الحرير الحي» (بنفسجي زجاجي كمراجع التصميم): لوحتان (نهار/ليل) تُمزجان حيًّا؛ راجع [silk]. */
    val SILK_DAY = p(0xFFF7F3FF, 0xFFE6DCFB, 0xFFFFFFFF, 0xFF241547, 0xFF5B4C85, 0xFF6D3FD8, 0xFFA78BF5, 0xFFFFFFFF, false)
    val SILK_NIGHT = p(0xFF120633, 0xFF2B1075, 0xFF1F0F4A, 0xFFF6F0FF, 0xFFCBBDF0, 0xFFB794FF, 0xFFD9C7FF, 0xFF1A0845, true)

    private fun smooth(x: Float): Float {
        val c = x.coerceIn(0f, 1f)
        return c * c * (3f - 2f * c)
    }

    private fun mix(a: Long, b: Long, t: Float): Long {
        fun ch(sh: Int): Long {
            val x = ((a shr sh) and 0xFF).toFloat()
            val y = ((b shr sh) and 0xFF).toFloat()
            return (x + (y - x) * t).toInt().coerceIn(0, 255).toLong()
        }
        return (0xFFL shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
    }

    /**
     * يمزج لوحتي الحرير: الأسطح (الخلفية والبطاقة) تتدرّج بمنحنى حاد حول المنتصف كي لا يطول زمن «اللون الرمادي الوسطي»،
     * والنصوص والتمييز تتبدّل دفعة واحدة عند عبور سطح البطاقة عتبة سطوع، فيبقى النص مقروءًا في كل لحظة تقريبًا.
     * [day] = 0 ليل كامل، 1 نهار كامل.
     */
    fun silk(day: Float): PaletteSpec {
        val d = day.coerceIn(0f, 1f)
        if (d <= 0f) return SILK_NIGHT
        if (d >= 1f) return SILK_DAY
        val s = smooth((d - 0.35f) / 0.30f)
        val top = mix(SILK_NIGHT.bgTop, SILK_DAY.bgTop, s)
        val bottom = mix(SILK_NIGHT.bgBottom, SILK_DAY.bgBottom, s)
        val card = mix(SILK_NIGHT.card, SILK_DAY.card, s)
        val ink = if (luminance(card) > 0.25) SILK_DAY else SILK_NIGHT
        return PaletteSpec(top, bottom, card, ink.text, ink.textDim, ink.accent, ink.accentSoft, ink.onAccent, ink === SILK_NIGHT)
    }

    val NATURE = p(0xFF050E24, 0xFF14336B, 0xFF0A1530, 0xFFFFF4D6, 0xFFD0D6E6, 0xFFE2B857, 0xFFF3D98B, 0xFF050E24, true)
    val PARADISE = p(0xFF05301F, 0xFF0F6B3F, 0xFF0B4A2E, 0xFFF4FFE8, 0xFFCFE8D4, 0xFFF2D675, 0xFFF8E7A5, 0xFF05301F, true)
    val FAITH_NIGHT = p(0xFF050B1F, 0xFF16264F, 0xFF0D1838, 0xFFFFF4D6, 0xFFC9D2E8, 0xFFE9C46A, 0xFFF5DF9C, 0xFF050B1F, true)
    val ROYAL_GOLD = p(0xFF1A1205, 0xFF3D2A08, 0xFF2A1D07, 0xFFFFF1CC, 0xFFE0CFA2, 0xFFF0C24B, 0xFFF9DE8A, 0xFF1A1205, true)
    val ISLAMIC_EMERALD = p(0xFF03231B, 0xFF0A5A45, 0xFF0A3D31, 0xFFE9FFF4, 0xFFB9E0D0, 0xFF4FE3A8, 0xFF8FF0C8, 0xFF03231B, true)
    val PACIFIC = p(0xFF04243D, 0xFF0B5C86, 0xFF08334F, 0xFFEAF8FF, 0xFFBFDDEE, 0xFF6FD6F2, 0xFFA6E8F8, 0xFF04243D, true)
    val VIOLET_SKY = p(0xFF1B0F3D, 0xFF4B2C86, 0xFF2A1A59, 0xFFF5ECFF, 0xFFD3C2EE, 0xFFE0C2FF, 0xFFF0DEFF, 0xFF1B0F3D, true)
    val GALAXY = p(0xFF05030F, 0xFF1B1048, 0xFF120A33, 0xFFF1EEFF, 0xFFC6C0E6, 0xFFB69CFF, 0xFFD3C2FF, 0xFF05030F, true)
    val DAWN = p(0xFF2B1B52, 0xFF8C3F63, 0xFF3A2150, 0xFFFFF1EA, 0xFFF0D2D8, 0xFFFFC27A, 0xFFFFDDA8, 0xFF2B1B52, true)
    val SUNSET = p(0xFF2A1238, 0xFF8A3A2E, 0xFF3B1A33, 0xFFFFF0E0, 0xFFF2D3BE, 0xFFFFB347, 0xFFFFD08A, 0xFF2A1238, true)
    val QUIET_RAIN = p(0xFF0B1A24, 0xFF1F3F52, 0xFF132B3A, 0xFFE8F3F8, 0xFFB6CDD8, 0xFF8CCBE6, 0xFFB8E0F2, 0xFF0B1A24, true)
    val WATERFALL = p(0xFF042B2C, 0xFF0B6B63, 0xFF074445, 0xFFE6FFFB, 0xFFB4E3DC, 0xFF6FF0D8, 0xFFA6F7E7, 0xFF042B2C, true)
    val GOLD_DESERT = p(0xFF2B1A0B, 0xFF7A4E1C, 0xFF3C2610, 0xFFFFF3DD, 0xFFF3E0BE, 0xFFFFC857, 0xFFFFE08F, 0xFF2B1A0B, true)
    val MOON_CLOUDS = p(0xFF0A1226, 0xFF2B3A63, 0xFF141E3B, 0xFFF3F5FF, 0xFFC8D0EA, 0xFFD9DEF5, 0xFFEEF0FF, 0xFF0A1226, true)
    val CRYSTAL = p(0xFF0B2236, 0xFF2A6C8F, 0xFF123552, 0xFFF0FAFF, 0xFFD6EEF8, 0xFF9BE3FF, 0xFFC6F0FF, 0xFF0B2236, true)
    val PEARL = p(0xFFF7F3F6, 0xFFE4DDEB, 0xFFFFFFFF, 0xFF2A2433, 0xFF5C5468, 0xFF7A4FA8, 0xFFA98BCB, 0xFFFFFFFF, false)
    val CALLIGRAPHY = p(0xFFF6EDD7, 0xFFE6D5AE, 0xFFFFFAEB, 0xFF2B1D0C, 0xFF5E4A2E, 0xFF8A5A0F, 0xFFB98A2E, 0xFFFFFFFF, false)
    val GEOMETRIC = p(0xFF08203A, 0xFF123E63, 0xFF0D2E4F, 0xFFEFF7FF, 0xFFBCD3E8, 0xFFF0C75E, 0xFFF8DE97, 0xFF08203A, true)
    val ROYAL_TURQUOISE = p(0xFF032E33, 0xFF0A6E77, 0xFF07484F, 0xFFEBFFFF, 0xFFD2F0F0, 0xFF5EEAE0, 0xFF9EF3EC, 0xFF032E33, true)
    val NAVY_NIGHT = p(0xFF050B1A, 0xFF0F1E40, 0xFF0A152C, 0xFFEEF2FA, 0xFFBCC6DC, 0xFFC9D3E8, 0xFFE3E9F5, 0xFF050B1A, true)
    val LIT_GARDEN = p(0xFF04140D, 0xFF0F3A22, 0xFF0A2619, 0xFFF0FFE6, 0xFFC3E0B8, 0xFFD8F26A, 0xFFE9F9A0, 0xFF04140D, true)
    val QUIET_SNOW = p(0xFFEAF2FA, 0xFFD3E3F2, 0xFFFFFFFF, 0xFF13283D, 0xFF4A6178, 0xFF1F6AA5, 0xFF5AA0D4, 0xFFFFFFFF, false)
    val DEEP_SPACE = p(0xFF03020B, 0xFF150B3A, 0xFF0E0828, 0xFFF2EEFF, 0xFFC4BCE8, 0xFFFF9EC8, 0xFFFFC4DE, 0xFF03020B, true)
    val LANTERNS = p(0xFF1C0A12, 0xFF4A1A2C, 0xFF2E0F1D, 0xFFFFEFD2, 0xFFEBCFB0, 0xFFFFB84D, 0xFFFFD58F, 0xFF1C0A12, true)
    val SPIRITUAL_DAWN = p(0xFFFFF1E0, 0xFFF6D3C0, 0xFFFFFAF4, 0xFF3A1F2B, 0xFF6E4A55, 0xFFB0481F, 0xFFD98A5B, 0xFFFFFFFF, false)
    val AURORA = p(0xFF04121E, 0xFF0C3A4A, 0xFF0A2231, 0xFFEAFFF7, 0xFFB8E0D4, 0xFF7CF0B6, 0xFFB0F8D4, 0xFF04121E, true)
    val ROYAL_MARBLE = p(0xFFF4F2EE, 0xFFE0DBD2, 0xFFFFFFFF, 0xFF262320, 0xFF5A544C, 0xFF8A6A1E, 0xFFB8963F, 0xFFFFFFFF, false)
    val RAINY_SKY = p(0xFF10151C, 0xFF2C3946, 0xFF1A222C, 0xFFEEF2F6, 0xFFBEC9D4, 0xFF9CC3E0, 0xFFC2DAEE, 0xFF10151C, true)
    val SOFT_ROSE = p(0xFFFFEEF3, 0xFFF8D7E2, 0xFFFFFFFF, 0xFF3A1626, 0xFF73495B, 0xFFB02858, 0xFFD9628A, 0xFFFFFFFF, false)
    val UNSEE_SPECIAL = p(0xFF04202A, 0xFF0D5C57, 0xFF093A40, 0xFFFFF4D6, 0xFFC6E3DE, 0xFFE9C46A, 0xFFF5DF9C, 0xFF04202A, true)

    fun spec(id: ThemeId): PaletteSpec = when (id) {
        ThemeId.SILK -> SILK_DAY
        ThemeId.NATURE -> NATURE
        ThemeId.PARADISE -> PARADISE
        ThemeId.FAITH_NIGHT -> FAITH_NIGHT
        ThemeId.ROYAL_GOLD -> ROYAL_GOLD
        ThemeId.ISLAMIC_EMERALD -> ISLAMIC_EMERALD
        ThemeId.PACIFIC -> PACIFIC
        ThemeId.VIOLET_SKY -> VIOLET_SKY
        ThemeId.GALAXY -> GALAXY
        ThemeId.DAWN -> DAWN
        ThemeId.SUNSET -> SUNSET
        ThemeId.QUIET_RAIN -> QUIET_RAIN
        ThemeId.WATERFALL -> WATERFALL
        ThemeId.GOLD_DESERT -> GOLD_DESERT
        ThemeId.MOON_CLOUDS -> MOON_CLOUDS
        ThemeId.CRYSTAL -> CRYSTAL
        ThemeId.PEARL -> PEARL
        ThemeId.CALLIGRAPHY -> CALLIGRAPHY
        ThemeId.GEOMETRIC -> GEOMETRIC
        ThemeId.ROYAL_TURQUOISE -> ROYAL_TURQUOISE
        ThemeId.NAVY_NIGHT -> NAVY_NIGHT
        ThemeId.LIT_GARDEN -> LIT_GARDEN
        ThemeId.QUIET_SNOW -> QUIET_SNOW
        ThemeId.DEEP_SPACE -> DEEP_SPACE
        ThemeId.LANTERNS -> LANTERNS
        ThemeId.SPIRITUAL_DAWN -> SPIRITUAL_DAWN
        ThemeId.AURORA -> AURORA
        ThemeId.ROYAL_MARBLE -> ROYAL_MARBLE
        ThemeId.RAINY_SKY -> RAINY_SKY
        ThemeId.SOFT_ROSE -> SOFT_ROSE
        ThemeId.UNSEE_SPECIAL -> UNSEE_SPECIAL
    }

    /** ألوان رئيسية مقترحة: (للوضع الداكن، للوضع الفاتح) — كلها تحقق تباينًا مقبولًا على بطاقات كل الثيمات (مفحوص في الاختبارات). */
    val ACCENTS: List<Pair<String, Pair<Long, Long>>> = listOf(
        "ذهبي" to (0xFFE2B857 to 0xFF7A560F),
        "زمردي" to (0xFF5BD6A8 to 0xFF0F6B52),
        "فيروزي" to (0xFF5BC4D6 to 0xFF0E6B7A),
        "وردي" to (0xFFF0A3C0 to 0xFFA32A5E),
        "بنفسجي" to (0xFFD9B8FF to 0xFF6A35B8),
        "برتقالي" to (0xFFFFB070 to 0xFF9A4A0A),
    )

    private fun channel(c: Long, shift: Int): Double {
        val v = ((c shr shift) and 0xFF) / 255.0
        return if (v <= 0.03928) v / 12.92 else ((v + 0.055) / 1.055).pow(2.4)
    }

    fun luminance(c: Long): Double = 0.2126 * channel(c, 16) + 0.7152 * channel(c, 8) + 0.0722 * channel(c, 0)

    /** نسبة التباين WCAG بين لونين (1..21). */
    fun contrast(a: Long, b: Long): Double {
        val la = luminance(a)
        val lb = luminance(b)
        return (max(la, lb) + 0.05) / (min(la, lb) + 0.05)
    }
}
