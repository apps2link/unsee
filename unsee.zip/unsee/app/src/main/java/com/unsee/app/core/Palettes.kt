package com.unsee.app.core

import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * [animated] = للثيم خلفية متحركة خاصة به (ثيمات «المجموعة المتحركة»: الطبيعة الحية + 29 ثيمًا).
 * [fixedDark] = الثيمات المتحركة لها وضع ثابت (داكن أو فاتح) لأن خلفيتها مرسومة لوضع واحد؛ null = يتبع وضع التطبيق.
 */
enum class ThemeId(val label: String, val blurb: String, val animated: Boolean = false, val fixedDark: Boolean? = null) {
    SOFT("أُنسي الناعم", "فاتح نظيف بألوان هادئة وبطاقات مستديرة"),
    EMERALD("زمردي وذهبي", "الهوية الأساسية للتطبيق"),
    BLACK("أسود فاخر", "أسود عميق مع ذهب هادئ"),
    WHITE("أبيض هادئ", "نظيف ومريح للعين"),
    NIGHT("أزرق ليلي", "سماء الليل الهادئة"),
    PURPLE("بنفسجي", "بنفسجي ملكي ناعم"),
    PATTERN("زخارف هندسية", "نجوم إسلامية خفيفة في الخلفية"),
    NATURE("الطبيعة الحية", "فجر ونهار وغروب وليل متحرك (الثيم الأصلي كما هو)", animated = true, fixedDark = true),
    PARADISE("الجنة الخضراء", "أوراق متحركة وإضاءة شمس هادئة", animated = true, fixedDark = true),
    FAITH_NIGHT("ليلة إيمانية", "نجوم متلألئة وهلال مضيء", animated = true, fixedDark = true),
    ROYAL_GOLD("الذهب الملكي", "زخارف ذهبية وانعكاسات ضوئية", animated = true, fixedDark = true),
    EMERALD_GLOW("الزمرد الإسلامي", "جزيئات خضراء وإضاءة ناعمة", animated = true, fixedDark = true),
    PACIFIC("المحيط الهادئ", "تموجات مائية وضوء متحرك", animated = true, fixedDark = true),
    VIOLET_SKY("السماء البنفسجية", "سحب ضوئية ونجوم", animated = true, fixedDark = true),
    GALAXY("المجرة", "نجوم متحركة وعمق بصري", animated = true, fixedDark = true),
    FAJR("الفجر", "تدرج ضوئي يحاكي الشروق", animated = true, fixedDark = true),
    SUNSET("الغروب", "ألوان دافئة وإضاءة متغيرة", animated = true, fixedDark = true),
    CALM_RAIN("المطر الهادئ", "قطرات مطر وانعكاسات", animated = true, fixedDark = true),
    WATERFALL("الشلال", "حركة مياه وانسيابية بصرية", animated = true, fixedDark = true),
    GOLDEN_DESERT("الصحراء الذهبية", "رمال وإضاءة غروب", animated = true, fixedDark = true),
    MOON_CLOUDS("القمر والسحاب", "سحب تتحرك ببطء حول القمر", animated = true, fixedDark = true),
    CRYSTAL("الزجاج البلوري", "طبقات شفافة وانعكاسات", animated = true, fixedDark = false),
    PEARL("اللؤلؤ", "لمعان ناعم وتدرجات لؤلؤية", animated = true, fixedDark = false),
    CALLIGRAPHY("الخط العربي", "زخارف مستوحاة من الحروف العربية", animated = true, fixedDark = true),
    GEOMETRIC("النقوش الهندسية", "أشكال هندسية متحركة بانسيابية", animated = true, fixedDark = true),
    ROYAL_TURQUOISE("الفيروز الملكي", "تدرجات فيروزية وإضاءة متحركة", animated = true, fixedDark = true),
    NAVY_NIGHT("الليل الكحلي", "نجوم دقيقة ولمسات فضية", animated = true, fixedDark = true),
    GLOW_GARDEN("الحديقة المضيئة", "أضواء تشبه اليراعات", animated = true, fixedDark = true),
    QUIET_SNOW("الثلج الهادئ", "رقاقات ثلج تتحرك ببطء", animated = true, fixedDark = false),
    DEEP_SPACE("الفضاء العميق", "سدم كونية وتأثيرات عمق", animated = true, fixedDark = true),
    RAMADAN_LANTERNS("الفوانيس الرمضانية", "فوانيس متوهجة وحركة ضوئية", animated = true, fixedDark = true),
    SPIRITUAL_DAWN("الفجر الروحاني", "أفق مضيء وغيوم هادئة", animated = true, fixedDark = false),
    AURORA("الشفق القطبي", "أشرطة ضوئية متحركة", animated = true, fixedDark = true),
    ROYAL_MARBLE("الرخام الملكي", "خامات رخامية وإضاءة فاخرة", animated = true, fixedDark = false),
    RAINY_SKY("السماء الممطرة", "سحب ومطر وانعكاسات", animated = true, fixedDark = true),
    SOFT_ROSE("الورد الهادئ", "بتلات متحركة وألوان طبيعية", animated = true, fixedDark = false),
    UNSEE_SPECIAL("أُنسي الخاص", "هوية إسلامية بتقنيات حديثة: نجمة هندسية وهلال وأفق", animated = true, fixedDark = true),
    ;

    companion object {
        /** مجموعة الثيمات المتحركة (30) بالترتيب: الطبيعة الحية أولًا ثم الباقي. */
        val animatedSet: List<ThemeId> get() = values().filter { it.animated }
        val classicSet: List<ThemeId> get() = values().filter { !it.animated }
    }
}

enum class ThemeMode(val label: String) { SYSTEM("حسب النظام"), LIGHT("فاتح"), DARK("داكن") }

/** ألوان بصيغة ARGB (Long) كي يبقى الملف نقيًّا وقابلًا للاختبار على JVM. */
data class PaletteSpec(
    val bgTop: Long, val bgBottom: Long, val card: Long,
    val text: Long, val textDim: Long,
    val accent: Long, val accentSoft: Long, val onAccent: Long,
    val dark: Boolean,
)

object Palettes {
    private fun p(top: Long, bottom: Long, card: Long, text: Long, dim: Long, accent: Long, soft: Long, on: Long, dark: Boolean) =
        PaletteSpec(top, bottom, card, text, dim, accent, soft, on, dark)

    val EMERALD_DARK = p(0xFF04251E, 0xFF0A4A3B, 0xFF0F3D33, 0xFFFFF4D6, 0xFFC8D6CE, 0xFFE2B857, 0xFFF3D98B, 0xFF04251E, true)
    val EMERALD_LIGHT = p(0xFFF8F3E4, 0xFFEADFC0, 0xFFFFFFFF, 0xFF0B3A2F, 0xFF4A6158, 0xFF7A560F, 0xFFB8892B, 0xFFFFFFFF, false)
    val BLACK_DARK = p(0xFF000000, 0xFF111111, 0xFF1A1A1A, 0xFFF5ECD0, 0xFFBDB6A0, 0xFFD4AF37, 0xFFE8CF7A, 0xFF000000, true)
    val BLACK_LIGHT = p(0xFFFFFDF7, 0xFFF3EEDF, 0xFFFFFFFF, 0xFF1A1A1A, 0xFF595959, 0xFF7A5F0C, 0xFFB8962E, 0xFFFFFFFF, false)
    val WHITE_LIGHT = p(0xFFFFFFFF, 0xFFF1F5F3, 0xFFFFFFFF, 0xFF16302B, 0xFF55706A, 0xFF1F7A66, 0xFF5BB5A0, 0xFFFFFFFF, false)
    val WHITE_DARK = p(0xFF0F1A18, 0xFF16241F, 0xFF1C2C28, 0xFFEAF3F0, 0xFFABC0BA, 0xFF5BC4AB, 0xFF8EDBC8, 0xFF0F1A18, true)
    val NIGHT_DARK = p(0xFF050E24, 0xFF14336B, 0xFF0E2147, 0xFFFFF4D6, 0xFFC3CCE0, 0xFFE2B857, 0xFFF3D98B, 0xFF050E24, true)
    val NIGHT_LIGHT = p(0xFFEAF1FF, 0xFFD3E2FA, 0xFFFFFFFF, 0xFF0B1B3A, 0xFF44557A, 0xFF1D4E9E, 0xFF5B8BD6, 0xFFFFFFFF, false)
    val PURPLE_DARK = p(0xFF150B2B, 0xFF2D1B54, 0xFF241545, 0xFFF3EAFF, 0xFFCBB9E6, 0xFFD9B8FF, 0xFFEBD6FF, 0xFF150B2B, true)
    val PURPLE_LIGHT = p(0xFFF6EFFF, 0xFFE7D8FA, 0xFFFFFFFF, 0xFF2A1450, 0xFF5E4B82, 0xFF6A35B8, 0xFF9F73E0, 0xFFFFFFFF, false)
    val SOFT_LIGHT = p(0xFFE4F5EC, 0xFFF8F8F6, 0xFFFFFFFF, 0xFF14251F, 0xFF55675F, 0xFF0E7A5F, 0xFF5BC4A0, 0xFFFFFFFF, false)
    val SOFT_DARK = p(0xFF0B1F1A, 0xFF10241E, 0xFF16302A, 0xFFEAF6F0, 0xFFA9C2B9, 0xFF5BD6A8, 0xFF8EE6C6, 0xFF06251C, true)
    val NATURE_DARK = p(0xFF050E24, 0xFF14336B, 0xFF0A1530, 0xFFFFF4D6, 0xFFD0D6E6, 0xFFE2B857, 0xFFF3D98B, 0xFF050E24, true)

    val PARADISE_SPEC = p(0xFF06301F, 0xFF16703A, 0xFF0C3B26, 0xFFF1FFF0, 0xFFC5E3C9, 0xFFB8F27A, 0xFFD7FFA8, 0xFF06301F, true)
    val FAITH_NIGHT_SPEC = p(0xFF070B24, 0xFF1A2160, 0xFF111A47, 0xFFFFF6DC, 0xFFC9CDE8, 0xFFFFD36B, 0xFFFFE6A3, 0xFF070B24, true)
    val ROYAL_GOLD_SPEC = p(0xFF1A1205, 0xFF4A3410, 0xFF2A1D08, 0xFFFFF3D0, 0xFFD9C79A, 0xFFF2C14E, 0xFFFFDB85, 0xFF1A1205, true)
    val EMERALD_GLOW_SPEC = p(0xFF03241C, 0xFF0B5D49, 0xFF0A3A2E, 0xFFEAFFF6, 0xFFB5DCCD, 0xFF4EE3B0, 0xFF8FF0CF, 0xFF03241C, true)
    val PACIFIC_SPEC = p(0xFF04243A, 0xFF0B5B83, 0xFF0A3550, 0xFFEAF8FF, 0xFFB7D8E8, 0xFF6FD8FF, 0xFFA8E8FF, 0xFF04243A, true)
    val VIOLET_SKY_SPEC = p(0xFF1B0B3A, 0xFF4B2A8C, 0xFF2A1655, 0xFFF5EDFF, 0xFFD0BFEF, 0xFFE0B8FF, 0xFFF0D8FF, 0xFF1B0B3A, true)
    val GALAXY_SPEC = p(0xFF05030F, 0xFF1A1040, 0xFF120A2E, 0xFFF4F0FF, 0xFFC4BCE0, 0xFF9EC5FF, 0xFFC4DBFF, 0xFF05030F, true)
    val FAJR_SPEC = p(0xFF1A2455, 0xFF7A4278, 0xFF2A2A60, 0xFFFFF4E6, 0xFFE6D8EC, 0xFFFFC27A, 0xFFFFDDAA, 0xFF1A2455, true)
    val SUNSET_SPEC = p(0xFF2B1240, 0xFF93402F, 0xFF3A1A3A, 0xFFFFF4E0, 0xFFEBD3CC, 0xFFFFB86B, 0xFFFFD39A, 0xFF2B1240, true)
    val CALM_RAIN_SPEC = p(0xFF0D1B26, 0xFF2A4A60, 0xFF14293A, 0xFFEAF4FA, 0xFFB9CCD8, 0xFF8CCBF0, 0xFFB5E0F8, 0xFF0D1B26, true)
    val WATERFALL_SPEC = p(0xFF062A2E, 0xFF136468, 0xFF0A3C40, 0xFFE9FFFC, 0xFFB3DAD6, 0xFF7FF0E0, 0xFFB0F7EE, 0xFF062A2E, true)
    val GOLDEN_DESERT_SPEC = p(0xFF3A1C0A, 0xFF8A4E18, 0xFF4A2A12, 0xFFFFF5E0, 0xFFE6CFAE, 0xFFFFD27A, 0xFFFFE3A8, 0xFF3A1C0A, true)
    val MOON_CLOUDS_SPEC = p(0xFF0A1330, 0xFF2E4270, 0xFF16224A, 0xFFF2F5FF, 0xFFC3CCE6, 0xFFFFE8A8, 0xFFFFF2CC, 0xFF0A1330, true)
    val CRYSTAL_SPEC = p(0xFFEAF6FF, 0xFFD0E6F7, 0xFFFFFFFF, 0xFF0E2A3F, 0xFF46627A, 0xFF14739E, 0xFF4FA9D4, 0xFFFFFFFF, false)
    val PEARL_SPEC = p(0xFFFBF7F3, 0xFFEDE4EE, 0xFFFFFFFF, 0xFF2B2430, 0xFF645A6A, 0xFF8A4F7D, 0xFFB98AB0, 0xFFFFFFFF, false)
    val CALLIGRAPHY_SPEC = p(0xFF1C1710, 0xFF3B2F1E, 0xFF2A2218, 0xFFF5EBD5, 0xFFCFC2A6, 0xFFD9A441, 0xFFEBC77A, 0xFF1C1710, true)
    val GEOMETRIC_SPEC = p(0xFF0A2230, 0xFF16505E, 0xFF0E3340, 0xFFEAFBFF, 0xFFB5D6DE, 0xFFFFC857, 0xFFFFDC8F, 0xFF0A2230, true)
    val ROYAL_TURQUOISE_SPEC = p(0xFF032F3A, 0xFF0B6E7A, 0xFF07434F, 0xFFEAFFFD, 0xFFB3DEDB, 0xFF5CF0E6, 0xFF9BF7F0, 0xFF032F3A, true)
    val NAVY_NIGHT_SPEC = p(0xFF030A1C, 0xFF0C1F4A, 0xFF0A1633, 0xFFEDF1FA, 0xFFB8C2DC, 0xFFD6DEEE, 0xFFEEF2FA, 0xFF030A1C, true)
    val GLOW_GARDEN_SPEC = p(0xFF03140C, 0xFF0F3A1F, 0xFF0A2616, 0xFFEFFFE6, 0xFFBBD9B0, 0xFFE6F25A, 0xFFF2F99A, 0xFF03140C, true)
    val QUIET_SNOW_SPEC = p(0xFFEEF4FA, 0xFFD9E5F0, 0xFFFFFFFF, 0xFF14283A, 0xFF4C6176, 0xFF1F6FA8, 0xFF6AA6D3, 0xFFFFFFFF, false)
    val DEEP_SPACE_SPEC = p(0xFF02020A, 0xFF1A0B30, 0xFF0E0820, 0xFFF2EFFF, 0xFFBFB8DC, 0xFFFF9ECF, 0xFFFFC2E0, 0xFF02020A, true)
    val RAMADAN_LANTERNS_SPEC = p(0xFF14091F, 0xFF4A1F3A, 0xFF2A1230, 0xFFFFF1D6, 0xFFE0C8C8, 0xFFFFB84D, 0xFFFFD58F, 0xFF14091F, true)
    val SPIRITUAL_DAWN_SPEC = p(0xFFFFF3E3, 0xFFFFE0C8, 0xFFFFFFFF, 0xFF3A2418, 0xFF7A5A48, 0xFFB5521B, 0xFFE08A4E, 0xFFFFFFFF, false)
    val AURORA_SPEC = p(0xFF03111F, 0xFF0A3A44, 0xFF08232F, 0xFFEBFFF8, 0xFFB3DACB, 0xFF6BFFB8, 0xFFA6FFD4, 0xFF03111F, true)
    val ROYAL_MARBLE_SPEC = p(0xFFF7F5F2, 0xFFE4E0DA, 0xFFFFFFFF, 0xFF1E1B18, 0xFF5C554D, 0xFF8C6A1F, 0xFFC4A24D, 0xFFFFFFFF, false)
    val RAINY_SKY_SPEC = p(0xFF1A2430, 0xFF445A6E, 0xFF223242, 0xFFF0F5FA, 0xFFC5D1DC, 0xFFA8D8FF, 0xFFCDE8FF, 0xFF1A2430, true)
    val SOFT_ROSE_SPEC = p(0xFFFFF0F3, 0xFFFBDCE4, 0xFFFFFFFF, 0xFF3A1A24, 0xFF7A5560, 0xFFB02A55, 0xFFE06C8D, 0xFFFFFFFF, false)
    val UNSEE_SPECIAL_SPEC = p(0xFF04251E, 0xFF2B1E5C, 0xFF0F2F3D, 0xFFFFF4D6, 0xFFCBD6D2, 0xFFE2B857, 0xFFF3D98B, 0xFF04251E, true)

    fun spec(id: ThemeId, dark: Boolean): PaletteSpec = when (id) {
        ThemeId.SOFT -> if (dark) SOFT_DARK else SOFT_LIGHT
        ThemeId.EMERALD, ThemeId.PATTERN -> if (dark) EMERALD_DARK else EMERALD_LIGHT
        ThemeId.BLACK -> if (dark) BLACK_DARK else BLACK_LIGHT
        ThemeId.WHITE -> if (dark) WHITE_DARK else WHITE_LIGHT
        ThemeId.NIGHT -> if (dark) NIGHT_DARK else NIGHT_LIGHT
        ThemeId.PURPLE -> if (dark) PURPLE_DARK else PURPLE_LIGHT
        ThemeId.NATURE -> NATURE_DARK // الطبيعة المتحركة داكنة دائمًا
        ThemeId.PARADISE -> PARADISE_SPEC
        ThemeId.FAITH_NIGHT -> FAITH_NIGHT_SPEC
        ThemeId.ROYAL_GOLD -> ROYAL_GOLD_SPEC
        ThemeId.EMERALD_GLOW -> EMERALD_GLOW_SPEC
        ThemeId.PACIFIC -> PACIFIC_SPEC
        ThemeId.VIOLET_SKY -> VIOLET_SKY_SPEC
        ThemeId.GALAXY -> GALAXY_SPEC
        ThemeId.FAJR -> FAJR_SPEC
        ThemeId.SUNSET -> SUNSET_SPEC
        ThemeId.CALM_RAIN -> CALM_RAIN_SPEC
        ThemeId.WATERFALL -> WATERFALL_SPEC
        ThemeId.GOLDEN_DESERT -> GOLDEN_DESERT_SPEC
        ThemeId.MOON_CLOUDS -> MOON_CLOUDS_SPEC
        ThemeId.CRYSTAL -> CRYSTAL_SPEC
        ThemeId.PEARL -> PEARL_SPEC
        ThemeId.CALLIGRAPHY -> CALLIGRAPHY_SPEC
        ThemeId.GEOMETRIC -> GEOMETRIC_SPEC
        ThemeId.ROYAL_TURQUOISE -> ROYAL_TURQUOISE_SPEC
        ThemeId.NAVY_NIGHT -> NAVY_NIGHT_SPEC
        ThemeId.GLOW_GARDEN -> GLOW_GARDEN_SPEC
        ThemeId.QUIET_SNOW -> QUIET_SNOW_SPEC
        ThemeId.DEEP_SPACE -> DEEP_SPACE_SPEC
        ThemeId.RAMADAN_LANTERNS -> RAMADAN_LANTERNS_SPEC
        ThemeId.SPIRITUAL_DAWN -> SPIRITUAL_DAWN_SPEC
        ThemeId.AURORA -> AURORA_SPEC
        ThemeId.ROYAL_MARBLE -> ROYAL_MARBLE_SPEC
        ThemeId.RAINY_SKY -> RAINY_SKY_SPEC
        ThemeId.SOFT_ROSE -> SOFT_ROSE_SPEC
        ThemeId.UNSEE_SPECIAL -> UNSEE_SPECIAL_SPEC
    }

    /** ألوان رئيسية مقترحة: (للوضع الداكن، للوضع الفاتح) — كلها تحقق تباينًا مقبولًا على بطاقات الوضع المناسب. */
    val ACCENTS: List<Pair<String, Pair<Long, Long>>> = listOf(
        "ذهبي" to (0xFFE2B857 to 0xFF7A560F),
        "زمردي" to (0xFF5BD6A8 to 0xFF0F6B52),
        "فيروزي" to (0xFF5BC4D6 to 0xFF0E6B7A),
        "وردي" to (0xFFF0A3C0 to 0xFFA32A5E),
        "بنفسجي" to (0xFFD9B8FF to 0xFF6A35B8),
        "برتقالي" to (0xFFFFB070 to 0xFF9A4A0A),
    )

    private fun channel(c: Long, shift: Int): Double {
        val v = ((c shr shift) and 0xFF) / 255.0
        return if (v <= 0.03928) v / 12.92 else ((v + 0.055) / 1.055).pow(2.4)
    }

    fun luminance(c: Long): Double = 0.2126 * channel(c, 16) + 0.7152 * channel(c, 8) + 0.0722 * channel(c, 0)

    /** نسبة التباين WCAG بين لونين (1..21). */
    fun contrast(a: Long, b: Long): Double {
        val la = luminance(a)
        val lb = luminance(b)
        return (max(la, lb) + 0.05) / (min(la, lb) + 0.05)
    }
}
