package com.unsee.app.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.unsee.app.core.Arabic
import com.unsee.app.core.DateText
import com.unsee.app.core.TimeLogic
import com.unsee.app.data.AdhkarData
import com.unsee.app.data.Category
import com.unsee.app.data.Settings
import com.unsee.app.data.Store
import com.unsee.app.widget.WidgetStyle
import java.time.LocalDate
import java.time.LocalTime

private val PILL = RoundedCornerShape(50)

@Composable
private fun SectionTitle(text: String) =
    Text(text, color = UColors.Cream, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))

/** بلاطة قسم: مربع مستدير بلون هادئ وأيقونة كبيرة وتحتها الاسم. */
@Composable
private fun CategoryTile(c: Category, done: Int, total: Int, onClick: () -> Unit) {
    Column(Modifier.width(98.dp).clip(RoundedCornerShape(24.dp)).clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(98.dp).clip(RoundedCornerShape(26.dp))
                .background(Brush.verticalGradient(listOf(UColors.tint(c.tint(), 0.26f), UColors.tint(c.tint(), 0.10f)))),
            contentAlignment = Alignment.Center,
        ) {
            Icon(c.icon(), c.title, tint = c.tint(), modifier = Modifier.size(46.dp))
            if (total > 0 && done >= total) {
                Box(Modifier.align(Alignment.TopStart).padding(8.dp).size(22.dp).clip(CircleShape).background(UColors.Gold), contentAlignment = Alignment.Center) {
                    Icon(Ico.Check, null, tint = UColors.OnAccent, modifier = Modifier.size(14.dp))
                }
            }
        }
        Text(c.title, color = UColors.Cream, fontWeight = FontWeight.Bold, fontSize = 13.sp, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp, bottom = 2.dp))
    }
}

@Composable
private fun StatBlock(title: String, big: String, sub: String, frac: Float, modifier: Modifier = Modifier) {
    Column(modifier.padding(horizontal = 6.dp)) {
        Text(title, color = UColors.Gold, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Text(big, color = UColors.Cream, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text(sub, color = UColors.CreamDim, fontSize = 13.sp)
        Spacer(Modifier.height(10.dp))
        LinearProgressIndicator(
            progress = { frac.coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape),
            color = UColors.Gold, trackColor = UColors.Cream.copy(alpha = 0.10f),
        )
    }
}

@Composable
private fun DiscoverTile(icon: ImageVector, label: String, tint: Color, modifier: Modifier, onClick: () -> Unit) {
    Row(
        modifier.clip(RoundedCornerShape(24.dp)).background(UColors.tint(tint, 0.14f)).clickable(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(UColors.CardSolid), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.width(10.dp))
        Text(label, color = UColors.Cream, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 2)
    }
}

@Composable
fun HomeScreen(store: Store, s: Settings, nav: NavController) {
    val ctx = LocalContext.current
    val progress by store.observeAsState { store.todayProgress() }
    val tas by store.observeAsState { store.tasbih() }
    val taps by store.observeAsState { store.todayTaps() }
    val today = remember { LocalDate.now() }
    val hour = remember { LocalTime.now().hour }
    val suggested = TimeLogic.suggestedCategory(hour)
    var heroOffset by rememberSaveable { mutableIntStateOf(0) }
    var heroHidden by rememberSaveable { mutableStateOf(false) }
    var howTo by remember { mutableStateOf(false) }
    val pool = remember(suggested) {
        AdhkarData.forCategory(suggested).filter { it.isShort }.ifEmpty { AdhkarData.all.filter { it.isShort } }
    }
    val hero = pool[Math.floorMod(today.dayOfYear + heroOffset, pool.size)]
    val (done, total) = categoryProgress(suggested, progress)
    val nextZikr = firstIncomplete(suggested, progress)
    val goal = s.dailyGoal
    val hijri = DateText.hijri(today)

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {

        // ---- الرأس: حبّة الترحيب + أزرار دائرية
        item {
            Appear {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        Modifier.weight(1f).height(60.dp).softSurface(PILL).clickable { nav.navigate("appsettings") }.padding(horizontal = 18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            val name = if (s.userName.isNotBlank()) " ${s.userName}" else ""
                            Text("${LocalVoice.current.greeting(hour)}$name", color = UColors.Gold, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1)
                            Text("أُنسي · أذكارك أقرب", color = UColors.CreamDim, fontSize = 12.sp, maxLines = 1)
                        }
                        Icon(Ico.Expand, null, tint = UColors.Cream)
                    }
                    CircleIconButton(Ico.Search, "بحث", { nav.navigate("adhkar") }, 56.dp)
                    CircleIconButton(Ico.Heart, "المفضلة", { nav.navigate("favorites") }, 56.dp)
                    CircleIconButton(Ico.Bell, "التذكيرات", { nav.navigate("reminders") }, 56.dp)
                }
            }
        }

        // ---- صف الحبوب: التاريخ + عدّاد اليوم + السجل
        item {
            Appear(60) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        Modifier.weight(1f).height(54.dp).softSurface(PILL, 3.dp).clickable { nav.navigate("stats") }.padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Ico.Calendar, null, tint = UColors.Gold, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.width(10.dp))
                        Text(
                            "${DateText.weekDay(today.dayOfWeek)}، " + (hijri ?: DateText.gregorian(today)),
                            color = UColors.Cream, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
                        )
                        Icon(Ico.Expand, null, tint = UColors.CreamDim)
                    }
                    Row(
                        Modifier.height(54.dp).clip(PILL).background(UColors.Gold.copy(alpha = 0.10f)).border(1.5.dp, UColors.Gold, PILL)
                            .clickable { nav.navigate("tasbih") }.padding(horizontal = 18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(Arabic.digits(taps), color = UColors.Cream, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                        Spacer(Modifier.width(8.dp))
                        Icon(Ico.Star, "ضغطات اليوم", tint = UColors.Gold)
                    }
                    CircleIconButton(Ico.History, "السجل", { nav.navigate("stats") }, 54.dp)
                }
            }
        }

        // ---- حاوية أبيض بالبلاطات الملونة
        item {
            Appear(120) {
                Column(Modifier.fillMaxWidth().softSurface(RoundedCornerShape(30.dp), 3.dp).padding(vertical = 16.dp)) {
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Category.values().forEach { c ->
                            val (d, t) = categoryProgress(c, progress)
                            CategoryTile(c, d, t) { nav.navigate("list/${c.name}") }
                        }
                    }
                }
            }
        }

        // ---- البطاقة الكبيرة الملوّنة: ورد اليوم
        item {
            Appear(180) {
                val shape = RoundedCornerShape(34.dp)
                Column(
                    Modifier.fillMaxWidth().clip(shape)
                        .background(Brush.verticalGradient(listOf(UColors.tint(UColors.Gold, 0.20f), UColors.tint(UColors.Gold, 0.06f))))
                        .border(1.dp, UColors.Gold.copy(alpha = 0.18f), shape)
                        .padding(16.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(10.dp).clip(CircleShape).background(UColors.Gold))
                        Spacer(Modifier.width(8.dp))
                        Text("وردك الآن · ${suggested.title}", color = UColors.Cream, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        PillChip("التذكير", Ico.Alarm) { nav.navigate("reminders") }
                        Spacer(Modifier.width(8.dp))
                        CircleIconButton(Ico.Chevron, "فتح القسم", { nav.navigate("list/${suggested.name}") }, 44.dp)
                    }
                    Spacer(Modifier.height(18.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                        StatBlock("المتبقي", Arabic.digits((total - done).coerceAtLeast(0)), "من ${Arabic.digits(total)} ذكرًا", if (total == 0) 0f else done.toFloat() / total, Modifier.weight(1f))
                        Box(Modifier.padding(horizontal = 8.dp).width(1.dp).height(96.dp).background(UColors.Cream.copy(alpha = 0.12f)))
                        StatBlock("تسبيح اليوم", Arabic.digits(tas.todayTotal), "من ${Arabic.digits(goal)}", tas.todayTotal.toFloat() / goal, Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Ico.Refresh, null, tint = UColors.CreamDim, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("آخر تحديث: الآن", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        Text("يتجدد الورد كل يوم", color = UColors.CreamDim, fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        CtaButton(
                            if (done == 0) "ابدأ الآن" else if (nextZikr != null) "أكمل وردك" else "راجع وردك", Ico.Book,
                            { nav.navigate("list/${suggested.name}" + (nextZikr?.let { "?start=${it.id}" } ?: "")) },
                            Modifier.weight(1.5f),
                        )
                        Column(
                            Modifier.weight(1f).height(60.dp).softSurface(PILL, 0.dp).clickable { nav.navigate("tasbih") }.padding(horizontal = 16.dp),
                            verticalArrangement = Arrangement.Center,
                        ) {
                            Text("المسبحة", color = UColors.CreamDim, fontSize = 12.sp)
                            Text("${Arabic.digits(tas.count)} / ${Arabic.digits(tas.target)}", color = UColors.Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    }
                }
            }
        }

        // ---- ذكر اليوم: بانر على طراز البطاقات الترويجية
        item { SectionTitle("ذكر اليوم") }
        item {
            AnimatedVisibility(!heroHidden) {
                val shape = RoundedCornerShape(30.dp)
                val accent = hero.category.tint()
                Row(
                    Modifier.fillMaxWidth().clip(shape).background(UColors.tint(accent, 0.20f)).padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(hero.title, color = UColors.Cream, fontWeight = FontWeight.Bold, fontSize = 22.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            CircleIconButton(Ico.Close, "إخفاء", { heroHidden = true }, 38.dp)
                        }
                        Spacer(Modifier.height(6.dp))
                        AnimatedContent(targetState = hero, transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(150)) }, label = "hero") { z ->
                            Text(z.text, color = UColors.Cream.copy(alpha = 0.85f), fontSize = 18.sp, lineHeight = 30.sp, maxLines = 4, overflow = TextOverflow.Ellipsis, fontFamily = LocalAppFont.current)
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(
                                Modifier.clip(PILL).background(UColors.Cream).clickable { nav.navigate("list/${hero.category.name}?start=${hero.id}") }.padding(horizontal = 22.dp, vertical = 12.dp),
                            ) { Text("اعرف أكثر", color = UColors.CardSolid, fontWeight = FontWeight.Bold) }
                            PillChip("التالي", Ico.Forward) { heroOffset++ }
                            CircleIconButton(Ico.Share, "مشاركة", { shareZikr(ctx, hero) }, 44.dp)
                        }
                    }
                    Spacer(Modifier.width(10.dp))
                    Box(Modifier.size(72.dp).clip(CircleShape).background(UColors.CardSolid.copy(alpha = 0.7f)), contentAlignment = Alignment.Center) {
                        Icon(hero.category.icon(), null, tint = accent, modifier = Modifier.size(38.dp))
                    }
                }
            }
        }

        // ---- متابعة الورد
        item { SectionTitle("متابعة الورد") }
        val resume = Category.values().mapNotNull { c ->
            val (d, t) = categoryProgress(c, progress)
            val started = AdhkarData.forCategory(c).any { (progress[it.id] ?: 0) > 0 }
            val next = firstIncomplete(c, progress)
            if (started && next != null && d < t) Triple(c, d to t, next) else null
        }.take(3)
        if (resume.isEmpty()) {
            item {
                EmptyState(Ico.Book, "لم تبدأ وردًا اليوم بعد", "ابدأ بـ${suggested.title}، وسيظهر هنا ما لم تُكمله لتستأنفه من موضعك.", "ابدأ ${suggested.title}") { nav.navigate("list/${suggested.name}") }
            }
        } else {
            items(resume.size) { i ->
                val (c, dt, next) = resume[i]
                GlassCard(Modifier.fillMaxWidth(), onClick = { nav.navigate("list/${c.name}?start=${next.id}") }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(50.dp).clip(RoundedCornerShape(16.dp)).background(UColors.tint(c.tint(), 0.2f)), contentAlignment = Alignment.Center) {
                            Icon(c.icon(), null, tint = c.tint())
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(c.title, color = UColors.Cream, fontWeight = FontWeight.Bold)
                            Text("التالي: ${next.title}", color = UColors.CreamDim, fontSize = 12.sp, maxLines = 1)
                            Spacer(Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress = { dt.first.toFloat() / dt.second },
                                modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                                color = UColors.Gold, trackColor = UColors.Cream.copy(alpha = 0.10f),
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        Icon(Ico.Chevron, null, tint = UColors.Gold)
                    }
                }
            }
        }

        // ---- اكتشف: بلاطات ملوّنة
        item { SectionTitle("اكتشف") }
        item {
            val tiles = listOf(
                listOf(
                    Triple(Ico.Heart, "المفضلة", Color(0xFFEC4899)) to { nav.navigate("favorites") },
                    Triple(Ico.Chart, "الإحصائيات", Color(0xFF3B82F6)) to { nav.navigate("stats") },
                ),
                listOf(
                    Triple(Ico.Palette, "الثيمات", Color(0xFF8B5CF6)) to { nav.navigate("themes") },
                    Triple(Ico.Alarm, "التذكيرات", Color(0xFFF59E0B)) to { nav.navigate("reminders") },
                ),
                listOf(
                    Triple(Ico.Share, "مشاركة ذكر", Color(0xFF14B8A6)) to { shareZikr(ctx, hero) },
                    Triple(Ico.Widgets, "الويدجت", Color(0xFF10B981)) to { nav.navigate("widgets") },
                ),
            )
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                tiles.forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        row.forEach { (spec, action) ->
                            DiscoverTile(spec.first, spec.second, spec.third, Modifier.weight(1f), action)
                        }
                    }
                }
            }
        }

        // ---- الويدجت
        item { SectionTitle("ودجت الشاشة الرئيسية") }
        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    listOf(WidgetStyle.CINEMATIC, WidgetStyle.LUXE, WidgetStyle.TASBIH, WidgetStyle.GLASS, WidgetStyle.PERIOD).forEach {
                        WidgetPreview(it, Modifier.clickable { nav.navigate("widgets") })
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text("أضف الودجت من شاشة الهاتف الرئيسية لتقرأ ذكرك دون فتح التطبيق.", color = UColors.CreamDim, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillButton("كل الودجت", { nav.navigate("widgets") }, icon = Ico.Widgets)
                    PillButton("التعليمات", { howTo = true }, icon = Ico.Help, filled = false)
                }
            }
        }

        // ---- مقترح لهذه الفترة
        item { SectionTitle("مقترح لهذه الفترة") }
        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Text("بحسب ساعة جهازك فقط (${suggested.title})، دون تحديد وقت صلاة.", color = UColors.CreamDim, fontSize = 12.sp)
                AdhkarData.forCategory(suggested).take(3).forEach { z ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { nav.navigate("list/${z.category.name}?start=${z.id}") }.padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(z.title, color = UColors.Cream, modifier = Modifier.weight(1f))
                        Text(if (z.count > 0) "×${Arabic.digits(z.count)}" else "∞", color = UColors.Gold, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
    if (howTo) WidgetHowToDialog { howTo = false }
}
