plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.unsee.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.unsee.app"
        // API 26 = Android 8.0: يغطي أكثر من 95% من الأجهزة، ويتيح requestPinAppWidget وقنوات الإشعارات
        // وAdaptive Icons وjava.time دون مكتبات إضافية.
        minSdk = 26
        targetSdk = 34
        versionCode = 4
        versionName = "1.4.0"
    }

    buildTypes {
        release {
            // لا نفعّل R8/shrinkResources: التطبيق يبحث عن خط Amiri اختياريًا عبر getIdentifier
            // وهذا يتعارض مع تقليص الموارد. حجم APK يبقى صغيرًا لأننا لا نستخدم مكتبات أيقونات ضخمة.
            isMinifyEnabled = false
            isShrinkResources = false
            // توقيع بمفتاح debug ليكون APK الإصدار قابلًا للتثبيت مباشرة للاستخدام الشخصي.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }
    testOptions { unitTests.isReturnDefaultValues = true }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")
    implementation("androidx.navigation:navigation-compose:2.8.2")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    val composeBom = platform("androidx.compose:compose-bom:2024.09.00")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material3:material3")
    // أيقونات احترافية بدل الرموز التعبيرية (تُحمَّل الأيقونات المستخدمة فقط عند تفعيل R8 في الإصدار)
    implementation("androidx.compose.material:material-icons-extended")

    testImplementation("junit:junit:4.13.2")
}
