# تجهيز أسرار توقيع أنسي على GitHub

لا تضع ملف JKS أو كلمات المرور داخل المستودع أو ملف ZIP.

من Termux على الهاتف:
1. أنشئ ملف Base64 من ملف المفتاح:
   base64 /storage/emulated/0/Unsee-Play-Store/01-Signing-Key/unsee-upload-key.jks | tr -d '\n' > /storage/emulated/0/Unsee-Play-Store/01-Signing-Key/unsee-upload-key.base64.txt
2. افتح ملف `unsee-upload-key.base64.txt` وانسخ محتواه إلى GitHub Actions Secret باسم `UNSEE_KEYSTORE_BASE64`.
3. أضف Secrets التالية في إعدادات المستودع > Secrets and variables > Actions:
   - `UNSEE_KEYSTORE_PASSWORD`: كلمة مرور الـ keystore.
   - `UNSEE_KEY_ALIAS`: اكتب `unsee`.
   - `UNSEE_KEY_PASSWORD`: كلمة مرور المفتاح الخاص. إذا ضغطت Enter عند سؤال keytool عن كلمة مرور المفتاح، فهي نفس كلمة مرور الـ keystore.
4. لا ترسل أي كلمة مرور أو محتوى Base64 في المحادثات.
5. بعد حفظ الأسرار، شغّل GitHub Actions يدويًا من تبويب Actions.

الـ workflow يبني اختبارات الوحدة وAPK تجريبيًا وAAB Release.
ملف AAB الناتج: `app/build/outputs/bundle/release/app-release.aab`.

ملاحظة: إذا كان المستودع عامًا، فالأسرار تُحفظ في GitHub Secrets ولا تُكتب في ملفات المشروع.
