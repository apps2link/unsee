package com.unsee.app.ui

import android.content.SharedPreferences
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import com.unsee.app.data.CompanionStore
import com.unsee.app.overlay.living.BatterySaver
import com.unsee.app.overlay.living.FxLevel
import com.unsee.app.overlay.living.IconCategory
import com.unsee.app.overlay.living.LivingConfig
import com.unsee.app.overlay.living.LivingIconPreviewView
import com.unsee.app.overlay.living.LivingIconType
import com.unsee.app.overlay.living.LivingMode
import com.unsee.app.overlay.living.LivingPrefs

private val BOX_PRESETS = listOf(
    0xFF0B1B3A, 0xFF12294F, 0xFF0F4D3A, 0xFF14532D, 0xFF5B1230, 0xFF3B2A78,
    0xFF1F2430, 0xFF4A3410, 0xFFF8F5EE, 0xFFFFF4D6, 0xFFEDE7FF, 0xFFE3F6EC,
)

internal fun parseHexColor(raw: String): Int? {
    val t = raw.trim().removePrefix("#")
    if (!Regex("^[0-9A-Fa-f]{6}$").matches(t)) return null
    return (0xFF000000L or t.toLong(16)).toInt()
}

internal fun toHexColor(argb: Int): String = "#%06X".format(argb and 0x00FFFFFF)

private fun isDarkColor(argb: Int): Boolean {
    val r = (argb shr 16) and 0xFF; val g = (argb shr 8) and 0xFF; val b = argb and 0xFF
    return (0.299f * r + 0.587f * g + 0.114f * b) / 255f < 0.55f
}

@Composable
fun LivingIconsScreen(nav: NavController) {
    val ctx = LocalContext.current
    val cs = remember { CompanionStore.get(ctx) }
    val cfg by cs.observeAsState { LivingPrefs.read(ctx) }
    var previewType by remember { mutableStateOf(cfg.defaultIcon) }
    fun save(block: SharedPreferences.Editor.() -> Unit) = LivingPrefs.edit(ctx, block)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ScreenHeader("أيقونات أُنسي الحيّة", { nav.popBackStack() })

        SectionLabel("ANSEE LIVING ICONS")
        GlassCard(Modifier.fillMaxWidth()) {
            SwitchRow("الأيقونات المتحركة", "اقفلها لترجع الفقاعة لرمزها المرسوم الأصلي. الفقاعة والتذكيرات تعمل في الحالتين.", cfg.enabled) { save { putBoolean("li_on", it) } }
        }

        // معاينة مباشرة قبل التطبيق
        GlassCard(Modifier.fillMaxWidth()) {
            Text("معاينة مباشرة", color = UColors.Cream, fontWeight = FontWeight.Bold)
            Text("هذه نفس الأيقونة بنفس الرسوم المتحركة وبإعداداتك الحالية. اختر واحدة لتراها قبل تطبيقها.", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                AndroidView(factory = { LivingIconPreviewView(it) }, update = { it.set(previewType, cfg) }, modifier = Modifier.size(160.dp))
            }
            Spacer(Modifier.height(8.dp))
            ChipRow(LivingIconType.values().toList(), { it == previewType }, { it.label }) { previewType = it }
            Spacer(Modifier.height(8.dp))
            PillButton("اجعلها الأيقونة الافتراضية", { save { putString("li_def", previewType.name) } })
            Text("الافتراضية الآن: ${cfg.defaultIcon.label}. تظهر حين لا يوجد تذكير معلّق (أو دائمًا في وضع «أيقونة ثابتة»).", color = UColors.CreamDim, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
        }

        SectionLabel("اختيار الأيقونة")
        GlassCard(Modifier.fillMaxWidth()) {
            ChipRow(LivingMode.values().toList(), { it == cfg.mode }, { it.label }) { save { putString("li_mode", it.name) } }
            Text(
                when (cfg.mode) {
                    LivingMode.AUTO -> "تتبدّل الأيقونة تلقائيًا حسب فئة أول تذكير معلّق فعليًا: قرآن ← المصحف، تسبيح ← السبحة، صلاة على النبي ← السحابة، صلاة ← المسجد، استغفار ← القلب، إيجابية وعمل صالح ← النبتة."
                    LivingMode.FIXED -> "تبقى الأيقونة الافتراضية ثابتة مهما كان نوع التذكير."
                    LivingMode.PER_CATEGORY -> "اختر أيقونة لكل فئة. «تلقائي» يعني الأيقونة المناسبة للفئة."
                },
                color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp),
            )
            if (cfg.mode == LivingMode.PER_CATEGORY) {
                IconCategory.values().forEach { cat ->
                    val cur = cfg.perCategory[cat.key]
                    Text(cat.label, color = UColors.Cream, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp, bottom = 4.dp))
                    ChipRow(listOf<LivingIconType?>(null) + LivingIconType.values().toList(), { it == cur }, { it?.label ?: "تلقائي" }) { LivingPrefs.setCategoryIcon(ctx, cat, it) }
                }
            }
        }

        SectionLabel("الحركة والتأثيرات")
        GlassCard(Modifier.fillMaxWidth()) {
            LabeledSlider("سرعة الحركة: ${cfg.speedPct}%", cfg.speedPct.toFloat(), 40f..200f) { save { putInt("li_speed", it.toInt()) } }
            SwitchRow("الجسيمات الضوئية", "نجوم وشرارات ونقاط تتحرك حول الأيقونة", cfg.particles) { save { putBoolean("li_part", it) } }
            SwitchRow("الوهج والإضاءة", "هالات الضوء حول الأيقونة وداخلها", cfg.glow) { save { putBoolean("li_glow", it) } }
            Text("مستوى التأثيرات", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp, bottom = 4.dp))
            ChipRow(FxLevel.values().toList(), { it == cfg.level }, { it.label }) { save { putString("li_level", it.name) } }
            Text("حجم الأيقونة العائمة", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp, bottom = 4.dp))
            ChipRow(LivingConfig.SIZE_LABELS.indices.toList(), { it == cfg.sizeIdx }, { LivingConfig.SIZE_LABELS[it] }) { save { putInt("li_size", it) } }
        }

        SectionLabel("توفير البطارية")
        GlassCard(Modifier.fillMaxWidth()) {
            ChipRow(BatterySaver.values().toList(), { it == cfg.battery }, { it.label }) { save { putString("li_batt", it.name) } }
            Text("التوفير يخفّض معدل الإطارات والجسيمات فقط ولا يلغي الأيقونة. الحركة تتوقف تمامًا حين تكون الفقاعة مخفية أو وأنت داخل أُنسي، وتتوقف أيضًا مع «إزالة الرسوم المتحركة» في النظام.", color = UColors.CreamDim, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
        }

        BoxAppearanceSection(cfg)
    }
}

@Composable
private fun BoxAppearanceSection(cfg: LivingConfig) {
    val ctx = LocalContext.current
    val startColor = cfg.boxColor ?: 0xFF12294F.toInt()
    val hsv0 = remember { FloatArray(3).also { android.graphics.Color.colorToHSV(startColor, it) } }
    var hue by remember { mutableFloatStateOf(hsv0[0]) }
    var sat by remember { mutableFloatStateOf(hsv0[1]) }
    var value by remember { mutableFloatStateOf(hsv0[2]) }
    var hex by remember { mutableStateOf(toHexColor(startColor)) }

    fun commit(argb: Int) { LivingPrefs.setBoxColor(ctx, argb) }
    fun fromPicker() {
        val c = android.graphics.Color.HSVToColor(floatArrayOf(hue, sat, value))
        hex = toHexColor(c); commit(c)
    }
    fun setColor(argb: Int) {
        val t = FloatArray(3); android.graphics.Color.colorToHSV(argb, t)
        hue = t[0]; sat = t[1]; value = t[2]; hex = toHexColor(argb); commit(argb)
    }

    SectionLabel("NOTIFICATION BOX APPEARANCE")
    GlassCard(Modifier.fillMaxWidth()) {
        Text("معاينة مباشرة لصندوق الإشعارات", color = UColors.Cream, fontWeight = FontWeight.Bold)
        Text("اللون والشفافية يغيّران طبقة الخلفية فقط. اللمعة والوهج وحركات البطاقة والأزرار تبقى كما هي فوق أي لون.", color = UColors.CreamDim, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
        BoxPreview(cfg)
    }

    GlassCard(Modifier.fillMaxWidth()) {
        Text("لون الخلفية", color = UColors.Cream, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text("الألوان الجاهزة", color = UColors.CreamDim, fontSize = 12.sp)
        Row(Modifier.padding(vertical = 8.dp).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BOX_PRESETS.take(6).forEach { p -> Swatch(p, cfg.boxColor == p.toInt()) { setColor(p.toInt()) } }
        }
        Row(Modifier.padding(bottom = 8.dp).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BOX_PRESETS.drop(6).forEach { p -> Swatch(p, cfg.boxColor == p.toInt()) { setColor(p.toInt()) } }
        }
        PickerSlider("الدرجة", hue, 0f..360f) { hue = it; fromPicker() }
        PickerSlider("التشبّع", sat, 0f..1f) { sat = it; fromPicker() }
        PickerSlider("السطوع", value, 0f..1f) { value = it; fromPicker() }
        OutlinedTextField(
            value = hex,
            onValueChange = { t ->
                hex = t.take(7)
                parseHexColor(hex)?.let { c ->
                    val h = FloatArray(3); android.graphics.Color.colorToHSV(c, h)
                    hue = h[0]; sat = h[1]; value = h[2]; commit(c)
                }
            },
            label = { Text("HEX") },
            singleLine = true,
            isError = hex.isNotEmpty() && parseHexColor(hex) == null,
            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Ascii),
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        )
        LabeledSlider("شفافية الخلفية: ${cfg.boxOpacityPct}%", cfg.boxOpacityPct.toFloat(), LivingConfig.MIN_BOX_OPACITY.toFloat()..100f) {
            LivingPrefs.edit(ctx) { putInt("li_boxalpha", it.toInt()) }
        }
        Text("أقل شفافية مسموحة ${LivingConfig.MIN_BOX_OPACITY}% كي يبقى النص مقروءًا. لون النص يتبدّل تلقائيًا (فاتح/داكن) بحسب سطوع الخلفية.", color = UColors.CreamDim, fontSize = 11.sp)
        Spacer(Modifier.height(8.dp))
        PillButton("استعادة التصميم الافتراضي", {
            LivingPrefs.resetBox(ctx)
            val t = FloatArray(3); android.graphics.Color.colorToHSV(0xFF12294F.toInt(), t)
            hue = t[0]; sat = t[1]; value = t[2]; hex = toHexColor(0xFF12294F.toInt())
        }, filled = false)
    }
}

@Composable
private fun Swatch(argb: Long, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(38.dp).clip(CircleShape).background(Color(argb))
            .border(if (selected) 3.dp else 1.dp, if (selected) UColors.Gold else UColors.Cream.copy(alpha = 0.35f), CircleShape)
            .clickable(onClick = onClick),
    )
}

@Composable
private fun PickerSlider(label: String, v: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Text(label, color = UColors.CreamDim, fontSize = 12.sp)
    Slider(
        value = v, onValueChange = onChange, valueRange = range,
        colors = SliderDefaults.colors(thumbColor = UColors.Gold, activeTrackColor = UColors.Gold, inactiveTrackColor = UColors.Gold.copy(alpha = 0.25f)),
    )
}

/** نموذج مرئي للصندوق: الخلفية بلون المستخدم، وفوقها لمعة متحركة مستقلة لإثبات أن الحركات لا تتأثر باللون. */
@Composable
private fun BoxPreview(cfg: LivingConfig) {
    val base = cfg.boxColor ?: 0xFF12294F.toInt()
    val dark = isDarkColor(base)
    val shape = RoundedCornerShape(28.dp)
    val tr = rememberInfiniteTransition(label = "boxShine")
    val p by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(2800, easing = LinearEasing), RepeatMode.Restart), label = "p")
    Column(
        Modifier.fillMaxWidth().clip(shape)
            .background(Color(base).copy(alpha = cfg.boxOpacityPct / 100f))
            .border(1.2.dp, Color.White.copy(alpha = if (dark) 0.35f else 0.8f), shape)
            .drawWithContent {
                drawContent()
                val x = size.width * (p * 1.6f - 0.3f)
                drawRect(Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = if (dark) 0.16f else 0.35f), Color.Transparent), startX = x - 80f, endX = x + 80f))
            }
            .padding(16.dp),
    ) {
        val primary = if (dark) Color(0xFFFFF4D6) else Color(0xFF1B2540)
        val secondary = if (dark) Color(0xFFC9C1A5) else Color(0xFF55607A)
        Text("ذكر", color = if (dark) Color(0xFFC4B5FD) else Color(0xFF4A3F8F), fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Text("سبحان الله وبحمده، سبحان الله العظيم", color = primary, fontSize = 18.sp, modifier = Modifier.padding(top = 6.dp))
        Text("— متفق عليه", color = secondary, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
    }
}
