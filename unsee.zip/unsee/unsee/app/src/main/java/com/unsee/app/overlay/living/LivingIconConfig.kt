package com.unsee.app.overlay.living

import android.content.Context
import android.content.SharedPreferences
import com.unsee.app.core.LogKind
import com.unsee.app.data.MsgCategory

/** الأيقونات الحيّة السبع. [label] اسم العرض في الإعدادات. */
enum class LivingIconType(val label: String) {
    LANTERN("الفانوس الذهبي"),
    QURAN("المصحف الشريف"),
    PLANT("النبتة الإيجابية"),
    TASBIH("السبحة"),
    MOSQUE("المسجد والهلال"),
    HEART("القلب النابض"),
    CLOUD("سحابة صلِّ على النبي"),
}

enum class LivingMode(val label: String) {
    AUTO("تلقائي حسب نوع التذكير"),
    FIXED("أيقونة ثابتة"),
    PER_CATEGORY("أيقونة لكل فئة"),
}

/** مستوى التأثيرات: يتحكم بعدد الجسيمات والطبقات الزخرفية. */
enum class FxLevel(val label: String, val particleScale: Float) {
    LIGHT("خفيف", 0.4f), MEDIUM("متوسط", 0.75f), RICH("غني", 1.0f),
}

/** توفير البطارية: يخفّض معدل الإطارات والجسيمات ولا يلغي النظام. [fps] = 0 يعني معدل الشاشة. */
enum class BatterySaver(val label: String, val fps: Int, val particleK: Float) {
    OFF("بلا توفير", 0, 1f), BALANCED("متوازن", 30, 0.6f), STRONG("توفير أقصى", 15, 0.25f),
}

/** فئات التذكير التي يمكن للمستخدم ربط أيقونة بكل منها. المفتاح ثابت ويُحفظ في الإعدادات. */
enum class IconCategory(val key: String, val label: String) {
    QURAN("QURAN", "القرآن الكريم"),
    TASBIH("TASBIH", "التسبيح والتحميد"),
    SALAWAT("SALAWAT", "الصلاة على النبي ﷺ"),
    MORNING("MORNING", "أذكار الصباح"),
    EVENING("EVENING", "أذكار المساء"),
    ISTIGHFAR("ISTIGHFAR", "الاستغفار والتوبة"),
    POSITIVE("POSITIVE", "الإيجابية والعمل الصالح"),
    PRAYER("PRAYER", "تذكير الصلاة"),
    DUA("DUA", "الدعاء"),
    MUHASABA("MUHASABA", "محاسبة النفس"),
}

data class LivingConfig(
    val enabled: Boolean = true,
    val mode: LivingMode = LivingMode.AUTO,
    val defaultIcon: LivingIconType = LivingIconType.LANTERN,
    val perCategory: Map<String, LivingIconType> = emptyMap(),
    val speedPct: Int = 100,
    val particles: Boolean = true,
    val glow: Boolean = true,
    val level: FxLevel = FxLevel.MEDIUM,
    val sizeIdx: Int = 1,
    val battery: BatterySaver = BatterySaver.OFF,
    // مظهر صندوق الإشعارات
    val boxColor: Int? = null,      // ARGB؛ null = التصميم الافتراضي
    val boxOpacityPct: Int = 100,   // ٤٠..١٠٠ (لا ينزل عن ٤٠ كي يبقى النص مقروءًا)
) {
    val speed: Float get() = speedPct.coerceIn(40, 200) / 100f
    val sizeScale: Float get() = SIZE_SCALES[sizeIdx.coerceIn(0, SIZE_SCALES.lastIndex)]

    companion object {
        val SIZE_SCALES = floatArrayOf(0.85f, 1.0f, 1.25f)
        val SIZE_LABELS = listOf("صغير", "متوسط", "كبير")
        const val MIN_BOX_OPACITY = 40
    }
}

/** الحفظ في نفس SharedPreferences المستخدمة في التطبيق (unsee_prefs) فلا نظام تخزين ثانٍ. */
object LivingPrefs {
    private const val FILE = "unsee_prefs"
    private fun sp(ctx: Context): SharedPreferences = ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    private inline fun <reified T : Enum<T>> enumOr(s: SharedPreferences, key: String, def: T): T =
        runCatching { enumValueOf<T>(s.getString(key, def.name) ?: def.name) }.getOrDefault(def)

    fun encodeMap(m: Map<String, LivingIconType>): String = m.entries.joinToString(";") { "${it.key}=${it.value.name}" }

    fun decodeMap(raw: String): Map<String, LivingIconType> =
        raw.split(';').mapNotNull {
            val p = it.split('=')
            if (p.size != 2) return@mapNotNull null
            val t = runCatching { LivingIconType.valueOf(p[1]) }.getOrNull() ?: return@mapNotNull null
            p[0] to t
        }.toMap()

    fun read(ctx: Context): LivingConfig {
        val s = sp(ctx)
        val d = LivingConfig()
        return LivingConfig(
            enabled = s.getBoolean("li_on", d.enabled),
            mode = enumOr(s, "li_mode", d.mode),
            defaultIcon = enumOr(s, "li_def", d.defaultIcon),
            perCategory = decodeMap(s.getString("li_percat", "") ?: ""),
            speedPct = s.getInt("li_speed", d.speedPct),
            particles = s.getBoolean("li_part", d.particles),
            glow = s.getBoolean("li_glow", d.glow),
            level = enumOr(s, "li_level", d.level),
            sizeIdx = s.getInt("li_size", d.sizeIdx),
            battery = enumOr(s, "li_batt", d.battery),
            boxColor = if (s.contains("li_boxcolor")) s.getInt("li_boxcolor", 0) else null,
            boxOpacityPct = s.getInt("li_boxalpha", d.boxOpacityPct).coerceIn(LivingConfig.MIN_BOX_OPACITY, 100),
        )
    }

    fun edit(ctx: Context, block: SharedPreferences.Editor.() -> Unit) = sp(ctx).edit().apply(block).apply()

    fun setCategoryIcon(ctx: Context, cat: IconCategory, icon: LivingIconType?) {
        val m = read(ctx).perCategory.toMutableMap()
        if (icon == null) m.remove(cat.key) else m[cat.key] = icon
        edit(ctx) { putString("li_percat", encodeMap(m)) }
    }

    fun setBoxColor(ctx: Context, argb: Int?) = edit(ctx) { if (argb == null) remove("li_boxcolor") else putInt("li_boxcolor", argb or 0xFF000000.toInt()) }

    /** استعادة تصميم صندوق الإشعارات الافتراضي (لون وشفافية فقط؛ لا يمس إعدادات الأيقونات). */
    fun resetBox(ctx: Context) = edit(ctx) { remove("li_boxcolor"); remove("li_boxalpha") }
}

/**
 * ربط التذكير بالأيقونة اعتمادًا على بيانات التذكير الفعلية: نوع العنصر المعلّق ([LogKind]) وفئة رسالة الذكر
 * ([MsgCategory]) وساعة اليوم لأذكار الصباح/المساء. لا عشوائية.
 */
object LivingIconMapping {
    /** فئة الربط للعنصر المعلّق. [category] تكون null لغير رسائل الذكر. [hour] ساعة اليوم 0..23. */
    fun categoryFor(kind: LogKind, category: MsgCategory?, hour: Int): IconCategory = when (kind) {
        LogKind.PRAYER -> IconCategory.PRAYER
        LogKind.MUHASABA -> IconCategory.MUHASABA
        LogKind.HABIT -> IconCategory.POSITIVE
        LogKind.PLAN -> IconCategory.ISTIGHFAR
        LogKind.DHIKR -> when (category) {
            MsgCategory.QURAN -> IconCategory.QURAN
            MsgCategory.TASBIH -> IconCategory.TASBIH
            MsgCategory.SALAWAT -> IconCategory.SALAWAT
            MsgCategory.DAY_ADHKAR -> if (hour in 4..14) IconCategory.MORNING else IconCategory.EVENING
            MsgCategory.ISTIGHFAR, MsgCategory.PARENTS -> IconCategory.ISTIGHFAR
            MsgCategory.SALAH -> IconCategory.PRAYER
            MsgCategory.DUA, MsgCategory.AKHIRA -> IconCategory.DUA
            MsgCategory.MUHASABA -> IconCategory.MUHASABA
            MsgCategory.SABR_SHUKR, MsgCategory.TONGUE, MsgCategory.HOPE -> IconCategory.POSITIVE
            null -> IconCategory.DUA
        }
    }

    /** الأيقونة الافتراضية لكل فئة (قبل أي تخصيص من المستخدم). */
    fun defaultIconFor(cat: IconCategory): LivingIconType = when (cat) {
        IconCategory.QURAN -> LivingIconType.QURAN
        IconCategory.TASBIH -> LivingIconType.TASBIH
        IconCategory.SALAWAT -> LivingIconType.CLOUD
        IconCategory.MORNING -> LivingIconType.MOSQUE
        IconCategory.EVENING -> LivingIconType.LANTERN
        IconCategory.ISTIGHFAR -> LivingIconType.HEART
        IconCategory.POSITIVE -> LivingIconType.PLANT
        IconCategory.PRAYER -> LivingIconType.MOSQUE
        IconCategory.DUA -> LivingIconType.LANTERN
        IconCategory.MUHASABA -> LivingIconType.HEART
    }

    /** الأيقونة النهائية. [cat] = null حين لا يوجد شيء معلّق (حالة الخمول). */
    fun resolve(cfg: LivingConfig, cat: IconCategory?): LivingIconType = when (cfg.mode) {
        LivingMode.FIXED -> cfg.defaultIcon
        LivingMode.AUTO -> if (cat == null) cfg.defaultIcon else defaultIconFor(cat)
        LivingMode.PER_CATEGORY -> if (cat == null) cfg.defaultIcon else (cfg.perCategory[cat.key] ?: defaultIconFor(cat))
    }
}
