package com.unsee.app.overlay.living

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator

/**
 * معاينة حيّة للأيقونة داخل شاشة الإعدادات: نفس الرسّام ونفس التأثيرات التي تظهر في الفقاعة العائمة،
 * على كرة زجاجية داكنة. تتوقف الحركة عند فصل العنصر أو إخفائه فلا استهلاك في الخلفية.
 */
class LivingIconPreviewView(ctx: Context) : View(ctx) {
    private var painter: LivingIconPainter = LivingPainters.create(LivingIconType.LANTERN)
    private var type: LivingIconType = LivingIconType.LANTERN
    private var cfg = LivingConfig()
    private val fx = Fx()
    private val body = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0x66FFE9A8 }
    private val clipPath = android.graphics.Path()
    private var clock = 0f
    private var last = 0L
    private var lastFrame = 0L
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener {
            val now = System.nanoTime()
            val fps = cfg.battery.fps
            if (fps > 0 && now - lastFrame < 1_000_000_000L / fps) return@addUpdateListener
            lastFrame = now
            if (last != 0L) clock += ((now - last) / 1e9f).coerceAtMost(0.25f) * cfg.speed
            last = now
            invalidate()
        }
    }

    fun set(newType: LivingIconType, newCfg: LivingConfig) {
        if (newType != type) { type = newType; painter = LivingPainters.create(newType) }
        cfg = newCfg
        fx.apply(newCfg)
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val r = minOf(w, h) / 2f
        body.shader = RadialGradient(-r * 0.3f, -r * 0.38f, r * 1.45f, intArrayOf(0xFF2A4F8F.toInt(), 0xFF12294F.toInt(), 0xFF081327.toInt()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        rim.strokeWidth = resources.displayMetrics.density * 1.5f
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (visibility == VISIBLE && !anim.isStarted) { last = 0L; anim.start() } }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE && isAttachedToWindow) { if (!anim.isStarted) { last = 0L; anim.start() } } else anim.cancel()
    }

    override fun onDraw(c: Canvas) {
        val r = minOf(width, height) / 2f
        c.save(); c.translate(width / 2f, height / 2f)
        c.drawCircle(0f, 0f, r - rim.strokeWidth, body)
        c.save()
        clipPath.reset(); clipPath.addCircle(0f, 0f, r - rim.strokeWidth * 1.5f, android.graphics.Path.Direction.CW)
        c.clipPath(clipPath)
        painter.draw(c, r * 0.94f, clock, fx)
        c.restore()
        c.drawCircle(0f, 0f, r - rim.strokeWidth, rim)
        c.restore()
    }
}
