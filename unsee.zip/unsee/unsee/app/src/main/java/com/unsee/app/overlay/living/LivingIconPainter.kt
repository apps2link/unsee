package com.unsee.app.overlay.living

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import kotlin.math.PI
import kotlin.math.floor
import kotlin.math.roundToInt
import kotlin.math.sin

/** إعدادات التأثيرات اللحظية التي يقرؤها كل رسّام عند كل إطار (كائن واحد مشترك، لا تخصيص ذاكرة). */
class Fx {
    var glow = true
    var particles = true
    var pScale = 1f
    /** الطبقات الزخرفية الثانوية (انعكاسات، أشعة، ومضات): تُعطَّل في «خفيف» وفي توفير البطارية الأقصى. */
    var deco = true

    fun n(base: Int): Int {
        if (!particles || base <= 0) return 0
        return (base * pScale).roundToInt().coerceAtLeast(1)
    }

    fun apply(cfg: LivingConfig) {
        glow = cfg.glow
        particles = cfg.particles
        pScale = cfg.level.particleScale * cfg.battery.particleK
        deco = cfg.level != FxLevel.LIGHT && cfg.battery != BatterySaver.STRONG
    }
}

internal const val TAU = (2.0 * PI).toFloat()

/**
 * رسّام أيقونة حيّة. يرسم حول النقطة (0,0) داخل دائرة نصف قطرها [r]، والزمن [t] بالثواني (مضروب بسرعة المستخدم).
 * كل طبقة (فانوس، غلاف، صفحة، ورقة، حبة، نجمة...) لها دورتها الخاصة بأزمنة غير متناسبة كي لا تتكرر الحركة آليًا.
 * جميع الـ Paint والـ Path تُنشأ مرة واحدة، فلا تخصيص ذاكرة داخل [draw].
 */
abstract class LivingIconPainter {
    protected val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    protected val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    protected val glowP = Paint(Paint.ANTI_ALIAS_FLAG)
    protected val path = Path()
    protected val path2 = Path()

    abstract fun draw(c: Canvas, r: Float, t: Float, fx: Fx)

    // ---------------------------------------------------------------- أدوات الزمن
    protected fun sm(x: Float): Float { val k = x.coerceIn(0f, 1f); return k * k * (3f - 2f * k) }
    protected fun seg(u: Float, a: Float, b: Float): Float = sm((u - a) / (b - a))
    protected fun cyc(t: Float, period: Float, off: Float = 0f): Float {
        val v = ((t + off) / period) % 1f
        return if (v < 0f) v + 1f else v
    }
    protected fun wv(t: Float, period: Float, ph: Float = 0f): Float = sin((t / period + ph) * TAU)
    protected fun pulse(p: Float, a: Float, b: Float): Float = if (p < a || p > b) 0f else sin(PI.toFloat() * (p - a) / (b - a))
    protected fun hash(n: Int): Float { val x = sin(n * 12.9898f) * 43758.547f; return x - floor(x) }
    protected fun lerp(a: Float, b: Float, k: Float) = a + (b - a) * k
    protected fun overshoot(x: Float): Float { val k = x.coerceIn(0f, 1f) - 1f; return 1f + 2.2f * k * k * k + 1.2f * k * k }

    protected fun lerpColor(a: Int, b: Int, k: Float): Int {
        val q = k.coerceIn(0f, 1f)
        fun ch(s: Int) = (((a shr s) and 0xFF) + ((((b shr s) and 0xFF) - ((a shr s) and 0xFF)) * q)).toInt()
        return Color.argb(ch(24), ch(16), ch(8), ch(0))
    }

    protected fun alphaOf(color: Int, a: Float): Int = (color and 0x00FFFFFF) or ((a.coerceIn(0f, 1f) * 255f).toInt() shl 24)

    // ---------------------------------------------------------------- أدوات الرسم
    /** هالة شعاعية ناعمة: Shader بنصف قطر 1 يُكبَّر بالـ Canvas. */
    protected fun unitHalo(color: Int): Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = RadialGradient(0f, 0f, 1f, intArrayOf(alphaOf(color, 1f), alphaOf(color, 0.35f), alphaOf(color, 0f)), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
    }

    protected fun halo(c: Canvas, p: Paint, x: Float, y: Float, rad: Float, a: Float) {
        if (a <= 0.01f) return
        p.alpha = (a.coerceIn(0f, 1f) * 255f).toInt()
        c.save(); c.translate(x, y); c.scale(rad, rad); c.drawCircle(0f, 0f, 1f, p); c.restore()
    }

    protected fun unitRadial(cx: Float, cy: Float, rad: Float, vararg colors: Int): Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        val pos = FloatArray(colors.size) { it / (colors.size - 1f) }
        shader = RadialGradient(cx, cy, rad, colors, pos, Shader.TileMode.CLAMP)
    }

    protected fun unitBand(color: Int): Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = LinearGradient(-1f, 0f, 1f, 0f, intArrayOf(alphaOf(color, 0f), alphaOf(color, 1f), alphaOf(color, 0f)), null, Shader.TileMode.CLAMP)
    }

    protected fun sparkle(c: Canvas, x: Float, y: Float, s: Float, color: Int, a: Float) {
        if (a <= 0.02f || s <= 0.1f) return
        path.reset()
        path.moveTo(x, y - s); path.quadTo(x, y, x + s, y); path.quadTo(x, y, x, y + s); path.quadTo(x, y, x - s, y); path.quadTo(x, y, x, y - s); path.close()
        fill.shader = null
        fill.color = alphaOf(color, a)
        c.drawPath(path, fill)
    }

    protected fun dot(c: Canvas, x: Float, y: Float, rad: Float, color: Int, a: Float) {
        if (a <= 0.02f) return
        fill.shader = null
        fill.color = alphaOf(color, a)
        c.drawCircle(x, y, rad, fill)
    }
}
