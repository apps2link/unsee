package com.unsee.app.overlay.living

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

private const val GOLD = 0xFFE2B857.toInt()
private const val GOLD_DK = 0xFF9A6B1E.toInt()
private const val GOLD_LT = 0xFFFFE9A8.toInt()

/** الفانوس الذهبي: تأرجح حول نقطة التعليق، لهب يرتعش داخل الزجاج، هالة، مدارات ذهبية تدور، ومضات، لمعة تعبر المعدن. */
class LanternPainter : LivingIconPainter() {
    private val aura = unitHalo(0xFFFFC857.toInt())
    private val flame = unitRadial(0f, 0f, 1f, 0xFFFFFFE0.toInt(), 0xFFFFC23D.toInt(), 0x00FF8A00)
    private val band = unitBand(0xFFFFFFFF.toInt())
    private val oval = RectF()

    override fun draw(c: Canvas, r: Float, t: Float, fx: Fx) {
        val flick = (0.78f + 0.14f * wv(t, 1.9f) + 0.08f * wv(t, 0.61f, 0.3f)).coerceIn(0.4f, 1f)
        // هالة خلف الفانوس
        if (fx.glow) halo(c, aura, 0f, -0.05f * r, r * 1.05f, 0.35f + 0.3f * flick)

        // مدارات ذهبية خلف الفانوس
        drawOrbit(c, r, t, fx, back = true)

        // التأرجح: موجتان غير متناسبتين فتبدو الحركة طبيعية لا ميكانيكية
        val swing = 8.5f * (wv(t, 3.4f) + 0.35f * wv(t, 1.7f, 0.18f)) / 1.35f
        c.save()
        c.rotate(swing, 0f, -0.92f * r)
        line.shader = null; line.strokeWidth = r * 0.035f; line.color = GOLD
        c.drawCircle(0f, -0.92f * r, r * 0.07f, line)
        c.drawLine(0f, -0.85f * r, 0f, -0.70f * r, line)

        // القبعة العلوية
        fill.shader = null; fill.color = GOLD_DK
        path.reset()
        path.moveTo(-0.22f * r, -0.62f * r); path.quadTo(0f, -0.80f * r, 0.22f * r, -0.62f * r)
        path.lineTo(0.31f * r, -0.50f * r); path.lineTo(-0.31f * r, -0.50f * r); path.close()
        c.drawPath(path, fill)
        fill.color = GOLD
        c.drawRect(-0.31f * r, -0.52f * r, 0.31f * r, -0.47f * r, fill)

        // الجسم + الزجاج
        path.reset()
        path.moveTo(-0.30f * r, -0.50f * r); path.lineTo(0.30f * r, -0.50f * r); path.lineTo(0.36f * r, -0.05f * r)
        path.lineTo(0.24f * r, 0.36f * r); path.lineTo(-0.24f * r, 0.36f * r); path.lineTo(-0.36f * r, -0.05f * r); path.close()
        fill.color = GOLD_DK
        c.drawPath(path, fill)
        path2.reset()
        path2.moveTo(-0.22f * r, -0.42f * r); path2.lineTo(0.22f * r, -0.42f * r); path2.lineTo(0.27f * r, -0.05f * r)
        path2.lineTo(0.17f * r, 0.28f * r); path2.lineTo(-0.17f * r, 0.28f * r); path2.lineTo(-0.27f * r, -0.05f * r); path2.close()
        fill.color = 0xFF3A2606.toInt()
        c.drawPath(path2, fill)
        // لهب داخلي يزيد ويقل
        c.save(); c.clipPath(path2)
        c.translate(0f, -0.02f * r); c.scale(0.40f * r, 0.46f * r)
        flame.alpha = (flick * 255f).toInt()
        c.drawCircle(0f, 0f, 1f, flame)
        c.restore()
        // أضلاع الزخرفة
        line.strokeWidth = r * 0.03f; line.color = GOLD
        c.drawPath(path2, line)
        c.drawLine(-0.09f * r, -0.42f * r, -0.11f * r, 0.28f * r, line)
        c.drawLine(0.09f * r, -0.42f * r, 0.11f * r, 0.28f * r, line)
        c.drawLine(-0.26f * r, -0.18f * r, 0.26f * r, -0.18f * r, line)

        // لمعة تعبر الهيكل المعدني
        if (fx.deco) {
            c.save(); c.clipPath(path)
            val x = lerp(-0.6f, 0.6f, cyc(t, 4.7f)) * r
            c.translate(x, -0.05f * r); c.rotate(14f); c.scale(0.10f * r, 0.7f * r)
            band.alpha = 140
            c.drawRect(-1f, -1f, 1f, 1f, band)
            c.restore()
        }

        // القاعدة والنهاية
        fill.color = GOLD_DK
        path.reset(); path.moveTo(-0.24f * r, 0.36f * r); path.lineTo(0.24f * r, 0.36f * r); path.lineTo(0.08f * r, 0.52f * r); path.lineTo(-0.08f * r, 0.52f * r); path.close()
        c.drawPath(path, fill)
        fill.color = GOLD
        c.drawCircle(0f, 0.58f * r, r * 0.055f, fill)
        c.restore()

        drawOrbit(c, r, t, fx, back = false)

        // ومضات عشوائية خفيفة: موضع كل ومضة يتغيّر في كل دورة بقيمة ثابتة مشتقة من رقم الدورة
        if (fx.deco) for (i in 0 until fx.n(4)) {
            val period = 2.3f + 0.7f * i
            val cycleNo = ((t + i * 0.9f) / period).toInt()
            val p = cyc(t, period, i * 0.9f)
            val a = pulse(p, 0.05f, 0.35f)
            val ang = hash(cycleNo * 7 + i) * TAU
            val rad = (0.35f + 0.5f * hash(cycleNo * 13 + i)) * r
            sparkle(c, cos(ang) * rad, sin(ang) * rad * 0.9f, r * (0.06f + 0.06f * a), GOLD_LT, a)
        }
    }

    /** مداران ذهبيان يدوران ببطء مع جسيمات تتحرك عليهما. [back] = النصف الخلفي (قبل الفانوس). */
    private fun drawOrbit(c: Canvas, r: Float, t: Float, fx: Fx, back: Boolean) {
        if (!fx.deco && !fx.particles) return
        for (k in 0 until 2) {
            val rx = (0.92f - 0.12f * k) * r
            val ry = (0.30f + 0.08f * k) * r
            val rot = t * (26f + 13f * k) * (if (k == 0) 1f else -1f) + 25f * k
            c.save(); c.rotate(rot)
            if (fx.deco) {
                oval.set(-rx, -ry, rx, ry)
                line.shader = null; line.strokeWidth = r * 0.028f
                for (s in 0 until 9) {
                    val start = (if (back) 180f else 0f) + s * 20f
                    line.color = alphaOf(GOLD, (0.15f + 0.5f * (1f - s / 9f)) * (if (back) 0.5f else 1f))
                    c.drawArc(oval, start, 20f, false, line)
                }
            }
            for (i in 0 until fx.n(4)) {
                val ang = t * (0.9f + 0.25f * i + 0.2f * k) * (if (k == 0) 1f else -1f) + i * 1.57f
                val depth = sin(ang)
                if ((depth < 0f) != back) continue
                val tw = 0.55f + 0.45f * wv(t, 1.1f + 0.3f * i, i * 0.23f)
                dot(c, cos(ang) * rx, depth * ry, r * (0.035f + 0.02f * tw), GOLD_LT, 0.5f + 0.5f * tw)
            }
            c.restore()
        }
    }
}

/**
 * المصحف: دورة كاملة ١١ ثانية — مغلق، ينفتح الغلاف فعليًا حول الكعب (تقلّص أفقي ثم انقلاب إلى الوجه الداخلي)،
 * تُقلَّب صفحتان بالطريقة نفسها، يخرج وهج وأشعة من المنتصف، ثم يُغلق. لا تكبير/تصغير لصورة المصحف.
 */
class QuranPainter : LivingIconPainter() {
    private val glowH = unitHalo(0xFFFFD36B.toInt())
    private val shade = unitBand(0xFF000000.toInt())
    private val cycleSec = 11f

    override fun draw(c: Canvas, r: Float, t: Float, fx: Fx) {
        val u = ((t % cycleSec) + cycleSec) % cycleSec
        val theta = when {
            u < 1.0f -> 0f
            u < 3.0f -> PI_F * seg(u, 1.0f, 3.0f)
            u < 7.2f -> PI_F
            u < 9.0f -> PI_F * (1f - seg(u, 7.2f, 9.0f))
            else -> 0f
        }
        val open = theta / PI_F
        val w = 0.60f * r
        val top = -0.52f * r
        val bot = 0.32f * r
        val spineX = lerp(-0.30f * r, 0f, open)

        // الحامل الخشبي
        line.shader = null; line.color = 0xFF7A4A1E.toInt(); line.strokeWidth = r * 0.10f
        c.drawLine(-0.40f * r, 0.70f * r, 0.08f * r, 0.30f * r, line)
        c.drawLine(0.40f * r, 0.70f * r, -0.08f * r, 0.30f * r, line)
        fill.shader = null; fill.color = 0xFF5B3413.toInt()
        c.drawRoundRect(-0.62f * r, 0.66f * r, 0.62f * r, 0.76f * r, r * 0.04f, r * 0.04f, fill)

        // وهج ذهبي من منتصف المصحف
        if (fx.glow) halo(c, glowH, spineX, -0.1f * r, r * (0.55f + 0.45f * open), 0.65f * open)

        // لوح الغلاف الخلفي + كتلة الصفحات اليمنى
        fill.color = 0xFF0F5A34.toInt()
        c.drawRoundRect(spineX - 0.02f * r, top - 0.03f * r, spineX + w + 0.03f * r, bot + 0.03f * r, r * 0.03f, r * 0.03f, fill)
        if (open > 0.5f) c.drawRoundRect(spineX - w - 0.03f * r, top - 0.03f * r, spineX + 0.02f * r, bot + 0.03f * r, r * 0.03f, r * 0.03f, fill)
        drawPage(c, r, spineX, w, top, bot, scaleX = 1f, shadeA = 0f)

        // الصفحات المقلوبة: كل صفحة تنقلب حول الكعب بنفس آلية الغلاف
        if (open > 0.99f) {
            val f1 = seg(u, 3.6f, 4.8f)
            val f2 = seg(u, 5.4f, 6.6f)
            drawFlip(c, r, spineX, w, top, bot, 0, f1)
            drawFlip(c, r, spineX, w, top, bot, 1, f2)
        }

        // الغلاف المتحرك: وجه أمامي أخضر مزخرف ثم وجه داخلي
        if (theta > 0.001f) {
            val cs = cos(theta)
            c.save(); c.translate(spineX, 0f); c.scale(if (abs(cs) < 0.02f) 0.02f else cs, 1f)
            if (theta < PI_F / 2f) {
                fill.color = 0xFF157347.toInt()
                c.drawRoundRect(0f, top, w, bot, r * 0.03f, r * 0.03f, fill)
                line.color = GOLD; line.strokeWidth = r * 0.025f
                c.drawRoundRect(0.06f * r, top + 0.06f * r, w - 0.06f * r, bot - 0.06f * r, r * 0.02f, r * 0.02f, line)
                c.save(); c.translate(w / 2f, (top + bot) / 2f)
                fill.color = GOLD
                path.reset()
                for (i in 0 until 16) {
                    val a = i * TAU / 16f
                    val rr = if (i % 2 == 0) 0.17f * r else 0.08f * r
                    if (i == 0) path.moveTo(cos(a) * rr, sin(a) * rr) else path.lineTo(cos(a) * rr, sin(a) * rr)
                }
                path.close(); c.drawPath(path, fill)
                c.restore()
            } else {
                // الوجه الداخلي للغلاف يصير الصفحة اليسرى
                drawPageFlat(c, r, 0f, w, top, bot)
            }
            c.restore()
        } else {
            // مغلق: الغلاف الأمامي يغطي الصفحات
            fill.color = 0xFF157347.toInt()
            c.drawRoundRect(spineX, top, spineX + w, bot, r * 0.03f, r * 0.03f, fill)
            line.color = GOLD; line.strokeWidth = r * 0.025f
            c.drawRoundRect(spineX + 0.06f * r, top + 0.06f * r, spineX + w - 0.06f * r, bot - 0.06f * r, r * 0.02f, r * 0.02f, line)
            fill.color = GOLD
            path.reset()
            for (i in 0 until 16) {
                val a = i * TAU / 16f
                val rr = if (i % 2 == 0) 0.17f * r else 0.08f * r
                val px = spineX + w / 2f + cos(a) * rr
                val py = (top + bot) / 2f + sin(a) * rr
                if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
            }
            path.close(); c.drawPath(path, fill)
        }

        // أشعة ضوئية خافتة تدور حول المصحف وهو مفتوح
        if (fx.deco && fx.glow && open > 0.05f) {
            c.save(); c.translate(spineX, -0.1f * r); c.rotate(t * 9f)
            fill.shader = null
            for (i in 0 until 6) {
                val a = i * TAU / 6f
                fill.color = alphaOf(GOLD_LT, 0.16f * open * (0.6f + 0.4f * wv(t, 3f + i * 0.4f)))
                path.reset(); path.moveTo(0f, 0f)
                path.lineTo(cos(a - 0.09f) * r, sin(a - 0.09f) * r); path.lineTo(cos(a + 0.09f) * r, sin(a + 0.09f) * r); path.close()
                c.drawPath(path, fill)
            }
            c.restore()
        }
        // ذرات ضوء ذهبية صغيرة تصعد من المنتصف
        if (open > 0.3f) for (i in 0 until fx.n(5)) {
            val p = cyc(t, 3.1f + 0.4f * i, i * 0.31f)
            dot(c, spineX + (hash(i * 5) - 0.5f) * 0.9f * r, -0.1f * r - p * 0.7f * r, r * 0.03f, GOLD_LT, (1f - p) * open)
        }
    }

    private fun drawFlip(c: Canvas, r: Float, spineX: Float, w: Float, top: Float, bot: Float, i: Int, f: Float) {
        if (f <= 0f) return
        val ang = PI_F * f
        drawPage(c, r, spineX, w * (0.96f - 0.02f * i), top + 0.02f * r, bot - 0.02f * r, scaleX = cos(ang), shadeA = 0.28f * sin(ang))
    }

    private fun drawPage(c: Canvas, r: Float, spineX: Float, w: Float, top: Float, bot: Float, scaleX: Float, shadeA: Float) {
        val sx = if (abs(scaleX) < 0.02f) 0.02f else scaleX
        c.save(); c.translate(spineX, 0f); c.scale(sx, 1f)
        drawPageFlat(c, r, 0f, w, top, bot)
        if (shadeA > 0f) { shade.alpha = (shadeA * 255f).toInt(); c.save(); c.translate(w / 2f, 0f); c.scale(w / 2f, 1f); c.drawRect(-1f, top, 1f, bot, shade); c.restore() }
        c.restore()
    }

    /** صفحة بلون ورقي مع أسطر نص رفيعة. الإحداثيات محلية من الكعب إلى [w]. */
    private fun drawPageFlat(c: Canvas, r: Float, x0: Float, w: Float, top: Float, bot: Float) {
        fill.shader = null; fill.color = 0xFFFBF1D4.toInt()
        c.drawRoundRect(x0, top, x0 + w, bot, r * 0.02f, r * 0.02f, fill)
        line.shader = null; line.color = 0x66A67C2E; line.strokeWidth = r * 0.016f
        var y = top + 0.10f * r
        while (y < bot - 0.06f * r) { c.drawLine(x0 + 0.07f * r, y, x0 + w - 0.07f * r, y, line); y += 0.085f * r }
    }

    private companion object { const val PI_F = 3.14159265f }
}

/** النبتة: دورة ١٢ ثانية — شتلة صغيرة، نمو الساق، تفتّح الأوراق واحدة تلو الأخرى، تمايل بالهواء، حلقة خضراء، ثم عودة سلسة. */
class PlantPainter : LivingIconPainter() {
    private val ringHalo = unitHalo(0xFF4ADE80.toInt())
    private val streak = unitBand(0xFFFFFFFF.toInt())
    private val oval = RectF()
    private val cycleSec = 12f

    private class Leaf(val f: Float, val side: Float, val size: Float, val startAt: Float)
    private val leaves = arrayOf(Leaf(0.42f, -1f, 0.36f, 2.0f), Leaf(0.62f, 1f, 0.36f, 3.1f), Leaf(1f, -1f, 0.50f, 4.2f), Leaf(1f, 1f, 0.50f, 5.0f))

    override fun draw(c: Canvas, r: Float, t: Float, fx: Fx) {
        val u = ((t % cycleSec) + cycleSec) % cycleSec
        val shrink = 1f - seg(u, 10.2f, 11.6f)
        val g = (0.14f + 0.86f * seg(u, 0.4f, 4.0f)) * shrink + 0.14f * (1f - shrink)
        val yaw = t * 0.35f

        if (fx.glow) halo(c, ringHalo, 0f, 0.05f * r, r * 1.0f, 0.30f + 0.12f * wv(t, 3.7f))

        // حلقة ضوئية خضراء تدور حول الكرة
        if (fx.deco) {
            c.save(); c.rotate(t * 32f)
            oval.set(-0.94f * r, -0.40f * r, 0.94f * r, 0.40f * r)
            line.shader = null; line.strokeWidth = r * 0.04f
            for (s in 0 until 10) { line.color = alphaOf(0xFF86EFAC.toInt(), 0.75f * (1f - s / 10f)); c.drawArc(oval, s * 16f, 16f, false, line) }
            c.restore()
        }

        // التربة
        fill.shader = null; fill.color = 0xFF4A2E17.toInt()
        c.drawOval(-0.50f * r, 0.50f * r, 0.50f * r, 0.78f * r, fill)
        fill.color = 0xFF6B4423.toInt()
        c.drawOval(-0.40f * r, 0.50f * r, 0.40f * r, 0.66f * r, fill)

        // النبتة تدور ببطء (تقلّص أفقي دوري يوحي بالدوران داخل الكرة)
        c.save(); c.scale(0.72f + 0.28f * cos(yaw), 1f)
        val baseY = 0.58f * r
        val tipX = 0.07f * r * wv(t, 4.1f) * g
        val tipY = baseY - g * 1.12f * r
        val midX = -0.06f * r * wv(t, 5.3f, 0.2f) * g
        line.shader = null; line.color = 0xFF2F9E4F.toInt(); line.strokeWidth = r * (0.05f + 0.03f * g)
        path.reset(); path.moveTo(0f, baseY); path.quadTo(midX, (baseY + tipY) / 2f, tipX, tipY)
        c.drawPath(path, line)

        for ((i, lf) in leaves.withIndex()) {
            val grow = seg(u, lf.startAt, lf.startAt + 1.4f) * shrink
            if (grow <= 0.01f) continue
            val px = lerp(0f, tipX, lf.f * lf.f) + midX * (1f - lf.f) * lf.f * 1.6f
            val py = baseY + (tipY - baseY) * lf.f
            val ease = overshoot(grow)
            val openAng = lerp(-88f, -24f, ease.coerceIn(0f, 1.15f)) + 5.5f * wv(t, 2.6f + 0.5f * i, i * 0.3f)
            c.save(); c.translate(px, py)
            c.scale(lf.side, 1f); c.rotate(openAng)
            val s = lf.size * r * grow
            fill.shader = null; fill.color = if (i % 2 == 0) 0xFF4ADE80.toInt() else 0xFF34C46A.toInt()
            path.reset(); path.moveTo(0f, 0f); path.quadTo(s * 0.5f, -s * 0.42f, s, 0f); path.quadTo(s * 0.5f, s * 0.42f, 0f, 0f); path.close()
            c.drawPath(path, fill)
            line.color = 0xFF1F7A3A.toInt(); line.strokeWidth = max(0.5f, s * 0.04f)
            c.drawLine(0f, 0f, s * 0.92f, 0f, line)
            c.restore()
        }
        c.restore()

        // ومضات خضراء
        for (i in 0 until fx.n(5)) {
            val p = cyc(t, 2.4f + 0.5f * i, i * 0.37f)
            val no = ((t + i * 0.37f) / (2.4f + 0.5f * i)).toInt()
            val a = pulse(p, 0.1f, 0.6f)
            sparkle(c, (hash(no * 3 + i) - 0.5f) * 1.5f * r, (hash(no * 5 + i) - 0.6f) * 1.3f * r, r * (0.05f + 0.06f * a), 0xFFBBF7D0.toInt(), a)
        }
        // انعكاس زجاجي متحرك على سطح الكرة
        if (fx.deco) {
            val p = cyc(t, 5.3f)
            if (p < 0.4f) {
                c.save(); c.rotate(-28f); c.translate(lerp(-1.1f, 1.1f, p / 0.4f) * r, 0f); c.scale(0.12f * r, 1.0f * r)
                streak.alpha = 95; c.drawRect(-1f, -1f, 1f, 1f, streak); c.restore()
            }
        }
    }
}
