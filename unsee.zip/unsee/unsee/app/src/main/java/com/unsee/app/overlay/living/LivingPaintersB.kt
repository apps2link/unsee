package com.unsee.app.overlay.living

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

private const val PI_F = 3.14159265f

/** السبحة: دوران بسرعة متغيرة على مسار بيضاوي بعمق، حبة «تُعدّ» وتتقدم وحدها، شعاع ضوء يمر على الحبات، شرابة تتمايل. */
class TasbihPainter : LivingIconPainter() {
    private val bead = unitRadial(-0.35f, -0.4f, 1.35f, 0xFFB7F7D2.toInt(), 0xFF16A34A.toInt(), 0xFF053D2B.toInt())
    private val glowH = unitHalo(0xFF4ADE80.toInt())
    private val n = 16

    override fun draw(c: Canvas, r: Float, t: Float, fx: Fx) {
        val a = 0.82f * r
        val b = 0.50f * r
        val cy = -0.08f * r
        val spacing = TAU / n
        val ang = t * 0.42f + 0.22f * sin(t * 0.9f)           // سرعة تتغير بشكل طبيعي
        val countedIdx = ((t / 2.6f).toInt()) % n
        val cp = cyc(t, 2.6f)
        val nudge = 0.42f * spacing * sin(PI_F * (cp / 0.5f).coerceIn(0f, 1f))   // تقدّم حبة واحدة للأمام بصورة مستقلة

        if (fx.glow) halo(c, glowH, 0f, cy, r * 0.95f, 0.22f + 0.1f * wv(t, 3.3f))

        // الخيط
        line.shader = null; line.color = 0xFF063A29.toInt(); line.strokeWidth = r * 0.03f
        c.drawOval(RectFHolder.set(-a, cy - b, a, cy + b), line)

        val beamX = lerp(-1.1f, 1.1f, cyc(t, 3.4f)) * r
        for (pass in 0..1) {
            for (i in 0 until n) {
                var th = ang + i * spacing
                if (i == countedIdx) th += nudge
                val z = sin(th)                         // العمق: الأمامي (z>0) أكبر وأسطع
                if ((z >= 0f) != (pass == 1)) continue
                val x = cos(th) * a
                val y = cy + z * b
                val counted = i == countedIdx && nudge > 0.02f
                val rad = r * (0.088f + 0.022f * z) * (if (counted) 1.18f else 1f)
                c.save(); c.translate(x, y); c.scale(rad, rad)
                bead.alpha = (200 + 55 * z).toInt().coerceIn(120, 255)
                c.drawCircle(0f, 0f, 1f, bead)
                c.restore()
                if (fx.deco) {
                    val hit = max(0f, 1f - abs(x - beamX) / (0.26f * r))
                    if (hit > 0.02f) dot(c, x - rad * 0.2f, y - rad * 0.25f, rad * 0.62f, 0xFFFFFFFF.toInt(), 0.65f * hit)
                }
                if (counted) dot(c, x, y, rad * 1.7f, 0xFF86EFAC.toInt(), 0.25f * sin(PI_F * (cp / 0.5f).coerceIn(0f, 1f)))
            }
        }

        // الإمام (حبة ثابتة أمامية) والشرابة
        val iy = cy + b + 0.02f * r
        c.save(); c.translate(0f, iy); c.scale(r * 0.115f, r * 0.115f); bead.alpha = 255; c.drawCircle(0f, 0f, 1f, bead); c.restore()
        c.save(); c.rotate(8f * wv(t, 1.9f), 0f, iy + 0.1f * r)
        line.color = 0xFF22C55E.toInt(); line.strokeWidth = r * 0.022f
        for (k in -2..2) c.drawLine(k * 0.012f * r, iy + 0.12f * r, k * 0.045f * r, iy + 0.40f * r, line)
        fill.shader = null; fill.color = 0xFF16A34A.toInt()
        c.drawCircle(0f, iy + 0.15f * r, r * 0.045f, fill)
        c.restore()

        for (i in 0 until fx.n(5)) {
            val p = cyc(t, 2.7f + 0.4f * i, i * 0.29f)
            val no = ((t + i * 0.29f) / (2.7f + 0.4f * i)).toInt()
            sparkle(c, (hash(no * 3 + i) - 0.5f) * 1.5f * r, (hash(no * 7 + i) - 0.6f) * 1.2f * r, r * 0.07f, 0xFFBBF7D0.toInt(), pulse(p, 0.1f, 0.5f))
        }
    }
}

/** مجسّم RectF مشترك لتفادي التخصيص داخل الرسم. */
internal object RectFHolder {
    private val rf = RectF()
    fun set(l: Float, t: Float, r: Float, b: Float): RectF { rf.set(l, t, r, b); return rf }
}

/** المسجد والهلال: نوافذ تضيء تدريجيًا بتأخير مستقل، هلال يتمايل ويتوهج، نجوم تومض بأزمنة مختلفة، سحب تنجرف، لمعة على القبة. */
class MosquePainter : LivingIconPainter() {
    private val moonHalo = unitHalo(0xFFFFE9A8.toInt())
    private val winHalo = unitHalo(0xFFFFC857.toInt())
    private val crescent = android.graphics.Path()
    private val cut = android.graphics.Path()
    private var builtR = -1f
    private val sx = floatArrayOf(-0.62f, -0.25f, 0.08f, 0.72f, -0.78f)
    private val sy = floatArrayOf(-0.72f, -0.52f, -0.80f, -0.22f, -0.28f)
    private val winX = floatArrayOf(-0.36f, -0.18f, 0f, 0.18f, 0.36f)

    private fun build(r: Float) {
        if (builtR == r) return
        builtR = r
        crescent.reset(); cut.reset()
        crescent.addCircle(0f, 0f, 0.20f * r, android.graphics.Path.Direction.CW)
        cut.addCircle(0.09f * r, -0.04f * r, 0.17f * r, android.graphics.Path.Direction.CW)
        crescent.op(cut, android.graphics.Path.Op.DIFFERENCE)
    }

    override fun draw(c: Canvas, r: Float, t: Float, fx: Fx) {
        build(r)
        // الليل يزداد إشراقًا ببطء ثم يهدأ
        val night = (0.5f + 0.5f * sin(t / 14f * TAU - 1.2f)) * 1.25f

        // نجوم تومض باستقلال
        for (i in sx.indices) {
            val tw = 0.5f + 0.5f * sin(t * (1.3f + 0.37f * i) + i * 1.7f)
            sparkle(c, sx[i] * r, sy[i] * r, r * (0.045f + 0.045f * tw), 0xFFFFF4D6.toInt(), 0.3f + 0.7f * tw)
        }

        // الهلال: ميلان خفيف وانجراف بطيء وتوهج متدرج
        val mx = 0.48f * r + 0.03f * r * wv(t, 9f)
        val my = -0.58f * r + 0.04f * r * wv(t, 6.5f, 0.3f)
        if (fx.glow) halo(c, moonHalo, mx, my, r * 0.55f, 0.35f + 0.3f * (0.5f + 0.5f * wv(t, 5.2f)))
        c.save(); c.translate(mx, my); c.rotate(-18f + 7f * wv(t, 6f))
        fill.shader = null; fill.color = 0xFFFFE9A8.toInt(); c.drawPath(crescent, fill)
        c.restore()

        // سحب خفيفة تنجرف
        if (fx.deco) for (k in 0 until 2) {
            val x = (cyc(t, 46f + 20f * k, k * 0.5f) * 2.8f - 1.4f) * r
            val y = (-0.20f + 0.30f * k) * r
            val col = 0xFFD8CCFF.toInt()
            dot(c, x, y, r * 0.13f, col, 0.22f); dot(c, x + 0.14f * r, y + 0.02f * r, r * 0.10f, col, 0.22f); dot(c, x - 0.14f * r, y + 0.03f * r, r * 0.09f, col, 0.22f)
        }

        // مآذن
        val navy = 0xFF0E1D42.toInt()
        fill.color = navy
        for (k in 0..1) {
            val mxp = (k * 2 - 1) * 0.62f * r
            c.drawRect(mxp - 0.05f * r, -0.18f * r, mxp + 0.05f * r, 0.62f * r, fill)
            c.drawRect(mxp - 0.075f * r, -0.20f * r, mxp + 0.075f * r, -0.14f * r, fill)
            path.reset(); path.moveTo(mxp - 0.05f * r, -0.20f * r); path.lineTo(mxp, -0.40f * r); path.lineTo(mxp + 0.05f * r, -0.20f * r); path.close()
            c.drawPath(path, fill)
        }
        // البناء والقبة
        c.drawRect(-0.50f * r, 0.20f * r, 0.50f * r, 0.62f * r, fill)
        RectFHolder.set(-0.34f * r, -0.14f * r, 0.34f * r, 0.54f * r).let { c.drawArc(it, 180f, 180f, true, fill) }
        c.drawRect(-0.012f * r, -0.28f * r, 0.012f * r, -0.12f * r, fill)
        dot(c, 0f, -0.30f * r, r * 0.03f, 0xFFE2B857.toInt(), 1f)
        // حافة ذهبية وانعكاس ضوئي يعبر القبة
        line.shader = null; line.strokeWidth = r * 0.02f; line.color = alphaOf(0xFFE2B857.toInt(), 0.35f + 0.25f * night.coerceIn(0f, 1f))
        c.drawArc(RectFHolder.set(-0.34f * r, -0.14f * r, 0.34f * r, 0.54f * r), 180f, 180f, false, line)
        if (fx.deco) {
            val p = cyc(t, 5.1f)
            if (p < 0.5f) {
                line.color = alphaOf(0xFFFFFFFF.toInt(), 0.7f * sin(PI_F * p / 0.5f)); line.strokeWidth = r * 0.04f
                val st = 180f + 160f * (p / 0.5f)
                c.drawArc(RectFHolder.set(-0.30f * r, -0.10f * r, 0.30f * r, 0.50f * r), st, 14f, false, line)
            }
        }
        // نوافذ تضيء تدريجيًا: لكل نافذة تأخير مستقل
        for (i in winX.indices) {
            val k = ((night - i * 0.12f) * 3f).coerceIn(0f, 1f)
            val flick = 0.9f + 0.1f * wv(t, 1.7f + 0.3f * i, i * 0.2f)
            val a = k * flick
            if (fx.glow) halo(c, winHalo, winX[i] * r, 0.43f * r, r * 0.16f, 0.5f * a)
            fill.shader = null; fill.color = lerpColor(0xFF1B2B55.toInt(), 0xFFFFD36B.toInt(), a)
            c.drawRoundRect(winX[i] * r - 0.045f * r, 0.34f * r, winX[i] * r + 0.045f * r, 0.54f * r, r * 0.04f, r * 0.04f, fill)
        }
        for (k in 0..1) {
            val sx2 = (k * 2 - 1) * 0.62f * r
            val a = ((night - 0.5f) * 3f).coerceIn(0f, 1f)
            fill.color = lerpColor(0xFF1B2B55.toInt(), 0xFFFFD36B.toInt(), a)
            c.drawRoundRect(sx2 - 0.025f * r, 0.0f, sx2 + 0.025f * r, 0.12f * r, r * 0.02f, r * 0.02f, fill)
        }
        // جسيمات ضوء تصعد بهدوء
        for (i in 0 until fx.n(7)) {
            val p = cyc(t, 6f + 0.7f * i, i * 0.13f)
            dot(c, (hash(i * 11) - 0.5f) * 1.5f * r, 0.6f * r - p * 1.3f * r, r * 0.025f, 0xFFFFE9A8.toInt(), sin(PI_F * p) * 0.8f)
        }
    }
}

/** القلب النابض: نبضة «لَبْ-دَبْ» حقيقية، موجات تخرج مع كل نبضة، لمعان أحمر على السطح، جسيمات متوهجة، اهتزاز خفيف متزامن. */
class HeartPainter : LivingIconPainter() {
    private val body = unitRadial(-0.3f, -0.4f, 1.25f, 0xFFFF9AA8.toInt(), 0xFFE11D48.toInt(), 0xFF7F0A24.toInt())
    private val redHalo = unitHalo(0xFFFF4D6D.toInt())
    private val streak = unitBand(0xFFFFFFFF.toInt())
    private val heart = android.graphics.Path().apply {
        moveTo(0f, 0.62f)
        cubicTo(-1.05f, 0.0f, -0.62f, -0.85f, 0f, -0.32f)
        cubicTo(0.62f, -0.85f, 1.05f, 0.0f, 0f, 0.62f)
        close()
    }
    private val period = 1.15f

    override fun draw(c: Canvas, r: Float, t: Float, fx: Fx) {
        val p = cyc(t, period)
        val s = pulse(p, 0f, 0.16f) + 0.65f * pulse(p, 0.22f, 0.38f)
        val scale = 1f + 0.17f * s
        val shake = sin(t * 55f) * 0.012f * r * s

        if (fx.glow) halo(c, redHalo, 0f, 0f, r * (0.95f + 0.1f * s), 0.35f + 0.35f * s)

        // موجات ضوئية تخرج مع كل نبضة
        val rings = if (fx.deco) 2 else 1
        for (j in 0 until rings) {
            val q = (p + j * 0.5f) % 1f
            line.shader = null; line.strokeWidth = r * 0.03f
            line.color = alphaOf(0xFFFF6B86.toInt(), (1f - q) * 0.55f)
            c.drawCircle(0f, 0f, r * (0.42f + 0.55f * q), line)
        }

        c.save(); c.translate(shake, -0.02f * r); c.scale(0.66f * r * scale, 0.66f * r * scale)
        body.alpha = 255; c.drawPath(heart, body)
        fill.shader = null; fill.color = 0x66FFFFFF
        c.save(); c.rotate(-32f); c.drawOval(-0.55f, -0.58f, -0.12f, -0.38f, fill); c.restore()
        c.restore()

        // لمعان أحمر ينزلق على سطح الكرة
        if (fx.deco) {
            val q = cyc(t, 4.3f)
            if (q < 0.4f) {
                c.save(); c.rotate(-30f); c.translate(lerp(-1.1f, 1.1f, q / 0.4f) * r, 0f); c.scale(0.12f * r, r)
                streak.alpha = 85; c.drawRect(-1f, -1f, 1f, 1f, streak); c.restore()
            }
        }
        // جسيمات متوهجة تنساب للخارج
        for (i in 0 until fx.n(7)) {
            val q = cyc(t, 3.2f + 0.3f * i, i * 0.17f)
            val ang = hash(i * 9) * TAU
            val rad = (0.4f + 0.55f * q) * r
            dot(c, cos(ang) * rad, sin(ang) * rad, r * 0.03f, 0xFFFF8FA3.toInt(), sin(PI_F * q))
        }
    }
}

/** سحابة «صلِّ على النبي»: السحابة تطفو وتتنفس، كل كتلة منها لها حركتها، لونها يتدرّج بين الأبيض والأرجواني، القلب ينبض، خلفها مسجد وهلال ونجوم. النص ثابت غير مشوَّه. */
class CloudPainter : LivingIconPainter() {
    private val puffBase = unitRadial(-0.3f, -0.35f, 1.25f, 0xFFFFFFFF.toInt(), 0xFFEDE7FF.toInt(), 0xFFB9A8F5.toInt())
    private val halo1 = unitHalo(0xFFB9A8F5.toInt())
    private val moonHalo = unitHalo(0xFFFFE9A8.toInt())
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; isFakeBoldText = true; color = 0xFF3B2A78.toInt() }
    private val heart = android.graphics.Path().apply {
        moveTo(0f, 0.62f)
        cubicTo(-1.05f, 0.0f, -0.62f, -0.85f, 0f, -0.32f)
        cubicTo(0.62f, -0.85f, 1.05f, 0.0f, 0f, 0.62f)
        close()
    }
    private val moon = android.graphics.Path()
    private val moonCut = android.graphics.Path()
    private var moonR = -1f
    private val px = floatArrayOf(-0.46f, -0.18f, 0.18f, 0.48f, 0.0f)
    private val py = floatArrayOf(0.20f, 0.06f, 0.08f, 0.22f, 0.30f)
    private val pr = floatArrayOf(0.27f, 0.34f, 0.33f, 0.25f, 0.38f)

    override fun draw(c: Canvas, r: Float, t: Float, fx: Fx) {
        val bob = 0.05f * r * wv(t, 3.6f)
        val breath = 1f + 0.025f * wv(t, 4.2f, 0.1f)

        // خلفية: مسجد صغير وهلال ونجوم
        val crescentA = 0.5f + 0.5f * wv(t, 6f)
        if (fx.glow) halo(c, moonHalo, 0.42f * r, -0.58f * r, r * 0.45f, 0.25f + 0.35f * crescentA)
        fill.shader = null
        if (moonR != r) {
            moonR = r; moon.reset(); moonCut.reset()
            moon.addCircle(0f, 0f, 0.13f * r, android.graphics.Path.Direction.CW)
            moonCut.addCircle(0.06f * r, -0.02f * r, 0.11f * r, android.graphics.Path.Direction.CW)
            moon.op(moonCut, android.graphics.Path.Op.DIFFERENCE)
        }
        fill.color = alphaOf(0xFFFFE9A8.toInt(), 0.55f + 0.45f * crescentA)
        c.save(); c.translate(0.42f * r, -0.58f * r); c.rotate(-18f); c.drawPath(moon, fill); c.restore()
        fill.color = 0xFF241A56.toInt()
        c.drawRect(-0.40f * r, -0.50f * r, 0.12f * r, -0.20f * r, fill)
        c.drawArc(RectFHolder.set(-0.30f * r, -0.74f * r, 0.02f * r, -0.30f * r), 180f, 180f, true, fill)
        c.drawRect(-0.46f * r, -0.66f * r, -0.40f * r, -0.20f * r, fill)
        c.drawRect(0.12f * r, -0.66f * r, 0.18f * r, -0.20f * r, fill)
        for (i in 0 until 4) {
            val tw = 0.5f + 0.5f * sin(t * (1.4f + 0.4f * i) + i * 2.1f)
            sparkle(c, (-0.7f + 0.42f * i) * r, (-0.78f + 0.12f * (i % 2)) * r, r * (0.04f + 0.04f * tw), 0xFFFFF4D6.toInt(), 0.3f + 0.7f * tw)
        }

        // هالة حول السحابة + السحابة نفسها
        if (fx.glow) halo(c, halo1, 0f, 0.15f * r + bob, r * 0.95f, 0.30f + 0.2f * wv(t, 5f))
        c.save(); c.translate(0f, 0.08f * r + bob); c.scale(breath, breath)
        for (i in px.indices) {
            val dy = 0.02f * r * wv(t, 2.3f + 0.45f * i, i * 0.21f)
            val dx = 0.012f * r * wv(t, 3.1f + 0.3f * i, i * 0.4f)
            c.save(); c.translate(px[i] * r + dx, py[i] * r + dy); c.scale(pr[i] * r, pr[i] * r)
            puffBase.alpha = 255; c.drawCircle(0f, 0f, 1f, puffBase)
            c.restore()
            if (fx.deco) dot(c, px[i] * r + dx, py[i] * r + dy, pr[i] * r, lerpColor(0xFFFFFFFF.toInt(), 0xFFC9B8FF.toInt(), 0.5f + 0.5f * wv(t, 5.5f, i * 0.12f)), 0.22f)
        }
        c.restore()

        // القلب ينبض
        val bp = cyc(t, 1.2f)
        val hs = 1f + 0.22f * (pulse(bp, 0f, 0.16f) + 0.6f * pulse(bp, 0.22f, 0.38f))
        c.save(); c.translate(0f, 0.52f * r + bob); c.scale(0.095f * r * hs, 0.095f * r * hs)
        fill.shader = null; fill.color = 0xFFE11D48.toInt(); c.drawPath(heart, fill)
        c.restore()

        // النص ثابت: يتبع الطفو فقط، دون تدوير أو تحجيم يشوّهه
        txt.textSize = r * 0.215f
        c.drawText("صل على النبي", 0f, 0.20f * r + bob, txt)
    }
}

object LivingPainters {
    fun create(type: LivingIconType): LivingIconPainter = when (type) {
        LivingIconType.LANTERN -> LanternPainter()
        LivingIconType.QURAN -> QuranPainter()
        LivingIconType.PLANT -> PlantPainter()
        LivingIconType.TASBIH -> TasbihPainter()
        LivingIconType.MOSQUE -> MosquePainter()
        LivingIconType.HEART -> HeartPainter()
        LivingIconType.CLOUD -> CloudPainter()
    }
}
