package com.unsee.app

import com.unsee.app.core.LogKind
import com.unsee.app.data.MsgCategory
import com.unsee.app.overlay.living.BatterySaver
import com.unsee.app.overlay.living.Fx
import com.unsee.app.overlay.living.FxLevel
import com.unsee.app.overlay.living.IconCategory
import com.unsee.app.overlay.living.LivingConfig
import com.unsee.app.overlay.living.LivingIconMapping
import com.unsee.app.overlay.living.LivingIconType
import com.unsee.app.overlay.living.LivingMode
import com.unsee.app.overlay.living.LivingPrefs
import com.unsee.app.ui.parseHexColor
import com.unsee.app.ui.toHexColor
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LivingIconsTest {
    @Test fun prayerAndHabitKindsMapToTheirCategories() {
        assertEquals(IconCategory.PRAYER, LivingIconMapping.categoryFor(LogKind.PRAYER, null, 12))
        assertEquals(IconCategory.POSITIVE, LivingIconMapping.categoryFor(LogKind.HABIT, null, 12))
        assertEquals(IconCategory.MUHASABA, LivingIconMapping.categoryFor(LogKind.MUHASABA, null, 12))
    }

    @Test fun dhikrCategoriesFollowTheMessageCategory() {
        assertEquals(IconCategory.QURAN, LivingIconMapping.categoryFor(LogKind.DHIKR, MsgCategory.QURAN, 12))
        assertEquals(IconCategory.TASBIH, LivingIconMapping.categoryFor(LogKind.DHIKR, MsgCategory.TASBIH, 12))
        assertEquals(IconCategory.SALAWAT, LivingIconMapping.categoryFor(LogKind.DHIKR, MsgCategory.SALAWAT, 12))
        assertEquals(IconCategory.ISTIGHFAR, LivingIconMapping.categoryFor(LogKind.DHIKR, MsgCategory.ISTIGHFAR, 12))
    }

    @Test fun dayAdhkarSplitsMorningAndEveningByHour() {
        assertEquals(IconCategory.MORNING, LivingIconMapping.categoryFor(LogKind.DHIKR, MsgCategory.DAY_ADHKAR, 7))
        assertEquals(IconCategory.EVENING, LivingIconMapping.categoryFor(LogKind.DHIKR, MsgCategory.DAY_ADHKAR, 18))
        assertEquals(IconCategory.EVENING, LivingIconMapping.categoryFor(LogKind.DHIKR, MsgCategory.DAY_ADHKAR, 2))
    }

    @Test fun everyIconIsReachableAutomatically() {
        val reached = IconCategory.values().map { LivingIconMapping.defaultIconFor(it) }.toSet()
        assertEquals(LivingIconType.values().toSet(), reached)
    }

    @Test fun everyMessageCategoryHasAMapping() {
        MsgCategory.values().forEach { LivingIconMapping.categoryFor(LogKind.DHIKR, it, 12) }
    }

    @Test fun modesResolveAsDocumented() {
        val base = LivingConfig(defaultIcon = LivingIconType.PLANT)
        assertEquals(LivingIconType.QURAN, LivingIconMapping.resolve(base.copy(mode = LivingMode.AUTO), IconCategory.QURAN))
        assertEquals(LivingIconType.PLANT, LivingIconMapping.resolve(base.copy(mode = LivingMode.AUTO), null))
        assertEquals(LivingIconType.PLANT, LivingIconMapping.resolve(base.copy(mode = LivingMode.FIXED), IconCategory.QURAN))
        val per = base.copy(mode = LivingMode.PER_CATEGORY, perCategory = mapOf(IconCategory.QURAN.key to LivingIconType.HEART))
        assertEquals(LivingIconType.HEART, LivingIconMapping.resolve(per, IconCategory.QURAN))
        assertEquals(LivingIconType.TASBIH, LivingIconMapping.resolve(per, IconCategory.TASBIH))
    }

    @Test fun perCategoryMapRoundTripsAndDropsGarbage() {
        val m = mapOf("QURAN" to LivingIconType.HEART, "PRAYER" to LivingIconType.LANTERN)
        assertEquals(m, LivingPrefs.decodeMap(LivingPrefs.encodeMap(m)))
        assertEquals(mapOf("QURAN" to LivingIconType.HEART), LivingPrefs.decodeMap("QURAN=HEART;BAD;X=NOPE;=="))
        assertTrue(LivingPrefs.decodeMap("").isEmpty())
    }

    @Test fun effectLevelAndBatteryScaleParticles() {
        val fx = Fx()
        fx.apply(LivingConfig(level = FxLevel.RICH, battery = BatterySaver.OFF))
        assertEquals(10, fx.n(10)); assertTrue(fx.deco)
        fx.apply(LivingConfig(level = FxLevel.LIGHT))
        assertTrue(fx.n(10) in 1..5); assertTrue(!fx.deco)
        fx.apply(LivingConfig(level = FxLevel.RICH, battery = BatterySaver.STRONG))
        assertTrue(fx.n(10) < 10); assertTrue(!fx.deco)
        fx.apply(LivingConfig(particles = false))
        assertEquals(0, fx.n(10))
    }

    @Test fun batterySaverNeverDisablesTheSystem() {
        BatterySaver.values().forEach { assertTrue(it.particleK > 0f) }
        assertEquals(0, BatterySaver.OFF.fps)
    }

    @Test fun hexParsing() {
        assertEquals(0xFF12294F.toInt(), parseHexColor("#12294F"))
        assertEquals(0xFF12294F.toInt(), parseHexColor("12294f"))
        assertNull(parseHexColor("#12294"))
        assertNull(parseHexColor("#GGGGGG"))
        assertEquals("#12294F", toHexColor(0xFF12294F.toInt()))
    }

    @Test fun configClampsSpeedAndSize() {
        assertEquals(0.4f, LivingConfig(speedPct = 1).speed, 0.001f)
        assertEquals(2.0f, LivingConfig(speedPct = 999).speed, 0.001f)
        assertEquals(1.25f, LivingConfig(sizeIdx = 99).sizeScale, 0.001f)
    }
}
