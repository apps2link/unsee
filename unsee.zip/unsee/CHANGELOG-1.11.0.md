# أُنسي 1.11.0 — Premium Islamic Ambient Glassmorphism

## الملفات المعدّلة
- `app/src/main/java/com/unsee/app/ui/UnseeApp.kt` — `consumeWindowInsets(pad)` على NavHost (سبب مشكلة الكيبورد: Scaffold مع bottomBar لا يمرّر مساحة الكيبورد للمحتوى).
- `app/src/main/java/com/unsee/app/ui/MuhasabaArena.kt` — `imePadding()` على حاويتي ورقة التسجيل ومحرر الخطة، + `BringIntoViewRequester` لخانة «حاجة تانية/عمل صالح تاني» (يُنفَّذ بعد استقرار حركة الكيبورد). `verticalScroll` الموجود أصلًا أُبقي.
- `app/src/main/java/com/unsee/app/overlay/BubbleView.kt` — إعادة كتابة كاملة: كرة زجاجية حيّة، 7 حالات، نبضة تذكير، احتفال/مواساة.
- `app/src/main/java/com/unsee/app/overlay/BubbleService.kt` — بطاقة زجاجية جديدة، أزرار بحركة ضغط، بطاقة نتيجة، مزامنة حالة الفقاعة، احترام تقليل الحركة. منطق السحب/التأجيل/الأفعال لم يتغيّر.
- `app/build.gradle.kts` — versionName 1.11.0 / versionCode 12.

## ملفات جديدة
- `overlay/GlassSkin.kt` (حالات وألوان ونابض)، `overlay/GlassCardDrawable.kt` (خلفية زجاجية)، `overlay/GlyphView.kt` (أيقونة مرسومة متحركة)، `test/.../GlassSkinTest.kt`.
