import re,glob,os
root='app/src/main'
res=set(); 
for f in glob.glob(root+'/res/**/*',recursive=True):
    if os.path.isfile(f):
        d=os.path.basename(os.path.dirname(f)).split('-')[0]; n=os.path.splitext(os.path.basename(f))[0]
        res.add((d,n))
ids=set()
for f in glob.glob(root+'/res/**/*.xml',recursive=True):
    for m in re.finditer(r'@\+id/(\w+)',open(f,encoding='utf-8').read()): ids.add(m.group(1))
strings=set(re.findall(r'name="(\w+)"',open(root+'/res/values/strings.xml',encoding='utf-8').read()))
colors=set(re.findall(r'name="(\w+)"',open(root+'/res/values/colors.xml',encoding='utf-8').read()))
bad=0
for f in glob.glob(root+'/java/**/*.kt',recursive=True):
    for m in re.finditer(r'R\.(drawable|layout|id|xml|font|mipmap)\.(\w+)',open(f,encoding='utf-8').read()):
        k,n=m.groups()
        ok = n in ids if k=='id' else (k,n) in res
        if not ok: print('MISSING',f,k,n); bad+=1
for f in glob.glob(root+'/res/**/*.xml',recursive=True)+[root+'/AndroidManifest.xml']:
    t=open(f,encoding='utf-8').read()
    for m in re.finditer(r'@(drawable|layout|xml|mipmap|string|color|style)/(\w+)',t):
        k,n=m.groups()
        ok={'string':n in strings,'color':n in colors,'style':True}.get(k,(k,n) in res)
        if not ok: print('MISSING ref',f,k,n); bad+=1
# kotlin brace/paren balance
for f in glob.glob(root+'/java/**/*.kt',recursive=True)+glob.glob('app/src/test/**/*.kt',recursive=True):
    t=open(f,encoding='utf-8').read()
    t2=re.sub(r'"(?:\\.|[^"\\])*"','""',t)
    for a,b in ['{}','()','[]']:
        if t2.count(a)!=t2.count(b): print('UNBALANCED',f,a,t2.count(a),t2.count(b)); bad+=1
print('OK: كل المراجع موجودة والأقواس متوازنة' if not bad else f'{bad} problems')
