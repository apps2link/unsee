import re,glob,sys
EXT={ # symbol -> import path
'dp':'androidx.compose.ui.unit.dp','sp':'androidx.compose.ui.unit.sp','Dp':'androidx.compose.ui.unit.Dp',
'Modifier':'androidx.compose.ui.Modifier','Alignment':'androidx.compose.ui.Alignment',
'Composable':'androidx.compose.runtime.Composable','remember':'androidx.compose.runtime.remember',
'getValue':'androidx.compose.runtime.getValue','setValue':'androidx.compose.runtime.setValue',
'mutableStateOf':'androidx.compose.runtime.mutableStateOf','LaunchedEffect':'androidx.compose.runtime.LaunchedEffect',
'rememberCoroutineScope':'androidx.compose.runtime.rememberCoroutineScope','State':'androidx.compose.runtime.State',
'mutableIntStateOf':'androidx.compose.runtime.mutableIntStateOf','mutableFloatStateOf':'androidx.compose.runtime.mutableFloatStateOf',
'Box':'androidx.compose.foundation.layout.Box','Column':'androidx.compose.foundation.layout.Column','Row':'androidx.compose.foundation.layout.Row',
'Spacer':'androidx.compose.foundation.layout.Spacer','Arrangement':'androidx.compose.foundation.layout.Arrangement',
'fillMaxWidth':'androidx.compose.foundation.layout.fillMaxWidth','fillMaxSize':'androidx.compose.foundation.layout.fillMaxSize',
'padding':'androidx.compose.foundation.layout.padding','size':'androidx.compose.foundation.layout.size','height':'androidx.compose.foundation.layout.height','width':'androidx.compose.foundation.layout.width',
'PaddingValues':'androidx.compose.foundation.layout.PaddingValues','ColumnScope':'androidx.compose.foundation.layout.ColumnScope','RowScope':'androidx.compose.foundation.layout.RowScope',
'WindowInsets':'androidx.compose.foundation.layout.WindowInsets','safeDrawing':'androidx.compose.foundation.layout.safeDrawing','navigationBarsPadding':'androidx.compose.foundation.layout.navigationBarsPadding','safeDrawingPadding':'androidx.compose.foundation.layout.safeDrawingPadding',
'background':'androidx.compose.foundation.background','border':'androidx.compose.foundation.border','clickable':'androidx.compose.foundation.clickable',
'horizontalScroll':'androidx.compose.foundation.horizontalScroll','verticalScroll':'androidx.compose.foundation.verticalScroll','rememberScrollState':'androidx.compose.foundation.rememberScrollState','Canvas':'androidx.compose.foundation.Canvas',
'RoundedCornerShape':'androidx.compose.foundation.shape.RoundedCornerShape','CircleShape':'androidx.compose.foundation.shape.CircleShape',
'LazyColumn':'androidx.compose.foundation.lazy.LazyColumn','items':'androidx.compose.foundation.lazy.items',
'clip':'androidx.compose.ui.draw.clip','shadow':'androidx.compose.ui.draw.shadow','drawWithCache':'androidx.compose.ui.draw.drawWithCache',
'Color':'androidx.compose.ui.graphics.Color','Brush':'androidx.compose.ui.graphics.Brush','compositeOver':'androidx.compose.ui.graphics.compositeOver','Shape':'androidx.compose.ui.graphics.Shape','lerp':'androidx.compose.ui.graphics.lerp',
'ImageVector':'androidx.compose.ui.graphics.vector.ImageVector','graphicsLayer':'androidx.compose.ui.graphics.graphicsLayer',
'Text':'androidx.compose.material3.Text','Icon':'androidx.compose.material3.Icon','TextButton':'androidx.compose.material3.TextButton','AlertDialog':'androidx.compose.material3.AlertDialog',
'LinearProgressIndicator':'androidx.compose.material3.LinearProgressIndicator','CircularProgressIndicator':'androidx.compose.material3.CircularProgressIndicator','Scaffold':'androidx.compose.material3.Scaffold',
'OutlinedTextField':'androidx.compose.material3.OutlinedTextField','FilterChip':'androidx.compose.material3.FilterChip','Switch':'androidx.compose.material3.Switch','Slider':'androidx.compose.material3.Slider','MaterialTheme':'androidx.compose.material3.MaterialTheme',
'FontWeight':'androidx.compose.ui.text.font.FontWeight','FontFamily':'androidx.compose.ui.text.font.FontFamily','TextAlign':'androidx.compose.ui.text.style.TextAlign','TextOverflow':'androidx.compose.ui.text.style.TextOverflow',
'LocalContext':'androidx.compose.ui.platform.LocalContext','LocalView':'androidx.compose.ui.platform.LocalView','LocalDensity':'androidx.compose.ui.platform.LocalDensity',
'AnimatedVisibility':'androidx.compose.animation.AnimatedVisibility','AnimatedContent':'androidx.compose.animation.AnimatedContent','fadeIn':'androidx.compose.animation.fadeIn','fadeOut':'androidx.compose.animation.fadeOut',
'slideInVertically':'androidx.compose.animation.slideInVertically','slideOutVertically':'androidx.compose.animation.slideOutVertically','togetherWith':'androidx.compose.animation.togetherWith','tween':'androidx.compose.animation.core.tween',
'rememberPagerState':'androidx.compose.foundation.pager.rememberPagerState','HorizontalPager':'androidx.compose.foundation.pager.HorizontalPager',
'collectAsStateWithLifecycle':'androidx.lifecycle.compose.collectAsStateWithLifecycle','NavController':'androidx.navigation.NavController',
'delay':'kotlinx.coroutines.delay','launch':'kotlinx.coroutines.launch',
'OutlinedTextFieldDefaults':'androidx.compose.material3.OutlinedTextFieldDefaults','KeyboardOptions':'androidx.compose.foundation.text.KeyboardOptions','KeyboardType':'androidx.compose.ui.text.input.KeyboardType',
'Offset':'androidx.compose.ui.geometry.Offset','Size':'androidx.compose.ui.geometry.Size','Stroke':'androidx.compose.ui.graphics.drawscope.Stroke',
'animateContentSize':'androidx.compose.animation.animateContentSize','rememberSaveable':'androidx.compose.runtime.saveable.rememberSaveable',
}
# project symbols
proj={}
for f in glob.glob('main/java/**/*.kt',recursive=True):
    t=open(f,encoding='utf-8').read()
    pk=re.search(r'^package ([\w.]+)',t,re.M).group(1)
    for m in re.finditer(r'^(?:internal |private |data |enum |sealed )*(?:class|object|interface|fun(?: <\w+>)?(?: [\w.<>?]+\.)?|val|var) (\w+)',t,re.M):
        proj.setdefault(m.group(1),set()).add((pk,f))
bad=0
for f in sorted(glob.glob('main/java/**/*.kt',recursive=True)+glob.glob('test/**/*.kt',recursive=True)):
    t=open(f,encoding='utf-8').read()
    pk=re.search(r'^package ([\w.]+)',t,re.M).group(1)
    body=re.sub(r'(?m)^\s*(import|package) .*$','',t)
    body=re.sub(r'(?m)//.*$','',body)
    body=re.sub(r'"(?:\\.|[^"\\])*"','""',body)
    imports=set(re.findall(r'^import ([\w.*]+)',t,re.M))
    def has(path):
        if path in imports: return True
        pkg=path.rsplit('.',1)[0]
        return pkg+'.*' in imports
    for sym,path in EXT.items():
        pat = r'(?<![\w])\.'+sym+r'\b' if sym in('dp','sp') else r'(?<![\w.])'+sym+r'\b'
        if sym in ('dp','sp'): used=re.search(r'\d\.?\d*f?\.'+sym+r'\b|\)\.'+sym+r'\b|\w\.'+sym+r'\b',body) and re.search(r'[\d\w)]\.'+sym+r'\b',body)
        elif sym in ('padding','size','height','width','fillMaxWidth','fillMaxSize','clip','background','border','clickable','shadow','graphicsLayer','horizontalScroll','verticalScroll','navigationBarsPadding','safeDrawingPadding','animateContentSize','drawWithCache','compositeOver'):
            used=re.search(r'\.'+sym+r'\(',body) or re.search(r'(?<![\w.])'+sym+r'\(',body)
        elif sym in('items','launch','delay'): used=re.search(r'(?<![\w.])'+sym+r'[ (]',body)
        else: used=re.search(r'(?<![\w.])'+sym+r'\b',body)
        if not used: continue
        if has(path): continue
        # defined locally?
        if re.search(r'(?:fun|val|var|class|object) (?:\w+\.)?'+sym+r'\b',body): continue
        print(f"{f}: uses '{sym}' without import {path}"); bad+=1
    # project symbols from other packages
    for sym,defs in proj.items():
        if any(d[0]==pk for d in defs): continue
        if not re.search(r'(?<![\w.])'+sym+r'\b',body): continue
        if any(re.search(r'^import '+re.escape(d[0])+r'\.(?:'+sym+r'|\*)',t,re.M) for d in defs): continue
        if re.search(r'(?:fun|val|var|class|object) (?:\w+\.)?'+sym+r'\b',body): continue
        if len(sym)<4: continue
        print(f"{f}: uses project symbol '{sym}' from {[d[0] for d in defs]} without import"); bad+=1
print("missing imports:",bad)
