"""
يولّد مؤثرات أُنسي الصوتية (WAV أحادي 16-bit، 22.05kHz) بالتركيب الرقمي. لا تلاوة ولا موسيقى:
  sfx_clap   تصفيق جماعي (ضجيج مُرشَّح بنبضات عشوائية) عند فعل الخير
  sfx_point  «تينج» ناعم واحد عند إضافة نقطة
  sfx_sad    انزلاق نغمة منخفضة واحدة مع زفير خفيف (حزن لطيف) عند تسجيل ذنب
  sfx_pop    فقاعة قصيرة عند ظهور الفقاعة العائمة
  sfx_remind ضربة جرس واحدة ناعمة لتذكير الصلاة والخطط
تشغيل: python3 tools/gen_sounds.py  (يحتاج numpy)
"""
import wave, os
import numpy as np

SR = 22050
OUT = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "res", "raw")
rng = np.random.default_rng(7)


def t(d): return np.arange(int(SR * d)) / SR
def norm(x, peak=0.85):
    m = np.max(np.abs(x)) or 1.0
    return x / m * peak
def fade(x, a=0.004, b=0.02):
    n = len(x); fa = int(SR * a); fb = int(SR * b)
    x = x.copy()
    if fa: x[:fa] *= np.linspace(0, 1, fa)
    if fb: x[-fb:] *= np.linspace(1, 0, fb)
    return x
def lowpass(x, k):
    return np.convolve(x, np.ones(k) / k, mode="same")
def save(name, x):
    x = np.clip(x, -1, 1)
    pcm = (x * 32767).astype("<i2")
    with wave.open(os.path.join(OUT, name + ".wav"), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())


# ---- تصفيق: ~90 نبضة ضجيج قصيرة، كثافتها تعلو ثم تخفت
def clap():
    d = 1.7
    out = np.zeros(int(SR * d))
    for _ in range(90):
        # توزيع زمني: أغلبها في الوسط
        pos = np.clip(rng.normal(0.55, 0.32), 0.0, 1.45)
        n = int(SR * rng.uniform(0.012, 0.03))
        burst = rng.standard_normal(n)
        burst = burst - lowpass(burst, 24)      # قص الترددات المنخفضة
        burst = lowpass(burst, 3)               # قص الحدّة العالية
        burst *= np.exp(-np.arange(n) / (n * 0.22))
        s = int(pos * SR)
        out[s:s + n] += burst[: max(0, len(out) - s)] * rng.uniform(0.3, 1.0)
    env = np.minimum(t(d) / 0.12, 1.0) * np.exp(-np.maximum(t(d) - 0.9, 0) / 0.45)
    return fade(norm(out * env, 0.8), 0.004, 0.05)


# ---- نقطة: تينج ناعم
def point():
    x = t(0.45)
    s = np.sin(2 * np.pi * 880 * x) + 0.45 * np.sin(2 * np.pi * 1320 * x) + 0.15 * np.sin(2 * np.pi * 2640 * x)
    return fade(norm(s * np.exp(-x / 0.11), 0.7), 0.002, 0.05)


# ---- حزن: نغمة منخفضة تنزلق مع زفير
def sad():
    d = 0.95
    x = t(d)
    f = 240 - 90 * (x / d) ** 0.7
    ph = 2 * np.pi * np.cumsum(f) / SR
    tone = np.sin(ph) + 0.25 * np.sin(2 * ph)
    env = np.minimum(x / 0.08, 1) * np.exp(-x / 0.45)
    breath = lowpass(rng.standard_normal(len(x)), 40) * 0.5 * np.exp(-x / 0.3)
    return fade(norm(tone * env + breath * 0.35, 0.6), 0.01, 0.12)


# ---- فقاعة
def pop():
    x = t(0.16)
    f = 380 + 700 * (x / 0.16) ** 0.6
    s = np.sin(2 * np.pi * np.cumsum(f) / SR)
    return fade(norm(s * np.exp(-x / 0.045), 0.65), 0.002, 0.03)


# ---- جرس تذكير: ضربة واحدة بجزيئات غير توافقية
def remind():
    x = t(1.15)
    s = np.zeros_like(x)
    for ratio, amp, tau in [(1.0, 1.0, 0.55), (2.76, 0.35, 0.28), (5.4, 0.12, 0.14)]:
        s += amp * np.sin(2 * np.pi * 660 * ratio * x) * np.exp(-x / tau)
    return fade(norm(s, 0.7), 0.002, 0.08)


for n, fn in [("sfx_clap", clap), ("sfx_point", point), ("sfx_sad", sad), ("sfx_pop", pop), ("sfx_remind", remind)]:
    save(n, fn())
    print("ok", n)
