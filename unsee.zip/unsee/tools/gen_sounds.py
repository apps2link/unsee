#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
يولّد الأصوات الثلاثة الوحيدة في أُنسي (تركيب رقمي، لا تسجيلات خارجية):
  sfx_chirp.wav  زقزقة عصفور — إشعار الفقاعة العائمة
  sfx_clap.wav   تصفيق جماهيري — عند عمل حسنة
  sfx_sad.wav    بكاء حزين — عند عمل سيئة
هذه أصوات مركّبة وليست تسجيلات حقيقية. لاستبدالها بتسجيلات: ضع ملفات بنفس الأسماء في app/src/main/res/raw
(wav أو ogg، يفضّل أحادية ≤ 4 ثوانٍ) دون تغيير الكود.
"""
import wave, os, sys
import numpy as np
from scipy.signal import butter, sosfilt

SR = 22050
OUT = os.path.join(os.path.dirname(__file__), '..', 'app', 'src', 'main', 'res', 'raw')
rng = np.random.default_rng(7)

def save(name, x):
    x = x / (np.max(np.abs(x)) + 1e-9) * 0.85
    pcm = (x * 32767).astype('<i2')
    with wave.open(os.path.join(OUT, name + '.wav'), 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())

def bp(x, lo, hi, order=2):
    return sosfilt(butter(order, [lo, hi], btype='band', fs=SR, output='sos'), x)

def note(f0, f1, dur, vib=0.0, vib_hz=38):
    n = int(SR * dur); t = np.arange(n) / SR
    f = f0 + (f1 - f0) * (t / dur) + vib * np.sin(2 * np.pi * vib_hz * t)
    ph = 2 * np.pi * np.cumsum(f) / SR
    env = np.sin(np.pi * t / dur) ** 0.8
    return (np.sin(ph) + 0.28 * np.sin(2 * ph) + 0.08 * np.sin(3 * ph)) * env

def chirp():
    parts, gap = [], np.zeros(int(SR * 0.055))
    for f0, f1, d, v in [(3100, 4300, 0.11, 60), (3500, 4900, 0.10, 80), (2900, 4500, 0.13, 70), (4400, 3200, 0.12, 50)]:
        parts += [note(f0, f1, d, v), gap]
    parts.append(np.zeros(int(SR * 0.16)))
    for f0, f1 in [(3800, 4600), (3900, 4700), (4000, 4800)]:
        parts += [note(f0, f1, 0.055, 90, 55), np.zeros(int(SR * 0.035))]
    x = np.concatenate(parts)
    return x

def applause():
    T = 3.4; n = int(SR * T); x = np.zeros(n)
    templates = []
    for _ in range(14):
        L = int(SR * rng.uniform(0.010, 0.028))
        b = rng.standard_normal(L) * np.exp(-np.arange(L) / (L * rng.uniform(0.18, 0.35)))
        c = rng.uniform(1100, 3600)
        templates.append(bp(np.pad(b, (0, 200)), c * 0.6, min(c * 1.6, SR / 2 - 100)))
    t = np.arange(n) / SR
    rate = 260 * (np.sin(np.pi * np.clip(t / T, 0, 1)) ** 0.55)
    count = int(np.sum(rate) / SR * 1.0 * (T / T))
    probs = rate / rate.sum()
    for pos in rng.choice(n, size=count, p=probs):
        tpl = templates[rng.integers(len(templates))] * rng.uniform(0.25, 1.0)
        e = min(n, pos + len(tpl)); x[pos:e] += tpl[:e - pos]
    bed = bp(rng.standard_normal(n), 700, 5500) * 0.12 * (np.sin(np.pi * np.clip(t / T, 0, 1)) ** 0.7)
    x = x + bed
    for d, g in [(0.031, 0.32), (0.057, 0.24), (0.089, 0.16)]:
        k = int(SR * d); y = np.zeros(n); y[k:] = x[:-k] * g; x = x + y
    x *= np.minimum(1.0, (T - t) / 0.35)
    return x

def formant(x, f, bw):
    lo, hi = max(50, f - bw), min(SR / 2 - 100, f + bw)
    return bp(x, lo, hi)

def cry(dur, f_start, f_peak, f_end, amp):
    n = int(SR * dur); t = np.arange(n) / SR; u = t / dur
    f = np.where(u < 0.3, f_start + (f_peak - f_start) * (u / 0.3), f_peak + (f_end - f_peak) * ((u - 0.3) / 0.7))
    f = f * (1 + 0.035 * np.sin(2 * np.pi * 6.2 * t))
    ph = np.cumsum(f) / SR
    src = np.mod(ph, 1.0) * 2 - 1
    src = src - 0.35 * np.roll(src, 1)
    src = src + 0.04 * rng.standard_normal(n)
    open_ = 0.7 + 0.3 * np.sin(np.pi * np.clip(u * 1.2, 0, 1))
    y = formant(src, 850, 220) * 1.0 * open_ + formant(src, 1700, 300) * 0.55 + formant(src, 2900, 350) * 0.25
    env = np.minimum(1, t / 0.06) * np.exp(-1.6 * u) * np.minimum(1, (dur - t) / 0.08)
    return y * env * amp

def sad():
    parts = []
    for dur, a, b, c, g, pause in [(0.95, 330, 470, 300, 1.0, 0.22), (0.80, 320, 440, 280, 0.85, 0.20), (0.65, 310, 410, 260, 0.7, 0.0)]:
        parts += [cry(dur, a, b, c, g), np.zeros(int(SR * pause))]
        sob = bp(rng.standard_normal(int(SR * 0.16)), 600, 1800) * np.hanning(int(SR * 0.16)) * 0.12 * g
        parts.append(sob)
    return np.concatenate(parts)

if __name__ == '__main__':
    os.makedirs(OUT, exist_ok=True)
    save('sfx_chirp', chirp()); save('sfx_clap', applause()); save('sfx_sad', sad())
    print('ok')
