#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""يولّد ملفات Kotlin من hisn_almuslim.json (لا تعدّلها يدويًا): HisnBookData.kt و LegacyIdMap.kt
الاستخدام: python3 gen_kotlin.py hisn_almuslim.json legacy_map.json out_dir"""
import json, sys, os

def k(s):
    if s is None: return 'null'
    s = s.replace('\\', '\\\\').replace('"', '\\"').replace('$', '\\$').replace('\n', '\\n')
    return '"' + s + '"'

def main():
    db = json.load(open(sys.argv[1], encoding='utf-8'))
    lm = json.load(open(sys.argv[2], encoding='utf-8'))['map']
    out = sys.argv[3]; os.makedirs(out, exist_ok=True)
    L = ['// ملف مولَّد آليًا من «حصن المسلم» عبر tools/hisn/gen_kotlin.py — لا تعدّله يدويًا.',
         'package com.unsee.app.data', '']
    L.append('internal object HisnMeta {')
    m = db['meta']
    L.append('    const val TITLE = %s' % k(m['title']))
    L.append('    const val AUTHOR = %s' % k(m['author']))
    L.append('    const val CHAPTERS = %d' % m['chapters'])
    L.append('    const val DHIKR_NUMBERS = %d' % m['dhikrNumbers'])
    L.append('    const val ENTRIES = %d' % m['entries'])
    L.append('    const val FOOTNOTES = %d' % m['footnotes'])
    L.append('    val preface: List<String> = listOf(')
    for p in db['preface']['paragraphs']: L.append('        %s,' % k(p))
    L.append('    )')
    L.append('    val prefaceFootnotes: List<Footnote> = listOf(')
    for f in db['preface']['footnotes']: L.append('        Footnote(%d, %s),' % (f['n'], k(f['text'])))
    L.append('    )')
    L.append('}'); L.append('')
    L.append('internal object HisnChapters {')
    L.append('    val all: List<HisnChapter> = listOf(')
    for c in db['chapters']:
        L.append('        HisnChapter(%d, %s, %s, %s),' % (c['no'], k(c['title']), k(c['titleRaw']), k(c['category'])))
    L.append('    )')
    L.append('}'); L.append('')
    rows = db['entries']; parts = [rows[i:i + 12] for i in range(0, len(rows), 12)]
    L.append('internal object HisnRows {')
    L.append('    val all: List<HisnRow> by lazy {')
    L.append('        val out = ArrayList<HisnRow>(%d)' % len(rows))
    for i in range(len(parts)): L.append('        out += part%d()' % i)
    L.append('        out')
    L.append('    }')
    kind = {'DHIKR': 'KD', 'ADDITION': 'KA', 'FADL': 'KF', 'NOTE': 'KN'}
    for i, part in enumerate(parts):
        L.append('')
        L.append('    private fun part%d(): List<HisnRow> = listOf(' % i)
        for e in part:
            fn = ', '.join('Footnote(%d, %s)' % (f['n'], k(f['text'])) for f in e['footnotes'])
            L.append('        r(%s, %s, %d, %d, %d, %s, %d, %s, %s, %s, %s),' % (
                k(e['id']), kind[e['kind']], e['bookNo'] or 0, e['chapterNo'], e['seq'] or 0, k(e['text']),
                e['count'], k(e['countText']), k(e['countWhen']), k(e['afterNote']),
                ('listOf(%s)' % fn) if fn else 'emptyList()'))
        L.append('    )')
    L.append('}')
    open(os.path.join(out, 'HisnBookData.kt'), 'w', encoding='utf-8').write('\n'.join(L) + '\n')
    M = ['// ملف مولَّد: ربط معرّفات المكتبة القديمة بمقابلاتها في حصن المسلم (gen_legacy_map.py).',
         'package com.unsee.app.data', '', 'internal object LegacyIdMap {', '    val map: Map<String, String> = mapOf(']
    for a, b in sorted(lm.items()): M.append('        %s to %s,' % (k(a), k(b)))
    M += ['    )', '}']
    open(os.path.join(out, 'LegacyIdMap.kt'), 'w', encoding='utf-8').write('\n'.join(M) + '\n')
    print('rows', len(rows), 'parts', len(parts), 'legacy', len(lm))

main()
