#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
يربط معرّفات الأذكار القديمة (المكتبة اليدوية السابقة في أُنسي) بمقابلاتها في «حصن المسلم»
بمطابقة حروف النص (دون تشكيل). ما لا يطابق نص الكتاب حرفيًا لا يُربط؛ يبقى معرّفه القديم
محفوظًا للمفضلة فقط ويُعرض بوسم «من المكتبة السابقة — خارج نص الكتاب».

الاستخدام: python3 gen_legacy_map.py LegacyAdhkar.kt hisn_almuslim.json out_map.json
"""
import json, re, sys

def skel(s):
    s = re.sub(r'[\u064B-\u065F\u0670\u0640]', '', s)
    s = re.sub('[أإآٱ]', 'ا', s).replace('ة', 'ه').replace('ى', 'ي')
    s = re.sub(r'[^\u0621-\u064A]', '', s)
    s = s.replace('صلياللهعليهوسلم', '').replace('السماوات', 'السموات').replace('يئوده', 'يؤوده')
    return s

def split_top(s):
    out, depth, cur, i, instr = [], 0, '', 0, False
    while i < len(s):
        c = s[i]
        if instr:
            cur += c
            if c == '\\': cur += s[i + 1]; i += 1
            elif c == '"': instr = False
        else:
            if c == '"': instr = True; cur += c
            elif c in '([': depth += 1; cur += c
            elif c in ')]': depth -= 1; cur += c
            elif c == ',' and depth == 0: out.append(cur.strip()); cur = ''
            else: cur += c
        i += 1
    if cur.strip(): out.append(cur.strip())
    return out

def calls(src, name):
    for m in re.finditer(r'\b' + name + r'\(', src):
        i = m.end(); depth = 1; instr = False; j = i
        while j < len(src) and depth:
            c = src[j]
            if instr:
                if c == '\\': j += 1
                elif c == '"': instr = False
            else:
                if c == '"': instr = True
                elif c == '(': depth += 1
                elif c == ')': depth -= 1
            j += 1
        yield split_top(src[i:j - 1])

def main():
    src = open(sys.argv[1], encoding='utf-8').read()
    db = json.load(open(sys.argv[2], encoding='utf-8'))
    consts = {}
    for m in re.finditer(r'private const val (\w+) =\s*\n?\s*"((?:[^"\\]|\\.)*)"', src):
        consts[m.group(1)] = m.group(2)
    def lit(a):
        a = a.strip()
        if a.startswith('named:'): a = a[6:]
        m = re.fullmatch(r'"((?:[^"\\]|\\.)*)"', a, re.S)
        if m:
            t = m.group(1)
            t = re.sub(r'\$\{?(\w+)\}?', lambda x: consts.get(x.group(1), ''), t)
            return t.replace('\\n', '\n')
        if a in consts: return consts[a]
        return None
    def kw(args, name):
        for a in args:
            if a.startswith(name + ' ='): return a.split('=', 1)[1].strip()
        return None
    old = {}
    for a in calls(src, 'Zikr'):
        if len(a) >= 4 and lit(a[0]) and not a[0].startswith('"m_$') and 'key' not in a[0]:
            t = lit(a[3]) if lit(a[3]) is not None else lit(a[3])
            if t: old[lit(a[0])] = t
    for a in calls(src, 'dual'):
        pos = [x for x in a if '=' not in x.split('"')[0] or x.startswith('"')]
        key = lit(a[0]); morning = lit(a[2]) if len(a) > 2 else None
        ev = kw(a, 'evening'); 
        if key and morning:
            old['m_' + key] = morning
            old['e_' + key] = lit(ev) if ev and lit(ev) else morning
    # فهرس الكتاب: نص → معرّف (أول ورود)
    book = {}
    ch27 = {c['no'] for c in db['chapters'] if c['category'] == 'MORNING_EVENING'}
    for e in db['entries']:
        if e['kind'] not in ('DHIKR', 'ADDITION'): continue
        k = skel(e['text'])
        book.setdefault(k, []).append(e)
    mapping, unmatched, contained = {}, [], []
    chcat = {c['no']: c['category'] for c in db['chapters']}
    for oid, text in sorted(old.items()):
        k = skel(text)
        want = {'m_': 'MORNING_EVENING', 'e_': 'MORNING_EVENING', 'p_': 'AFTER_PRAYER', 's_': 'SLEEP_WAKE'}.get(oid[:2])
        hit = [e for e in book.get(k, []) if not want or chcat[e['chapterNo']] == want]
        if not hit and len(k) >= 25:
            cands = []
            for e in db['entries']:
                if e['kind'] not in ('DHIKR', 'ADDITION'): continue
                if want and chcat[e['chapterNo']] != want: continue
                if k in skel(e['text']): cands.append(e)
            if len(cands) == 1:
                hit = cands; contained.append((oid, cands[0]['id']))
        if not hit:
            unmatched.append(oid); continue
        e = hit[0]
        base = e['id']
        if e['chapterNo'] in ch27:
            if oid.startswith('m_') and e['countWhen'] != 'EVENING': mapping[oid] = 'm_' + base
            elif oid.startswith('e_') and e['countWhen'] != 'MORNING': mapping[oid] = 'e_' + base
            else: unmatched.append(oid)
        else:
            mapping[oid] = base
    json.dump({'map': mapping, 'unmatched': unmatched, 'old_total': len(old)}, open(sys.argv[3], 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('old', len(old), 'mapped', len(mapping), 'unmatched', len(unmatched))
    print('contained-match (old text is part of a longer book item):', contained)
    print('unmatched:', ' '.join(unmatched))
    print('mapped sample:', list(mapping.items())[:12])

if __name__ == '__main__':
    main()
