#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
مطابقة قاعدة البيانات المستخرجة مع الكتاب عبر مسار استخراج مستقل.

المسار الأول (extract_hisn.py) يقرأ XML الملف مباشرة. هذا الفاحص يقارنه بنص مُحوَّل بأداة أخرى
(pandoc أو extract-text إلى Markdown) — فإن اتفق المساران حرفًا بحرف (على مستوى الحروف العربية
دون التشكيل) فالنص سليم من أخطاء القراءة. يتحقق أيضًا من الترتيب ومن حواشي التخريج وعناوين الأبواب.

الاستخدام:
    pandoc ar_Hisn_Almuslim.docx -t plain --wrap=none -o book_plain.txt   # أو: extract-text file.docx > book.md
    python3 verify_hisn.py hisn_almuslim.json book_plain.txt
"""
import json, re, sys

EXPANSIONS = ['بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ', 'سبحانه وتعالى', 'صلى الله عليه وسلم', 'رضي الله عنهما',
              'رضي الله عنها', 'رضي الله عنه', 'رحمه الله', 'الٓمٓ']

def skel(s):
    s = re.sub(r'[\u064B-\u065F\u0670\u0640]', '', s)
    s = re.sub('[أإآٱ]', 'ا', s).replace('ة', 'ه').replace('ى', 'ي')
    return re.sub(r'[^\u0621-\u064A]', '', s)

def drop_expansions(s):
    for x in sorted(EXPANSIONS, key=len, reverse=True):
        s = s.replace(x, ' ')
    return s

def main():
    db = json.load(open(sys.argv[1], encoding='utf-8'))
    ref = open(sys.argv[2], encoding='utf-8', errors='replace').read()
    # الحواشي في النص المرجعي تُحذف علاماتها، ورموز الخط الخاصة تُحذف من المرجع كما حُذفت توسعاتها من القاعدة
    ref_clean = re.sub(r'\[\^\d+\]', ' ', ref)
    ref_clean = re.sub(r'[\ufb50-\ufbff%^\u00d7\u2018\u2019]', ' ', ref_clean)
    # الحذف متماثل: العبارات المكتوبة نصًّا في الكتاب تُحذف من الجانبين كي لا تُحسب فرقًا
    ref_clean = re.sub(r'الـ\s*ـم', ' ', ref_clean)
    ref_clean = drop_expansions(ref_clean)
    ref_sk = skel(ref_clean)
    problems, pos = [], 0
    checked = 0
    for e in db['entries']:
        pieces = [e['text']] + ([e['countText']] if e.get('countText') else []) + ([e['afterNote']] if e.get('afterNote') else [])
        for p in pieces:
            k = skel(drop_expansions(p))
            if len(k) < 3: continue
            i = ref_sk.find(k, max(0, pos - 5000))
            if i < 0:
                problems.append(('نص غير موجود في المرجع', e['id'], p[:60]))
            else:
                pos = max(pos, i)
                checked += 1
    # الحواشي: مستقلة الترتيب؛ تُطابَق على الكتلة الكاملة للمرجع
    fn_checked = 0
    all_fn = [f for e in db['entries'] for f in e['footnotes']] + db['preface']['footnotes']
    for f in all_fn:
        k = skel(drop_expansions(f['text']))
        if len(k) >= 3 and k in ref_sk: fn_checked += 1
        else: problems.append(('حاشية غير موجودة في المرجع', f['n'], f['text'][:60]))
    # العناوين
    t_checked = 0
    for ch in db['chapters']:
        k = skel(drop_expansions(ch['title']))
        if k and k in ref_sk: t_checked += 1
        else: problems.append(('عنوان غير موجود', ch['no'], ch['title'][:60]))
    # أرقام الأذكار: 1..267 بلا فجوات
    nums = sorted({e['bookNo'] for e in db['entries'] if e['kind'] == 'DHIKR'})
    assert nums == list(range(1, 268)), 'ترقيم الأذكار غير متصل'
    print('نصوص مطابقة: %d | حواشٍ مطابقة: %d من %d | عناوين مطابقة: %d من %d' % (checked, fn_checked, len(all_fn), t_checked, len(db['chapters'])))
    print('مشكلات: %d' % len(problems))
    for p in problems[:40]: print('  ', p)
    sys.exit(1 if problems else 0)

if __name__ == '__main__':
    main()
