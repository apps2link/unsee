#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
استخراج «حصن المسلم» من ملف DOCX إلى قاعدة بيانات JSON منظمة.

المبدأ: الكتاب هو المرجع الوحيد. لا يُولَّد أي نص. كل تحويل على النص الأصلي مسجَّل في ملف التدقيق
(hisn_audit.json) ليكون قابلًا للمراجعة. الاستخدام:
    python3 extract_hisn.py ar_Hisn_Almuslim.docx out_dir
"""
import json, re, sys, zipfile, os, collections
from lxml import etree

W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
def q(t): return '{%s}%s' % (W, t)

# ───────────── تحويلات موثَّقة لرموز الخط الخاصة ─────────────
# 1) رموز w:sym من خط AGA Arabesque (مضمَّن في الملف؛ جرى رسم حروفه والتحقق منها بصريًا).
SYM_MAP = {
    ('AGA Arabesque', 'F049'): 'سبحانه وتعالى',
    ('AGA Arabesque', 'F072'): 'صلى الله عليه وسلم',
    ('AGA Arabesque', 'F074'): 'رضي الله عنه',
}
# 2) محارف خط AAAGoldenLotus (غير مضمَّن في الملف) — تُحوَّل حسب السياق وتُسجَّل للمراجعة.
GLYPH_CHARS = {
    '\u00d7': 'صلى الله عليه وسلم',   # ×
    '\u2019': 'رضي الله عنها',        # ’  (عائشة ’)
    '\u2018': 'رحمه الله',            # ‘  (ابن باز ‘)
    '^':      'رضي الله عنهما',      # ^  (صحابي وأبوه / صحابيان)
}
EXPECTED_CONTEXT = {  # كلمة مفتاحية يجب أن تسبق الرمز مباشرة، وإلا يتوقف الاستخراج لمراجعة بشرية
    '\u00d7': ('كان', 'قال', 'الرسول', 'النبي', 'أنه', 'أنَّه'),
    '\u2019': ('عائشة', 'فاطمة'),
    '\u2018': ('باز',),
    '^': ('عمر', 'الحسين', 'الزبير', 'عمرو', 'وَالحُسَينَ'),
}
# 3) البسملة بخط QCF_BSML (غير مضمَّن): ثلاثة محارف ﭑ ﭒ ﭓ — تسبق دائمًا سور الإخلاص والفلق والناس.
BASMALA_GLYPHS = '\ufb51 \ufb52\ufb53'
BASMALA_TEXT = 'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ'
# 4) حروف مقطّعة بخط خاص: «الـ%ـم%» ← «الٓمٓ»
MUQATTAAT = ('الـ%ـم%', 'الٓمٓ')

TATWEEL = '\u0640'
audit = {'sym': collections.Counter(), 'glyph': [], 'basmala': 0, 'muqattaat': 0, 'notes': []}

def ptext(p, doc_footnote_marks=True):
    out = []
    for el in p.iter():
        if el.tag == q('t'): out.append(el.text or '')
        elif el.tag in (q('br'), q('cr')): out.append(' ')
        elif el.tag == q('tab'): out.append(' ')
        elif el.tag == q('footnoteReference') and doc_footnote_marks:
            out.append('{{fn:%s}}' % el.get(q('id')))
        elif el.tag == q('sym'):
            key = (el.get(q('font')), (el.get(q('char')) or '').upper())
            if key not in SYM_MAP:
                raise SystemExit('رمز غير معروف %r — يلزم تحقق بشري' % (key,))
            audit['sym'][key[1]] += 1
            out.append(SYM_MAP[key])
    return ''.join(out)

def _sd(s):
    return re.sub(r'[\u064B-\u065F\u0670\u0640]', '', s)

def fix_glyphs(t, where):
    t, nb = re.subn(r'\ufb51\s*\ufb52\s*\ufb53', BASMALA_TEXT, t)
    audit['basmala'] += nb
    if MUQATTAAT[0] in t:
        audit['muqattaat'] += t.count(MUQATTAAT[0])
        t = t.replace(*MUQATTAAT)
    for ch, rep in GLYPH_CHARS.items():
        while ch in t:
            i = t.index(ch)
            before = t[max(0, i - 40):i]
            ok = any(_sd(k) in _sd(before) for k in EXPECTED_CONTEXT[ch])
            audit['glyph'].append({'where': where, 'char': ch, 'to': rep, 'context': before[-30:], 'expected_ok': ok})
            if not ok:
                raise SystemExit('سياق غير متوقع للرمز %r في %s: %r' % (ch, where, before))
            t = t[:i].rstrip(' ') + ' ' + rep + t[i + 1:]
    return t

def norm_ws(t):
    return re.sub(r'\s+', ' ', t).strip()

# ───────────── التصنيف حسب أبواب الكتاب ─────────────
# كل باب (1..132) يُنسب إلى قسم واحد. MORNING_EVENING خاص بالباب 27 ويُفرَّع بالتطبيق.
CATEGORY_BY_CHAPTER = {}
def _set(cat, *rng):
    for r in rng:
        if isinstance(r, tuple):
            for n in range(r[0], r[1] + 1): CATEGORY_BY_CHAPTER[n] = cat
        else: CATEGORY_BY_CHAPTER[r] = cat
_set('SLEEP_WAKE', 1, (28, 31))
_set('CLEAN', (2, 9))
_set('HOME', 10, 11)
_set('ENTER_EXIT', (12, 14))
_set('PRAYER', (15, 24), 26, 32)
_set('AFTER_PRAYER', 25, 33)
_set('MORNING_EVENING', 27)
_set('DUAS', (34, 46), 88, 92, 94)
_set('FAMILY', 47, 48, (79, 81))
_set('HEALTH', (49, 60), 124)
_set('NATURE', (61, 67))
_set('FOOD', (68, 76))
_set('SOCIAL', 77, 78, 82, 83, (84, 87), (89, 91), 93, (108, 114))
_set('TRAVEL', (95, 105))
_set('HAJJ', (115, 121))
_set('MISC', 106, 107, (122, 123), 125, 126, 127, 128, (129, 132))

# ───────────── أعداد التكرار الصريحة في الكتاب ─────────────
def strip_diac(s):
    """تطبيع للمطابقة فقط (حذف التشكيل وتوحيد الهمزات والتاء المربوطة) — لا يُطبَّق على النص المخزَّن."""
    s = re.sub(r'[\u064B-\u065F\u0670\u0640]', '', s)
    s = re.sub('[أإآٱ]', 'ا', s)
    return s.replace('ة', 'ه').replace('ى', 'ي')

COUNT_WORDS = [  # (نمط على النص بلا تشكيل، العدد)
    (r'مائ[هة]|مئ[هة]', 100), (r'عشر', 10), (r'سبع', 7), (r'اربع', 4), (r'ثلاث', 3),
    (r'مره واحده|مرة واحدة', 1), (r'مرتين', 2),
]
def parse_count(count_text):
    if not count_text: return 0, None
    s = strip_diac(count_text)
    n = 0
    for pat, v in COUNT_WORDS:
        if re.search(pat, s): n = v; break
    when = None
    if 'اذا اصبح' in s: when = 'MORNING'
    elif 'اذا امسي' in s: when = 'EVENING'
    return n, when

COUNT_HINT = re.compile(r'(مره|مرات|مرتين|ثلاث|اربع|خمس|سبع|عشر|مائه|مئه|اذا اصبح|اذا امسي|في اليوم)')

def parse(docx_path):
    z = zipfile.ZipFile(docx_path)
    doc = etree.fromstring(z.read('word/document.xml'))
    fnx = etree.fromstring(z.read('word/footnotes.xml'))
    paras = [ptext(p) for p in doc.iter(q('p'))]
    fns = {}
    for f in fnx.findall(q('footnote')):
        i = f.get(q('id'))
        if int(i) < 2: continue
        t = norm_ws(' '.join(ptext(p, False) for p in f.iter(q('p'))))
        t = re.sub(r'^\(\)\s*', '', t)
        fns[int(i)] = fix_glyphs(t, 'footnote %s' % i)
    return paras, fns

def split_footnotes(s):
    """يفصل علامات الحواشي عن النص ويعيد (النص النظيف، قائمة أرقام الحواشي بالترتيب).
    علامة الحاشية في الأصل مطبوعة بين قوسين «(١)»، فيُحذف القوسان معها لا العلامة وحدها."""
    ids = [int(x) for x in re.findall(r'\{\{fn:(\d+)\}\}', s)]
    s = re.sub(r'\(\s*\{\{fn:\d+\}\}\s*\)', '', s)
    s = re.sub(r'\{\{fn:\d+\}\}', '', s)
    return s, ids

HEAD_TATWEEL = re.compile(r'^\s*(\d+)\s*ـ\s*(.+)$', re.S)
HEAD_DASH = re.compile(r'^\s*(\d+)\s*[–-]\s*([^\s(].*)$', re.S)
ITEM = re.compile(r'^\s*(\d+)\s*-\s*(?:\((\d+)\))?\s*(.*)$', re.S)
SUBITEM = re.compile(r'^\s*\((\d+)\)\s*(.*)$', re.S)

def build(paras, fns):
    first_fadl = next(i for i, p in enumerate(paras) if 'فَاذْكُرُونِي أَذْكُرْكُمْ' in p)
    start = first_fadl - 1
    while not paras[start].strip(): start -= 1
    end = next(i for i, p in enumerate(paras) if p.strip() == 'الفهرس')
    chapters, entries = [], []
    cur_ch = None
    next_ch, next_item = 1, 1
    last_book_no = None
    used_fn = []
    sub_counter = collections.Counter()

    def add_entry(kind, bookNo, seq, raw):
        nonlocal last_book_no
        body, ids = split_footnotes(raw)
        used_fn.extend(ids)
        e = {'kind': kind, 'bookNo': bookNo, 'chapterNo': cur_ch['no'], 'seq': seq, '_raw': body, '_fn': ids}
        entries.append(e)
        return e

    # باب «فضل الذكر» (قبل الباب 1): فقرات تُحفظ كما هي
    cur_ch = {'no': 0, 'title': 'فضل الذكر', 'titleRaw': norm_ws(paras[start]), 'category': 'FADL'}
    chapters.append(cur_ch)
    i = start + 1
    while i < end:
        s = paras[i].strip()
        if not s: i += 1; continue
        m = HEAD_TATWEEL.match(s)
        mdash = HEAD_DASH.match(s)
        if (m and int(m.group(1)) == next_ch) or (mdash and int(mdash.group(1)) == next_ch and not ITEM.match(s.replace(' -', '-', 1)) ) or \
           (mdash and int(mdash.group(1)) == next_ch and int(mdash.group(1)) != next_item and not re.match(r'^\s*\d+\s*-\s*\(', s)):
            mm = m or mdash
            raw_title = norm_ws(mm.group(2))
            title = norm_ws(raw_title.replace(TATWEEL, ''))
            cur_ch = {'no': next_ch, 'title': title, 'titleRaw': raw_title, 'category': CATEGORY_BY_CHAPTER[next_ch]}
            chapters.append(cur_ch); next_ch += 1; i += 1; continue
        mi = ITEM.match(s)
        if mi and int(mi.group(1)) in (next_item,) :
            no = int(mi.group(1)); seq = int(mi.group(2)) if mi.group(2) else None
            add_entry('DHIKR', no, seq, mi.group(3)); last_book_no = no; next_item = no + 1; i += 1; continue
        ms = SUBITEM.match(s)
        if ms and cur_ch['no'] > 0 and last_book_no is not None:
            add_entry('DHIKR', last_book_no, int(ms.group(1)), ms.group(2)); i += 1; continue
        # فقرة غير مرقّمة
        if cur_ch['no'] == 0:
            add_entry('FADL', None, None, s); i += 1; continue
        # إضافة/بدل (تبدأ بقوس مربع أو «وإن قال» ...) أو ملاحظة
        if s.startswith('((') or s.startswith('وإن قال') or s.startswith('وَإِنْ قَالَ'):
            add_entry('ADDITION', last_book_no, None, s)
        else:
            add_entry('NOTE', last_book_no if entries and entries[-1]['chapterNo'] == cur_ch['no'] else None, None, s)
        i += 1
    assert next_ch == 133, 'عدد الأبواب غير متوقع: %d' % (next_ch - 1)
    assert next_item == 268, 'عدد الأذكار غير متوقع: %d' % (next_item - 1)
    return chapters, entries, used_fn

# أعداد مطبوعة داخل نص الذكر نفسه بين قوسين في آخره (روجعت يدويًا). كل مدخل: معرّف → (عبارة العدد كما في الكتاب).
# أما العبارات الداخلية في أذكار مركّبة (مثل «ثلاثًا وثلاثين» في تسبيح ما بعد الصلاة) فتبقى في النص ولا يُختزل عدد الذكر إلى رقم واحد.
COUNT_FROM_TEXT_END = {'h76': 'ثلاث مرات'}

TAIL_RE = re.compile(r'\)\)\s*(.*)$', re.S)

def finish_entry(e, fns, chapter_titles):
    raw = norm_ws(e.pop('_raw')); ids = e.pop('_fn')
    raw = fix_glyphs(raw, 'entry %s/%s' % (e['bookNo'], e['seq']))
    e['footnotes'] = [{'n': n, 'text': fns[n]} for n in ids]
    text, count_text, after = raw, None, None
    if e['kind'] in ('DHIKR', 'ADDITION') and raw.startswith('(('):
        k = raw.rfind('))')
        main, tail = raw[2:k], raw[k + 2:]
        if main.count('(') == main.count(')') and main.count('[') == main.count(']'):
            text = main.strip()
            tail = tail.strip().lstrip('.').strip()
            # العدد الصريح: قوس أول الذيل فيه لفظ عدد، أو عبارة عدد مباشرة بعد القوسين («ثلاث مرات»)
            mt = re.match(r'^\(([^()]*)\)', tail)
            if mt and COUNT_HINT.search(strip_diac(mt.group(1))):
                count_text = norm_ws(mt.group(1)); tail = tail[mt.end():].strip()
            elif COUNT_HINT.search(strip_diac(tail[:60])) and re.match(r'^(ثلاث|اربع|سبع|عشر|مائه|مئه|مره|مرتين)', strip_diac(tail)):
                mb = re.match(r'^[^،؛.]+', tail)
                count_text = norm_ws(mb.group(0)); tail = tail[mb.end():].strip()
            tail = tail.strip(' .')
            after = tail or None
        else:
            text = raw   # أقواس غير متوازنة في الأصل: نبقي النص بحرفه ونعلّم للمراجعة
            audit['notes'].append('أقواس غير متوازنة في الذكر %s — بقي النص كما هو' % e['bookNo'])
    for key, phrase in COUNT_FROM_TEXT_END.items():
        pass
    e['text'] = text
    e['countText'] = count_text
    n, when = parse_count(count_text)
    e['count'] = n
    e['countWhen'] = when
    e['afterNote'] = after
    ph = COUNT_FROM_TEXT_END.get(e.get('_id'))
    if ph:
        m_end = re.search(r'\(([^()]*)\)\s*\.?\s*$', e['text'])
        if m_end and strip_diac(m_end.group(1)).strip() == strip_diac(ph).strip():
            e['countText'] = norm_ws(m_end.group(1))
            e['text'] = e['text'][:m_end.start()].rstrip()
            e['count'], e['countWhen'] = parse_count(e['countText'])
            audit['notes'].append('الذكر %s: نُقل «(%s)» من آخر النص إلى حقل العدد' % (e['_id'], e['countText']))
        else:
            raise SystemExit('تعذّر تطبيق تجاوز العدد للذكر %s' % e['_id'])
    return e

def main():
    src, outdir = sys.argv[1], sys.argv[2]
    os.makedirs(outdir, exist_ok=True)
    paras, fns = parse(src)
    chapters, entries, used_fn = build(paras, fns)
    # معرّفات
    seen = collections.Counter(); nid = collections.Counter()
    for e in entries:
        if e['kind'] in ('DHIKR', 'ADDITION') and e['bookNo'] is not None:
            seen[e['bookNo']] += 1
            e['_id'] = 'h%d' % e['bookNo'] if seen[e['bookNo']] == 1 else 'h%d_%d' % (e['bookNo'], seen[e['bookNo']])
        finish_entry(e, fns, None)
        if e['kind'] in ('DHIKR', 'ADDITION') and e['bookNo'] is not None:
            e['id'] = e['_id']
        else:
            nid[e['chapterNo']] += 1
            e['id'] = ('f%d' if e['kind'] == 'FADL' else 'n%d_') % e['chapterNo'] + ('' if e['kind']=='FADL' else str(nid[e['chapterNo']]))
            if e['kind'] == 'FADL': e['id'] = 'f%d' % nid[e['chapterNo']]
    # مقدمة المؤلف (قبل «فضل الذكر»): تُحفظ حرفيًا مع حاشيتها
    p0 = next(i for i, p in enumerate(paras) if p.strip() == 'المقدمة')
    p1 = next(i for i, p in enumerate(paras) if 'فَاذْكُرُونِي أَذْكُرْكُمْ' in p) - 1
    pre_pars, pre_fn = [], []
    for p in paras[p0 + 1:p1]:
        t = norm_ws(p)
        if not t or t in ('المؤلف',) or t.startswith('حرر في'): continue
        body, ids = split_footnotes(t)
        pre_fn += ids; used_fn.extend(ids)
        pre_pars.append(fix_glyphs(norm_ws(body), 'preface'))
    preface = {'paragraphs': pre_pars, 'footnotes': [{'n': n, 'text': fns[n]} for n in pre_fn]}
    # فحوص بنيوية
    assert sorted(used_fn) == list(range(2, 316)), 'الحواشي غير مستخدمة مرة واحدة بالضبط'
    ids = [e['id'] for e in entries]
    assert len(ids) == len(set(ids)), 'معرّفات مكررة'
    out = {
        'meta': {
            'title': 'حصن المسلم من أذكار الكتاب والسنة',
            'author': 'د. سعيد بن علي بن وهف القحطاني',
            'sourceFile': os.path.basename(src),
            'chapters': len(chapters) - 1, 'dhikrNumbers': 267,
            'entries': len(entries), 'footnotes': len(fns),
            'schema': 1,
        },
        'preface': preface,
        'chapters': chapters,
        'entries': [{k: e[k] for k in ('id', 'kind', 'bookNo', 'chapterNo', 'seq', 'text', 'count', 'countText', 'countWhen', 'afterNote', 'footnotes')} for e in entries],
    }
    json.dump(out, open(os.path.join(outdir, 'hisn_almuslim.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    audit['sym'] = dict(audit['sym'])
    json.dump(audit, open(os.path.join(outdir, 'hisn_audit.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('chapters', len(chapters) - 1, 'entries', len(entries), 'footnotes', len(fns))
    print(collections.Counter(e['kind'] for e in entries))

if __name__ == '__main__':
    main()
