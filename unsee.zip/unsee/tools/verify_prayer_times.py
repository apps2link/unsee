# Independent Python port of PrayerTimes.kt (same formulas) used to sanity check results.
import math, datetime as dt
from zoneinfo import ZoneInfo
def rad(d): return math.radians(d)
dsin=lambda d: math.sin(rad(d)); dcos=lambda d: math.cos(rad(d)); dtan=lambda d: math.tan(rad(d))
darcsin=lambda x: math.degrees(math.asin(x)); darccos=lambda x: math.degrees(math.acos(x))
darctan2=lambda y,x: math.degrees(math.atan2(y,x)); darccot=lambda x: math.degrees(math.atan(1.0/x))
fixA=lambda a: a-360.0*math.floor(a/360.0); fixH=lambda h: h-24.0*math.floor(h/24.0)
def julian(y,m,d):
    if m<=2: y-=1; m+=12
    a=math.floor(y/100.0); b=2-a+math.floor(a/4.0)
    return math.floor(365.25*(y+4716))+math.floor(30.6001*(m+1))+d+b-1524.5
def sunpos(jd):
    D=jd-2451545.0; g=fixA(357.529+0.98560028*D); q=fixA(280.459+0.98564736*D)
    L=fixA(q+1.915*dsin(g)+0.020*dsin(2*g)); e=23.439-0.00000036*D
    ra=fixH(darctan2(dcos(e)*dsin(L),dcos(L))/15.0)
    return darcsin(dsin(e)*dsin(L)), q/15.0-ra
def compute(date,lat,lng,fajrA,ishaA,ishaMin,asrF,zone):
    jd=julian(date.year,date.month,date.day)-lng/(15.0*24.0)
    mid=lambda t: fixH(12.0-sunpos(jd+t)[1])
    def ang(angle,t,ccw):
        decl=sunpos(jd+t)[0]; noon=mid(t)
        x=(-dsin(angle)-dsin(decl)*dsin(lat))/(dcos(decl)*dcos(lat))
        if x<-1 or x>1: return float('nan')
        v=darccos(x)/15.0
        return noon+(-v if ccw else v)
    def asr(f,t):
        decl=sunpos(jd+t)[0]; a=-darccot(f+dtan(abs(lat-decl))); return ang(a,t,False)
    f,sr,dh,a,ss,m,i=5/24,6/24,12/24,13/24,18/24,18/24,18/24
    for _ in range(2):
        H=dict(fajr=ang(fajrA,f,True),sunrise=ang(0.833,sr,True),dhuhr=mid(dh),asr=asr(asrF,a),
               sunset=ang(0.833,ss,False),maghrib=ang(0.833,m,False),
               isha=float('nan') if ishaMin>0 else ang(ishaA,i,False))
        nn=lambda k,cur: cur if math.isnan(H[k]) else H[k]/24
        f=nn('fajr',f); sr=nn('sunrise',sr); dh=H['dhuhr']/24; a=nn('asr',a); ss=nn('sunset',ss); m=nn('maghrib',m); i=nn('isha',i)
    shift=-lng/15.0
    if ishaMin>0: H['isha']=H['maghrib']+ishaMin/60.0
    out={}
    for k in('fajr','sunrise','dhuhr','asr','maghrib','isha'):
        h=H[k]+shift
        if math.isnan(h): out[k]=None; continue
        secs=round(h*60.0)*60
        out[k]=(dt.datetime(date.year,date.month,date.day,tzinfo=dt.timezone.utc)+dt.timedelta(seconds=secs)).astimezone(ZoneInfo(zone))
    return out
def show(label,date,lat,lng,zone,method='EGYPT',asr=1.0):
    P={'EGYPT':(19.5,17.5,0),'MWL':(18,17,0),'UMM':(18.5,0,90),'KARACHI':(18,18,0),'ISNA':(15,15,0)}[method]
    r=compute(date,lat,lng,P[0],P[1],P[2],asr,zone)
    print(label,date,method,' '.join(f"{k}={v.strftime('%H:%M') if v else None}" for k,v in r.items()))
    return r
if __name__=='__main__':
    C=(30.0444,31.2357,'Africa/Cairo')
    show('Cairo',dt.date(2026,6,21),*C)
    show('Cairo',dt.date(2026,12,21),*C)
    show('Cairo',dt.date(2026,3,20),*C)
    show('Cairo',dt.date(2026,10,29),*C)
    show('Cairo',dt.date(2026,10,30),*C)
    show('Minya',dt.date(2026,10,29),28.1099,30.7503,'Africa/Cairo')
    show('Makkah',dt.date(2026,6,21),21.3891,39.8579,'Asia/Riyadh','UMM')
    show('Makkah',dt.date(2026,12,21),21.3891,39.8579,'Asia/Riyadh','UMM')
    show('London',dt.date(2026,6,21),51.5072,-0.1276,'Europe/London','MWL')
    show('Tokyo',dt.date(2026,3,20),35.68,139.69,'Asia/Tokyo','MWL')
